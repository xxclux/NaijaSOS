/* global RTCPeerConnection */
/**
 * Minimal WebRTC signalling client.
 * ---------------------------------------------------------------------------
 * Citizen = producer. Command centre / responder = viewer.
 *
 * The viewer asks the server for a stream; the server relays that request to
 * everyone in the incident room. The citizen creates one peer connection per
 * viewer (so a dispatcher and an ambulance crew can watch simultaneously), and
 * SDP/ICE is relayed peer-to-peer by Socket.IO. Media never touches the server,
 * which is the correct architecture for privacy and bandwidth.
 *
 * In production add a TURN server (coturn) for restrictive carrier NATs, and
 * record to object storage only with explicit consent.
 */
(() => {
  const ICE = {
    iceServers: [
      { urls: 'stun:stun.l.google.com:19302' },
      { urls: 'stun:global.stun.twilio.com:3478' }
    ],
    iceCandidatePoolSize: 4
  };

  function serialiseCandidate(candidate) {
    try { return candidate.toJSON(); } catch { return candidate; }
  }

  function createProducer({ socket, incidentId, onState, onViewerCount, onRemoteStream }) {
    let stream = null;
    const peers = new Map();

    function closePeer(viewerId) {
      const entry = peers.get(viewerId);
      if (!entry) return;
      try { entry.pc.close(); } catch { /* already closed */ }
      peers.delete(viewerId);
      onViewerCount?.(peers.size);
      if (!peers.size) onState?.('ready');
    }

    async function handleRequest({ viewerSocketId, incidentId: requestedIncident }) {
      if (!stream || !viewerSocketId) return;
      if (requestedIncident && String(requestedIncident) !== String(incidentId)) return;
      closePeer(viewerSocketId);
      const pc = new RTCPeerConnection(ICE);
      peers.set(viewerSocketId, { pc, pending: [] });
      onViewerCount?.(peers.size);
      stream.getTracks().forEach((track) => pc.addTrack(track, stream));
      // The State EOC can speak back to the caller: the viewer renegotiates and
      // adds its microphone track. Play whatever it sends through the callback.
      pc.ontrack = (event) => {
        const remote = event.streams?.[0] || new MediaStream([event.track]);
        onRemoteStream?.(remote, viewerSocketId);
      };
      pc.onicecandidate = (event) => {
        if (!event.candidate) return;
        socket.emit('webrtc:ice', {
          target: viewerSocketId,
          incidentId,
          candidate: serialiseCandidate(event.candidate)
        });
      };
      pc.onconnectionstatechange = () => {
        if (['failed', 'disconnected', 'closed'].includes(pc.connectionState)) closePeer(viewerSocketId);
      };
      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        socket.emit('webrtc:offer', { target: viewerSocketId, incidentId, sdp: pc.localDescription });
        onState?.('live');
      } catch (error) {
        console.error('[webrtc] offer failed', error);
        closePeer(viewerSocketId);
      }
    }

    // A viewer (State EOC agent) may add a microphone track after the call is
    // already live. It sends a renegotiation offer; the citizen answers it.
    // A producer only ever *receives* offers from viewers — its own initial
    // offer goes the other way — so any offer for a known peer is treated as a
    // renegotiation.
    const onRenegotiateOffer = async ({ from, incidentId: incoming, sdp }) => {
      if (incoming && String(incoming) !== String(incidentId)) return;
      const entry = peers.get(from);
      if (!entry || !sdp) return;
      try {
        await entry.pc.setRemoteDescription(sdp);
        for (const candidate of entry.pending.splice(0)) {
          await entry.pc.addIceCandidate(candidate).catch(() => {});
        }
        const answer = await entry.pc.createAnswer();
        await entry.pc.setLocalDescription(answer);
        socket.emit('webrtc:answer', { target: from, incidentId, sdp: entry.pc.localDescription });
      } catch (error) {
        console.error('[webrtc] renegotiation failed', error);
      }
    };

    const onAnswer = async ({ from, sdp }) => {
      const entry = peers.get(from);
      if (!entry) return;
      try {
        await entry.pc.setRemoteDescription(sdp);
        for (const candidate of entry.pending.splice(0)) {
          await entry.pc.addIceCandidate(candidate).catch(() => {});
        }
      } catch (error) { console.error('[webrtc] answer failed', error); }
    };
    const onIce = async ({ from, candidate }) => {
      const entry = peers.get(from);
      if (!entry || !candidate) return;
      if (entry.pc.remoteDescription) {
        await entry.pc.addIceCandidate(candidate).catch(() => {});
      } else {
        entry.pending.push(candidate);
      }
    };
    const onEnd = ({ from }) => { if (from) closePeer(from); };

    socket.on('webrtc:request', handleRequest);
    socket.on('webrtc:offer', onRenegotiateOffer);
    socket.on('webrtc:answer', onAnswer);
    socket.on('webrtc:ice', onIce);
    socket.on('webrtc:end', onEnd);

    return {
      setStream(newStream) {
        stream = newStream;
        if (stream) onState?.('live');
      },
      get stream() { return stream; },
      get viewerCount() { return peers.size; },
      closeAll() {
        [...peers.keys()].forEach(closePeer);
        stream = null;
      },
      // Remove signalling listeners so a stopped producer cannot answer late
      // requests from viewers after the feed has been switched off.
      destroy() {
        [...peers.keys()].forEach(closePeer);
        stream = null;
        socket.off('webrtc:request', handleRequest);
        socket.off('webrtc:offer', onRenegotiateOffer);
        socket.off('webrtc:answer', onAnswer);
        socket.off('webrtc:ice', onIce);
        socket.off('webrtc:end', onEnd);
      }
    };
  }

  function createViewer({ socket, incidentId, videoEl, onState, viewerName = 'Command centre' }) {
    let pc = null;
    let remoteId = null;
    let pending = [];
    let timer = null;
    let micStream = null;
    let micOfferSent = false;
    let micRetryTimer = null;

    function cleanup() {
      if (timer) clearTimeout(timer);
      timer = null;
      if (micRetryTimer) clearTimeout(micRetryTimer);
      micRetryTimer = null;
      try { pc?.close(); } catch { /* already closed */ }
      pc = null;
      pending = [];
      remoteId = null;
      micOfferSent = false;
      if (videoEl) videoEl.srcObject = null;
    }

    function addMicTracks(connection) {
      if (!connection || !micStream) return [];
      const existing = new Set(
        connection.getSenders()
          .map((sender) => sender.track?.id)
          .filter(Boolean)
      );
      const added = [];
      for (const track of micStream.getAudioTracks()) {
        if (existing.has(track.id)) continue;
        connection.addTrack(track, micStream);
        added.push(track);
      }
      return added;
    }

    async function renegotiate({ retries = 12 } = {}) {
      if (!pc || !remoteId || !micStream) return;
      if (!pc.currentRemoteDescription) {
        if (retries > 0) {
          if (micRetryTimer) clearTimeout(micRetryTimer);
          micRetryTimer = setTimeout(() => renegotiate({ retries: retries - 1 }), 350);
        }
        return;
      }
      if (pc.signalingState !== 'stable') {
        if (retries > 0) {
          if (micRetryTimer) clearTimeout(micRetryTimer);
          micRetryTimer = setTimeout(() => renegotiate({ retries: retries - 1 }), 350);
        }
        return;
      }
      try {
        const offer = await pc.createOffer();
        await pc.setLocalDescription(offer);
        micOfferSent = true;
        socket.emit('webrtc:offer', {
          target: remoteId, incidentId, renegotiate: true, sdp: pc.localDescription
        });
      } catch (error) {
        console.error('[webrtc] viewer renegotiation failed', error);
      }
    }

    async function handleOffer({ from, incidentId: incoming, sdp }) {
      if (incoming && String(incoming) !== String(incidentId)) return;
      cleanup();
      remoteId = from;
      pc = new RTCPeerConnection(ICE);
      onState?.('connecting');
      pc.ontrack = (event) => {
        if (videoEl) {
          videoEl.srcObject = event.streams[0];
          videoEl.play().catch(() => {
            // Autoplay can be blocked; the user requested the feed, so attempt
            // once more after a short interaction.
            onState?.('tap-to-play');
          });
        }
        onState?.('live');
      };
      pc.onicecandidate = (event) => {
        if (!event.candidate) return;
        socket.emit('webrtc:ice', {
          target: from, incidentId, candidate: serialiseCandidate(event.candidate)
        });
      };
      pc.onconnectionstatechange = () => {
        if (pc?.connectionState === 'connected') onState?.('live');
        if (['failed', 'disconnected'].includes(pc?.connectionState)) onState?.('lost');
      };
      try {
        await pc.setRemoteDescription(sdp);
        for (const candidate of pending.splice(0)) {
          await pc.addIceCandidate(candidate).catch(() => {});
        }
        // If the State EOC is already armed to speak, include the microphone
        // in the initial answer so no renegotiation is needed.
        addMicTracks(pc);
        const answer = await pc.createAnswer();
        await pc.setLocalDescription(answer);
        socket.emit('webrtc:answer', { target: from, incidentId, sdp: pc.localDescription });
      } catch (error) {
        console.error('[webrtc] viewer answer failed', error);
        onState?.('failed');
      }
    }

    const onAnswer = async ({ from, sdp }) => {
      if (!pc || from !== remoteId || !sdp) return;
      try {
        await pc.setRemoteDescription(sdp);
        for (const candidate of pending.splice(0)) {
          await pc.addIceCandidate(candidate).catch(() => {});
        }
      } catch (error) {
        console.error('[webrtc] viewer answer apply failed', error);
      }
    };
    const onIce = async ({ from, candidate }) => {
      if (!pc || from !== remoteId || !candidate) return;
      if (pc.remoteDescription) {
        await pc.addIceCandidate(candidate).catch(() => {});
      } else {
        pending.push(candidate);
      }
    };
    const onEnd = ({ from }) => {
      if (!from || from === remoteId) { cleanup(); onState?.('ended'); }
    };

    socket.on('webrtc:offer', handleOffer);
    socket.on('webrtc:answer', onAnswer);
    socket.on('webrtc:ice', onIce);
    socket.on('webrtc:end', onEnd);

    let stopped = false;

    function request() {
      if (stopped) return;
      if (typeof RTCPeerConnection === 'undefined') { onState?.('unsupported'); return; }
      onState?.('requesting');
      socket.emit('webrtc:request', { incidentId, viewerName });
      if (timer) clearTimeout(timer);
      timer = setTimeout(() => onState?.('waiting'), 7000);
    }

    function stop() {
      if (stopped) return;
      stopped = true;
      if (remoteId) socket.emit('webrtc:end', { target: remoteId, incidentId });
      cleanup();
      micStream = null;
      socket.off('webrtc:offer', handleOffer);
      socket.off('webrtc:answer', onAnswer);
      socket.off('webrtc:ice', onIce);
      socket.off('webrtc:end', onEnd);
      onState?.('ended');
    }

    return {
      request,
      stop,
      destroy: stop,
      /**
       * Attach the State EOC agent's microphone. If the call is already live,
       * renegotiate so the citizen starts receiving the agent's voice.
       */
      setMicStream(stream) {
        micStream = stream || null;
        if (!pc || !micStream) return;
        const added = addMicTracks(pc);
        if (added.length && pc.currentRemoteDescription) renegotiate();
      },
      get micStream() { return micStream; },
      get live() { return !!pc && pc.connectionState === 'connected'; }
    };
  }

  window.NaijaSOSWebRTC = { createProducer, createViewer };
})();
