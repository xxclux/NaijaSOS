/* global NaijaSOS, NaijaSOSWebRTC, L */
/**
 * Command centre controller.
 * ---------------------------------------------------------------------------
 * The dispatcher sees one operational picture:
 *   queue (priority-sorted) + live map + incident brief.
 *
 * Socket.IO keeps the queue, map and brief in sync. Candidate search is a
 * server call because ranking must use the same authoritative fleet state for
 * every dispatcher. Assignment is optimistic in the UI but guarded by the
 * server's transactional re-check.
 */
(() => {
  const S = window.NaijaSOS;
  const { socket, api, toast, esc, typeMeta, agencyMeta, incidentStatus, assignmentStatus } = S;
  const $ = (id) => document.getElementById(id);
  const $$ = S.$$;

  const AGENCY_ORDER = ['POLICE', 'MEDICAL', 'FIRE', 'ROAD_SAFETY', 'GENERAL'];
  const TYPE_TO_AGENCY = { medical: 'MEDICAL', police: 'POLICE', fire: 'FIRE', road_safety: 'ROAD_SAFETY', general: 'GENERAL' };
  const ACTIVE_ASSIGNMENT = ['alerting', 'accepted', 'en_route', 'on_scene', 'transporting'];
  let DISPATCHER = { name: 'NEMA operator', id: 'NEMA' };

  const state = {
    mode: null,
    account: null,
    incidents: new Map(),
    units: new Map(),
    agencies: [],
    stats: null,
    selectedId: null,
    detail: null,
    detailTab: 'notes',
    candidates: new Map(),
    candidatesLoading: new Set(),
    filter: 'all',
    search: '',
    soundOn: localStorage.getItem('naijasos.dispatchSound') !== '0',
    showFleet: true,
    showRoutes: true,
    fleetQuery: '',
    selectedUnitId: null,
    map: null,
    incidentLayer: null,
    unitLayer: null,
    routeLayer: null,
    incidentMarkers: new Map(),
    unitMarkers: new Map(),
    viewer: null,
    viewerIncidentId: null,
    callViewer: null,
    callMicStream: null,
    lastNewAt: 0,
    bootstrapped: false
  };

  // -------------------------------------------------------------------------
  // Small formatting helpers
  // -------------------------------------------------------------------------
  const typeOf = (incident) => typeMeta[incident?.type] || typeMeta.general;
  const priorityOf = (incident) => S.priorityMeta[incident?.priority] || S.priorityMeta[2];
  const statusOf = (incident) => incidentStatus[incident?.status] || incidentStatus.new;
  const pill = (color) => `style="border-color:${color}55;background:${color}18;color:${color}"`;

  function unitList() {
    return [...state.units.values()];
  }

  function agencyAvailability(code) {
    return unitList().filter((u) => u.agencyCode === code && u.status === 'available').length;
  }

  function agencyOnline(code) {
    return unitList().filter((u) => u.agencyCode === code && u.isOnline).length;
  }

  // Only the responsible State EOC (or Super Admin override) may dispatch.
  // NEMA is national oversight.
  function canDispatch() {
    return state.mode === 'state' || state.mode === 'superadmin';
  }

  function dispatchLockNote() {
    return 'Only the responsible State EOC can dispatch a first responder. NEMA is national oversight — the SOS is live on the state desk; the state dispatches. When a responder accepts, the state is notified.';
  }

  function unitMatchesQuery(unit, query) {
    const q = (query || '').trim().toLowerCase();
    if (!q) return true;
    return [
      unit.callSign, unit.vehicleType, unit.plateNumber, unit.station,
      unit.stateCode, unit.stateName, unit.agencyCode,
      agencyMeta[unit.agencyCode]?.label, agencyMeta[unit.agencyCode]?.short,
      unit.status, unit.responderKind, unit.linkedUsername
    ].filter(Boolean).join(' ').toLowerCase().includes(q);
  }

  function syncBadgeHtml(unit) {
    const label = S.unitSyncLabel ? S.unitSyncLabel(unit) : (unit?.isOnline ? 'ONLINE' : 'OFFLINE');
    const age = S.syncAgeText ? S.syncAgeText(unit) : '';
    if (!unit?.isLinked) return `<span class="badge badge-warn font-mono !text-[7px]">UNLINKED</span>`;
    if (label === 'SYNCING LIVE') return `<span class="badge badge-ok font-mono !text-[7px]"><span class="live-dot mr-1"></span>SYNCING LIVE · ${esc(age)}</span>`;
    if (label === 'ONLINE') return `<span class="badge badge-warn font-mono !text-[7px]">ONLINE · STALE GPS · ${esc(age)}</span>`;
    return `<span class="badge badge-muted font-mono !text-[7px]">OFFLINE · ${esc(age)}</span>`;
  }

  function activeAssignments(incident) {
    return incident?.activeAssignments || (incident?.assignments || []).filter((a) => ACTIVE_ASSIGNMENT.includes(a.status));
  }

  function summaryOf(detail) {
    const active = activeAssignments(detail);
    return {
      ...detail,
      unitCount: active.length,
      units: active.map((a) => a.callSign),
      agencyCodes: [...new Set(active.map((a) => a.agencyCode))],
      minimumEta: active.length ? Math.min(...active.map((a) => Number(a.etaMinutes) || 99)) : null
    };
  }

  function sortedIncidents() {
    return [...state.incidents.values()].sort((a, b) => {
      if (a.priority !== b.priority) return a.priority - b.priority;
      return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
    });
  }

  function filteredIncidents() {
    const query = state.search.trim().toLowerCase();
    return sortedIncidents().filter((incident) => {
      if (state.filter === 'p1' && incident.priority !== 1) return false;
      if (state.filter === 'unassigned' && (incident.unitCount || 0) > 0) return false;
      if (state.filter === 'mine' && (incident.unitCount || 0) === 0) return false;
      if (!query) return true;
      return [incident.code, incident.address, incident.landmark, incident.reporterName, incident.description, incident.type]
        .filter(Boolean).join(' ').toLowerCase().includes(query);
    });
  }

  function updateElapsedLabels() {
    const now = Date.now();
    $$('[data-live-since]').forEach((el) => {
      const iso = el.getAttribute('data-live-since');
      if (!iso) return;
      const seconds = Math.max(0, (now - new Date(iso).getTime()) / 1000);
      el.textContent = S.elapsed(seconds);
    });
  }

  // -------------------------------------------------------------------------
  // KPIs + queue
  // -------------------------------------------------------------------------
  function renderKpis() {
    const incidents = [...state.incidents.values()];
    const units = unitList();
    const stats = state.stats || {};
    const active = incidents.length;
    const critical = incidents.filter((i) => i.priority === 1).length;
    const unack = incidents.filter((i) => !i.acknowledgedAt || i.status === 'new').length;
    const available = units.filter((u) => u.status === 'available').length;
    const busy = units.filter((u) => ['dispatched', 'en_route', 'on_scene', 'transporting'].includes(u.status)).length;
    const onScene = units.filter((u) => u.status === 'on_scene').length;

    const online = units.filter((u) => u.isOnline).length;
    const fresh = units.filter((u) => u.isOnline && u.isGpsFresh).length;

    $('kpiActive').textContent = String(active).padStart(2, '0');
    $('kpiActiveSub').textContent = `${stats.openAssignments ?? busy} units committed`;
    $('kpiCritical').textContent = String(critical).padStart(2, '0');
    $('kpiCriticalSub').textContent = critical ? 'life-threatening calls' : 'no P1 calls open';
    $('kpiUnack').textContent = String(unack).padStart(2, '0');
    $('kpiUnackSub').textContent = unack ? 'needs dispatcher action' : 'queue triaged';
    $('kpiUnits').textContent = String(available).padStart(2, '0');
    $('kpiUnitsSub').textContent = `${fresh} syncing live · ${online} online · ${units.length} total`;
    const avg = Number(stats.avgResponseSeconds) || 0;
    $('kpiResponse').innerHTML = `${Math.floor(avg / 60)}<span class="text-[13px] text-dim">m</span> ${String(avg % 60).padStart(2, '0')}<span class="text-[13px] text-dim">s</span>`;
    $('kpiResolved').textContent = String(stats.resolvedToday ?? 0).padStart(2, '0');
    $('kpiResolvedSub').textContent = `${stats.unacknowledged ?? unack} awaiting acknowledgement`;

    $('sideAvailable') && ($('sideAvailable').textContent = String(available).padStart(2, '0'));
    $('sideBusy') && ($('sideBusy').textContent = String(busy).padStart(2, '0'));
    if ($('sideFleetCount')) $('sideFleetCount').textContent = units.length;
    $('mapIncidentCount') && ($('mapIncidentCount').textContent = active);
  }

  function renderQueue() {
    const list = filteredIncidents();
    const container = $('incidentQueue');
    const top = container.scrollTop;
    $('queueCount').textContent = `${list.length} live`;
    if (!list.length) {
      container.innerHTML = `<div class="flex flex-col items-center justify-center gap-2 px-5 py-12 text-center">
        <span class="material-symbols-outlined text-[30px] text-dim">inbox</span>
        <p class="text-[12px] font-bold text-text">No incidents in this view</p>
        <p class="max-w-[220px] text-[10px] leading-relaxed text-dim">${state.search ? 'Try a different search term.' : 'The queue is clear — new SOS alerts appear here instantly.'}</p>
      </div>`;
      return;
    }
    container.innerHTML = list.map((incident) => {
      const type = typeOf(incident);
      const priority = priorityOf(incident);
      const status = statusOf(incident);
      const selected = incident.id === state.selectedId;
      const units = incident.unitCount || 0;
      return `<button type="button" data-incident-id="${incident.id}" aria-pressed="${selected}"
        class="incident-card ${selected ? 'is-selected' : ''}" style="--type-color:${type.color}">
        <span class="absolute inset-y-0 left-0 w-[3px]" style="background:${type.color}"></span>
        <div class="flex items-start gap-2.5 pl-1">
          <span class="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border" style="border-color:${type.color}44;background:${type.color}14;color:${type.color}">
            <span class="material-symbols-outlined text-[17px]" style="font-variation-settings:'FILL' 1">${type.icon}</span>
          </span>
          <div class="min-w-0 flex-1">
            <div class="flex flex-wrap items-center gap-1.5">
              <span class="incident-card__code">${esc(incident.code)}</span>
              <span class="badge" ${pill(priority.color)}>${priority.short}</span>
              <span class="badge ml-auto" ${pill(status.color)}>${status.label}</span>
            </div>
            <p class="incident-card__address">${esc(incident.address || 'Location shared')}</p>
            <div class="incident-card__meta flex-wrap">
              <span class="material-symbols-outlined !text-[12px]">schedule</span>
              <span class="data" data-live-since="${incident.createdAt}">00:00</span>
              <span>·</span>
              <span class="flex items-center gap-1 ${units ? 'text-ok' : 'text-road'}">
                <span class="material-symbols-outlined !text-[12px]">${units ? 'local_taxi' : 'pending'}</span>
                ${units ? `${units} unit${units === 1 ? '' : 's'}` : 'unassigned'}
              </span>
              <span>·</span>
              <span>${esc(incident.reporterName || 'Anonymous')}</span>
            </div>
          </div>
        </div>
      </button>`;
    }).join('');
    container.scrollTop = top;
    updateElapsedLabels();
  }

  function setQueueFilter(filter) {
    state.filter = filter;
    $$('#queueFilters [data-filter]').forEach((button) => {
      button.classList.toggle('is-active', button.dataset.filter === filter);
    });
    renderQueue();
  }

  // -------------------------------------------------------------------------
  // Map
  // -------------------------------------------------------------------------
  function initMap() {
    state.map = S.initMap('dispatchMap', { center: S.LAGOS_CENTRE, zoom: 11.3 });
    if (!state.map) return;
    state.incidentLayer = L.layerGroup().addTo(state.map);
    state.unitLayer = L.layerGroup().addTo(state.map);
    state.routeLayer = L.layerGroup().addTo(state.map);
  }

  function ensureIncidentMarkers() {
    if (!state.map) return;
    const seen = new Set();
    for (const incident of state.incidents.values()) {
      seen.add(incident.id);
      const selected = incident.id === state.selectedId;
      let marker = state.incidentMarkers.get(incident.id);
      if (!marker) {
        marker = L.marker([incident.lat, incident.lng], {
          icon: S.incidentMarkerIcon(incident, selected),
          riseOnHover: true,
          zIndexOffset: selected ? 800 : 100
        });
        marker.bindTooltip(`${esc(incident.code)} · ${esc(incident.address || 'Location shared')}`, { direction: 'top', offset: [0, -18] });
        marker.on('click', () => selectIncident(incident.id));
        marker.addTo(state.incidentLayer);
        state.incidentMarkers.set(incident.id, marker);
      } else {
        marker.setLatLng([incident.lat, incident.lng]);
        marker.setIcon(S.incidentMarkerIcon(incident, selected));
        marker.setZIndexOffset(selected ? 800 : 100);
        if (marker.getTooltip()) marker.setTooltipContent(`${esc(incident.code)} · ${esc(incident.address || 'Location shared')}`);
      }
    }
    for (const [id, marker] of state.incidentMarkers) {
      if (seen.has(id)) continue;
      state.incidentLayer.removeLayer(marker);
      state.incidentMarkers.delete(id);
    }
  }

  function renderUnitMarkers() {
    if (!state.map) return;
    const seen = new Set();
    for (const unit of state.units.values()) {
      if (!Number.isFinite(Number(unit.lat)) || !Number.isFinite(Number(unit.lng))) continue;
      // While a fleet search is active, dim the map to matching units only.
      const matchesSearch = unitMatchesQuery(unit, state.fleetQuery);
      if (!matchesSearch) {
        const existing = state.unitMarkers.get(unit.id);
        if (existing) state.unitLayer.removeLayer(existing);
        state.unitMarkers.delete(unit.id);
        continue;
      }
      seen.add(unit.id);
      const selected = state.selectedUnitId === unit.id;
      let marker = state.unitMarkers.get(unit.id);
      if (!marker) {
        marker = L.marker([unit.lat, unit.lng], {
          icon: S.unitMarkerIcon(unit, selected), zIndexOffset: -50
        });
        marker.bindTooltip('', { direction: 'top', offset: [0, -10] });
        const unitId = unit.id;
        marker._iconKey = `${unit.status}:${unit.agencyCode}:${unit.isOnline}:${unit.isGpsFresh}:${selected}`;
        marker.on('click', () => {
          const clicked = state.units.get(unitId);
          if (!clicked) return;
          state.selectedUnitId = unitId;
          renderFleetResults();
          const incident = state.incidents.get(clicked.activeIncidentId);
          if (incident) selectIncident(incident.id);
        });
        marker.addTo(state.unitLayer);
        state.unitMarkers.set(unit.id, marker);
      }
      marker.setLatLng([unit.lat, unit.lng]);
      const iconKey = `${unit.status}:${unit.agencyCode}:${unit.isOnline}:${unit.isGpsFresh}:${state.selectedUnitId === unit.id}`;
      if (marker._iconKey !== iconKey) {
        marker.setIcon(S.unitMarkerIcon(unit, state.selectedUnitId === unit.id));
        marker._iconKey = iconKey;
      }
      marker.setZIndexOffset(state.selectedUnitId === unit.id ? 900 : -50);
      const meta = agencyMeta[unit.agencyCode] || agencyMeta.GENERAL;
      const sync = S.unitSyncLabel ? S.unitSyncLabel(unit) : (unit.isOnline ? 'ONLINE' : 'OFFLINE');
      const age = S.syncAgeText ? S.syncAgeText(unit) : '';
      marker.setTooltipContent(`${esc(unit.callSign)} · ${esc(meta.short)} · ${esc(S.unitStatus[unit.status]?.label || unit.status)} · ${esc(sync)} (${esc(age)})`);
    }
    for (const [id, marker] of state.unitMarkers) {
      if (seen.has(id)) continue;
      state.unitLayer.removeLayer(marker);
      state.unitMarkers.delete(id);
    }
  }

  // -------------------------------------------------------------------------
  // Live fleet search & locate (ambulance / car in real time)
  // -------------------------------------------------------------------------
  function renderFleetResults() {
    const box = $('fleetResults');
    const hint = $('fleetSearchHint');
    const clearBtn = $('fleetSearchClear');
    if (!box) return;
    const query = state.fleetQuery || '';
    if (clearBtn) clearBtn.classList.toggle('hidden', !query);
    if (!query.trim()) {
      box.classList.add('hidden');
      if (hint) hint.classList.add('hidden');
      return;
    }
    const matches = unitList().filter((u) => unitMatchesQuery(u, query));
    if (hint) hint.classList.remove('hidden');
    if (!matches.length) {
      box.innerHTML = `<p class="px-2.5 py-3 text-center text-[11px] text-dim">No live unit matches “${esc(query)}”. Check the call sign or plate.</p>`;
      box.classList.remove('hidden');
      return;
    }
    matches.sort((a, b) => {
      // Online + fresh first, then call sign — most useful order for dispatch.
      const rank = (u) => (u.isOnline && u.isGpsFresh ? 0 : u.isOnline ? 1 : 2);
      return rank(a) - rank(b) || (a.callSign || '').localeCompare(b.callSign || '');
    });
    box.innerHTML = matches.map((unit) => {
      const meta = agencyMeta[unit.agencyCode] || agencyMeta.GENERAL;
      const selected = state.selectedUnitId === unit.id;
      return `<button type="button" data-locate-unit="${unit.id}"
        class="flex w-full items-center gap-2.5 rounded-lg px-2.5 py-2 text-left transition hover:bg-panel-2 ${selected ? 'bg-nema/10 ring-1 ring-nema/40' : ''}">
        <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border" style="border-color:${meta.color}55;background:${meta.color}18;color:${meta.color}">
          <span class="material-symbols-outlined text-[16px]">${meta.icon}</span>
        </span>
        <span class="min-w-0 flex-1">
          <span class="flex flex-wrap items-center gap-1.5">
            <span class="data text-[12px] font-bold text-text">${esc(unit.callSign)}</span>
            <span class="badge badge-muted font-mono">${esc(meta.short)}</span>
            ${syncBadgeHtml(unit)}
          </span>
          <span class="mt-0.5 block truncate text-[9px] text-dim">${esc(unit.vehicleType || '')} · ${esc(unit.station || '')} · ${esc(unit.stateCode || '')} · ${esc(S.unitStatus[unit.status]?.label || unit.status)}</span>
        </span>
        <span class="material-symbols-outlined shrink-0 text-[16px] text-dim">my_location</span>
      </button>`;
    }).join('');
    box.classList.remove('hidden');
  }

  function locateUnit(unitId, { fly = true } = {}) {
    const unit = state.units.get(unitId);
    if (!unit) return false;
    state.selectedUnitId = unitId;
    renderFleetResults();
    renderUnitMarkers();
    if (fly && Number.isFinite(Number(unit.lat)) && Number.isFinite(Number(unit.lng)) && state.map) {
      state.map.flyTo([unit.lat, unit.lng], Math.max(15, state.map.getZoom()), { duration: 0.65 });
      const marker = state.unitMarkers.get(unitId);
      setTimeout(() => marker?.openTooltip(), 680);
    }
    return true;
  }

  function locateFirstFleetMatch() {
    const query = state.fleetQuery || '';
    const matches = unitList().filter((u) => unitMatchesQuery(u, query));
    if (!matches.length) {
      toast('No live unit found', query ? `Nothing matches “${query}”.` : 'Type a call sign, plate, or station first.', 'info');
      return;
    }
    matches.sort((a, b) => {
      const rank = (u) => (u.isOnline && u.isGpsFresh ? 0 : u.isOnline ? 1 : 2);
      return rank(a) - rank(b) || (a.callSign || '').localeCompare(b.callSign || '');
    });
    locateUnit(matches[0].id, { fly: true });
  }

  function renderRoutes() {
    if (!state.map || !state.routeLayer) return;
    state.routeLayer.clearLayers();
    if (!state.showRoutes || !state.detail) return;
    for (const assignment of activeAssignments(state.detail)) {
      let points = S.escapeRoute(assignment.route);
      if (points.length < 2 && Number.isFinite(Number(assignment.unitLat))) {
        points = [[assignment.unitLat, assignment.unitLng], [state.detail.lat, state.detail.lng]];
      }
      if (points.length < 2) continue;
      L.polyline(points, {
        color: assignment.agencyColor || '#34d399',
        weight: 3.5,
        opacity: 0.82,
        lineCap: 'round',
        dashArray: assignment.status === 'alerting' ? '7 9' : null
      }).addTo(state.routeLayer);
    }
  }

  function flyToIncident(incident) {
    if (!state.map || !incident) return;
    state.map.flyTo([incident.lat, incident.lng], Math.max(13, state.map.getZoom()), { duration: 0.55 });
  }

  function fitAllIncidents() {
    if (!state.map) return;
    const points = sortedIncidents();
    if (!points.length) {
      state.map.setView(S.LAGOS_CENTRE, 11.3);
      return;
    }
    S.setMapView(state.map, points, { padding: [50, 50], maxZoom: 12.5 });
  }

  function refreshMapLayerVisibility() {
    if (!state.map) return;
    if (state.showFleet && !state.map.hasLayer(state.unitLayer)) state.unitLayer.addTo(state.map);
    if (!state.showFleet && state.map.hasLayer(state.unitLayer)) state.map.removeLayer(state.unitLayer);
    if (state.showRoutes && !state.map.hasLayer(state.routeLayer)) state.routeLayer.addTo(state.map);
    if (!state.showRoutes && state.map.hasLayer(state.routeLayer)) state.map.removeLayer(state.routeLayer);
    $('mapFleetToggle').classList.toggle('ring-1', state.showFleet);
    $('mapFleetToggle').classList.toggle('ring-alert/60', state.showFleet);
    $('mapFleetToggle').classList.toggle('text-alert-soft', state.showFleet);
    $('mapRoutesToggle').classList.toggle('ring-1', state.showRoutes);
    $('mapRoutesToggle').classList.toggle('ring-alert/60', state.showRoutes);
    $('mapRoutesToggle').classList.toggle('text-alert-soft', state.showRoutes);
  }

  function renderMapSelected() {
    const card = $('mapSelected');
    const incident = state.detail || state.incidents.get(state.selectedId);
    if (!incident) {
      card.classList.add('hidden');
      return;
    }
    card.classList.remove('hidden');
    const type = typeOf(incident);
    $('mapSelCode').textContent = incident.code;
    $('mapSelAddress').textContent = incident.address || 'Location shared';
    $('mapSelMeta').textContent = `${type.label} · ${incident.unitCount ?? activeAssignments(incident).length} units · ${statusOf(incident).label} · ${S.relativeTime(incident.createdAt)}`;
  }

  function refreshMapAll() {
    ensureIncidentMarkers();
    renderUnitMarkers();
    renderRoutes();
    renderMapSelected();
  }

  // -------------------------------------------------------------------------
  // Detail rendering
  // -------------------------------------------------------------------------
  function detailEmpty() {
    $('detailPanel').innerHTML = `<div class="flex flex-col items-center justify-center gap-3 px-6 py-16 text-center">
      <span class="radar"><span class="radar__sweep"></span><span class="radar__dot" style="left:64%;top:32%"></span><span class="radar__dot" style="left:32%;top:58%"></span></span>
      <p class="text-[14px] font-bold text-text">Select an incident</p>
      <p class="max-w-[250px] text-[11px] leading-relaxed text-muted">Choose a card from the live queue or click a map pin to open the operational brief.</p>
      <span class="badge badge-muted">Dispatch console ready</span>
    </div>`;
  }

  function detailLoading() {
    $('detailPanel').innerHTML = `<div class="space-y-3 p-4">
      <div class="skeleton h-6 w-2/3 rounded"></div>
      <div class="skeleton h-4 w-full rounded"></div>
      <div class="skeleton h-24 w-full rounded-xl"></div>
      <div class="skeleton h-36 w-full rounded-xl"></div>
      <div class="skeleton h-24 w-full rounded-xl"></div>
    </div>`;
  }

  function notesListHtml(incident) {
    const notes = incident.notes || [];
    if (!notes.length) {
      return `<p class="rounded-lg border border-dashed border-line px-3 py-4 text-center text-[10px] text-dim">No notes yet. Add operational context for the responding crew.</p>`;
    }
    return notes.map((note) => `<article class="rounded-lg border ${note.pinned ? 'border-road/30 bg-road/[0.04]' : 'border-line-soft bg-panel-2'} p-2.5">
      <div class="flex items-start gap-2">
        <span class="material-symbols-outlined mt-0.5 text-[14px] ${note.pinned ? 'text-road' : 'text-dim'}">${note.pinned ? 'push_pin' : 'sticky_note_2'}</span>
        <div class="min-w-0 flex-1">
          <p class="text-[11px] leading-relaxed text-text">${esc(note.body)}</p>
          <p class="mt-1 font-mono text-[8px] text-dim">${esc(note.authorName || 'Dispatcher')} · ${S.clockTime(note.createdAt)}${note.pinned ? ' · pinned' : ''}</p>
        </div>
      </div>
    </article>`).join('');
  }

  function chatListHtml(incident) {
    const messages = incident.messages || [];
    if (!messages.length) {
      return `<p class="text-[10px] text-dim">No messages yet. Send a safety instruction or request an update.</p>`;
    }
    return messages.map((message) => {
      const out = message.senderType === 'dispatcher' || message.senderType === 'responder';
      return `<div class="chat-bubble ${out ? 'chat-bubble--out' : ''}">
        <p class="chat-bubble__meta">${out ? 'Command' : esc(message.senderName || 'Citizen')} · ${S.clockTime(message.createdAt)}</p>
        <p>${esc(message.body)}</p>
      </div>`;
    }).join('');
  }

  function dispatchSectionHtml(incident) {
    const loading = state.candidatesLoading.has(incident.id);
    const results = state.candidates.get(incident.id) || {};
    const primary = TYPE_TO_AGENCY[incident.type] || 'MEDICAL';
    const primaryMeta = agencyMeta[primary] || agencyMeta.GENERAL;
    const allowed = canDispatch();
    // NEMA has no dispatch responsibility — show an oversight panel only.
    if (!allowed) {
      const stateLabel = esc(incident.stateName || incident.stateCode || 'The responsible state');
      return `<div class="panel-2 overflow-hidden" id="dispatchSection">
        <div class="flex items-center justify-between gap-2 border-b border-line-soft px-3 py-2.5">
          <div>
            <p class="panel-title !text-[10px]">Dispatch · State EOC owns this</p>
            <p class="mt-0.5 text-[8px] text-dim">${stateLabel} is dispatching — NEMA is national oversight</p>
          </div>
          <span class="badge badge-muted"><span class="material-symbols-outlined !text-[12px]">lock</span>State only</span>
        </div>
        <div class="space-y-2 p-2.5">
          <div class="rounded-xl border border-nema/30 bg-nema/[0.06] p-2.5">
            <p class="flex items-start gap-1.5 text-[9.5px] leading-relaxed text-muted"><span class="material-symbols-outlined !text-[15px] text-nema-soft">visibility</span><span>You can watch this SOS nationally. Dispatch controls live on the <strong class="text-text">${stateLabel} State EOC</strong> dashboard — the state assigns the nearest police / fire / road safety / ambulance. When the responder accepts, the state is notified.</span></p>
          </div>
          <p class="flex items-center justify-center gap-1 text-center font-mono text-[8px] text-dim">
            <span class="material-symbols-outlined !text-[11px]">route</span>
            NEMA triggered this SOS; the state dispatches
          </p>
        </div>
      </div>`;
    }
    const buttons = AGENCY_ORDER.map((code) => {
      const meta = agencyMeta[code];
      const free = agencyAvailability(code);
      const onlineCount = agencyOnline(code);
      const candidates = results[code]?.candidates || [];
      const top = candidates[0];
      const line = loading
        ? 'Scanning fleet…'
        : top
          ? `${esc(top.callSign)} · ${S.formatDistanceKm(top.distanceKm)} · ${S.formatEta(top.etaMinutes)}${top.isSameState === false ? ' · mutual aid' : ''}`
          : 'No available unit nearby';
      const disabled = loading || !top;
      return `<button type="button" data-action="candidates" data-agency="${code}" ${disabled ? 'disabled' : ''}
        class="group relative flex flex-col gap-1 rounded-xl border p-2.5 text-left transition ${disabled ? 'cursor-not-allowed opacity-55' : 'hover:-translate-y-0.5'}"
        style="border-color:${meta.color}33;background:${meta.color}0b">
        <span class="flex items-center justify-between gap-1.5">
          <span class="flex items-center gap-1.5 text-[10px] font-bold" style="color:${meta.color}">
            <span class="material-symbols-outlined !text-[15px]">${meta.icon}</span>${meta.short}
          </span>
          <span class="rounded border border-line bg-panel/60 px-1 py-0.5 font-mono text-[8px] text-dim">${free} free · ${onlineCount} online</span>
        </span>
        <span class="data block truncate text-[9.5px] ${top ? 'text-text' : 'text-dim'}">${line}</span>
      </button>`;
    }).join('');

    const nomCandidate = incident.nominatedCandidate
      || (results[primary]?.candidates?.[0])
      || (AGENCY_ORDER.map((c) => results[c]?.candidates?.[0]).filter(Boolean).sort((a, b) => (Number(a.distanceKm) || 0) - (Number(b.distanceKm) || 0))[0])
      || null;

    const nominationHtml = nomCandidate && !activeAssignments(incident).length ? `
      <div class="rounded-xl border border-nema/40 bg-nema/[0.08] p-3 space-y-2 mb-2.5">
        <div class="flex items-center justify-between gap-2 border-b border-nema/25 pb-2">
          <div class="flex items-center gap-2">
            <span class="flex h-8 w-8 items-center justify-center rounded-lg bg-nema/20 text-nema-soft">
              <span class="material-symbols-outlined text-[18px]">near_me</span>
            </span>
            <div>
              <p class="font-mono text-[8.5px] font-bold uppercase tracking-wider text-nema-soft">NEMA Nearest Proximity Assignment</p>
              <p class="text-[12px] font-bold text-text">${esc(nomCandidate.callSign)} · ${esc(nomCandidate.vehicleType || 'Vehicle')}</p>
            </div>
          </div>
          <span class="badge badge-warn font-mono text-[7.5px] animate-pulse">Awaiting EOC Dispatch</span>
        </div>

        <div class="grid grid-cols-3 gap-1.5 text-center font-mono">
          <div class="rounded-lg bg-panel/80 p-1.5 border border-line-soft">
            <p class="text-[7.5px] uppercase text-dim">Distance</p>
            <p class="text-[11px] font-bold text-text">${S.formatDistanceKm(nomCandidate.distanceKm)}</p>
          </div>
          <div class="rounded-lg bg-panel/80 p-1.5 border border-line-soft">
            <p class="text-[7.5px] uppercase text-dim">ETA</p>
            <p class="text-[11px] font-bold text-text">${S.formatEta(nomCandidate.etaMinutes)}</p>
          </div>
          <div class="rounded-lg bg-panel/80 p-1.5 border border-line-soft">
            <p class="text-[7.5px] uppercase text-dim">Terminal</p>
            <p class="text-[10px] font-bold text-[#f4c430]">Hytera MNC360</p>
          </div>
        </div>

        <p class="text-[9px] text-muted leading-relaxed">
          NEMA CAD identified this nearest proximity unit. Click below to alert the vehicle terminal with sirens and dispatch card.
        </p>

        <button type="button" data-action="dispatch-nominated" data-unit-id="${nomCandidate.id}" data-agency="${nomCandidate.agencyCode || primary}" class="btn btn-primary w-full py-2.5 text-[11.5px] font-bold shadow-lg shadow-nema/20">
          <span class="material-symbols-outlined text-[17px]">bolt</span>
          <span>DISPATCH ${esc(nomCandidate.callSign)} TO REAL EMERGENCY</span>
        </button>
      </div>` : '';

    return `<div class="panel-2 overflow-hidden" id="dispatchSection">
      <div class="flex items-center justify-between gap-2 border-b border-line-soft px-3 py-2.5">
        <div>
          <p class="panel-title !text-[10px]">State dispatch · nearest first</p>
          <p class="mt-0.5 text-[8px] text-dim">You own this dispatch — nearest available police / fire / road safety / ambulance to the citizen SOS · sorted by distance</p>
        </div>
        <button type="button" data-action="refresh-candidates" class="btn btn-quiet h-7 w-7 p-0" title="Refresh candidates" aria-label="Refresh candidates">
          <span class="material-symbols-outlined text-[16px]">refresh</span>
        </button>
      </div>
      <div class="p-2.5">${nominationHtml}<div class="grid grid-cols-2 gap-2">${buttons}</div></div>
      <div class="space-y-2 border-t border-line-soft p-2.5">
        <button type="button" data-action="auto-dispatch" class="btn btn-primary btn-sm w-full" ${loading ? 'disabled' : ''}>
          <span class="material-symbols-outlined text-[16px]">bolt</span>
          Dispatch nearest ${esc(primaryMeta.short)}
        </button>
        <button type="button" data-action="ai-dispatch" class="btn btn-ghost btn-sm w-full border-nema/40 text-nema-soft" ${loading ? 'disabled' : ''} title="Let the AI send the nearest unit automatically for the state">
          <span class="material-symbols-outlined text-[16px]">neurology</span>
          AI · auto-dispatch nearest for me
        </button>
        <p class="flex items-center justify-center gap-1 text-center font-mono text-[8px] text-dim">
          <span class="material-symbols-outlined !text-[11px]">route</span>
          National proximity ranking · nearest unit wins even across state lines
        </p>
      </div>
    </div>`;
  }

  function assignedSectionHtml(incident) {
    const active = activeAssignments(incident);
    return `<div class="panel-2 overflow-hidden" id="assignedSection">
      <div class="flex items-center justify-between gap-2 border-b border-line-soft px-3 py-2.5">
        <p class="panel-title !text-[10px]">Assigned units</p>
        <span class="badge ${active.length ? 'badge-ok' : 'badge-muted'}">${active.length} committed</span>
      </div>
      ${active.length ? active.map((assignment) => {
        const meta = agencyMeta[assignment.agencyCode] || agencyMeta.GENERAL;
        const status = assignmentStatus[assignment.status] || assignmentStatus.alerting;
        const progress = Math.round((Number(assignment.progress) || 0) * 100);
        return `<div class="border-b border-line-soft/70 p-2.5 last:border-0 space-y-2.5">
          <div class="flex items-start gap-2">
            <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg border" style="border-color:${meta.color}44;background:${meta.color}14;color:${meta.color}">
              <span class="material-symbols-outlined text-[15px]" style="font-variation-settings:'FILL' 1">${meta.icon}</span>
            </span>
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-1.5">
                <p class="data text-[11px] font-bold text-text">${esc(assignment.callSign)}</p>
                <span class="badge ml-auto" ${pill(status.color)}>${status.label}</span>
              </div>
              <p class="mt-0.5 truncate text-[9px] text-dim">${esc(assignment.vehicleType || meta.label)} · ${esc(assignment.station || '')}</p>
              <div class="mt-1.5 flex items-center gap-2">
                <div class="progress-track flex-1"><div class="progress-fill" style="width:${Math.min(100, progress)}%;--bar-color:${meta.color}"></div></div>
                <span class="data text-[9px] text-muted">${assignment.status === 'on_scene' || assignment.status === 'transporting' ? 'on scene' : S.formatEta(assignment.etaMinutes)}</span>
              </div>
            </div>
          </div>

          <!-- PTT (Push-to-Talk) Protocol Console for this First Responder -->
          <div class="rounded-xl border border-nema/30 bg-nema/[0.04] p-2.5 space-y-2">
            <div class="flex items-center justify-between gap-1.5">
              <span class="font-mono text-[8.5px] font-bold uppercase tracking-wider text-nema-soft flex items-center gap-1">
                <span class="material-symbols-outlined text-[14px]">radio</span>
                PTT Radio Protocol · ${esc(assignment.callSign)}
              </span>
              <span class="badge font-mono text-[7px]" id="pttStatus-${assignment.responderId}" style="--badge-accent:#7ddba8">
                <span class="live-dot mr-1"></span>RADIO STANDBY
              </span>
            </div>

            <p class="text-[8.5px] text-dim leading-snug">
              Push and hold to transmit voice directly to ${esc(assignment.callSign)}'s in-vehicle Hytera MNC360 terminal. Release to hear updates from the scene.
            </p>

            <button type="button" class="btn btn-nema ptt-button w-full py-2.5 font-bold flex items-center justify-center gap-2 select-none active:scale-[0.98] transition-all" id="pttBtn-${assignment.responderId}" data-action="ptt-press" data-unit-id="${assignment.responderId}" data-callsign="${assignment.callSign}">
              <span class="material-symbols-outlined text-[18px]">mic</span>
              <span id="pttBtnLabel-${assignment.responderId}">PUSH-TO-TALK (HOLD TO SPEAK)</span>
            </button>

            <div class="space-y-1 pt-1 border-t border-line-soft text-[8px] font-mono">
              <div class="flex items-center justify-between text-dim">
                <span>Stage: <strong class="text-text">${assignment.status.replace('_', ' ').toUpperCase()}</strong></span>
                <span>${assignment.status === 'transporting' ? '🚑 In Transit' : assignment.status === 'on_scene' ? '📍 On Scene' : '📡 Radio Linked'}</span>
              </div>
              ${assignment.destination ? `<div class="text-amber-400 font-semibold truncate"><span class="material-symbols-outlined !text-[10px] align-middle mr-0.5">local_hospital</span>Dest: ${esc(assignment.destination)}</div>` : ''}
              <div class="flex items-center gap-1 text-[7.5px] text-dim pt-0.5">
                <span class="${['alerting','accepted','en_route','on_scene','transporting','completed'].includes(assignment.status) ? 'text-ok font-bold' : ''}">1. En Route</span>
                <span>→</span>
                <span class="${['on_scene','transporting','completed'].includes(assignment.status) ? 'text-ok font-bold' : ''}">2. Scene</span>
                <span>→</span>
                <span class="${['transporting','completed'].includes(assignment.status) ? 'text-amber-400 font-bold' : ''}">3. Transport</span>
                <span>→</span>
                <span class="${assignment.status === 'completed' ? 'text-ok font-bold' : ''}">4. Handover</span>
              </div>
            </div>
          </div>
        </div>`;
      }).join('') : `<div class="px-3 py-4 text-center">
        <p class="text-[10px] text-dim">No units assigned. Use an agency above or smart-dispatch the nearest unit.</p>
      </div>`}
    </div>`;
  }

  function aiPanelHtml(incident) {
    const ai = incident.ai;
    if (!ai) return '';
    const mode = ai.mode || 'ai';
    const modeMeta = mode === 'human'
      ? { label: 'Human agent', color: '#f4c430', icon: 'support_agent' }
      : mode === 'closed'
        ? { label: 'Handed to crew', color: '#34d399', icon: 'task_alt' }
        : { label: 'AI active', color: '#2fa46c', icon: 'neurology' };
    const messages = (ai.messages || []).slice(-7);
    const bubble = (message) => {
      const mine = message.role === 'citizen';
      const system = message.role === 'system';
      if (system) {
        return `<div class="my-1 text-center font-mono text-[8px] leading-relaxed text-dim">${esc(message.body)}</div>`;
      }
      const role = message.role === 'human' ? 'Human agent' : message.role === 'ai' ? 'ResQLink AI' : 'Citizen';
      const color = message.role === 'human' ? '#f4c430' : message.role === 'ai' ? '#2fa46c' : '#ff5540';
      return `<div class="flex ${mine ? 'justify-end' : 'justify-start'}">
        <div class="max-w-[92%] rounded-xl border px-2.5 py-2" style="border-color:${color}33;background:${color}0d">
          <p class="font-mono text-[7.5px] font-bold uppercase tracking-wide" style="color:${color}">${role}</p>
          <p class="mt-0.5 whitespace-pre-line text-[10px] leading-relaxed text-text">${esc(message.body)}</p>
        </div>
      </div>`;
    };
    const guidance = ai.guidance || {};
    const actions = (guidance.actions || []).slice(0, 3);
    return `<div class="panel-2 overflow-hidden" id="aiSupportPanel">
      <div class="flex items-center gap-2 border-b border-line-soft px-3 py-2.5">
        <span class="flex h-7 w-7 items-center justify-center rounded-lg border border-nema/30 bg-nema/10 text-nema-soft">
          <span class="material-symbols-outlined text-[16px]">neurology</span>
        </span>
        <div class="min-w-0 flex-1">
          <p class="panel-title !text-[10px]">ResQLink AI · caller support</p>
          <p class="mt-0.5 truncate font-mono text-[8px] text-dim">${esc(ai.stateName || 'Nigeria')} · ${esc(ai.eoc || 'State EOC')}</p>
        </div>
        <span class="badge" ${pill(modeMeta.color)}><span class="material-symbols-outlined !text-[12px]">${modeMeta.icon}</span>${modeMeta.label}</span>
      </div>
      <div class="space-y-2 p-2.5">
        <div class="rounded-lg border border-nema/20 bg-nema/[0.05] px-2.5 py-2">
          <p class="flex items-center gap-1.5 font-mono text-[7.5px] font-bold uppercase tracking-[0.14em] text-nema-soft"><span class="material-symbols-outlined !text-[12px]">alt_route</span>AI geographic routing</p>
          <p class="mt-1 text-[9.5px] leading-relaxed text-muted">${esc(ai.routingReason || 'Location routed to the responsible state desk.')}</p>
        </div>
        ${ai.summary ? `<p class="text-[10px] leading-relaxed text-muted">${esc(ai.summary)}</p>` : ''}
        ${actions.length ? `<div class="flex flex-wrap gap-1">${actions.map((action) => `<span class="rounded-full border border-line bg-panel px-2 py-0.5 text-[8px] text-dim">${esc(action)}</span>`).join('')}</div>` : ''}
        <div class="max-h-[190px] space-y-1.5 overflow-y-auto scroll-thin rounded-lg border border-line-soft bg-panel p-2">
          ${messages.map(bubble).join('') || '<p class="text-center text-[9px] text-dim">No caller messages yet.</p>'}
        </div>
        ${mode === 'human'
          ? `<form data-form="ai-message" class="flex gap-1.5">
              <input id="aiMessageInput" class="input input-sm h-8 flex-1 text-[11px]" maxlength="500" placeholder="Message the caller as ${esc(ai.humanAgentName || DISPATCHER.name)}…" autocomplete="off" />
              <button type="submit" class="btn btn-primary h-8 w-8 p-0" aria-label="Send human agent message"><span class="material-symbols-outlined text-[16px]">send</span></button>
            </form>`
          : ''}
        <div class="flex items-center gap-1.5">
          ${mode === 'ai'
            ? `<button type="button" data-action="ai-takeover" class="btn btn-warn btn-sm flex-1"><span class="material-symbols-outlined text-[15px]">support_agent</span>Take over from AI</button>`
            : mode === 'human'
              ? `<button type="button" data-action="ai-release" class="btn btn-ghost btn-sm flex-1"><span class="material-symbols-outlined text-[15px]">neurology</span>Return to AI</button>`
              : `<span class="badge badge-ok w-full justify-center py-2"><span class="material-symbols-outlined !text-[13px]">handshake</span>Support handed to the responding crew</span>`}
        </div>
        <p class="text-center font-mono text-[7.5px] leading-relaxed text-dim">AI supports the caller until the first responder arrives; a human agent can take over at any time.</p>
      </div>
    </div>`;
  }

  function callSectionHtml(incident) {
    const call = incident.call;
    const canHandle = canDispatch();
    const recordings = call?.recordings || [];
    const fmtDuration = (seconds) => {
      const value = Math.max(0, Math.round(Number(seconds) || 0));
      return `${String(Math.floor(value / 60)).padStart(2, '0')}:${String(value % 60).padStart(2, '0')}`;
    };
    const fmtBytes = (bytes) => {
      const value = Number(bytes) || 0;
      if (value >= 1024 * 1024) return `${(value / (1024 * 1024)).toFixed(1)} MB`;
      if (value >= 1024) return `${Math.round(value / 1024)} KB`;
      return `${value} B`;
    };
    const statusMeta = !call
      ? { label: 'No call', color: '#727979', icon: 'phone_disabled' }
      : call.status === 'connected'
        ? { label: 'State EOC on line', color: '#34d399', icon: 'phone_in_talk' }
        : call.status === 'ringing'
          ? { label: 'Ringing State EOC', color: '#eab308', icon: 'ring_volume' }
          : { label: 'Call ended', color: '#727979', icon: 'call_end' };
    const claimLabel = call?.status === 'connected' ? 'Open call console' : 'Claim & engage call';
    const recordingRows = recordings.length
      ? recordings.map((recording) => `<div class="rounded-lg border border-line-soft bg-panel p-2">
          <div class="flex items-center justify-between gap-2">
            <div class="min-w-0">
              <p class="truncate font-mono text-[9px] font-bold text-text">${esc(recording.fileName || `Recording ${recording.id}`)}</p>
              <p class="mt-0.5 font-mono text-[8px] text-dim">${fmtDuration(recording.durationSeconds)} · ${fmtBytes(recording.bytes)} · ${esc(recording.status)} · ${S.clockTime(recording.createdAt)}</p>
            </div>
            <button type="button" data-action="play-recording" data-recording="${recording.id}" data-audio="recordingAudio-${recording.id}" class="btn btn-ghost btn-sm shrink-0" ${recording.isPlayable ? '' : 'disabled'}>
              <span class="material-symbols-outlined text-[15px]">play_arrow</span>Play
            </button>
          </div>
          <audio id="recordingAudio-${recording.id}" class="mt-1.5 hidden w-full" controls preload="none"></audio>
        </div>`).join('')
      : `<p class="text-[9px] text-dim">No call audio has been uploaded yet. The citizen browser records the line once the microphone is allowed.</p>`;

    return `<div class="panel-2 overflow-hidden" id="callSection">
      <div class="flex items-center gap-2 border-b border-line-soft px-3 py-2.5">
        <span class="flex h-7 w-7 items-center justify-center rounded-lg border" style="border-color:${statusMeta.color}44;background:${statusMeta.color}14;color:${statusMeta.color}">
          <span class="material-symbols-outlined text-[16px]">${statusMeta.icon}</span>
        </span>
        <div class="min-w-0 flex-1">
          <p class="panel-title !text-[10px]">Call &amp; conclusive tracking</p>
          <p class="mt-0.5 truncate font-mono text-[8px] text-dim">${call ? `${esc(call.stateCode)} · session #${call.id} · opened ${S.clockTime(call.createdAt)}` : 'Every SOS opens a State EOC call line'}</p>
        </div>
        <span class="badge" ${pill(statusMeta.color)}>${statusMeta.label}</span>
      </div>
      <div class="space-y-2 p-2.5">
        ${call ? `<div class="grid grid-cols-2 gap-1.5">
          <div class="rounded-lg border border-line-soft bg-panel px-2 py-1.5">
            <p class="font-mono text-[8px] uppercase tracking-wide text-dim">On the line</p>
            <p class="mt-0.5 truncate text-[10.5px] font-bold text-text">${esc(call.claimedByName || 'Unclaimed')}</p>
          </div>
          <div class="rounded-lg border border-line-soft bg-panel px-2 py-1.5">
            <p class="font-mono text-[8px] uppercase tracking-wide text-dim">Talk time</p>
            <p class="data mt-0.5 text-[11px] font-bold text-text">${fmtDuration(call.durationSeconds)}</p>
          </div>
          <div class="col-span-2 rounded-lg border border-line-soft bg-panel px-2 py-1.5">
            <p class="font-mono text-[8px] uppercase tracking-wide text-dim">Tracking outcome</p>
            <p class="mt-0.5 text-[10px] leading-relaxed ${call.endReason ? 'text-text' : 'text-muted'}">${esc(call.endReason || (call.status === 'connected' ? 'State EOC engaged — tracking until the first responder is on scene.' : 'Waiting for the State EOC to claim the line.'))}</p>
          </div>
        </div>` : `<div class="rounded-lg border border-line-soft bg-panel px-2.5 py-2">
          <p class="text-[10px] leading-relaxed text-muted">This incident has no call session. Open one to start recording the citizen line for the State EOC and NEMA oversight.</p>
        </div>`}

        ${canHandle
          ? `<div class="flex flex-wrap items-center gap-1.5">
              ${!call || call.status === 'ended' || call.status === 'missed'
                ? `<button type="button" data-action="call-open" class="btn btn-primary btn-sm flex-1"><span class="material-symbols-outlined text-[15px]">phone_forwarded</span>Open call line</button>`
                : `<button type="button" data-action="call-claim" class="btn btn-primary btn-sm flex-1"><span class="material-symbols-outlined text-[15px]">support_agent</span>${claimLabel}</button>`}
              ${call?.isActive ? `<button type="button" data-action="call-end" class="btn btn-quiet btn-sm"><span class="material-symbols-outlined text-[15px]">call_end</span>End call</button>` : ''}
            </div>`
          : `<div class="flex items-center gap-2 rounded-lg border border-line-soft bg-panel px-2.5 py-2">
              <span class="material-symbols-outlined text-[15px] text-dim">visibility</span>
              <p class="text-[9px] leading-relaxed text-muted">NEMA national oversight — the responsible State EOC claims and handles this line. Call audio is recorded for review.</p>
            </div>`}

        <div class="flex items-center justify-between gap-2 border-t border-line-soft pt-2">
          <p class="panel-title !text-[9px]">Call recordings</p>
          <span class="badge badge-muted">${recordings.length}</span>
        </div>
        <div class="space-y-1.5">${recordingRows}</div>
        <button type="button" data-action="export-case" class="btn btn-ghost btn-sm w-full">
          <span class="material-symbols-outlined text-[15px]">download</span>Export conclusive case record
        </button>
        <p class="text-center font-mono text-[7.5px] leading-relaxed text-dim">${canHandle ? 'The State EOC stays on the line until the first responder is on scene. The handoff is written to the event log.' : 'NEMA observes the line and the conclusive event log. The state owns every dispatch and call action.'}</p>
      </div>
    </div>`;
  }

  function commsHtml(incident) {
    const tab = state.detailTab;
    const notes = incident.notes || [];
    const messages = incident.messages || [];
    const tabButton = (key, label, icon, count) => `<button type="button" data-action="tab" data-tab="${key}" class="tab ${tab === key ? 'is-active' : ''}">
      <span class="flex items-center gap-1.5"><span class="material-symbols-outlined !text-[15px]">${icon}</span>${label}${count ? ` <span class="rounded-full border border-line bg-panel-2 px-1 font-mono text-[8px] text-dim">${count}</span>` : ''}</span>
    </button>`;

    let content = '';
    if (tab === 'notes') {
      content = `<div class="space-y-2 p-2.5">
        <div id="notesList" class="space-y-2">${notesListHtml(incident)}</div>
        <form data-form="note" class="space-y-2 border-t border-line-soft pt-2.5">
          <textarea id="noteBody" class="textarea min-h-[58px] text-[12px]" maxlength="1500" placeholder="Add operational context for responding crews…" aria-label="Dispatcher note"></textarea>
          <div class="flex items-center justify-between gap-2">
            <label class="flex cursor-pointer items-center gap-1.5 text-[9px] text-muted"><input id="notePinned" type="checkbox" class="h-3 w-3 accent-[#ff5540]" /> Pin to top</label>
            <button type="submit" class="btn btn-ghost btn-sm"><span class="material-symbols-outlined text-[15px]">note_add</span>Add note</button>
          </div>
        </form>
      </div>`;
    } else if (tab === 'chat') {
      content = `<div class="flex flex-col">
        <div id="detailChat" class="chat-stream max-h-[230px] p-2.5">
          ${chatListHtml(incident)}
        </div>
        <form data-form="chat" class="flex gap-1.5 border-t border-line-soft p-2">
          <input id="detailChatInput" class="input input-sm h-8 flex-1 text-[11px]" maxlength="500" placeholder="Message citizen & responders…" autocomplete="off" aria-label="Chat message" />
          <button type="submit" class="btn btn-primary h-8 w-8 p-0" aria-label="Send message"><span class="material-symbols-outlined text-[16px]">send</span></button>
        </form>
      </div>`;
    } else {
      const media = incident.media;
      content = `<div class="space-y-2.5 p-2.5">
        <div class="relative overflow-hidden rounded-xl border border-line bg-[radial-gradient(circle_at_50%_35%,#1b2727,#080a0a)]">
          <div class="flex aspect-video flex-col items-center justify-center gap-2 px-6 text-center">
            <span class="flex h-11 w-11 items-center justify-center rounded-full border border-line bg-panel-2 text-alert"><span class="material-symbols-outlined text-[22px]">videocam</span></span>
            <p class="text-[11px] font-bold text-text">${media ? 'Citizen media session active' : 'No active media session'}</p>
            <p class="max-w-[240px] text-[9px] leading-relaxed text-dim">${media ? 'The citizen has opened a feed. Request the WebRTC stream to view it live.' : 'Ask the citizen to start the live feed from their SOS screen.'}</p>
            ${media ? '<span class="badge badge-ok"><span class="live-dot"></span> Session open</span>' : '<span class="badge badge-muted">Standby</span>'}
          </div>
          <span class="absolute left-2 top-2 badge badge-muted bg-black/60"><span class="material-symbols-outlined !text-[12px]">lock</span> responders only</span>
        </div>
        <button type="button" data-action="open-feed" class="btn btn-primary w-full">
          <span class="material-symbols-outlined text-[17px]">play_circle</span>Open live viewer
        </button>
        <p class="text-center font-mono text-[8px] leading-relaxed text-dim">WebRTC media is peer-to-peer. Add a TURN server for restrictive carrier networks.</p>
      </div>`;
    }

    return `<div class="panel-2 overflow-hidden">
      <div class="flex border-b border-line-soft">
        ${tabButton('notes', 'Notes', 'sticky_note_2', notes.length)}
        ${tabButton('chat', 'Chat', 'chat_bubble', messages.length)}
        ${tabButton('media', 'Media', 'videocam', 0)}
      </div>
      ${content}
    </div>`;
  }

  function timelineHtml(incident) {
    const events = (incident.events || []).slice(-7).reverse();
    if (!events.length) return '<p class="text-[10px] text-dim">No updates recorded yet.</p>';
    const colors = {
      created: '#ff5540', acknowledged: '#eab308', dispatched: '#f97316', accepted: '#eab308',
      en_route: '#f59e0b', on_scene: '#34d399', transporting: '#3b82f6', completed: '#34d399',
      resolved: '#727979', cancelled: '#727979', location: '#34d399', note: '#a6acac',
      updated: '#a6acac', declined: '#727979', state_notified: '#34d399',
      ai_dispatch: '#2fa46c', ai_dispatch_failed: '#eab308', ai_triage: '#2fa46c',
      call_started: '#eab308', call_claimed: '#34d399', call_ended: '#727979',
      call_handoff: '#34d399', call_recording_started: '#ff5540', call_recording_saved: '#34d399',
      call_recording_failed: '#eab308'
    };
    return `<div class="timeline">
      ${events.map((event, index) => `<div class="timeline-item ${index === 0 ? 'is-current' : ''}" style="--dot:${colors[event.type] || '#727979'}">
        <div class="flex items-start justify-between gap-2">
          <p class="text-[10.5px] leading-snug text-text">${esc(event.message)}</p>
          <span class="shrink-0 font-mono text-[8px] text-dim">${S.clockTime(event.createdAt)}</span>
        </div>
        <p class="mt-0.5 font-mono text-[8px] uppercase tracking-wide text-dim">${esc(event.type)} · ${esc(event.actorType || 'system')}</p>
      </div>`).join('')}
    </div>`;
  }

  function detailHtml(incident) {
    const type = typeOf(incident);
    const priority = priorityOf(incident);
    const status = statusOf(incident);
    const active = activeAssignments(incident);
    const eta = active.length ? Math.min(...active.map((a) => Number(a.etaMinutes) || 99)) : null;
    const media = incident.media;
    const hazards = incident.hazards || [];
    const phone = incident.reporterPhone;
    const photoSrc = incident.photoUrl
      ? `${incident.photoUrl}?token=${encodeURIComponent(S.authToken?.() || '')}`
      : null;

    return `<div class="sticky top-0 z-10 border-b border-line-soft bg-panel/95 backdrop-blur">
      <div class="p-3">
        <div class="flex items-start gap-2.5">
          <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl border" style="border-color:${type.color}55;background:${type.color}16;color:${type.color}">
            <span class="material-symbols-outlined text-[20px]" style="font-variation-settings:'FILL' 1">${type.icon}</span>
          </span>
          <div class="min-w-0 flex-1">
            <div class="flex flex-wrap items-center gap-1.5">
              <span class="data text-[13px] font-bold text-text">${esc(incident.code)}</span>
              <span class="badge" ${pill(type.color)}>${type.label}</span>
              <span class="badge" ${pill(priority.color)}>${priority.short}</span>
              <span class="badge" ${pill(status.color)}>${status.label}</span>
              <span class="badge badge-muted"><span class="material-symbols-outlined !text-[11px]">location_on</span>${esc(incident.stateName || incident.stateCode || 'Nigeria')}</span>
            </div>
            <p class="mt-1 text-[12px] font-semibold leading-snug text-text">${esc(incident.address || 'Location shared')}</p>
            <p class="mt-0.5 truncate text-[9px] text-dim">${esc(incident.landmark || 'No landmark supplied')}</p>
          </div>
          <button type="button" data-action="copy-coords" class="btn btn-quiet h-7 w-7 shrink-0 p-0" title="Copy coordinates" aria-label="Copy coordinates">
            <span class="material-symbols-outlined text-[16px]">content_copy</span>
          </button>
        </div>

        <div class="mt-2.5 grid grid-cols-3 gap-1.5">
          <div class="rounded-lg border border-line-soft bg-panel-2 px-2 py-1.5">
            <p class="font-mono text-[8px] uppercase tracking-wide text-dim">Open for</p>
            <p class="data mt-0.5 text-[12px] font-bold text-text" data-live-since="${incident.createdAt}">00:00</p>
          </div>
          <div class="rounded-lg border border-line-soft bg-panel-2 px-2 py-1.5">
            <p class="font-mono text-[8px] uppercase tracking-wide text-dim">Units</p>
            <p class="data mt-0.5 text-[12px] font-bold ${active.length ? 'text-ok' : 'text-road'}">${active.length}</p>
          </div>
          <div class="rounded-lg border border-line-soft bg-panel-2 px-2 py-1.5">
            <p class="font-mono text-[8px] uppercase tracking-wide text-dim">ETA</p>
            <p class="data mt-0.5 text-[12px] font-bold text-text" data-detail-eta>${eta == null ? '—' : S.formatEta(eta)}</p>
          </div>
        </div>

        <div class="mt-2.5 flex items-center gap-1.5">
          ${incident.acknowledgedAt
            ? `<span class="badge badge-ok flex-1 justify-center py-2"><span class="live-dot"></span> Acknowledged ${S.clockTime(incident.acknowledgedAt)}</span>`
            : `<button type="button" data-action="acknowledge" class="btn btn-warn btn-sm flex-1"><span class="material-symbols-outlined text-[15px]">fact_check</span>Acknowledge</button>`}
          <button type="button" data-action="resolve" class="btn btn-ok btn-icon" title="Resolve incident" aria-label="Resolve incident">
            <span class="material-symbols-outlined text-[18px]">check_circle</span>
          </button>
          <button type="button" data-action="cancel" class="btn btn-quiet btn-icon" title="Cancel incident" aria-label="Cancel incident">
            <span class="material-symbols-outlined text-[18px]">cancel</span>
          </button>
        </div>
      </div>
    </div>

    <div class="space-y-2.5 p-2.5">
      ${photoSrc ? `<div class="panel-2 overflow-hidden">
        <div class="flex items-center justify-between gap-2 border-b border-line-soft px-3 py-2">
          <p class="panel-title !text-[10px] flex items-center gap-1.5"><span class="material-symbols-outlined !text-[14px] text-alert">photo_camera</span>Citizen SOS photo</p>
          <span class="badge badge-muted">Sent with alert</span>
        </div>
        <button type="button" data-action="view-photo" class="relative block w-full" title="Open the citizen SOS photo">
          <img src="${esc(photoSrc)}" alt="Citizen SOS scene photo for ${esc(incident.code)}" class="w-full object-cover" style="max-height:220px" />
          <span class="absolute inset-x-0 bottom-0 flex items-center gap-1 bg-gradient-to-t from-black/80 to-transparent px-2.5 pb-1.5 pt-6 text-[9px] font-semibold text-white">
            <span class="material-symbols-outlined !text-[13px]">zoom_in</span>Tap to view full scene photo
          </span>
        </button>
      </div>` : ''}
      <div class="panel-2 p-2.5">
        <div class="flex items-center justify-between gap-2">
          <p class="panel-title !text-[10px]">Situation</p>
          <span class="badge badge-muted">${esc(incident.source || 'app')}</span>
        </div>
        <p class="mt-1.5 text-[11.5px] leading-relaxed text-text">${esc(incident.description || 'No situation notes supplied.')}</p>
        ${hazards.length ? `<div class="mt-2 flex flex-wrap gap-1">${hazards.map((hazard) => `<span class="badge badge-alert">${esc(hazard)}</span>`).join('')}</div>` : ''}
        <dl class="mt-2.5 grid grid-cols-2 gap-x-3 gap-y-1.5 text-[9.5px]">
          <div><dt class="text-dim">Caller</dt><dd class="truncate text-text">${esc(incident.reporterName || 'Anonymous')}</dd></div>
          <div><dt class="text-dim">People affected</dt><dd class="text-text">${incident.peopleAffected || 1}</dd></div>
          <div><dt class="text-dim">Phone</dt><dd>${phone ? `<a href="tel:${esc(phone)}" class="text-alert-soft hover:underline">${esc(phone)}</a>` : '<span class="text-text">—</span>'}</dd></div>
          <div><dt class="text-dim">GPS accuracy</dt><dd class="text-text">${incident.accuracyM ? `± ${Math.round(incident.accuracyM)} m` : '—'}</dd></div>
          <div class="col-span-2"><dt class="text-dim">Coordinates</dt><dd class="data text-[9.5px] text-text" data-detail-coords>${S.formatCoord(incident.lat, incident.lng)}</dd></div>
          <div class="col-span-2"><dt class="text-dim">AI state routing</dt><dd class="text-text">${esc(incident.stateName || incident.stateCode || 'Pending')} · ${esc(incident.ai?.eoc || 'State EOC')}</dd></div>
          <div class="col-span-2"><dt class="text-dim">Reported</dt><dd class="text-text">${new Date(incident.createdAt).toLocaleString('en-NG', { hour12: false })} · ${S.relativeTime(incident.createdAt)}</dd></div>
        </dl>
      </div>

      <!-- Staff update: NEMA / state staff can correct priority, crowd size
           and situation notes without leaving the incident tab. -->
      <form data-form="update-incident" class="panel-2 space-y-2 p-2.5">
        <div class="flex items-center justify-between gap-2">
          <p class="panel-title !text-[10px]">Staff update</p>
          <span class="badge badge-muted font-mono">PATCH live</span>
        </div>
        <div class="grid grid-cols-2 gap-2">
          <div>
            <label class="field-label" for="updatePriority">Priority</label>
            <select id="updatePriority" class="select input-sm h-8 text-[11px]">
              <option value="1" ${incident.priority === 1 ? 'selected' : ''}>P1 · Critical</option>
              <option value="2" ${incident.priority === 2 ? 'selected' : ''}>P2 · Urgent</option>
              <option value="3" ${incident.priority === 3 ? 'selected' : ''}>P3 · Routine</option>
              <option value="4" ${incident.priority === 4 ? 'selected' : ''}>P4 · Low</option>
            </select>
          </div>
          <div>
            <label class="field-label" for="updatePeople">People affected</label>
            <input id="updatePeople" type="number" min="1" max="999" value="${incident.peopleAffected || 1}" class="input input-sm h-8 text-[11px]" />
          </div>
        </div>
        <div>
          <label class="field-label" for="updateDescription">Situation update</label>
          <textarea id="updateDescription" class="textarea min-h-[56px] text-[12px]" maxlength="1000" placeholder="Update the situation for responders…">${esc(incident.description || '')}</textarea>
        </div>
        <button type="submit" class="btn btn-ghost btn-sm w-full">
          <span class="material-symbols-outlined text-[15px]">edit_note</span>Save staff update
        </button>
      </form>

      ${aiPanelHtml(incident)}
      ${callSectionHtml(incident)}
      ${dispatchSectionHtml(incident)}
      ${assignedSectionHtml(incident)}
      ${commsHtml(incident)}

      <div class="panel-2 overflow-hidden">
        <div class="flex items-center justify-between border-b border-line-soft px-3 py-2.5">
          <p class="panel-title !text-[10px]">Event log</p>
          <span class="badge badge-muted">${(incident.events || []).length} updates</span>
        </div>
        <div class="p-2.5">${timelineHtml(incident)}</div>
      </div>
    </div>`;
  }

  function renderDetail({ resetScroll = false } = {}) {
    const panel = $('detailPanel');
    const incident = state.detail;
    if (!incident) {
      detailEmpty();
      return;
    }
    const previousScroll = panel.scrollTop;
    const noteDraft = $('noteBody')?.value || '';
    const chatDraft = $('detailChatInput')?.value || '';
    // Preserve staff-update drafts across live ticks so typing isn't wiped.
    const updateDraft = $('updateDescription')?.value ?? null;
    const priorityDraft = $('updatePriority')?.value ?? null;
    const peopleDraft = $('updatePeople')?.value ?? null;
    const aiDraft = $('aiMessageInput')?.value || '';
    panel.innerHTML = detailHtml(incident);
    const noteInput = $('noteBody');
    if (noteInput && noteDraft) noteInput.value = noteDraft;
    const chatInput = $('detailChatInput');
    if (chatInput && chatDraft) chatInput.value = chatDraft;
    if (updateDraft != null && $('updateDescription')) $('updateDescription').value = updateDraft;
    if (priorityDraft != null && $('updatePriority')) $('updatePriority').value = priorityDraft;
    if (peopleDraft != null && $('updatePeople')) $('updatePeople').value = peopleDraft;
    const aiInput = $('aiMessageInput');
    if (aiInput && aiDraft) aiInput.value = aiDraft;
    const chat = $('detailChat');
    if (chat) chat.scrollTop = chat.scrollHeight;
    panel.scrollTop = resetScroll ? 0 : previousScroll;
    if (resetScroll) panel.scrollTop = 0;
  }

  function renderDispatchSection() {
    const host = $('dispatchSection');
    if (!host || !state.detail) return;
    host.outerHTML = dispatchSectionHtml(state.detail);
  }

  function renderAssignedSection() {
    const host = $('assignedSection');
    if (!host || !state.detail) return;
    host.outerHTML = assignedSectionHtml(state.detail);
  }

  function updateLiveDetail(detail) {
    const coords = document.querySelector('[data-detail-coords]');
    if (coords) coords.textContent = S.formatCoord(detail.lat, detail.lng);
    const eta = document.querySelector('[data-detail-eta]');
    if (eta) {
      const active = activeAssignments(detail);
      const value = active.length ? Math.min(...active.map((a) => Number(a.etaMinutes) || 99)) : null;
      eta.textContent = value == null ? '—' : S.formatEta(value);
    }
    renderMapSelected();
  }

  function shouldFullRender(prev, next) {
    if (!prev) return true;
    if (prev.status !== next.status || prev.priority !== next.priority) return true;
    if (prev.acknowledgedAt !== next.acknowledgedAt) return true;
    if (prev.description !== next.description) return true;
    if ((prev.hazards || []).join('|') !== (next.hazards || []).join('|')) return true;
    if (prev.address !== next.address || prev.landmark !== next.landmark) return true;
    const callSignature = (incident) => {
      const call = incident.call;
      if (!call) return 'none';
      return [call.id, call.status, call.claimedByName, call.endedAt, (call.recordings || []).length, call.durationSeconds].join(':');
    };
    if (callSignature(prev) !== callSignature(next)) return true;
    const signature = (incident) => activeAssignments(incident)
      .map((a) => `${a.id}:${a.status}:${Math.round((a.progress || 0) * 100)}:${a.etaMinutes}`)
      .join('|');
    return signature(prev) !== signature(next);
  }

  function applyDetail(detail, { forceRender = false } = {}) {
    if (!detail) return;
    const summary = summaryOf(detail);
    state.incidents.set(detail.id, summary);

    if (!detail.isActive) {
      state.incidents.delete(detail.id);
      if (state.selectedId === detail.id) {
        state.selectedId = null;
        state.detail = null;
        stopViewer();
        stopCallViewer();
        detailEmpty();
      }
      ensureIncidentMarkers();
      renderQueue();
      renderKpis();
      renderMapSelected();
      renderRoutes();
      toast(detail.status === 'cancelled' ? 'Incident cancelled' : 'Incident resolved', `${detail.code} was closed.`, 'info');
      return;
    }

    if (state.selectedId === detail.id) {
      const previous = state.detail;
      state.detail = summary;
      if (forceRender || shouldFullRender(previous, summary)) renderDetail();
      else updateLiveDetail(summary);
      if (detail.media) renderMapSelected();
    }
    renderQueue();
    renderKpis();
    ensureIncidentMarkers();
    renderRoutes();
    renderMapSelected();
  }

  // -------------------------------------------------------------------------
  // Selection + data loading
  // -------------------------------------------------------------------------
  function scrollDetailIntoView() {
    const panel = document.querySelector('.dispatch-detail');
    if (panel) panel.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }

  async function selectIncident(id, { fly = true } = {}) {
    const numericId = Number(id);
    if (!numericId) return;
    if (state.selectedId === numericId && state.detail?.id === numericId) {
      scrollDetailIntoView();
      return;
    }
    if (state.selectedId && state.selectedId !== numericId) {
      socket.emit('incident:unsubscribe', { incidentId: state.selectedId });
    }
    state.selectedId = numericId;
    state.detail = null;
    state.detailTab = 'notes';
    stopViewer();
    stopCallViewer();
    renderQueue();
    ensureIncidentMarkers();
    renderMapSelected();
    detailLoading();
    const summary = state.incidents.get(numericId);
    if (summary && fly) flyToIncident(summary);
    socket.emit('incident:subscribe', { incidentId: numericId });
    try {
      const { incident } = await api(`/api/incidents/${numericId}`);
      if (state.selectedId !== numericId) return;
      applyDetail(incident, { forceRender: true });
      renderDetail({ resetScroll: true });
      loadCandidates(numericId);
      // Clicking a queue card / map pin always brings the full incident
      // tab into view (critical on mobile where the detail sits below).
      scrollDetailIntoView();
    } catch (error) {
      toast('Could not load incident', error.message, 'error');
      if (state.selectedId === numericId) detailEmpty();
    }
  }

  async function loadCandidates(incidentId, { force = false } = {}) {
    if (!force && state.candidates.has(incidentId)) return;
    if (state.candidatesLoading.has(incidentId)) return;
    state.candidatesLoading.add(incidentId);
    renderDispatchSection();
    try {
      const results = await Promise.all(AGENCY_ORDER.map(async (code) => {
        const data = await api(`/api/incidents/${incidentId}/candidates?agency=${code}&radius=40&limit=4`);
        return [code, data];
      }));
      state.candidates.set(incidentId, Object.fromEntries(results));
    } catch (error) {
      toast('Candidate search failed', error.message, 'error');
    } finally {
      state.candidatesLoading.delete(incidentId);
      if (state.selectedId === incidentId) renderDispatchSection();
    }
  }

  async function refreshDetail() {
    if (!state.selectedId) return;
    try {
      const { incident } = await api(`/api/incidents/${state.selectedId}`);
      if (state.selectedId !== incident.id) return;
      applyDetail(incident);
    } catch { /* transient network issue */ }
  }

  // -------------------------------------------------------------------------
  // Dispatch actions
  // -------------------------------------------------------------------------
  async function acknowledgeIncident() {
    if (!state.detail) return;
    try {
      const { incident } = await api(`/api/incidents/${state.detail.id}/acknowledge`, {
        method: 'POST', body: { actor: DISPATCHER.name }
      });
      applyDetail(incident, { forceRender: true });
      toast('Incident acknowledged', `${incident.code} is now being actively managed.`, 'success');
      S.chime();
    } catch (error) {
      toast('Could not acknowledge', error.message, 'error');
    }
  }

  async function dispatchUnit({ agencyCode, responderId = null, incidentId = state.detail?.id } = {}) {
    if (!canDispatch()) throw new Error('Only the responsible State EOC can dispatch a first responder. NEMA is national oversight.');
    if (!incidentId) throw new Error('No incident selected');
    const result = await api(`/api/incidents/${incidentId}/dispatch`, {
      method: 'POST',
      body: { agencyCode, responderId, dispatcher: DISPATCHER.name }
    });
    applyDetail(result.incident, { forceRender: true });
    const assignment = result.assignment;
    toast('Unit dispatched', `${assignment.callSign} assigned · ${S.formatDistanceKm(assignment.distanceKm)} · ETA ${S.formatEta(assignment.etaMinutes)}.`, 'success', 6500);
    if (state.soundOn) S.dispatchTone();
    return result;
  }

  async function autoDispatch() {
    if (!state.detail) return;
    if (!canDispatch()) { toast('State dispatches only', dispatchLockNote(), 'info', 7000); return; }
    const incident = state.detail;
    const agency = TYPE_TO_AGENCY[incident.type] || 'MEDICAL';
    const buttons = $$('[data-action="auto-dispatch"]');
    buttons.forEach((button) => { button.disabled = true; });
    try {
      await dispatchUnit({ agencyCode: agency, incidentId: incident.id });
    } catch (error) {
      toast('Dispatch failed', error.message, 'error', 6500);
    } finally {
      buttons.forEach((button) => { button.disabled = false; });
    }
  }

  async function dispatchNominatedUnit(button, responderId, agencyCode) {
    if (!state.detail) return;
    if (!canDispatch()) { toast('State dispatches only', dispatchLockNote(), 'info', 7000); return; }
    button.disabled = true;
    const original = button.innerHTML;
    button.innerHTML = '<span class="material-symbols-outlined animate-spin text-[16px]">progress_activity</span> Dispatching…';
    try {
      await dispatchUnit({ agencyCode: agencyCode || 'MEDICAL', responderId, incidentId: state.detail.id });
      toast('Dispatch Sent', `Vehicle alerted with siren & route. State EOC is now linked via PTT radio.`, 'success', 6000);
    } catch (err) {
      toast('Dispatch failed', err.message, 'error', 6500);
      button.disabled = false;
      button.innerHTML = original;
    }
  }

  // -------------------------------------------------------------------------
  // Push-To-Talk (PTT) Protocol for State EOC
  // -------------------------------------------------------------------------
  const pttState = {
    transmitting: false,
    receiving: false,
    targetUnitId: null,
    targetCallSign: null,
    mediaRecorder: null,
    audioStream: null
  };

  function playRadioBeep(type = 'start') {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      if (type === 'start') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        gain.gain.setValueAtTime(0.09, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.08);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.09);
      } else {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, ctx.currentTime);
        osc.frequency.setValueAtTime(850, ctx.currentTime + 0.07);
        gain.gain.setValueAtTime(0.07, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.16);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.17);
      }
    } catch { /* audio not allowed */ }
  }

  function setPttUi(unitId, callSign, mode) {
    const tx = mode === 'tx';
    const rx = mode === 'rx';
    for (const id of [`pttBtn-${unitId}`, `callPttBtn-${unitId}`]) {
      const btn = $(id);
      if (!btn) continue;
      btn.classList.toggle('btn-nema', !tx);
      btn.classList.toggle('bg-alert', tx);
      btn.classList.toggle('text-white', tx);
      btn.classList.toggle('animate-pulse', tx);
    }
    for (const [id, idleLabel] of [
      [`pttBtnLabel-${unitId}`, 'PUSH-TO-TALK (HOLD TO SPEAK)'],
      [`callPttBtnLabel-${unitId}`, 'HOLD TO TALK']
    ]) {
      const label = $(id);
      if (!label) continue;
      label.textContent = tx ? `TRANSMITTING TO ${callSign}… (RELEASE TO LISTEN)` : idleLabel;
    }
    for (const id of [`pttStatus-${unitId}`, `callPttStatus-${unitId}`]) {
      const status = $(id);
      if (!status) continue;
      if (tx) {
        status.innerHTML = `<span class="live-dot live-dot--red mr-1"></span>TX TRANSMITTING`;
        status.style.setProperty('--badge-accent', '#ff5540');
      } else if (rx) {
        status.innerHTML = `<span class="live-dot live-dot--warn mr-1"></span>RX FROM ${esc(callSign)}`;
        status.style.setProperty('--badge-accent', '#eab308');
      } else {
        status.innerHTML = `<span class="live-dot mr-1"></span>RADIO STANDBY`;
        status.style.setProperty('--badge-accent', '#7ddba8');
      }
    }
  }

  async function startPttTransmission(unitId, callSign) {
    if (pttState.transmitting) return;
    pttState.transmitting = true;
    pttState.targetUnitId = unitId;
    pttState.targetCallSign = callSign;

    playRadioBeep('start');
    setPttUi(unitId, callSign, 'tx');

    socket.emit('ptt:tx-start', {
      incidentId: state.detail?.id,
      unitId,
      unitCallSign: callSign,
      senderRole: 'dispatch',
      senderName: DISPATCHER.name || 'State EOC Dispatcher'
    });

    try {
      if (!pttState.audioStream) {
        pttState.audioStream = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: true, noiseSuppression: true } }).catch(() => null);
      }
      if (pttState.audioStream) {
        const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm';
        pttState.mediaRecorder = new MediaRecorder(pttState.audioStream, { mimeType });
        pttState.mediaRecorder.ondataavailable = async (e) => {
          if (e.data && e.data.size > 0 && pttState.transmitting) {
            const buffer = await e.data.arrayBuffer();
            const bytes = new Uint8Array(buffer);
            let binary = '';
            for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
            const base64 = btoa(binary);
            socket.emit('ptt:tx-audio', {
              incidentId: state.detail?.id,
              unitId,
              audioData: base64,
              mimeType,
              senderRole: 'dispatch',
              senderName: DISPATCHER.name || 'State EOC Dispatcher'
            });
          }
        };
        pttState.mediaRecorder.start(250);
      }
    } catch (err) {
      console.warn('[ptt] mic stream error:', err.message);
    }
  }

  function stopPttTransmission() {
    if (!pttState.transmitting) return;
    const unitId = pttState.targetUnitId;
    const callSign = pttState.targetCallSign;
    pttState.transmitting = false;

    playRadioBeep('end');

    if (pttState.mediaRecorder && pttState.mediaRecorder.state !== 'inactive') {
      try { pttState.mediaRecorder.stop(); } catch {}
    }

    setPttUi(unitId, callSign, 'idle');

    socket.emit('ptt:tx-end', {
      incidentId: state.detail?.id,
      unitId,
      unitCallSign: callSign,
      senderRole: 'dispatch',
      senderName: DISPATCHER.name || 'State EOC Dispatcher'
    });
  }

  const seenPttEvents = new Set();
  function isDuplicatePttEvent(payload) {
    const key = payload?.txId
      ? `${payload.txId}:${payload.seq}`
      : `${payload?.socketId}:${payload?.timestamp}:${payload?.audioData?.length || 0}`;
    if (seenPttEvents.has(key)) return true;
    seenPttEvents.add(key);
    if (seenPttEvents.size > 600) seenPttEvents.delete(seenPttEvents.values().next().value);
    return false;
  }

  function handlePttIncoming(payload, eventType) {
    // The server fans PTT out across several rooms, so the same frame can
    // arrive more than once on a socket. Keep only the first copy.
    if (isDuplicatePttEvent(payload)) return;
    const unitId = payload.unitId;
    const callSign = payload.unitCallSign || 'Responder';

    if (eventType === 'start') {
      playRadioBeep('start');
      pttState.receiving = true;
      setPttUi(unitId, callSign, 'rx');
      toast('PTT Radio Transmission', `${callSign} is transmitting voice from the scene…`, 'info', 4000);
    } else if (eventType === 'audio') {
      if (payload.audioData) {
        try {
          const binary = atob(payload.audioData);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
          const blob = new Blob([bytes], { type: payload.mimeType || 'audio/webm' });
          const audio = new Audio(URL.createObjectURL(blob));
          audio.play().catch(() => {});
        } catch {}
      }
    } else if (eventType === 'end') {
      playRadioBeep('end');
      pttState.receiving = false;
      setPttUi(unitId, callSign, 'idle');
    }
  }

  async function aiDispatchNearest() {
    if (!state.detail) return;
    if (!canDispatch()) { toast('State dispatches only', dispatchLockNote(), 'info', 7000); return; }
    const buttons = $$('[data-action="ai-dispatch"]');
    buttons.forEach((button) => { button.disabled = true; });
    try {
      const result = await api(`/api/incidents/${state.detail.id}/ai/dispatch`, { method: 'POST' });
      if (result?.assignment) {
        applyDetail(result.incident, { forceRender: true });
        toast('AI dispatched nearest unit', `${result.assignment.callSign} assigned · ETA ${S.formatEta(result.assignment.etaMinutes)}.`, 'success', 6500);
        if (state.soundOn) S.dispatchTone();
      } else {
        toast('AI dispatch', 'A unit is already assigned to this incident.', 'info');
      }
    } catch (error) {
      toast('AI dispatch failed', error.message, 'error', 6500);
    } finally {
      buttons.forEach((button) => { button.disabled = false; });
    }
  }

  async function submitStaffUpdate(form) {
    if (!state.detail) return;
    const priority = Number(form.querySelector('#updatePriority')?.value);
    const peopleAffected = Number(form.querySelector('#updatePeople')?.value);
    const description = form.querySelector('#updateDescription')?.value?.trim() || '';
    const submit = form.querySelector('[type="submit"]');
    if (submit) submit.disabled = true;
    try {
      const { incident } = await api(`/api/incidents/${state.detail.id}`, {
        method: 'PATCH',
        body: {
          priority: Number.isFinite(priority) ? priority : state.detail.priority,
          peopleAffected: Number.isFinite(peopleAffected) && peopleAffected > 0 ? peopleAffected : state.detail.peopleAffected,
          description,
          actor: DISPATCHER.name
        }
      });
      applyDetail(incident, { forceRender: true });
      toast('Incident updated', `${incident.code} staff update saved.`, 'success');
    } catch (error) {
      toast('Update failed', error.message, 'error');
    } finally {
      if (submit) submit.disabled = false;
    }
  }

  function openCandidateModal(agencyCode) {
    if (!state.detail) return;
    if (!canDispatch()) { toast('State dispatches only', dispatchLockNote(), 'info', 7000); return; }
    const incident = state.detail;
    const data = state.candidates.get(incident.id);
    const meta = agencyMeta[agencyCode] || agencyMeta.GENERAL;
    if (!data) {
      toast('Still scanning', 'Candidate search has not completed yet. Try again in a moment.', 'info');
      return;
    }
    const candidates = data[agencyCode]?.candidates || [];
    const body = `<div class="space-y-3">
      <div class="flex items-center gap-2.5 rounded-xl border border-line-soft bg-panel-2 p-3">
        <span class="flex h-9 w-9 items-center justify-center rounded-lg border" style="border-color:${meta.color}44;background:${meta.color}14;color:${meta.color}">
          <span class="material-symbols-outlined text-[19px]">${meta.icon}</span>
        </span>
        <div class="min-w-0 flex-1">
          <p class="text-[12px] font-bold text-text">${esc(meta.label)} candidates</p>
          <p class="mt-0.5 truncate text-[10px] text-dim">${esc(incident.code)} · ${esc(incident.address || '')}</p>
        </div>
        <span class="badge badge-muted">${candidates.length} found</span>
      </div>
      ${candidates.length ? candidates.map((candidate, index) => `<div class="flex items-center gap-2.5 rounded-xl border border-line-soft bg-panel-2 p-2.5">
        <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-full border font-mono text-[10px] font-bold" style="border-color:${meta.color}55;background:${meta.color}12;color:${meta.color}">${index + 1}</span>
        <div class="min-w-0 flex-1">
          <div class="flex flex-wrap items-center gap-1.5">
            <p class="data text-[12px] font-bold text-text">${esc(candidate.callSign)}</p>
            <span class="badge badge-muted">${esc(candidate.status)}</span>
            ${syncBadgeHtml(candidate)}
            ${candidate.isSameState === false ? `<span class="badge badge-warn font-mono !text-[7px]">MUTUAL AID · ${esc(candidate.stateCode || '')}</span>` : `<span class="badge badge-muted font-mono !text-[7px]">${esc(candidate.stateCode || '')}</span>`}
            ${candidate.batteryPct != null ? `<span class="badge ${candidate.batteryPct < 25 ? 'badge-p1' : 'badge-muted'}">${Math.round(candidate.batteryPct)}%</span>` : ''}
          </div>
          <p class="mt-0.5 truncate text-[9px] text-dim">${esc(candidate.vehicleType || meta.label)} · ${esc(candidate.station || '')} · ${S.formatCoord ? esc(S.formatCoord(candidate.lat, candidate.lng)) : ''}</p>
          <p class="mt-1 flex flex-wrap items-center gap-2 font-mono text-[9px] text-muted">
            <span>${index === 0 ? 'Nearest · ' : ''}${S.formatDistanceKm(candidate.distanceKm)}</span><span class="text-dim">·</span>
            <span>ETA ${S.formatEta(candidate.etaMinutes)}</span>
          </p>
        </div>
        <div class="flex shrink-0 flex-col items-end gap-1">
          <button type="button" class="btn btn-ghost btn-sm" data-locate-candidate="${candidate.id}" title="Fly the command map to this unit">
            <span class="material-symbols-outlined text-[14px]">my_location</span>Locate
          </button>
          <button type="button" class="btn ${candidate.status === 'available' ? 'btn-primary' : 'btn-quiet'} btn-sm" data-dispatch="${candidate.id}" data-agency="${agencyCode}">Dispatch</button>
        </div>
      </div>`).join('') : `<div class="rounded-xl border border-dashed border-line p-6 text-center">
        <span class="material-symbols-outlined text-[28px] text-dim">search_off</span>
        <p class="mt-1 text-[12px] font-bold text-text">No ${esc(meta.short.toLowerCase())} unit available nearby</p>
        <p class="mt-1 text-[10px] leading-relaxed text-dim">No available ${esc(meta.label.toLowerCase())} unit is live right now. The search already covered the national fleet nearest the citizen SOS — try another agency or wait for a unit to clear.</p>
      </div>`}
      <p class="font-mono text-[8px] leading-relaxed text-dim">Ranked nearest-first by distance from the citizen SOS location (national fleet; same-state preferred only on a tie). “SYNCING LIVE” means the terminal is online and its GPS is fresh.</p>
    </div>`;

    const dialog = S.modal({
      title: `Dispatch ${meta.label}`,
      subtitle: `${incident.code} · ${candidates.length} ranked candidate${candidates.length === 1 ? '' : 's'}`,
      body,
      footer: `<button class="btn btn-ghost" data-close>Cancel</button>
               ${candidates[0] ? `<button class="btn btn-primary" data-nearest>Dispatch nearest · ${esc(candidates[0].callSign)}</button>` : ''}`
    });

    const run = async (button, responderId) => {
      button.disabled = true;
      const original = button.innerHTML;
      button.innerHTML = '<span class="material-symbols-outlined animate-spin text-[15px]">progress_activity</span> Assigning';
      try {
        await dispatchUnit({ agencyCode, responderId, incidentId: incident.id });
        dialog.close();
      } catch (error) {
        toast('Dispatch failed', error.message, 'error', 6500);
        button.disabled = false;
        button.innerHTML = original;
      }
    };

    dialog.el.querySelectorAll('[data-dispatch]').forEach((button) => {
      button.addEventListener('click', () => run(button, Number(button.dataset.dispatch)));
    });
    dialog.el.querySelectorAll('[data-locate-candidate]').forEach((button) => {
      button.addEventListener('click', () => {
        if (locateUnit(Number(button.dataset.locateCandidate), { fly: true })) {
          toast('Locating unit', 'The map is flying to that vehicle.', 'info', 2500);
        }
      });
    });
    dialog.el.querySelector('[data-nearest]')?.addEventListener('click', (event) => {
      run(event.currentTarget, Number(candidates[0].id));
    });
  }

  async function resolveSelected(status) {
    if (!state.detail) return;
    const incident = state.detail;
    const isResolve = status === 'resolved';
    const confirmed = await S.confirmDialog({
      title: isResolve ? 'Resolve incident?' : 'Cancel incident?',
      body: isResolve
        ? `This closes <strong class="text-text">${esc(incident.code)}</strong>, marks all assigned units complete and releases them back to the fleet.`
        : `This cancels <strong class="text-text">${esc(incident.code)}</strong> and releases any responding units. Use this only if the alert is false or duplicated.`,
      confirmLabel: isResolve ? 'Resolve incident' : 'Cancel incident',
      danger: !isResolve
    });
    if (!confirmed) return;
    try {
      const { incident: updated } = await api(`/api/incidents/${incident.id}/resolve`, {
        method: 'POST',
        body: {
          status,
          actor: DISPATCHER.name,
          note: isResolve ? 'Closed by command centre' : 'Cancelled by command centre'
        }
      });
      stopViewer();
      applyDetail(updated, { forceRender: true });
      toast(isResolve ? 'Incident resolved' : 'Incident cancelled', `${updated.code} has been closed.`, 'success');
    } catch (error) {
      toast('Could not close incident', error.message, 'error');
    }
  }

  // -------------------------------------------------------------------------
  // Comms
  // -------------------------------------------------------------------------
  async function submitNote(form) {
    if (!state.detail) return;
    const body = form.querySelector('#noteBody')?.value.trim();
    if (!body) return;
    const pinned = !!form.querySelector('#notePinned')?.checked;
    try {
      const { note } = await api(`/api/incidents/${state.detail.id}/notes`, {
        method: 'POST',
        body: { body, pinned, authorName: DISPATCHER.name, authorId: DISPATCHER.id }
      });
      const incident = state.detail;
      incident.notes = incident.notes || [];
      if (!incident.notes.some((n) => n.id === note.id)) incident.notes.push(note);
      incident.notes.sort((a, b) => Number(b.pinned) - Number(a.pinned) || new Date(b.createdAt) - new Date(a.createdAt));
      const textarea = form.querySelector('#noteBody');
      if (textarea) textarea.value = '';
      const checkbox = form.querySelector('#notePinned');
      if (checkbox) checkbox.checked = false;
      renderDetail();
      toast(pinned ? 'Pinned note added' : 'Note added', 'The responding crew can see this immediately.', 'success');
    } catch (error) {
      toast('Note not saved', error.message, 'error');
    }
  }

  async function submitChat(form) {
    if (!state.detail) return;
    const input = form.querySelector('#detailChatInput');
    const body = input?.value.trim();
    if (!body) return;
    if (input) input.value = '';
    try {
      const { message } = await api(`/api/incidents/${state.detail.id}/messages`, {
        method: 'POST',
        body: { senderType: 'dispatcher', senderId: DISPATCHER.id, senderName: DISPATCHER.name, body }
      });
      const incident = state.detail;
      incident.messages = incident.messages || [];
      if (!incident.messages.some((m) => m.id === message.id)) incident.messages.push(message);
      renderDetail();
      input?.focus();
    } catch (error) {
      toast('Message not sent', error.message, 'error');
    }
  }

  async function takeOverAi() {
    if (!state.detail) return;
    try {
      const { ai } = await api(`/api/incidents/${state.detail.id}/ai/takeover`, {
        method: 'POST', body: { agentName: DISPATCHER.name }
      });
      state.detail.ai = ai;
      toast('You are now the human agent', 'The AI has handed the caller to you. The incident stays open until the responder arrives.', 'success');
      renderDetail();
    } catch (error) {
      toast('Could not take over', error.message, 'error');
    }
  }

  async function releaseAi() {
    if (!state.detail) return;
    try {
      const { ai } = await api(`/api/incidents/${state.detail.id}/ai/release`, { method: 'POST' });
      state.detail.ai = ai;
      toast('Returned to AI', 'The AI is supporting the caller again.', 'info');
      renderDetail();
    } catch (error) {
      toast('Could not return to AI', error.message, 'error');
    }
  }

  async function submitAiMessage(form) {
    if (!state.detail) return;
    const input = form.querySelector('#aiMessageInput');
    const body = input?.value.trim();
    if (!body) return;
    if (input) input.value = '';
    try {
      const { ai } = await api(`/api/incidents/${state.detail.id}/ai/agent-message`, {
        method: 'POST', body: { body, agentName: DISPATCHER.name }
      });
      state.detail.ai = ai;
      renderDetail();
    } catch (error) {
      toast('Message not sent', error.message, 'error');
    }
  }

  // -------------------------------------------------------------------------
  // Emergency call engagement (State EOC owns the line)
  // -------------------------------------------------------------------------
  function stopCallViewer() {
    if (state.callViewer) {
      try { state.callViewer.destroy?.(); } catch { /* already stopped */ }
      state.callViewer = null;
    }
    if (state.callMicStream) {
      state.callMicStream.getTracks().forEach((track) => { track.enabled = false; try { track.stop(); } catch { } });
      state.callMicStream = null;
    }
  }

  async function loadRecordingAudio(recordingId, elementId) {
    const audio = document.getElementById(elementId);
    if (!audio) return null;
    if (!audio.dataset.loaded) {
      const token = S.authToken?.();
      const response = await fetch(`/api/recordings/${recordingId}/audio`, {
        headers: token ? { Authorization: `Bearer ${token}` } : {}
      });
      if (!response.ok) {
        let message = `Audio unavailable (${response.status})`;
        try { message = (await response.json()).error || message; } catch { /* binary */ }
        throw new Error(message);
      }
      const blob = await response.blob();
      audio.src = URL.createObjectURL(blob);
      audio.dataset.loaded = '1';
      audio.classList.remove('hidden');
    }
    return audio;
  }

  async function playRecording(recordingId, elementId) {
    try {
      const audio = await loadRecordingAudio(Number(recordingId), elementId);
      if (!audio) return;
      await audio.play().catch(() => { });
    } catch (error) {
      toast('Recording unavailable', error.message, 'error');
    }
  }

  async function openCallLine() {
    if (!state.detail) return;
    try {
      const { call } = await api(`/api/incidents/${state.detail.id}/call`, { method: 'POST', body: {} });
      state.detail.call = call;
      renderDetail();
      toast('Call line opened', 'The citizen line is ringing. Claim it to speak and record.', 'success');
    } catch (error) {
      toast('Could not open call line', error.message, 'error');
    }
  }

  async function claimSelectedCall() {
    if (!state.detail) return;
    if (!canDispatch()) { toast('State EOC handles calls', 'NEMA is national oversight and cannot claim the citizen line.', 'info', 7000); return; }
    const buttons = $$('[data-action="call-claim"]');
    buttons.forEach((button) => { button.disabled = true; });
    try {
      const { call } = await api(`/api/incidents/${state.detail.id}/call/claim`, {
        method: 'POST', body: { actorName: DISPATCHER.name }
      });
      state.detail.call = call;
      renderDetail();
      toast('Call claimed', `${call.claimedByName || DISPATCHER.name} is on the line. Audio is recording for NEMA oversight.`, 'success', 6000);
      if (state.detail.call?.status === 'connected') openCallConsole();
    } catch (error) {
      toast('Could not claim call', error.message, 'error', 6000);
    } finally {
      buttons.forEach((button) => { button.disabled = false; });
    }
  }

  async function endSelectedCall() {
    if (!state.detail) return;
    if (!canDispatch()) { toast('State EOC handles calls', 'NEMA cannot end the state-owned citizen line.', 'info', 6000); return; }
    const confirmed = await S.confirmDialog({
      title: 'End the emergency call?',
      body: 'The citizen stays connected to the incident, but the State EOC line closes and the audio recording is finalised for NEMA review.',
      confirmLabel: 'End call',
      danger: true
    });
    if (!confirmed) return;
    try {
      const { call } = await api(`/api/incidents/${state.detail.id}/call/end`, {
        method: 'POST', body: { reason: 'Call ended by the State EOC' }
      });
      state.detail.call = call;
      stopCallViewer();
      renderDetail();
      toast('Call ended', 'The recording is saved for NEMA and Super Admin observation.', 'info', 6000);
    } catch (error) {
      toast('Could not end call', error.message, 'error');
    }
  }

  async function exportCaseRecord() {
    if (!state.detail) return;
    try {
      const { incident } = await api(`/api/incidents/${state.detail.id}`);
      const record = {
        exportedAt: new Date().toISOString(),
        exportedBy: DISPATCHER.name,
        incident,
        call: incident.call || null,
        events: incident.events || [],
        assignments: incident.activeAssignments || []
      };
      const blob = new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement('a');
      anchor.href = url;
      anchor.download = `${incident.code}-case-record.json`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      setTimeout(() => URL.revokeObjectURL(url), 2000);
      toast('Case record exported', `${incident.code} tracking, call metadata and event log downloaded.`, 'success');
    } catch (error) {
      toast('Export failed', error.message, 'error');
    }
  }

  function openCallConsole() {
    if (!state.detail) return;
    const incident = state.detail;
    const call = incident.call;
    const recordings = call?.recordings || [];
    const radioUnits = (incident.activeAssignments || []).filter((assignment) => assignment.responderId);
    const canHandle = canDispatch();
    stopCallViewer();
    stopViewer();

    const dialog = S.modal({
      title: `Emergency call · ${incident.code}`,
      subtitle: canHandle
        ? 'State EOC line — citizen audio, agent microphone and NEMA-observed recording'
        : 'NEMA national oversight — listen only',
      wide: true,
      body: `<div class="space-y-3">
        <div class="relative aspect-video overflow-hidden rounded-xl border border-line bg-[radial-gradient(circle_at_50%_38%,#15201f,#070909)]">
          <video id="callConsoleMedia" class="h-full w-full object-cover" autoplay playsinline></video>
          <div id="callConsoleOverlay" class="absolute inset-0 flex flex-col items-center justify-center gap-2 px-6 text-center">
            <span class="flex h-14 w-14 items-center justify-center rounded-full border border-line bg-panel-2 text-alert">
              <span id="callConsoleIcon" class="material-symbols-outlined text-[26px]">phone_in_talk</span>
            </span>
            <p id="callConsoleTitle" class="text-[12px] font-bold text-text">Connecting to the citizen line…</p>
            <p id="callConsoleBody" class="max-w-[320px] text-[10px] leading-relaxed text-dim">The citizen must allow their microphone. The State EOC can then hear them and speak back.</p>
          </div>
          <div class="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between p-2">
            <span class="badge badge-muted bg-black/60"><span class="material-symbols-outlined !text-[12px]">shield_person</span> ${canHandle ? 'State EOC' : 'NEMA oversight'}</span>
            <span id="callConsoleLive" class="badge badge-alert hidden"><span class="live-dot live-dot--red"></span> LIVE</span>
          </div>
        </div>
        <div class="flex items-center justify-between gap-2 rounded-lg border border-line-soft bg-panel-2 px-3 py-2">
          <p id="callConsoleStatus" class="text-[10px] text-muted">${call ? `${call.status.toUpperCase()} · ${esc(call.claimedByName || 'Unclaimed')}` : 'No call session'}</p>
          <span class="font-mono text-[8px] text-dim">WebRTC · recorded</span>
        </div>
        ${canHandle ? `<div class="flex flex-wrap gap-1.5">
          <button id="callConsoleSpeak" type="button" class="btn btn-primary btn-sm flex-1"><span class="material-symbols-outlined text-[15px]">mic</span>Start speaking</button>
          <button id="callConsoleRequest" type="button" class="btn btn-ghost btn-sm"><span class="material-symbols-outlined text-[15px]">play_circle</span>Request audio</button>
          ${call?.isActive ? `<button id="callConsoleEnd" type="button" class="btn btn-quiet btn-sm"><span class="material-symbols-outlined text-[15px]">call_end</span>End call</button>` : ''}
        </div>` : `<p class="rounded-lg border border-line-soft bg-panel-2 px-3 py-2 text-[9px] leading-relaxed text-dim">Oversight mode: the responsible State EOC owns this line. You can listen and review the saved recording.</p>`}
        ${canHandle ? `<div class="rounded-xl border border-line-soft bg-panel-2 p-2.5">
          <div class="flex items-center justify-between gap-2">
            <p class="panel-title !text-[9px] flex items-center gap-1.5"><span class="material-symbols-outlined text-[14px]">radio</span>Responder radio · PTT</p>
            <span class="badge badge-muted font-mono !text-[7px]">${radioUnits.length} linked</span>
          </div>
          ${radioUnits.length ? `<div class="mt-2 space-y-1.5">${radioUnits.map((assignment) => `<div class="flex items-center gap-2 rounded-lg border border-line-soft bg-panel p-2">
            <div class="min-w-0 flex-1">
              <p class="data truncate text-[10.5px] font-bold text-text">${esc(assignment.callSign)}</p>
              <p id="callPttStatus-${assignment.responderId}" class="mt-0.5 font-mono text-[8px] text-dim" style="--badge-accent:#7ddba8"><span class="live-dot mr-1"></span>RADIO STANDBY</p>
            </div>
            <button type="button" id="callPttBtn-${assignment.responderId}" data-action="ptt-press" data-unit-id="${assignment.responderId}" data-callsign="${esc(assignment.callSign)}" class="btn btn-nema btn-sm select-none ptt-button">
              <span class="material-symbols-outlined text-[15px]">radio</span>
              <span id="callPttBtnLabel-${assignment.responderId}">HOLD TO TALK</span>
            </button>
          </div>`).join('')}</div>` : `<p class="mt-1.5 text-[9px] leading-relaxed text-dim">No first responder has accepted this incident yet. Dispatch/alerts are sent from the incident panel; once a crew accepts, its radio channel appears here so you can talk to them without leaving the citizen call.</p>`}
        </div>` : ''}
        <div class="flex items-center justify-between gap-2 border-t border-line-soft pt-2">
          <p class="panel-title !text-[9px]">Recorded call audio</p>
          <span class="badge badge-muted">${recordings.length}</span>
        </div>
        <div class="space-y-1.5">${recordings.length ? recordings.map((recording) => `<div class="rounded-lg border border-line-soft bg-panel p-2">
          <div class="flex items-center justify-between gap-2">
            <p class="truncate font-mono text-[9px] text-text">${S.clockTime(recording.createdAt)} · ${Math.round(Number(recording.durationSeconds) || 0)}s · ${Math.round(Number(recording.bytes || 0) / 1024)} KB</p>
            <button type="button" data-action="play-recording" data-recording="${recording.id}" data-audio="consoleRecordingAudio-${recording.id}" class="btn btn-ghost btn-sm shrink-0" ${recording.isPlayable ? '' : 'disabled'}>
              <span class="material-symbols-outlined text-[15px]">play_arrow</span>Play
            </button>
          </div>
          <audio id="consoleRecordingAudio-${recording.id}" class="mt-1.5 hidden w-full" controls preload="none"></audio>
        </div>`).join('') : '<p class="text-[9px] text-dim">No audio uploaded yet.</p>'}</div>
      </div>`,
      footer: `<button class="btn btn-ghost" data-close>Close</button>`,
      onClose: stopCallViewer
    });

    const video = dialog.el.querySelector('#callConsoleMedia');
    const overlay = dialog.el.querySelector('#callConsoleOverlay');
    const overlayIcon = dialog.el.querySelector('#callConsoleIcon');
    const overlayTitle = dialog.el.querySelector('#callConsoleTitle');
    const overlayBody = dialog.el.querySelector('#callConsoleBody');
    const statusEl = dialog.el.querySelector('#callConsoleStatus');
    const liveBadge = dialog.el.querySelector('#callConsoleLive');
    const speakBtn = dialog.el.querySelector('#callConsoleSpeak');
    const requestBtn = dialog.el.querySelector('#callConsoleRequest');
    const endBtn = dialog.el.querySelector('#callConsoleEnd');

    const setCallState = (name) => {
      const copy = {
        requesting: ['Calling the citizen line…', 'Asking the citizen device to share the call audio.', 'phone_forwarded'],
        waiting: ['Waiting for the citizen', 'The request reached the incident room. The citizen may still be allowing their microphone.', 'hourglass_top'],
        connecting: ['Securing the line', 'WebRTC is negotiating the citizen audio stream.', 'sync'],
        live: ['Citizen line live', 'You are listening to the caller. Use “Start speaking” to talk back.', 'graphic_eq'],
        ended: ['Line ended', 'The call has closed. The recording remains available for review.', 'call_end'],
        failed: ['Line failed', 'Media negotiation failed. Check microphone permissions and request the line again.', 'error'],
        'tap-to-play': ['Tap to listen', 'The browser blocked autoplay. Click the media area to start audio.', 'play_circle'],
        unsupported: ['WebRTC unavailable', 'This browser cannot open a live call line.', 'block']
      }[name] || ['Waiting', 'No media attached yet.', 'phone_in_talk'];
      statusEl.textContent = name === 'live' ? 'LIVE · citizen audio connected' : copy[0];
      overlayIcon.textContent = copy[2];
      overlayTitle.textContent = copy[0];
      overlayBody.textContent = copy[1];
      liveBadge.classList.toggle('hidden', name !== 'live');
      overlay.classList.toggle('hidden', name === 'live');
      if (name === 'live') video.play().catch(() => { });
    };

    state.callViewer = NaijaSOSWebRTC.createViewer({
      socket,
      incidentId: incident.id,
      videoEl: video,
      viewerName: DISPATCHER.name,
      onState: setCallState
    });

    const request = () => {
      stopCallViewer();
      if (state.callMicStream) {
        const stream = state.callMicStream;
        state.callMicStream = null;
        stream.getTracks().forEach((track) => track.stop());
      }
      state.callViewer = NaijaSOSWebRTC.createViewer({
        socket, incidentId: incident.id, videoEl: video,
        viewerName: DISPATCHER.name, onState: setCallState
      });
      state.callViewer.request();
      setCallState('requesting');
    };

    requestBtn?.addEventListener('click', request);
    video.addEventListener('click', () => video.play().catch(() => { }));
    request();

    speakBtn?.addEventListener('click', async () => {
      if (state.callMicStream) {
        state.callMicStream.getTracks().forEach((track) => { track.enabled = false; track.stop(); });
        state.callMicStream = null;
        state.callViewer?.setMicStream(null);
        speakBtn.innerHTML = '<span class="material-symbols-outlined text-[15px]">mic</span>Start speaking';
        toast('Agent microphone off', 'The citizen can no longer hear you. Recording continues.', 'info', 3000);
        return;
      }
      if (!navigator.mediaDevices?.getUserMedia) {
        toast('Microphone unavailable', 'This browser cannot access a microphone.', 'error');
        return;
      }
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
        });
        state.callMicStream = stream;
        state.callViewer?.setMicStream(stream);
        speakBtn.innerHTML = '<span class="material-symbols-outlined text-[15px]">mic_off</span>Stop speaking';
        toast('Agent microphone live', 'The citizen can hear you now. Both sides are mixed into the NEMA recording.', 'success', 4000);
      } catch (error) {
        toast('Microphone blocked', error.name === 'NotAllowedError' ? 'Allow microphone access to speak back to the caller.' : error.message, 'error', 6000);
      }
    });

    endBtn?.addEventListener('click', async () => {
      await endSelectedCall();
      dialog.close();
    });
  }

  // -------------------------------------------------------------------------
  // Live feed viewer
  // -------------------------------------------------------------------------
  function stopViewer() {
    if (state.viewer) {
      try { state.viewer.destroy?.(); } catch { /* already stopped */ }
      state.viewer = null;
    }
    state.viewerIncidentId = null;
  }

  function openScenePhoto() {
    if (!state.detail?.photoUrl) return;
    const incident = state.detail;
    const src = `${incident.photoUrl}?token=${encodeURIComponent(S.authToken?.() || '')}`;
    S.modal({
      title: `Citizen SOS photo · ${incident.code}`,
      subtitle: 'Captured or attached by the citizen device when the SOS was sent',
      wide: true,
      body: `<div class="overflow-hidden rounded-xl border border-line bg-black">
        <img src="${esc(src)}" alt="Citizen SOS scene photo for ${esc(incident.code)}" class="w-full object-contain" style="max-height:68vh" />
      </div>
      <p class="mt-2 text-[10px] leading-relaxed text-dim">This is the image the citizen sent with the alert. It stays linked to the incident record for State EOC review and NEMA oversight.</p>`,
      footer: `<a class="btn btn-ghost" href="${esc(src)}" download="${esc(incident.code)}-scene.jpg" target="_blank" rel="noopener"><span class="material-symbols-outlined text-[16px]">download</span>Download</a>
               <button class="btn btn-primary" data-close>Close</button>`
    });
  }

  function openFeedModal() {
    if (!state.detail) return;
    const incident = state.detail;
    stopViewer();

    const dialog = S.modal({
      title: `Live feed · ${incident.code}`,
      subtitle: 'Peer-to-peer WebRTC viewer — media does not pass through the server',
      wide: true,
      body: `<div class="space-y-3">
        <div class="relative aspect-video overflow-hidden rounded-xl border border-line bg-black">
          <video id="dispatchFeedVideo" class="h-full w-full object-cover" autoplay playsinline></video>
          <div id="feedOverlay" class="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-[radial-gradient(circle_at_50%_40%,#1c2828,#080a0a)] px-6 text-center">
            <span class="flex h-12 w-12 items-center justify-center rounded-full border border-line bg-panel-2 text-dim">
              <span id="feedOverlayIcon" class="material-symbols-outlined text-[24px]">videocam</span>
            </span>
            <p id="feedOverlayTitle" class="text-[12px] font-bold text-text">Ready to request</p>
            <p id="feedOverlayBody" class="max-w-[320px] text-[10px] leading-relaxed text-dim">The citizen must have started their feed. Requesting opens a direct WebRTC session from the citizen's device.</p>
          </div>
          <div class="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between p-2">
            <span class="badge badge-muted bg-black/60"><span class="material-symbols-outlined !text-[12px]">lock</span> Responders only</span>
            <span id="feedLiveBadge" class="badge badge-alert hidden"><span class="live-dot live-dot--red"></span> LIVE</span>
          </div>
        </div>
        <div class="flex items-center justify-between gap-2 rounded-lg border border-line-soft bg-panel-2 px-3 py-2">
          <p id="feedStatus" class="text-[10px] text-muted">No media requested yet.</p>
          <span class="font-mono text-[8px] text-dim">WebRTC · STUN</span>
        </div>
        <p class="text-[10px] leading-relaxed text-dim">${incident.media ? 'A media session is registered. If the citizen is still switching the camera on, the viewer will wait for their offer.' : 'No media session yet. Ask the citizen to press “Start feed” on their SOS screen, then request again.'}</p>
      </div>`,
      footer: `<button class="btn btn-ghost" data-close>Close</button>
               <button id="feedStop" class="btn btn-ghost hidden">Stop stream</button>
               <button id="feedRequest" class="btn btn-primary"><span class="material-symbols-outlined text-[17px]">play_circle</span>Request stream</button>`,
      onClose: stopViewer
    });

    const video = dialog.el.querySelector('#dispatchFeedVideo');
    const overlay = dialog.el.querySelector('#feedOverlay');
    const overlayIcon = dialog.el.querySelector('#feedOverlayIcon');
    const overlayTitle = dialog.el.querySelector('#feedOverlayTitle');
    const overlayBody = dialog.el.querySelector('#feedOverlayBody');
    const statusEl = dialog.el.querySelector('#feedStatus');
    const liveBadge = dialog.el.querySelector('#feedLiveBadge');
    const requestBtn = dialog.el.querySelector('#feedRequest');
    const stopBtn = dialog.el.querySelector('#feedStop');

    const setViewerState = (name) => {
      const copy = {
        requesting: ['Connecting…', 'Asking the citizen device for its stream.', 'wifi_tethering'],
        waiting: ['Waiting for citizen', 'The request reached the incident room, but the citizen has not started a feed yet. You can leave this open.', 'hourglass_top'],
        connecting: ['Negotiating media', 'WebRTC is exchanging session descriptions and ICE candidates.', 'sync'],
        live: ['Live', 'Direct peer-to-peer stream from the citizen device.', 'videocam'],
        ended: ['Stream ended', 'The citizen stopped sharing. You can request again while the incident is open.', 'videocam_off'],
        failed: ['Stream failed', 'The media negotiation failed. Check camera permissions and network connectivity, then request again.', 'error'],
        'tap-to-play': ['Tap to play', 'Your browser blocked autoplay. Click the video area to start playback.', 'play_circle'],
        unsupported: ['WebRTC unavailable', 'This browser does not support WebRTC media sessions.', 'block']
      }[name] || ['Waiting', 'No stream is attached yet.', 'videocam'];
      statusEl.textContent = name === 'live' ? 'Live · peer-to-peer' : copy[0];
      overlayIcon.textContent = copy[2];
      overlayTitle.textContent = copy[0];
      overlayBody.textContent = copy[1];
      const isLive = name === 'live';
      liveBadge.classList.toggle('hidden', !isLive);
      overlay.classList.toggle('hidden', isLive);
      if (isLive) {
        video.play().catch(() => {});
        requestBtn.classList.add('hidden');
        stopBtn.classList.remove('hidden');
      } else if (name === 'ended' || name === 'failed') {
        requestBtn.classList.remove('hidden');
        stopBtn.classList.add('hidden');
      }
    };

    state.viewer = NaijaSOSWebRTC.createViewer({
      socket,
      incidentId: incident.id,
      videoEl: video,
      viewerName: DISPATCHER.name,
      onState: setViewerState
    });
    state.viewerIncidentId = incident.id;

    requestBtn.addEventListener('click', () => {
      stopViewer();
      state.viewer = NaijaSOSWebRTC.createViewer({
        socket, incidentId: incident.id, videoEl: video,
        viewerName: DISPATCHER.name, onState: setViewerState
      });
      state.viewerIncidentId = incident.id;
      state.viewer.request();
      setViewerState('requesting');
      requestBtn.classList.add('hidden');
      stopBtn.classList.remove('hidden');
    });
    stopBtn.addEventListener('click', () => {
      stopViewer();
      setViewerState('ended');
    });
  }

  // -------------------------------------------------------------------------
  // Modals: intake, fleet, agencies, analytics, settings
  // -------------------------------------------------------------------------
  function openCreateIncident(prefill = {}) {
    const center = prefill.lat != null ? { lat: prefill.lat, lng: prefill.lng } : (state.map?.getCenter() || { lat: S.LAGOS_CENTRE[0], lng: S.LAGOS_CENTRE[1] });
    const dialog = S.modal({
      title: 'Create incident',
      subtitle: 'Manual phone / radio intake · dispatcher-created',
      wide: true,
      body: `<form id="newIncidentForm" class="space-y-3">
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block">
            <span class="field-label">Emergency type</span>
            <select name="type" class="select text-[12px]">
              <option value="medical">Medical</option>
              <option value="police">Police</option>
              <option value="fire">Fire</option>
              <option value="road_safety">Road safety</option>
              <option value="general">General SOS / multi-agency</option>
            </select>
          </label>
          <label class="block">
            <span class="field-label">Priority</span>
            <select name="priority" class="select text-[12px]">
              <option value="">Auto by type</option>
              <option value="1">P1 · Critical</option>
              <option value="2">P2 · Urgent</option>
              <option value="3">P3 · Routine</option>
              <option value="4">P4 · Low</option>
            </select>
          </label>
        </div>
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block">
            <span class="field-label">Caller name</span>
            <input name="reporterName" class="input text-[12px]" value="Phone caller" autocomplete="off" />
          </label>
          <label class="block">
            <span class="field-label">Callback number</span>
            <input name="reporterPhone" class="input text-[12px]" placeholder="+234…" autocomplete="off" />
          </label>
        </div>
        <label class="block">
          <span class="field-label">Address / location description</span>
          <input name="address" class="input text-[12px]" placeholder="e.g. Opebi Road, Ikeja" value="${esc(prefill.address || '')}" autocomplete="off" />
        </label>
        <label class="block">
          <span class="field-label">Landmark</span>
          <input name="landmark" class="input text-[12px]" placeholder="e.g. Opposite Opebi Roundabout" autocomplete="off" />
        </label>
        <label class="block">
          <span class="field-label">Situation notes</span>
          <textarea name="description" class="textarea min-h-[76px] text-[12px]" maxlength="1000" placeholder="What is happening, who is affected, what can the crew expect?"></textarea>
        </label>
        <div class="grid gap-3 sm:grid-cols-3">
          <label class="block">
            <span class="field-label">Latitude</span>
            <input name="lat" class="input data text-[12px]" value="${Number(center.lat).toFixed(6)}" inputmode="decimal" />
          </label>
          <label class="block">
            <span class="field-label">Longitude</span>
            <input name="lng" class="input data text-[12px]" value="${Number(center.lng).toFixed(6)}" inputmode="decimal" />
          </label>
          <label class="block">
            <span class="field-label">People affected</span>
            <input name="peopleAffected" class="input text-[12px]" type="number" min="1" max="999" value="1" />
          </label>
        </div>
        <div class="flex flex-wrap items-center justify-between gap-2">
          <button type="button" data-use-center class="btn btn-quiet btn-sm"><span class="material-symbols-outlined text-[15px]">my_location</span>Use map centre</button>
          <label class="block flex-1 sm:max-w-[280px]">
            <span class="field-label">Hazards (comma separated)</span>
            <input name="hazards" class="input h-8 text-[11px]" placeholder="Weapons, Traffic, Fire" />
          </label>
        </div>
      </form>`,
      footer: `<button class="btn btn-ghost" data-close>Cancel</button>
               <button type="submit" form="newIncidentForm" class="btn btn-primary"><span class="material-symbols-outlined text-[17px]">add_alert</span>Create incident</button>`
    });

    const form = dialog.el.querySelector('#newIncidentForm');
    dialog.el.querySelector('[data-use-center]')?.addEventListener('click', () => {
      const c = state.map?.getCenter();
      if (!c) return;
      form.elements.lat.value = c.lat.toFixed(6);
      form.elements.lng.value = c.lng.toFixed(6);
    });
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const data = new FormData(form);
      const lat = Number(data.get('lat'));
      const lng = Number(data.get('lng'));
      if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
        toast('Invalid coordinates', 'Enter a valid latitude and longitude or use the map centre.', 'error');
        return;
      }
      const payload = {
        type: data.get('type'),
        lat,
        lng,
        address: String(data.get('address') || '').trim(),
        landmark: String(data.get('landmark') || '').trim() || null,
        description: String(data.get('description') || '').trim(),
        reporterName: String(data.get('reporterName') || 'Phone caller').trim(),
        reporterPhone: String(data.get('reporterPhone') || '').trim() || null,
        peopleAffected: Number(data.get('peopleAffected')) || 1,
        hazards: String(data.get('hazards') || '').split(',').map((h) => h.trim()).filter(Boolean),
        source: 'phone',
        liveTracking: false,
        createdByRole: 'dispatcher'
      };
      if (data.get('priority')) payload.priority = Number(data.get('priority'));
      const submit = dialog.el.querySelector('[type="submit"][form="newIncidentForm"]');
      if (submit) { submit.disabled = true; submit.textContent = 'Creating…'; }
      try {
        const result = await api('/api/incidents', { method: 'POST', body: payload });
        dialog.close();
        state.selectedId = null;
        applyDetail(result.incident, { forceRender: true });
        toast('Incident created', `${result.incident.code} entered the live queue.`, 'success');
        selectIncident(result.incident.id);
      } catch (error) {
        toast('Could not create incident', error.message, 'error');
        if (submit) { submit.disabled = false; submit.textContent = 'Create incident'; }
      }
    });
  }

  function openFleetModal() {
    const groups = AGENCY_ORDER.map((code) => ({
      code,
      meta: agencyMeta[code],
      units: unitList().filter((u) => u.agencyCode === code)
    }));
    const body = `<div class="space-y-4">
      ${groups.map((group) => `<section>
        <div class="mb-2 flex items-center justify-between">
          <h3 class="flex items-center gap-2 text-[12px] font-bold text-text">
            <span class="material-symbols-outlined text-[17px]" style="color:${group.meta.color}">${group.meta.icon}</span>${esc(group.meta.label)}
          </h3>
          <span class="badge badge-muted">${group.units.filter((u) => u.status === 'available').length}/${group.units.length} ready</span>
        </div>
        <div class="panel-2 divide-y divide-line-soft overflow-hidden">
          ${group.units.map((unit) => {
            const status = S.unitStatus[unit.status] || S.unitStatus.offline;
            return `<div class="flex items-center gap-2.5 p-2.5">
              <span class="h-2 w-2 shrink-0 rounded-full" style="background:${status.color}"></span>
              <div class="min-w-0 flex-1">
                <div class="flex items-center gap-1.5">
                  <p class="data text-[11px] font-bold text-text">${esc(unit.callSign)}</p>
                  <span class="badge" ${pill(status.color)}>${status.label}</span>
                  ${unit.activeIncidentCode ? `<span class="badge badge-muted">${esc(unit.activeIncidentCode)}</span>` : ''}
                </div>
                <p class="mt-0.5 truncate text-[9px] text-dim">${esc(unit.vehicleType)} · ${esc(unit.station)} · ${esc(unit.plateNumber)}</p>
              </div>
              <div class="shrink-0 text-right">
                <p class="data text-[10px] text-muted">${Math.round(unit.batteryPct || 0)}%</p>
                <p class="font-mono text-[8px] text-dim">${unit.isSimulated ? 'AVL sim' : 'tablet'}</p>
              </div>
            </div>`;
          }).join('') || '<p class="p-3 text-[10px] text-dim">No units configured.</p>'}
        </div>
      </section>`).join('')}
    </div>`;
    S.modal({
      title: 'Fleet &amp; units',
      subtitle: 'Live duty status, battery and assignment state',
      wide: true,
      body,
      footer: `<a href="/responder" target="_blank" rel="noopener" class="btn btn-ghost"><span class="material-symbols-outlined text-[16px]">tablet</span>Open field console</a><button class="btn btn-primary" data-close>Done</button>`
    });
  }

  function openAgenciesModal() {
    const body = `<div class="grid gap-3 sm:grid-cols-2">
      ${state.agencies.map((agency) => {
        const units = unitList().filter((u) => u.agencyCode === agency.code);
        const free = units.filter((u) => u.status === 'available').length;
        return `<div class="rounded-xl border border-line bg-panel-2 p-3">
          <div class="flex items-start gap-2.5">
            <span class="flex h-9 w-9 items-center justify-center rounded-lg border" style="border-color:${agency.color}44;background:${agency.color}14;color:${agency.color}">
              <span class="material-symbols-outlined text-[19px]">${agency.icon}</span>
            </span>
            <div class="min-w-0 flex-1">
              <p class="text-[12px] font-bold text-text">${esc(agency.shortName)}</p>
              <p class="mt-0.5 text-[9px] leading-snug text-dim">${esc(agency.name)}</p>
            </div>
            <span class="badge" ${pill(agency.isActive ? '#34d399' : '#727979')}>${agency.isActive ? 'online' : 'offline'}</span>
          </div>
          <dl class="mt-2.5 grid grid-cols-2 gap-2 text-[9px]">
            <div><dt class="text-dim">Units ready</dt><dd class="data mt-0.5 text-[12px] font-bold text-ok">${free}</dd></div>
            <div><dt class="text-dim">Fleet</dt><dd class="data mt-0.5 text-[12px] font-bold text-text">${units.length}</dd></div>
            <div class="col-span-2"><dt class="text-dim">Emergency number</dt><dd class="data mt-0.5 text-text">${esc(agency.emergencyNumber || '112')}</dd></div>
            <div class="col-span-2"><dt class="text-dim">Jurisdiction</dt><dd class="mt-0.5 text-text">${esc(agency.jurisdiction || 'Lagos State')}</dd></div>
          </dl>
        </div>`;
      }).join('')}
    </div>`;
    S.modal({
      title: 'Multi-agency directory',
      subtitle: 'Four agencies operating on the same incident bus',
      wide: true,
      body,
      footer: `<button class="btn btn-primary" data-close>Done</button>`
    });
  }

  function openAnalyticsModal() {
    const incidents = [...state.incidents.values()];
    const typeCounts = Object.keys(typeMeta).filter((key) => key !== 'general').map((key) => ({
      key, meta: typeMeta[key], count: incidents.filter((i) => i.type === key).length
    }));
    const max = Math.max(1, ...typeCounts.map((t) => t.count));
    const statusCounts = ['new', 'triage', 'dispatched', 'en_route', 'on_scene', 'transporting'].map((status) => ({
      status,
      meta: incidentStatus[status],
      count: incidents.filter((i) => i.status === status).length
    }));
    const avg = Number(state.stats?.avgResponseSeconds) || 0;
    const body = `<div class="space-y-4">
      <div class="grid grid-cols-3 gap-2">
        <div class="panel-2 p-3"><p class="data text-[22px] font-bold text-text">${incidents.length}</p><p class="mt-1 text-[8px] uppercase tracking-wide text-dim">Active</p></div>
        <div class="panel-2 p-3"><p class="data text-[22px] font-bold text-alert">${incidents.filter((i) => i.priority === 1).length}</p><p class="mt-1 text-[8px] uppercase tracking-wide text-dim">P1 critical</p></div>
        <div class="panel-2 p-3"><p class="data text-[22px] font-bold text-ok">${Math.floor(avg / 60)}:${String(avg % 60).padStart(2, '0')}</p><p class="mt-1 text-[8px] uppercase tracking-wide text-dim">Avg triage</p></div>
      </div>
      <section>
        <h3 class="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted">Demand by type</h3>
        <div class="space-y-2">
          ${typeCounts.map((entry) => `<div class="flex items-center gap-2">
            <span class="w-20 shrink-0 text-[10px] text-muted">${entry.meta.label}</span>
            <div class="h-2 flex-1 overflow-hidden rounded-full bg-white/[0.05]"><div class="h-full rounded-full" style="width:${Math.max(4, (entry.count / max) * 100)}%;background:${entry.meta.color}"></div></div>
            <span class="data w-5 text-right text-[10px] text-text">${entry.count}</span>
          </div>`).join('')}
        </div>
      </section>
      <section>
        <h3 class="mb-2 text-[11px] font-bold uppercase tracking-wide text-muted">Current pipeline</h3>
        <div class="grid grid-cols-3 gap-2">
          ${statusCounts.map((entry) => `<div class="rounded-lg border border-line-soft bg-panel-2 p-2">
            <p class="data text-[16px] font-bold" style="color:${entry.meta.color}">${entry.count}</p>
            <p class="mt-0.5 text-[8px] uppercase tracking-wide text-dim">${entry.meta.label}</p>
          </div>`).join('')}
        </div>
      </section>
      <p class="font-mono text-[8px] leading-relaxed text-dim">Analytics are computed live from the active incident set. In production this view would query the warehouse (response-time percentiles, agency SLA, geofence compliance).</p>
    </div>`;
    S.modal({
      title: 'Demand & performance',
      subtitle: 'Live operational analytics for the current shift',
      wide: true,
      body,
      footer: `<button class="btn btn-primary" data-close>Done</button>`
    });
  }

  function openSettingsModal() {
    const dialog = S.modal({
      title: 'Console settings',
      subtitle: 'Personal preferences for this browser',
      body: `<div class="space-y-3">
        <label class="flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-line-soft bg-panel-2 p-3">
          <span class="flex items-center gap-2.5"><span class="material-symbols-outlined text-[18px] text-muted">volume_up</span><span><span class="block text-[12px] font-bold text-text">Alert sounds</span><span class="block text-[9px] text-dim">Chime for new incidents, tone for dispatch</span></span></span>
          <input id="settingSound" type="checkbox" class="h-4 w-4 accent-[#ff5540]" ${state.soundOn ? 'checked' : ''} />
        </label>
        <label class="flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-line-soft bg-panel-2 p-3">
          <span class="flex items-center gap-2.5"><span class="material-symbols-outlined text-[18px] text-muted">local_taxi</span><span><span class="block text-[12px] font-bold text-text">Fleet layer</span><span class="block text-[9px] text-dim">Show live unit positions on the map</span></span></span>
          <input id="settingFleet" type="checkbox" class="h-4 w-4 accent-[#ff5540]" ${state.showFleet ? 'checked' : ''} />
        </label>
        <label class="flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-line-soft bg-panel-2 p-3">
          <span class="flex items-center gap-2.5"><span class="material-symbols-outlined text-[18px] text-muted">route</span><span><span class="block text-[12px] font-bold text-text">Route layer</span><span class="block text-[9px] text-dim">Draw assigned response routes</span></span></span>
          <input id="settingRoutes" type="checkbox" class="h-4 w-4 accent-[#ff5540]" ${state.showRoutes ? 'checked' : ''} />
        </label>
        <div class="rounded-xl border border-road/25 bg-road/[0.04] p-3">
          <p class="text-[10px] font-bold text-[#f3d36a]">Prototype limitations</p>
          <p class="mt-1 text-[9px] leading-relaxed text-muted">Routing uses the public OSRM demo endpoint with a synthetic fallback. WebRTC uses public STUN; add TURN (coturn) for production carrier NATs. Data is stored locally in SQLite.</p>
        </div>
      </div>`,
      footer: `<button class="btn btn-ghost" id="testSound">Test sound</button><button class="btn btn-primary" data-close>Done</button>`
    });
    dialog.el.querySelector('#settingSound').addEventListener('change', (event) => toggleSound(event.target.checked));
    dialog.el.querySelector('#settingFleet').addEventListener('change', (event) => {
      state.showFleet = event.target.checked;
      refreshMapLayerVisibility();
    });
    dialog.el.querySelector('#settingRoutes').addEventListener('change', (event) => {
      state.showRoutes = event.target.checked;
      refreshMapLayerVisibility();
      renderRoutes();
    });
    dialog.el.querySelector('#testSound').addEventListener('click', () => S.dispatchTone());
  }

  function toggleSound(force) {
    state.soundOn = typeof force === 'boolean' ? force : !state.soundOn;
    localStorage.setItem('naijasos.dispatchSound', state.soundOn ? '1' : '0');
    const button = $('soundToggle');
    button.innerHTML = `<span class="material-symbols-outlined text-[19px]">${state.soundOn ? 'volume_up' : 'volume_off'}</span>`;
    button.classList.toggle('text-alert-soft', state.soundOn);
    toast(state.soundOn ? 'Alert sounds on' : 'Alert sounds muted', state.soundOn ? 'New incidents and dispatches will chime.' : 'The console will stay silent.', 'info');
  }

  // -------------------------------------------------------------------------
  // Tenant administration (NEMA creates state logins; a state issues field
  // responder credentials; neither role can cross the tenant boundary)
  // -------------------------------------------------------------------------
  function slugify(value) {
    return String(value || '').toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.+|\.+$/g, '').slice(0, 40);
  }

  function applyTenantUi(account) {
    const isSuperAdmin = account.role === 'superadmin' || account.username === 'admin';
    const isNema = account.role === 'nema';
    const stateName = isSuperAdmin ? 'Super Admin Backend' : (isNema ? 'NEMA National Command' : `${account.stateName || account.stateCode} State EOC`);
    state.account = account;
    state.mode = isSuperAdmin ? 'superadmin' : (isNema ? 'nema' : 'state');
    DISPATCHER = {
      name: account.displayName || account.username,
      id: account.username
    };

    $('sideBrandSub').textContent = isSuperAdmin
      ? 'Super Admin · Central Backend'
      : (isNema ? 'NEMA National Command' : `${account.stateName || account.stateCode} State EOC`);
    $('shiftOrg').textContent = isSuperAdmin
      ? 'National Entity Registration & Master Control'
      : (isNema ? 'NEMA HQ · Abuja · Federal SOS Dispatch' : `${account.stateName || account.stateCode} State EOC · ${account.stateCode}`);
    $('tenantChipLabel').textContent = stateName;
    $('tenantChipSub').textContent = isSuperAdmin
      ? 'System Governance'
      : (isNema ? 'Federal SOS Allocation' : `Tenant · ${account.stateCode}`);
    $('tenantChipIcon').textContent = isSuperAdmin ? 'admin_panel_settings' : (isNema ? 'account_balance' : 'location_city');
    $('tenantChip').classList.remove('hidden');
    $('mapScopeLabel').textContent = (isSuperAdmin || isNema) ? 'National response grid (All 36 States + FCT)' : `${account.stateName || account.stateCode} response grid`;
    $('userName').textContent = account.displayName || account.username;
    $('userRole').textContent = `${S.roleLabel(account.role)} · ${account.username}`;
    $('userInitials').textContent = String(account.displayName || account.username)
      .split(/\s+/).filter(Boolean).slice(0, 2).map((part) => part[0]).join('').toUpperCase();

    // Side navigation toggles:
    const navGroupLabel = $('sideNavGroupLabel');
    if (navGroupLabel) navGroupLabel.textContent = isSuperAdmin ? 'Central Registration' : (isNema ? 'National Governance' : 'State Operations');
    $('navNema')?.classList.toggle('hidden', !isSuperAdmin);
    $('navStates')?.classList.toggle('hidden', !(isSuperAdmin || isNema));
    $('navResponders')?.classList.toggle('hidden', false);
    $('navRegistrations')?.classList.toggle('hidden', false);
    $('registerEntityBtn')?.classList.toggle('hidden', !isSuperAdmin);
    // NEMA registers states; states never self-register.
    $('registerStateBtn')?.classList.toggle('hidden', !isNema);

    const navGroup = $('tenantNavGroup'); if (navGroup) navGroup.classList.remove('hidden');
    if (isSuperAdmin) $('navNema')?.classList.add('is-active');
    else if (isNema) $('navStates')?.classList.add('is-active');
    document.title = `NaijaSOS · ${stateName}`;
    updateRegistrationCount();
  }

  function updateRegistrationCount() {
    const count = state.stats?.pendingRegistrations;
    const badge = $('sideRegCount');
    if (!badge) return;
    badge.textContent = count == null ? '—' : String(count);
    badge.classList.toggle('!text-alert-soft', Number(count) > 0);
  }

  function credentialMarkup(account, password, extra = '') {
    return `<div class="space-y-3">
      <div class="rounded-xl border border-ok/30 bg-ok/[0.06] p-3">
        <p class="text-[11px] font-bold text-ok">Credential issued</p>
        <p class="mt-1 text-[10px] leading-relaxed text-muted">Give this only to the named person. The password is shown once and cannot be retrieved again.</p>
      </div>
      <div class="grid gap-2 sm:grid-cols-2">
        <div class="rounded-lg border border-line-soft bg-panel-2 p-2.5">
          <p class="field-label">Username</p>
          <p class="data mt-1 break-all text-[14px] font-bold text-text" id="issuedUsername">${esc(account?.username || '—')}</p>
        </div>
        <div class="rounded-lg border border-line-soft bg-panel-2 p-2.5">
          <p class="field-label">Temporary password</p>
          <p class="data mt-1 break-all text-[14px] font-bold text-[#f4c430]" id="issuedPassword">${esc(password || '—')}</p>
        </div>
      </div>
      <dl class="grid gap-2 text-[10px] sm:grid-cols-2">
        <div><dt class="text-dim">Workspace</dt><dd class="mt-0.5 text-text">${esc(S.roleLabel(account?.role))}</dd></div>
        <div><dt class="text-dim">State</dt><dd class="mt-0.5 text-text">${esc(account?.stateName || account?.stateCode || 'National')}</dd></div>
        <div><dt class="text-dim">Display name</dt><dd class="mt-0.5 text-text">${esc(account?.displayName || '—')}</dd></div>
        <div><dt class="text-dim">Call sign</dt><dd class="mt-0.5 text-text">${esc(account?.callSign || '—')}</dd></div>
      </dl>
      ${extra}
      <p class="rounded-lg border border-[#f4c430]/20 bg-[#f4c430]/[0.04] p-2.5 text-[9px] leading-relaxed text-muted">
        The user signs in at <span class="data text-text">/login</span> and must select the matching workspace. A state login cannot open a field tablet, and a responder login cannot enter command.
      </p>
    </div>`;
  }

  function openCredentialModal({ account, password, title = 'Login ready' }) {
    const canIssueCode = account?.role === 'state';
    const dialog = S.modal({
      title,
      subtitle: 'One-time credential handover',
      body: credentialMarkup(account, password),
      footer: `${canIssueCode ? `<button class="btn btn-nema" id="generateAccessCode" type="button"><span class="material-symbols-outlined text-[16px]">key</span>Generate access code</button>` : ''}
        <button class="btn btn-ghost" id="copyCredential" type="button"><span class="material-symbols-outlined text-[16px]">content_copy</span>Copy both</button>
        <button class="btn btn-primary" data-close>Done</button>`
    });
    dialog.el.querySelector('#copyCredential')?.addEventListener('click', () => {
      S.copyText(`Username: ${account.username}\nTemporary password: ${password}\nSign in: ${location.origin}/login`);
      toast('Credential copied', 'Share it over a secure channel.', 'success');
    });
    dialog.el.querySelector('#generateAccessCode')?.addEventListener('click', () => {
      dialog.close();
      openStateAccessCodeModal(account);
    });
  }

  async function openNemaAccountsModal() {
    let data;
    try {
      data = await api('/api/admin/nema-accounts');
    } catch (error) {
      toast('Could not load NEMA command accounts', error.message, 'error');
      return;
    }
    const accounts = data.accounts || [];
    const buildRows = () => {
      if (!accounts.length) {
        return '<p class="p-6 text-center text-[10px] text-dim">No NEMA command accounts created yet.</p>';
      }
      return `<div class="record-table">
        <div class="record-table__head">
          <span>Command operator</span>
          <span>Username</span>
          <span>Active sessions</span>
          <span class="text-right">Action</span>
        </div>
        ${accounts.map((acc) => `<div class="record-row">
          <div class="record-row__main">
            <span class="record-row__icon border-nema/30 bg-nema/10 text-nema-soft">
              <span class="material-symbols-outlined text-[18px]">${acc.role === 'superadmin' ? 'admin_panel_settings' : 'account_balance'}</span>
            </span>
            <div class="min-w-0">
              <div class="flex items-center gap-1.5">
                <p class="record-row__title">${esc(acc.displayName || acc.username)}</p>
                <span class="badge ${acc.role === 'superadmin' ? 'badge-ok' : 'badge-muted'}">${esc(acc.role)}</span>
              </div>
              <p class="record-row__meta">Created ${S.relativeTime(acc.createdAt)}</p>
            </div>
          </div>
          <div class="record-row__cell">
            <p class="record-row__label">Username</p>
            <p class="record-row__value font-mono">${esc(acc.username)}</p>
          </div>
          <div class="record-row__cell">
            <p class="record-row__label">Sessions</p>
            <p class="record-row__value">${acc.activeSessions || 0} active</p>
            <p class="record-row__sub">${acc.lastLoginAt ? `Last active ${S.relativeTime(acc.lastLoginAt)}` : 'Never signed in'}</p>
          </div>
          <div class="record-row__action">
            <button type="button" class="btn btn-ghost btn-sm" data-reset-nema="${acc.id}">Reset pass</button>
          </div>
        </div>`).join('')}
      </div>`;
    };

    const dialog = S.modal({
      title: 'NEMA National Command Desks',
      subtitle: `${accounts.length} registered federal command accounts · Managed by Super Admin`,
      wide: true,
      body: `<div class="space-y-3">
        <div class="flex items-center justify-between rounded-xl border border-nema/30 bg-nema/10 p-3">
          <div class="flex items-center gap-2.5">
            <span class="material-symbols-outlined text-[20px] text-nema-soft">verified_user</span>
            <div>
              <p class="text-[12px] font-bold text-text">Federal Command Dispatchers</p>
              <p class="text-[10px] text-dim">Super Admin registers NEMA national dispatchers to monitor incoming SOS and dispatch to Hytera radios.</p>
            </div>
          </div>
          <button id="btnCreateNemaAccount" class="btn btn-nema btn-sm shrink-0"><span class="material-symbols-outlined text-[16px]">person_add</span>New NEMA Desk</button>
        </div>
        <div id="nemaAccountList" class="max-h-[380px] overflow-y-auto scroll-thin">${buildRows()}</div>
      </div>`,
      footer: `<button class="btn btn-ghost" data-close>Close</button>`
    });

    dialog.el.querySelector('#btnCreateNemaAccount')?.addEventListener('click', () => {
      dialog.close();
      openNemaAccountForm();
    });
    dialog.el.querySelector('#nemaAccountList')?.addEventListener('click', async (event) => {
      const button = event.target.closest('[data-reset-nema]');
      if (!button) return;
      const accId = Number(button.dataset.resetNema);
      try {
        const result = await api(`/api/admin/nema-accounts/${accId}/reset`, { method: 'POST' });
        dialog.close();
        openCredentialModal({
          account: result.account,
          password: result.temporaryPassword,
          title: 'NEMA credential reset'
        });
      } catch (err) {
        toast('Reset failed', err.message, 'error');
      }
    });
  }

  function openNemaAccountForm() {
    const dialog = S.modal({
      title: 'Register NEMA Command Operator',
      subtitle: 'Create a federal operator account with national dispatch authority',
      body: `<form id="nemaAccountForm" class="space-y-3">
        <label class="block">
          <span class="field-label">Username</span>
          <input id="nemaUsername" class="input" placeholder="e.g. nema.command2" required minlength="3" maxlength="40" />
        </label>
        <label class="block">
          <span class="field-label">Display name / Desk description</span>
          <input id="nemaDisplayName" class="input" placeholder="e.g. NEMA National Dispatcher - North Zone" required maxlength="80" />
        </label>
        <label class="block">
          <span class="field-label">Password (blank generates a secure password)</span>
          <input id="nemaPassword" class="input" placeholder="Leave blank to auto-generate" minlength="8" />
        </label>
        <div id="nemaAccountError" class="hidden rounded-lg border border-alert/35 bg-alert/10 px-3 py-2 text-[10px] text-alert-soft"></div>
      </form>`,
      footer: `<button class="btn btn-ghost" data-close>Cancel</button>
        <button id="nemaAccountSubmit" class="btn btn-nema" type="submit" form="nemaAccountForm">Create NEMA Desk</button>`
    });

    dialog.el.querySelector('#nemaAccountForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const submit = dialog.el.querySelector('#nemaAccountSubmit');
      submit.disabled = true;
      try {
        const result = await api('/api/admin/nema-accounts', {
          method: 'POST',
          body: {
            username: dialog.el.querySelector('#nemaUsername').value.trim(),
            displayName: dialog.el.querySelector('#nemaDisplayName').value.trim(),
            password: dialog.el.querySelector('#nemaPassword').value || undefined
          }
        });
        dialog.close();
        openCredentialModal({
          account: result.account,
          password: result.temporaryPassword,
          title: 'NEMA Desk Created'
        });
      } catch (err) {
        submit.disabled = false;
        const box = dialog.el.querySelector('#nemaAccountError');
        box.textContent = err.message;
        box.classList.remove('hidden');
      }
    });
  }

  function openRegisterResponderForm(preselectedState = null) {
    const states = [
      { code: 'LA', name: 'Lagos' }, { code: 'FC', name: 'FCT' }, { code: 'KN', name: 'Kano' },
      { code: 'RV', name: 'Rivers' }, { code: 'KD', name: 'Kaduna' }, { code: 'OG', name: 'Ogun' },
      { code: 'OY', name: 'Oyo' }, { code: 'ED', name: 'Edo' }, { code: 'EN', name: 'Enugu' },
      { code: 'AN', name: 'Anambra' }, { code: 'DT', name: 'Delta' }, { code: 'PL', name: 'Plateau' }
    ];
    const defaultState = preselectedState || state.account?.stateCode || 'LA';

    const dialog = S.modal({
      title: 'Register Vehicle & Hytera MNC360 Hardware',
      subtitle: 'Registers vehicle unit, binds Hytera MNC360 radio IMEI, and provisions in-vehicle APK',
      wide: true,
      body: `<form id="newResponderForm" class="space-y-4">
        <div class="rounded-xl border border-[#f4c430]/30 bg-[#f4c430]/[0.04] p-3 text-[10px] text-dim flex items-center gap-2">
          <span class="material-symbols-outlined text-[#f4c430] text-[20px]">radio</span>
          <p><span class="font-bold text-text">Hardware Architecture:</span> First responders use dedicated in-vehicle Hytera Android APKs (MNC360 hardware radios). Telemetry and voice stream directly to state &amp; national dashboards.</p>
        </div>
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block">
            <span class="field-label">Unit Call Sign *</span>
            <input id="respCallSign" class="input uppercase font-bold" placeholder="e.g. AMB-LA-05, POLICE-12" required />
          </label>
          <label class="block">
            <span class="field-label">Assigned State *</span>
            <select id="respStateCode" class="input">
              ${states.map(s => `<option value="${s.code}" ${s.code === defaultState ? 'selected' : ''}>${esc(s.name)} (${esc(s.code)})</option>`).join('')}
            </select>
          </label>
        </div>
        <div class="grid gap-3 sm:grid-cols-3">
          <label class="block">
            <span class="field-label">Agency Desk *</span>
            <select id="respAgencyCode" class="input">
              <option value="MEDICAL">Hospital / Medical Desk</option>
              <option value="POLICE">Police Command Desk</option>
              <option value="FIRE">Fire Service Desk</option>
              <option value="ROAD_SAFETY">Road Safety (FRSC) Desk</option>
              <option value="GENERAL">Others / Community Desk</option>
            </select>
          </label>
          <label class="block">
            <span class="field-label">Vehicle Category *</span>
            <select id="respKind" class="input">
              <option value="ambulance">Ambulance (ICU / Rapid)</option>
              <option value="patrol_car">Patrol Car / Rapid Response</option>
              <option value="fire_engine">Fire Engine / Water Tender</option>
              <option value="road_safety_tow">FRSC Tow / Rescue Unit</option>
              <option value="volunteer_car">Community Volunteer Car</option>
            </select>
          </label>
          <label class="block">
            <span class="field-label">Vehicle Make / Description *</span>
            <input id="respVehicleType" class="input" placeholder="e.g. Toyota HiAce Ambulance" required />
          </label>
        </div>
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block">
            <span class="field-label">Plate / Registration Number</span>
            <input id="respPlateNumber" class="input uppercase" placeholder="e.g. LAG-912-XY" />
          </label>
          <label class="block">
            <span class="field-label">Operating Station / Base *</span>
            <input id="respStation" class="input" placeholder="e.g. Ikeja Dispatch Base" required />
          </label>
        </div>
        <div class="rounded-xl border border-line bg-panel-2 p-3 space-y-3">
          <p class="font-mono text-[9px] uppercase tracking-wider text-dim flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[16px] text-nema-soft">memory</span> Hytera Radio Hardware Specification
          </p>
          <div class="grid gap-3 sm:grid-cols-2">
            <label class="block">
              <span class="field-label">Hardware Device Type</span>
              <input id="respHardwareType" class="input" value="Hytera MNC360 Smart PoC In-Vehicle Radio Terminal" />
            </label>
            <label class="block">
              <span class="field-label">Hardware IMEI / Device Serial Number</span>
              <input id="respHardwareImei" class="input font-mono" placeholder="e.g. 864209041234567" />
            </label>
          </div>
        </div>
        <div id="newResponderError" class="hidden rounded-lg border border-alert/35 bg-alert/10 px-3 py-2 text-[10px] text-alert-soft"></div>
      </form>`,
      footer: `<button class="btn btn-ghost" data-close>Cancel</button>
        <button id="newResponderSubmit" class="btn btn-nema" type="submit" form="newResponderForm">Register Unit &amp; Provision APK</button>`
    });

    dialog.el.querySelector('#newResponderForm').addEventListener('submit', async (e) => {
      e.preventDefault();
      const submit = dialog.el.querySelector('#newResponderSubmit');
      submit.disabled = true;
      try {
        const result = await api('/api/admin/responders', {
          method: 'POST',
          body: {
            callSign: dialog.el.querySelector('#respCallSign').value.trim(),
            stateCode: dialog.el.querySelector('#respStateCode').value,
            agencyCode: dialog.el.querySelector('#respAgencyCode').value,
            responderKind: dialog.el.querySelector('#respKind').value,
            vehicleType: dialog.el.querySelector('#respVehicleType').value.trim(),
            plateNumber: dialog.el.querySelector('#respPlateNumber').value.trim(),
            station: dialog.el.querySelector('#respStation').value.trim(),
            hardwareType: dialog.el.querySelector('#respHardwareType').value.trim(),
            hardwareImei: dialog.el.querySelector('#respHardwareImei').value.trim()
          }
        });
        dialog.close();
        openCredentialModal({
          account: result.account,
          password: result.temporaryPassword,
          title: 'First Responder Unit Registered',
          extra: `<div class="rounded-lg border border-nema/30 bg-nema/10 p-2.5 text-[10px] text-nema-soft">
            <p class="font-bold">Hytera MNC360 In-Vehicle Terminal Profile</p>
            <p class="mt-0.5 text-text">Device IMEI: ${esc(result.hardware?.imei || 'Not stated')} · Bound to Unit ${esc(result.unit?.callSign || '')}</p>
          </div>`
        });
      } catch (err) {
        submit.disabled = false;
        const box = dialog.el.querySelector('#newResponderError');
        box.textContent = err.message;
        box.classList.remove('hidden');
      }
    });
  }

  function openUnifiedRegistrationModal() {
    const dialog = S.modal({
      title: 'Central Entity Registration Gateway',
      subtitle: 'Super Admin master registration: NEMA Command Desks, State Counterparts, and First Responders',
      wide: true,
      body: `<div class="space-y-4">
        <p class="text-[11px] leading-relaxed text-dim">Select the entity to register into the national emergency infrastructure:</p>
        <div class="grid gap-3 sm:grid-cols-3">
          <button type="button" id="regChoiceNema" class="group flex flex-col items-start gap-2 rounded-xl border border-line bg-panel-2 p-3 text-left transition hover:border-nema hover:bg-panel-3">
            <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-nema/15 text-nema-soft">
              <span class="material-symbols-outlined text-[20px]">account_balance</span>
            </span>
            <div>
              <p class="text-[12px] font-bold text-text group-hover:text-white">NEMA Command Desk</p>
              <p class="mt-1 text-[9px] text-dim">Register national federal dispatchers to oversee live SOS incidents across Nigeria.</p>
            </div>
            <span class="mt-auto inline-flex items-center gap-1 font-mono text-[8px] font-bold uppercase text-nema-soft">Create Desk &rarr;</span>
          </button>
          <button type="button" id="regChoiceState" class="group flex flex-col items-start gap-2 rounded-xl border border-line bg-panel-2 p-3 text-left transition hover:border-[#3b82f6] hover:bg-panel-3">
            <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-[#3b82f6]/15 text-[#3b82f6]">
              <span class="material-symbols-outlined text-[20px]">location_city</span>
            </span>
            <div>
              <p class="text-[12px] font-bold text-text group-hover:text-white">State Counterpart (SEMA)</p>
              <p class="mt-1 text-[9px] text-dim">Provision state EOC accounts for 36 states + FCT and their agency desks (Hospital, Police, Fire, FRSC).</p>
            </div>
            <span class="mt-auto inline-flex items-center gap-1 font-mono text-[8px] font-bold uppercase text-[#3b82f6]">Manage States &rarr;</span>
          </button>
          <button type="button" id="regChoiceResponder" class="group flex flex-col items-start gap-2 rounded-xl border border-line bg-panel-2 p-3 text-left transition hover:border-[#f4c430] hover:bg-panel-3">
            <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-[#f4c430]/15 text-[#f4c430]">
              <span class="material-symbols-outlined text-[20px]">radio</span>
            </span>
            <div>
              <p class="text-[12px] font-bold text-text group-hover:text-white">First Responder Unit</p>
              <p class="mt-1 text-[9px] text-dim">Register ambulance, patrol car, fire truck or community car with Hytera MNC360 hardware IMEI.</p>
            </div>
            <span class="mt-auto inline-flex items-center gap-1 font-mono text-[8px] font-bold uppercase text-[#f4c430]">Register Hardware &rarr;</span>
          </button>
        </div>
      </div>`,
      footer: `<button class="btn btn-ghost" data-close>Close</button>`
    });

    dialog.el.querySelector('#regChoiceNema')?.addEventListener('click', () => {
      dialog.close();
      openNemaAccountForm();
    });
    dialog.el.querySelector('#regChoiceState')?.addEventListener('click', () => {
      dialog.close();
      openStateAccountsModal();
    });
    dialog.el.querySelector('#regChoiceResponder')?.addEventListener('click', () => {
      dialog.close();
      openRegisterResponderForm();
    });
  }

  async function openStateAccountsModal() {
    let data;
    try {
      data = await api('/api/nema/state-accounts');
    } catch (error) {
      toast('Could not load state logins', error.message, 'error');
      return;
    }
    const covered = data.states.filter((row) => row.account).length;
    const buildRows = (filter = '') => {
      const query = filter.trim().toLowerCase();
      const rows = data.states.filter((row) => !query
        || row.name.toLowerCase().includes(query)
        || row.code.toLowerCase().includes(query)
        || row.zone.toLowerCase().includes(query));
      if (!rows.length) {
        return '<p class="p-6 text-center text-[10px] text-dim">No states match that search.</p>';
      }
      return `<div class="record-table">
        <div class="record-table__head">
          <span>State counterpart</span>
          <span>Issued login</span>
          <span>Last activity</span>
          <span class="text-right">Action</span>
        </div>
        ${rows.map((row) => {
          const account = row.account;
          return `<div class="record-row">
            <div class="record-row__main">
              <span class="record-row__icon ${account ? 'border-nema/30 bg-nema/10 text-nema-soft' : 'border-line bg-panel text-dim'}">
                <span class="material-symbols-outlined text-[18px]">${account ? 'verified_user' : 'location_city'}</span>
              </span>
              <div class="min-w-0">
                <div class="flex flex-wrap items-center gap-1.5">
                  <p class="record-row__title">${esc(row.name)}</p>
                  <span class="badge badge-muted">${esc(row.code)}</span>
                  ${account ? '<span class="badge badge-ok">login active</span>' : '<span class="badge badge-alert">not issued</span>'}
                </div>
                <p class="record-row__meta">${esc(row.zone)} · ${esc(row.capital)}</p>
              </div>
            </div>
            <div class="record-row__cell">
              <p class="record-row__label">Username</p>
              <p class="record-row__value">${account ? esc(account.username) : '—'}</p>
              <p class="record-row__sub">${account ? `Issued by ${esc(account.createdByName || 'NEMA National Admin')}` : 'NEMA has not issued access'}</p>
            </div>
            <div class="record-row__cell">
              <p class="record-row__label">Last activity</p>
              <p class="record-row__value">${account?.lastLoginAt ? S.relativeTime(account.lastLoginAt) : 'Never signed in'}</p>
              <p class="record-row__sub">${account ? `${account.activeSessions || 0} session(s) · ${account.activeIncidents || 0} live incident(s)` : 'No sessions · no live incidents'}</p>
            </div>
            <div class="record-row__action">
              <div class="flex flex-wrap items-center justify-end gap-1.5">
                ${account ? `<button type="button" class="btn btn-nema btn-sm shrink-0" data-state-access="${account.id}" title="Generate a one-time code that opens this state dashboard">
                  <span class="material-symbols-outlined text-[14px]">key</span>Access code
                </button>` : ''}
                <button type="button" class="btn ${account ? 'btn-ghost' : 'btn-nema'} btn-sm shrink-0" data-state-code="${esc(row.code)}">
                  ${account ? 'Reset password' : 'Create login'}
                </button>
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>`;
    };

    const dialog = S.modal({
      title: 'State counterpart logins',
      subtitle: `${covered} of ${data.states.length} states issued · NEMA is the only role that can create them`,
      wide: true,
      body: `<div class="space-y-3">
        <div class="grid grid-cols-3 gap-2">
          <div class="admin-stat" style="--stat-accent:#7ddba8">
            <span class="material-symbols-outlined admin-stat__icon">public</span>
            <p class="admin-stat__value">${data.states.length}</p>
            <p class="admin-stat__label">States + FCT</p>
          </div>
          <div class="admin-stat" style="--stat-accent:#34d399">
            <span class="material-symbols-outlined admin-stat__icon">key</span>
            <p class="admin-stat__value">${covered}</p>
            <p class="admin-stat__label">NEMA-issued logins</p>
          </div>
          <div class="admin-stat" style="--stat-accent:#eab308">
            <span class="material-symbols-outlined admin-stat__icon">pending_actions</span>
            <p class="admin-stat__value">${data.states.length - covered}</p>
            <p class="admin-stat__label">Awaiting NEMA</p>
          </div>
        </div>
        <div class="flex items-start gap-2 rounded-xl border border-[#1f8a5b]/25 bg-[#1f8a5b]/[0.05] px-3 py-2.5">
          <span class="material-symbols-outlined mt-0.5 text-[16px] text-nema-soft">policy</span>
          <p class="text-[9px] leading-relaxed text-muted">A state cannot register itself or set its own password. NEMA creates the account, hands over the one-time password, and remains the only role that can reset it.</p>
        </div>
        <div class="relative">
          <span class="material-symbols-outlined pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-[16px] text-dim">search</span>
          <input id="stateAccountSearch" class="input h-9 pl-8 text-[11px]" placeholder="Search state, code or zone…" autocomplete="off" />
        </div>
        <div id="stateAccountList" class="max-h-[420px] overflow-y-auto scroll-thin">${buildRows()}</div>
      </div>`,
      footer: `<button class="btn btn-ghost" data-close>Close</button>`
    });

    const refreshRows = (filter) => {
      dialog.el.querySelector('#stateAccountList').innerHTML = buildRows(filter);
    };
    dialog.el.querySelector('#stateAccountSearch')?.addEventListener('input', (event) => refreshRows(event.target.value));
    dialog.el.querySelector('#stateAccountList')?.addEventListener('click', (event) => {
      const accessButton = event.target.closest('[data-state-access]');
      if (accessButton) {
        const account = data.accounts.find((item) => String(item.id) === accessButton.dataset.stateAccess);
        if (account) openStateAccessCodeModal(account);
        return;
      }
      const button = event.target.closest('[data-state-code]');
      if (!button) return;
      const row = data.states.find((item) => item.code === button.dataset.stateCode);
      if (!row) return;
      dialog.close();
      openStateAccountForm(row);
    });
  }

  async function openStateAccessCodeModal(account) {
    let result;
    try {
      result = await api(`/api/nema/state-accounts/${account.id}/access-code`, {
        method: 'POST',
        body: { ttlMinutes: 30 }
      });
    } catch (error) {
      toast('Could not generate access code', error.message, 'error');
      return;
    }
    const stateLabel = account.stateName ? `${account.stateName} State EOC` : `${account.stateCode} State EOC`;
    const code = result.code;
    const link = `${location.origin}${result.url}`;
    const expires = new Date(result.expiresAt);
    const expiresLabel = expires.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dialog = S.modal({
      title: `${stateLabel} access code`,
      subtitle: 'One-time code · opens the state dashboard directly',
      body: `<div class="space-y-3.5">
        <div class="flex items-center justify-between gap-2 rounded-xl border border-nema/30 bg-nema/10 p-3">
          <div class="flex items-center gap-2.5">
            <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-nema/20 text-nema-soft">
              <span class="material-symbols-outlined text-[20px]">location_city</span>
            </span>
            <div>
              <p class="text-[12px] font-bold text-text">${esc(stateLabel)}</p>
              <p class="text-[9px] text-dim">${esc(account.username)} · issues to state staff on duty</p>
            </div>
          </div>
          <span class="badge badge-ok">login active</span>
        </div>
        <div class="rounded-xl border border-line bg-ink px-4 py-5 text-center">
          <p class="font-mono text-[8px] font-bold uppercase tracking-[0.22em] text-dim">One-time access code</p>
          <p class="mt-2 select-all font-mono text-[34px] font-black tracking-[0.18em] text-nema-soft">${esc(code)}</p>
          <p class="mt-2 text-[9px] text-dim">Expires at <span class="font-bold text-text">${esc(expiresLabel)} WAT</span> · valid ${result.ttlMinutes} minutes · single use</p>
        </div>
        <div class="rounded-xl border border-line-soft bg-panel-2 p-2.5">
          <p class="font-mono text-[8px] uppercase tracking-wider text-dim">Direct dashboard link</p>
          <p class="mt-1 break-all font-mono text-[10px] text-text">${esc(link)}</p>
        </div>
        <p class="flex items-start gap-1.5 text-[9px] leading-relaxed text-dim">
          <span class="material-symbols-outlined !text-[14px] text-[#f4c430]">info</span>
          Send this code or link to the ${esc(stateLabel)} duty officer. It works once and can only open the state dashboard. Opening it in this browser signs this tab in as the state EOC.
        </p>
      </div>`,
      footer: `<button type="button" class="btn btn-ghost" id="copyAccessCode"><span class="material-symbols-outlined text-[15px]">content_copy</span>Copy code</button>
        <button type="button" class="btn btn-ghost" id="copyAccessLink"><span class="material-symbols-outlined text-[15px]">link</span>Copy link</button>
        <a class="btn btn-nema" href="${esc(link)}" target="_blank" rel="noopener"><span class="material-symbols-outlined text-[16px]">open_in_new</span>Open dashboard</a>`
    });
    dialog.el.querySelector('#copyAccessCode')?.addEventListener('click', () => {
      S.copyText(code);
      toast('Access code copied', `Share it securely with ${stateLabel}.`, 'success');
    });
    dialog.el.querySelector('#copyAccessLink')?.addEventListener('click', () => {
      S.copyText(link);
      toast('Dashboard link copied', 'The states dashboard opens with this one-time link.', 'success');
    });
  }

  function openStateAccountForm(row) {
    const account = row.account;
    const reset = !!account;
    const suggested = row.code === 'FC' ? 'fct.eoc' : `${slugify(row.shortName || row.name).replace(/\./g, '')}.eoc`;
    const dialog = S.modal({
      title: reset ? `Reset ${row.name} password` : `Create ${row.name} state login`,
      subtitle: reset ? 'This revokes every active session for the counterpart' : 'NEMA issues one account per state counterpart',
      body: `<form id="stateAccountForm" class="space-y-3">
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block">
            <span class="field-label">State</span>
            <input class="input" value="${esc(row.name)} (${esc(row.code)})" disabled />
          </label>
          <label class="block">
            <span class="field-label">Username</span>
            <input id="stateUsername" class="input" value="${esc(account?.username || suggested)}" ${reset ? 'disabled' : ''} required minlength="3" maxlength="40" />
          </label>
        </div>
        <label class="block">
          <span class="field-label">Display name</span>
          <input id="stateDisplayName" class="input" value="${esc(account?.displayName || `${row.name} State Emergency Operations Centre`)}" required maxlength="80" />
        </label>
        <label class="block">
          <span class="field-label">Temporary password ${reset ? '(leave blank to generate)' : '(blank generates one)'}</span>
          <input id="statePassword" class="input data" placeholder="At least 8 characters, or leave blank" minlength="8" />
        </label>
        <div id="stateAccountError" class="hidden rounded-lg border border-alert/35 bg-alert/10 px-3 py-2 text-[10px] text-alert-soft"></div>
        <p class="text-[9px] leading-relaxed text-dim">The state counterpart sees only ${esc(row.name)} incidents, units and applications. It can create field logins for its own responders but cannot sign in as one.</p>
      </form>`,
      footer: `<button class="btn btn-ghost" data-close>Cancel</button>
        <button id="stateAccountSubmit" class="btn btn-nema" type="submit" form="stateAccountForm">${reset ? 'Reset password' : 'Create state login'}</button>`
    });
    const form = dialog.el.querySelector('#stateAccountForm');
    form.addEventListener('submit', async (event) => {
      event.preventDefault();
      const submit = dialog.el.querySelector('#stateAccountSubmit');
      submit.disabled = true;
      try {
        const password = dialog.el.querySelector('#statePassword').value || undefined;
        let result;
        if (reset) {
          result = await api(`/api/nema/state-accounts/${account.id}/reset`, {
            method: 'POST', body: { password }
          });
        } else {
          result = await api('/api/nema/state-accounts', {
            method: 'POST',
            body: {
              stateCode: row.code,
              username: dialog.el.querySelector('#stateUsername').value.trim(),
              displayName: dialog.el.querySelector('#stateDisplayName').value.trim(),
              password
            }
          });
        }
        dialog.close();
        openCredentialModal({
          account: result.account,
          password: result.temporaryPassword,
          title: reset ? 'Password reset' : 'State login created'
        });
      } catch (error) {
        submit.disabled = false;
        const box = dialog.el.querySelector('#stateAccountError');
        box.textContent = error.message;
        box.classList.remove('hidden');
      }
    });
  }

  async function openResponderLoginsModal() {
    let data;
    try {
      data = await api('/api/state/responders');
    } catch (error) {
      toast('Could not load responder logins', error.message, 'error');
      return;
    }
    const accountByUnit = new Map((data.accounts || []).map((account) => [account.responderId, account]));
    const issued = data.accounts?.length || 0;
    const scopeLabel = state.mode === 'state'
      ? `${state.account.stateName || state.account.stateCode} State EOC`
      : 'National command';
    const dialog = S.modal({
      title: `${scopeLabel} responder logins`,
      subtitle: state.mode === 'state'
        ? 'Only this state EOC can issue field credentials for its own units'
        : 'Register units and issue field credentials across all states',
      wide: true,
      body: `<div class="space-y-3">
        <div class="grid grid-cols-3 gap-2">
          <div class="admin-stat" style="--stat-accent:#7ddba8">
            <span class="material-symbols-outlined admin-stat__icon">verified_user</span>
            <p class="admin-stat__value">${data.responders.length}</p>
            <p class="admin-stat__label">Verified units</p>
          </div>
          <div class="admin-stat" style="--stat-accent:#34d399">
            <span class="material-symbols-outlined admin-stat__icon">key</span>
            <p class="admin-stat__value">${issued}</p>
            <p class="admin-stat__label">State-issued logins</p>
          </div>
          <div class="admin-stat" style="--stat-accent:#eab308">
            <span class="material-symbols-outlined admin-stat__icon">pending_actions</span>
            <p class="admin-stat__value">${Math.max(0, data.responders.length - issued)}</p>
            <p class="admin-stat__label">Need credentials</p>
          </div>
        </div>
        <div class="flex items-center justify-between gap-2 rounded-xl border border-[#f4c430]/25 bg-[#f4c430]/[0.04] p-3">
          <div class="flex items-center gap-2">
            <span class="material-symbols-outlined text-[20px] text-[#f4c430]">radio</span>
            <p class="text-[10px] leading-relaxed text-muted"><span class="font-bold text-text">Hytera Radio Terminal APK:</span> Hardware IMEIs and field credentials provisioned here authenticate dedicated in-vehicle APKs.</p>
          </div>
          <button type="button" id="btnModalRegisterResponder" class="btn btn-nema btn-sm shrink-0"><span class="material-symbols-outlined text-[16px]">add</span>Register Unit</button>
        </div>
        <div class="record-table max-h-[430px] overflow-y-auto scroll-thin">
          <div class="record-table__head">
            <span>Unit</span>
            <span>Field login</span>
            <span>Issued by</span>
            <span class="text-right">Action</span>
          </div>
          ${data.responders.map((unit) => {
            const account = accountByUnit.get(unit.id);
            const kind = S.responderKinds[unit.responderKind] || S.responderKinds.other;
            return `<div class="record-row">
              <div class="record-row__main">
                <span class="record-row__icon" style="border-color:${kind.color}44;background:${kind.color}14;color:${kind.color}">
                  <span class="material-symbols-outlined text-[18px]">${kind.icon}</span>
                </span>
                <div class="min-w-0">
                  <div class="flex flex-wrap items-center gap-1.5">
                    <p class="record-row__title data">${esc(unit.callSign)}</p>
                    <span class="badge badge-muted">${esc(kind.label)}</span>
                    ${account ? '<span class="badge badge-ok">login issued</span>' : '<span class="badge badge-alert">no login</span>'}
                  </div>
                  <p class="record-row__meta">${esc(unit.agencyShort || kind.label)} · ${esc(unit.station || '—')} · ${esc(unit.publicId)}</p>
                </div>
              </div>
              <div class="record-row__cell">
                <p class="record-row__label">Username</p>
                <p class="record-row__value">${account ? esc(account.username) : '—'}</p>
                <p class="record-row__sub">${account ? `Last login ${account.lastLoginAt ? S.relativeTime(account.lastLoginAt) : 'never'}` : 'No credential issued'}</p>
              </div>
              <div class="record-row__cell">
                <p class="record-row__label">Issued by</p>
                <p class="record-row__value">${account ? esc(account.createdByName || scopeLabel) : '—'}</p>
                <p class="record-row__sub">${account ? (account.status === 'active' ? 'Active field credential' : 'Suspended credential') : 'Issuing authority action required'}</p>
              </div>
              <div class="record-row__action">
                <button type="button" class="btn ${account ? 'btn-ghost' : 'btn-nema'} btn-sm shrink-0" data-unit-key="${esc(unit.publicId)}">${account ? 'Rotate password' : 'Issue login'}</button>
              </div>
            </div>`;
          }).join('') || '<p class="p-6 text-center text-[10px] text-dim">No verified units in this state yet. Approve an application first.</p>'}
        </div>
        <p class="font-mono text-[8px] leading-relaxed text-dim">A responder login is bound to exactly one unit. Command staff cannot use it to sign in as a responder.</p>
      </div>`,
      footer: `<button class="btn btn-ghost" data-close>Close</button>`
    });
    dialog.el.querySelector('#btnModalRegisterResponder')?.addEventListener('click', () => {
      dialog.close();
      openRegisterResponderForm();
    });
    dialog.el.addEventListener('click', (event) => {
      const button = event.target.closest('[data-unit-key]');
      if (!button) return;
      const unit = data.responders.find((item) => item.publicId === button.dataset.unitKey);
      if (!unit) return;
      dialog.close();
      openResponderCredentialForm({ unit, account: accountByUnit.get(unit.id) });
    });
  }

  function openResponderCredentialForm({ unit, account = null, unitKey = null }) {
    const reset = !!account;
    const suggested = slugify(unit.callSign || unit.callsign || 'responder');
    const dialog = S.modal({
      title: reset ? `Rotate ${unit.callSign || unit.callsign} password` : `Issue ${unit.callSign || unit.callsign} field login`,
      subtitle: reset ? 'All active sessions for this tablet will be revoked' : 'The responder will use this to open the field dashboard',
      body: `<form id="responderCredentialForm" class="space-y-3">
        <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
          <p class="text-[12px] font-bold text-text">${esc(unit.callSign || unit.callsign || 'Responder unit')}</p>
          <p class="mt-0.5 text-[9px] text-dim">${esc(unit.vehicleType || S.responderKinds[unit.responderKind]?.label || 'Field unit')} · ${esc(unit.publicId || unit.station || '')}</p>
        </div>
        <label class="block">
          <span class="field-label">Username</span>
          <input id="responderUsername" class="input" value="${esc(account?.username || suggested)}" ${reset ? 'disabled' : ''} required minlength="3" maxlength="40" />
        </label>
        <label class="block">
          <span class="field-label">Display name</span>
          <input id="responderDisplayName" class="input" value="${esc(account?.displayName || `${unit.callSign || unit.callsign} field responder`)}" required maxlength="80" />
        </label>
        <label class="block">
          <span class="field-label">Temporary password ${reset ? '(leave blank to generate)' : '(blank generates one)'}</span>
          <input id="responderPassword" class="input data" placeholder="At least 8 characters, or leave blank" minlength="8" />
        </label>
        <div id="responderCredentialError" class="hidden rounded-lg border border-alert/35 bg-alert/10 px-3 py-2 text-[10px] text-alert-soft"></div>
        <p class="text-[9px] leading-relaxed text-dim">The responder sees only this unit, its alarms, assignments and navigation. They cannot see other units, the state queue or NEMA data.</p>
      </form>`,
      footer: `<button class="btn btn-ghost" data-close>Cancel</button>
        <button id="responderCredentialSubmit" class="btn btn-nema" type="submit" form="responderCredentialForm">${reset ? 'Rotate password' : 'Issue login'}</button>`
    });
    dialog.el.querySelector('#responderCredentialForm').addEventListener('submit', async (event) => {
      event.preventDefault();
      const submit = dialog.el.querySelector('#responderCredentialSubmit');
      submit.disabled = true;
      try {
        const password = dialog.el.querySelector('#responderPassword').value || undefined;
        const result = await api(`/api/state/responders/${encodeURIComponent(unitKey || unit.publicId || unit.id)}/credentials`, {
          method: 'POST',
          body: {
            username: dialog.el.querySelector('#responderUsername').value.trim(),
            displayName: dialog.el.querySelector('#responderDisplayName').value.trim(),
            password
          }
        });
        dialog.close();
        openCredentialModal({
          account: result.account,
          password: result.temporaryPassword,
          title: result.rotated ? 'Responder password rotated' : 'Responder login issued'
        });
      } catch (error) {
        submit.disabled = false;
        const box = dialog.el.querySelector('#responderCredentialError');
        box.textContent = error.message;
        box.classList.remove('hidden');
      }
    });
  }

  async function openRegistrationsModal() {
    let data;
    try {
      data = await api('/api/registrations');
    } catch (error) {
      toast('Could not load applications', error.message, 'error');
      return;
    }
    const registrations = data.registrations || [];
    const pending = registrations.filter((row) => row.status === 'pending');
    const approved = registrations.filter((row) => row.status === 'approved');
    const rejected = registrations.filter((row) => row.status === 'rejected');
    const rowHtml = (registration, actions = false) => {
      const kind = S.responderKinds[registration.responderKind] || S.responderKinds.other;
      return `<div class="record-row" data-registration-row="${registration.id}">
        <div class="record-row__main">
          <span class="record-row__icon" style="border-color:${kind.color}44;background:${kind.color}14;color:${kind.color}">
            <span class="material-symbols-outlined text-[18px]">${kind.icon}</span>
          </span>
          <div class="min-w-0">
            <div class="flex flex-wrap items-center gap-1.5">
              <p class="record-row__title">${esc(registration.fullName)}</p>
              <span class="badge badge-muted">${esc(kind.label)}</span>
              <span class="badge ${registration.status === 'pending' ? 'badge-alert' : registration.status === 'approved' ? 'badge-ok' : 'badge-muted'}">${esc(registration.status)}</span>
            </div>
            <p class="record-row__meta">${esc(registration.publicId)} · applied ${S.relativeTime(registration.createdAt)}</p>
          </div>
        </div>
        <div class="record-row__cell">
          <p class="record-row__label">State</p>
          <p class="record-row__value">${esc(registration.stateName)}</p>
          <p class="record-row__sub">${esc(registration.phone)}</p>
        </div>
        <div class="record-row__cell">
          <p class="record-row__label">Unit</p>
          <p class="record-row__value">${esc(registration.callsign || 'Unassigned')}</p>
          <p class="record-row__sub">${esc(registration.vehicleType || 'Vehicle not stated')}${registration.plateNumber ? ` · ${esc(registration.plateNumber)}` : ''}</p>
        </div>
        <div class="record-row__action">
          ${actions ? `<div class="flex gap-1">
            <button type="button" class="btn btn-ok btn-sm" data-review-id="${registration.id}" data-decision="approved">Approve</button>
            <button type="button" class="btn btn-quiet btn-sm" data-review-id="${registration.id}" data-decision="rejected">Reject</button>
          </div>` : `<p class="font-mono text-[8px] text-dim">${registration.verifiedBy ? `Verified by ${esc(registration.verifiedBy)}` : 'Awaiting review'}</p>`}
        </div>
      </div>`;
    };
    const recordHead = (finalLabel) => `<div class="record-table__head">
      <span>Applicant</span><span>State</span><span>Unit</span><span class="text-right">${finalLabel}</span>
    </div>`;
    const dialog = S.modal({
      title: state.mode === 'nema' ? 'National responder applications' : `${state.account.stateName || state.account.stateCode} responder applications`,
      subtitle: 'A registration is pending until the responsible state EOC verifies it',
      wide: true,
      body: `<div class="space-y-4">
        <div class="grid grid-cols-3 gap-2">
          <div class="admin-stat" style="--stat-accent:#eab308">
            <span class="material-symbols-outlined admin-stat__icon">pending_actions</span>
            <p class="admin-stat__value">${pending.length}</p>
            <p class="admin-stat__label">Pending review</p>
          </div>
          <div class="admin-stat" style="--stat-accent:#34d399">
            <span class="material-symbols-outlined admin-stat__icon">verified</span>
            <p class="admin-stat__value">${approved.length}</p>
            <p class="admin-stat__label">Approved units</p>
          </div>
          <div class="admin-stat" style="--stat-accent:#727979">
            <span class="material-symbols-outlined admin-stat__icon">block</span>
            <p class="admin-stat__value">${rejected.length}</p>
            <p class="admin-stat__label">Rejected</p>
          </div>
        </div>
        <section>
          <h3 class="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-muted"><span class="material-symbols-outlined text-[17px] text-road">pending_actions</span>Pending</h3>
          <div class="record-table">${pending.length ? recordHead('Review') + pending.map((row) => rowHtml(row, true)).join('') : '<p class="p-6 text-center text-[10px] text-dim">No applications waiting.</p>'}</div>
        </section>
        <section>
          <h3 class="mb-2 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wide text-muted"><span class="material-symbols-outlined text-[17px] text-ok">verified</span>Approved</h3>
          <div class="record-table max-h-[220px] overflow-y-auto scroll-thin">${approved.length ? recordHead('Verified') + approved.map((row) => rowHtml(row)).join('') : '<p class="p-6 text-center text-[10px] text-dim">No approved applications yet.</p>'}</div>
        </section>
      </div>`,
      footer: `<a href="/register" target="_blank" rel="noopener" class="btn btn-ghost"><span class="material-symbols-outlined text-[16px]">person_add</span>Public form</a><button class="btn btn-primary" data-close>Close</button>`
    });
    dialog.el.addEventListener('click', async (event) => {
      const button = event.target.closest('[data-review-id]');
      if (!button) return;
      const id = Number(button.dataset.reviewId);
      const decision = button.dataset.decision;
      const row = registrations.find((item) => item.id === id);
      if (!row) return;
      button.disabled = true;
      try {
        const { registration } = await api(`/api/registrations/${id}/review`, {
          method: 'POST',
          body: { status: decision, reviewer: DISPATCHER.name, note: decision === 'approved' ? 'Verified by state EOC' : 'Not verified' }
        });
        toast(decision === 'approved' ? 'Responder approved' : 'Application rejected', `${registration.fullName} · ${registration.publicId}`, decision === 'approved' ? 'success' : 'info');
        dialog.close();
        if (decision === 'approved' && state.mode === 'state' && registration.responderId) {
          const issue = await S.confirmDialog({
            title: 'Issue the field login now?',
            body: `The unit <strong class="text-text">${esc(registration.callsign || 'new unit')}</strong> is now dispatchable. Create the responder username and temporary password now, or issue it later from Responder logins.`,
            confirmLabel: 'Issue login'
          });
          if (issue) {
            openResponderCredentialForm({
              unit: {
                id: registration.responderId,
                publicId: registration.responderId,
                callSign: registration.callsign,
                vehicleType: registration.vehicleType,
                responderKind: registration.responderKind,
                station: `${registration.stateName} · ${registration.vehicleType || ''}`
              }
            });
          }
        }
        updateRegistrationCount();
      } catch (error) {
        button.disabled = false;
        toast('Review failed', error.message, 'error');
      }
    });
  }

  // -------------------------------------------------------------------------
  // Realtime
  // -------------------------------------------------------------------------
  function applyBootstrap(data, { initial = false } = {}) {
    if (!data) return;
    if (Array.isArray(data.agencies)) state.agencies = data.agencies;
    if (data.stats) state.stats = data.stats;
    if (Array.isArray(data.responders)) state.units = new Map(data.responders.map((unit) => [unit.id, unit]));
    if (Array.isArray(data.incidents)) {
      state.incidents = new Map();
      for (const incident of data.incidents) state.incidents.set(incident.id, incident);
    }
    state.bootstrapped = true;
    renderKpis();
    updateRegistrationCount();
    renderUnitMarkers();
    renderFleetResults();
    ensureIncidentMarkers();
    refreshMapLayerVisibility();
    renderRoutes();
    renderQueue();
    renderMapSelected();
    if (!state.selectedId && state.incidents.size) {
      const first = sortedIncidents()[0];
      if (first) selectIncident(first.id, { fly: false });
    } else if (state.selectedId && !state.incidents.has(state.selectedId)) {
      state.selectedId = null;
      state.detail = null;
      detailEmpty();
      stopViewer();
    }
    if (initial) {
      if (state.mode === 'state' && !state.incidents.size && state.account?.stateLat != null && state.map) {
        state.map.setView([state.account.stateLat, state.account.stateLng], 8, { animate: false });
      } else {
        fitAllIncidents();
      }
    }
  }

  function handleNewIncident(detail) {
    applyDetail(detail);
    const type = typeOf(detail);
    if (!state.selectedId) selectIncident(detail.id, { fly: false });
    if (state.soundOn && Date.now() - state.lastNewAt > 1500) {
      state.lastNewAt = Date.now();
      S.chime();
    }
    toast(`New ${type.label.toLowerCase()} incident`, `${detail.code} · ${detail.address || 'location received'}`, 'warning', 6000);
    $('queueSync').textContent = `last alert ${S.clockTime(new Date().toISOString())}`;
  }

  function handleFleet(units) {
    if (!Array.isArray(units)) return;
    state.units = new Map(units.map((unit) => [unit.id, unit]));
    renderUnitMarkers();
    renderKpis();
    renderFleetResults();
    // Refresh the open candidate list so "nearest" never goes stale.
    if (state.detail && state.candidates.has(state.detail.id)) {
      loadCandidates(state.detail.id, { force: true });
    }
    if (state.detail) syncDetailFromFleet(units);
  }

  function syncDetailFromFleet(units) {
    const detail = state.detail;
    if (!detail) return;
    const byId = new Map(units.map((unit) => [unit.id, unit]));
    let changed = false;
    let etaChanged = false;
    for (const assignment of activeAssignments(detail)) {
      const unit = byId.get(assignment.responderId);
      if (!unit) continue;
      if (unit.lat !== assignment.unitLat || unit.lng !== assignment.unitLng) {
        assignment.unitLat = unit.lat;
        assignment.unitLng = unit.lng;
        changed = true;
      }
      if (unit.progress != null && Math.abs((unit.progress || 0) - (assignment.progress || 0)) > 0.008) {
        assignment.progress = unit.progress;
        changed = true;
      }
      if (unit.etaMinutes != null && unit.etaMinutes !== assignment.etaMinutes) {
        assignment.etaMinutes = unit.etaMinutes;
        etaChanged = true;
      }
    }
    if (changed) {
      renderAssignedSection();
      renderRoutes();
      const eta = document.querySelector('[data-detail-eta]');
      if (eta) {
        const active = activeAssignments(detail);
        eta.textContent = active.length ? S.formatEta(Math.min(...active.map((a) => Number(a.etaMinutes) || 99))) : '—';
      }
      const summary = summaryOf(detail);
      state.incidents.set(summary.id, summary);
      renderMapSelected();
    } else if (etaChanged) {
      updateLiveDetail(detail);
    }
  }

  function bindSocket() {
    socket.on('connect', () => {
      socket.emit('dispatch:subscribe');
    });
    socket.on('dispatch:bootstrap', (data) => applyBootstrap(data));
    socket.on('incident:new', (detail) => handleNewIncident(detail));
    socket.on('incident:updated', (detail) => {
      if (!detail) return;
      applyDetail(detail);
      if (!detail.isActive && detail.id === state.selectedId) {
        // applyDetail already cleared the selection.
        state.candidates.delete(detail.id);
      }
    });
    socket.on('incident:location', (payload) => {
      const incident = state.incidents.get(payload.id);
      if (incident) {
        incident.lat = payload.lat;
        incident.lng = payload.lng;
        incident.accuracyM = payload.accuracyM;
        ensureIncidentMarkers();
        renderQueue();
      }
      if (state.detail?.id === payload.id) {
        state.detail.lat = payload.lat;
        state.detail.lng = payload.lng;
        state.detail.accuracyM = payload.accuracyM;
        updateLiveDetail(state.detail);
        ensureIncidentMarkers();
      }
    });
    socket.on('assignment:new', ({ incident, assignment }) => {
      applyDetail(incident, { forceRender: true });
      if (state.soundOn) S.dispatchTone();
      toast('Unit assigned', `${assignment.callSign} → ${incident.code} · ETA ${S.formatEta(assignment.etaMinutes)}`, 'success');
    });
    socket.on('assignment:updated', ({ incident }) => {
      applyDetail(incident);
    });
    // First responder accepted — state notified. State owns the dispatch now.
    const onResponderAccepted = ({ incident, assignment } = {}) => {
      if (!incident || !assignment) return;
      applyDetail(incident);
      const label = state.mode === 'state' ? 'Responder accepted' : 'Responder accepted (state notified)';
      toast(label, `${assignment.callSign || 'Unit'} accepted ${incident.code} and is en route.`, 'success', 6500);
      if (state.soundOn) S.chime?.();
    };
    socket.on('responder:accepted', onResponderAccepted);
    socket.on('state:notify', onResponderAccepted);
    socket.on('message:new', ({ incidentId, message }) => {
      if (state.detail?.id !== Number(incidentId)) return;
      const messages = state.detail.messages || (state.detail.messages = []);
      if (messages.some((m) => m.id === message.id)) return;
      messages.push(message);
      if (state.detailTab === 'chat') renderDetail();
    });
    socket.on('note:new', ({ incidentId, note }) => {
      if (state.detail?.id !== Number(incidentId)) return;
      const notes = state.detail.notes || (state.detail.notes = []);
      if (notes.some((n) => n.id === note.id)) return;
      notes.push(note);
      notes.sort((a, b) => Number(b.pinned) - Number(a.pinned) || new Date(b.createdAt) - new Date(a.createdAt));
      if (state.detailTab === 'notes') renderDetail();
    });
    socket.on('ai:update', ({ incidentId, ai } = {}) => {
      if (!state.detail || state.detail.id !== Number(incidentId) || !ai) return;
      state.detail.ai = ai;
      renderDetail();
    });
    socket.on('ai:message', ({ incidentId, message, ai } = {}) => {
      if (!state.detail || state.detail.id !== Number(incidentId)) return;
      if (ai) state.detail.ai = ai;
      const messages = state.detail.ai?.messages || (state.detail.ai ? (state.detail.ai.messages = []) : []);
      if (message && !messages.some((entry) => entry.id === message.id)) messages.push(message);
      renderDetail();
    });
    socket.on('ai:error', ({ message } = {}) => {
      if (message) toast('AI support', message, 'error');
    });
    socket.on('call:update', ({ incidentId, call } = {}) => {
      if (!call) return;
      const id = Number(incidentId);
      const summary = state.incidents.get(id);
      if (summary) summary.call = call;
      if (!state.detail || state.detail.id !== id) return;
      state.detail.call = call;
      renderDetail();
      const statusEl = document.getElementById('callConsoleStatus');
      if (statusEl) {
        statusEl.textContent = call.status === 'connected'
          ? `LIVE · ${call.claimedByName || 'State EOC'} on the line`
          : call.status === 'ended'
            ? `ENDED · ${call.endReason || 'Call closed'}`
            : `${String(call.status || '').toUpperCase()} · ${call.claimedByName || 'Unclaimed'}`;
      }
      if (call.status === 'ended') {
        stopCallViewer();
        if (state.soundOn) S.chime?.();
      }
    });
    socket.on('stats:update', (stats) => {
      state.stats = stats;
      renderKpis();
      updateRegistrationCount();
    });
    socket.on('fleet:update', (units) => handleFleet(units));
    const onUnitFrame = (unit) => {
      if (!unit?.id) return;
      // fleet:unit frames are full units; unit:presence frames are light.
      // Merge so presence never wipes call-sign/agency coordinates.
      const existing = state.units.get(unit.id);
      const merged = existing ? { ...existing, ...unit } : unit;
      state.units.set(unit.id, merged);
      renderUnitMarkers();
      renderKpis();
      renderFleetResults();
      if (state.detail) syncDetailFromFleet([...state.units.values()]);
    };
    socket.on('fleet:unit', onUnitFrame);
    socket.on('unit:presence', onUnitFrame);
    socket.on('unit:panic', (payload) => {
      if (!payload) return;
      toast('Unit distress panic', `${payload.callSign || 'Unit'} triggered a panic · ${payload.lat != null ? S.formatCoord(payload.lat, payload.lng) : 'location pending'}`, 'error', 8000);
    });

    // PTT Radio Protocol listeners
    socket.on('ptt:rx-start', (payload) => handlePttIncoming(payload, 'start'));
    socket.on('ptt:rx-audio', (payload) => handlePttIncoming(payload, 'audio'));
    socket.on('ptt:rx-end', (payload) => handlePttIncoming(payload, 'end'));
  }

  // -------------------------------------------------------------------------
  // Event bindings
  // -------------------------------------------------------------------------
  function bindUi() {
    $$('#queueFilters [data-filter]').forEach((button) => {
      button.addEventListener('click', () => setQueueFilter(button.dataset.filter));
    });

    const searchInputs = [$('queueSearch'), $('queueSearchMobile')].filter(Boolean);
    searchInputs.forEach((input) => {
      input.addEventListener('input', () => {
        state.search = input.value;
        searchInputs.forEach((other) => { if (other !== input) other.value = input.value; });
        renderQueue();
      });
    });

    // Live fleet search & locate (ambulance / car).
    const fleetSearch = $('fleetSearch');
    if (fleetSearch) {
      fleetSearch.addEventListener('input', () => {
        state.fleetQuery = fleetSearch.value;
        renderFleetResults();
        renderUnitMarkers();
      });
      fleetSearch.addEventListener('keydown', (event) => {
        if (event.key === 'Enter') { event.preventDefault(); locateFirstFleetMatch(); }
        else if (event.key === 'Escape') {
          fleetSearch.value = '';
          state.fleetQuery = '';
          state.selectedUnitId = null;
          renderFleetResults();
          renderUnitMarkers();
          fleetSearch.blur();
        }
      });
    }
    $('fleetSearchClear')?.addEventListener('click', () => {
      if (fleetSearch) fleetSearch.value = '';
      state.fleetQuery = '';
      state.selectedUnitId = null;
      renderFleetResults();
      renderUnitMarkers();
      fleetSearch?.focus();
    });
    $('fleetResults')?.addEventListener('click', (event) => {
      const button = event.target.closest('[data-locate-unit]');
      if (!button) return;
      locateUnit(Number(button.dataset.locateUnit), { fly: true });
    });

    $('incidentQueue').addEventListener('click', (event) => {
      const card = event.target.closest('[data-incident-id]');
      if (!card) return;
      selectIncident(Number(card.dataset.incidentId));
    });

    $('detailPanel').addEventListener('click', (event) => {
      const button = event.target.closest('[data-action]');
      if (!button) return;
      const action = button.dataset.action;
      if (action === 'dispatch-nominated') {
        const responderId = Number(button.dataset.unitId);
        const agencyCode = button.dataset.agency;
        dispatchNominatedUnit(button, responderId, agencyCode);
      } else if (action === 'candidates') openCandidateModal(button.dataset.agency);
      else if (action === 'auto-dispatch') autoDispatch();
      else if (action === 'ai-dispatch') aiDispatchNearest();
      else if (action === 'acknowledge') acknowledgeIncident();
      else if (action === 'resolve') resolveSelected('resolved');
      else if (action === 'cancel') resolveSelected('cancelled');
      else if (action === 'copy-coords') {
        if (state.detail) S.copyText(`${state.detail.lat}, ${state.detail.lng}`);
      } else if (action === 'tab') {
        state.detailTab = button.dataset.tab;
        renderDetail();
      } else if (action === 'refresh-candidates') {
        if (state.detail) loadCandidates(state.detail.id, { force: true });
      } else if (action === 'open-feed') {
        openFeedModal();
      } else if (action === 'view-photo') {
        openScenePhoto();
      } else if (action === 'ai-takeover') {
        takeOverAi();
      } else if (action === 'ai-release') {
        releaseAi();
      } else if (action === 'call-open') {
        openCallLine();
      } else if (action === 'call-claim') {
        claimSelectedCall();
      } else if (action === 'call-end') {
        endSelectedCall();
      } else if (action === 'play-recording') {
        playRecording(button.dataset.recording, button.dataset.audio);
      } else if (action === 'export-case') {
        exportCaseRecord();
      }
    });

    // PTT buttons live both in the incident detail panel and inside the call
    // console modal (which is mounted outside #detailPanel), so listen on the
    // document and resolve the target button from the event path.
    document.addEventListener('pointerdown', (event) => {
      const button = event.target.closest?.('[data-action="ptt-press"]');
      if (!button) return;
      event.preventDefault();
      startPttTransmission(Number(button.dataset.unitId), button.dataset.callsign);
    });

    const endPttDispatch = () => {
      if (pttState.transmitting) {
        stopPttTransmission();
      }
    };
    window.addEventListener('pointerup', endPttDispatch);
    window.addEventListener('pointercancel', endPttDispatch);

    $('detailPanel').addEventListener('submit', (event) => {
      const form = event.target.closest('form[data-form]');
      if (!form) return;
      event.preventDefault();
      if (form.dataset.form === 'note') submitNote(form);
      else if (form.dataset.form === 'chat') submitChat(form);
      else if (form.dataset.form === 'ai-message') submitAiMessage(form);
      else if (form.dataset.form === 'update-incident') submitStaffUpdate(form);
    });

    $('soundToggle').addEventListener('click', () => toggleSound());
    $('demoIncidentBtn').addEventListener('click', async () => {
      const button = $('demoIncidentBtn');
      button.disabled = true;
      try {
        await api('/api/demo/incident', { method: 'POST', body: { priority: 1, stateCode: state.account?.stateCode || undefined } });
        toast('Demo alert injected', state.mode === 'state' ? `A realistic SOS in ${state.account.stateName || state.account.stateCode} is now in the queue.` : 'A realistic SOS near a known landmark is now in the queue.', 'info');
      } catch (error) {
        toast('Could not create demo alert', error.message, 'error');
      } finally {
        button.disabled = false;
      }
    });
    $('newIncidentBtn')?.addEventListener('click', () => openCreateIncident());
    $('topNewIncidentBtn')?.addEventListener('click', () => openCreateIncident());
    $('mapNewIncident').addEventListener('click', () => {
      const center = state.map?.getCenter();
      openCreateIncident(center ? { lat: center.lat, lng: center.lng } : {});
    });
    $('mapRecenter').addEventListener('click', fitAllIncidents);
    $('mapFleetToggle').addEventListener('click', () => {
      state.showFleet = !state.showFleet;
      refreshMapLayerVisibility();
    });
    $('mapRoutesToggle').addEventListener('click', () => {
      state.showRoutes = !state.showRoutes;
      refreshMapLayerVisibility();
      renderRoutes();
    });
    $('mapSelOpen').addEventListener('click', () => {
      document.querySelector('.dispatch-detail')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });

    document.querySelectorAll('[data-nav]').forEach((button) => {
      button.addEventListener('click', () => {
        const nav = button.dataset.nav;
        document.querySelectorAll('[data-nav]').forEach((node) => node.classList.remove('is-active'));
        if (nav === 'command') {
          button.classList.add('is-active');
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return;
        }
        button.classList.add('is-active');
        if (nav === 'nema-accounts') openNemaAccountsModal();
        else if (nav === 'states') openStateAccountsModal();
        else if (nav === 'responder-logins') openResponderLoginsModal();
        else if (nav === 'registrations') openRegistrationsModal();
        else window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    });

    $('registerEntityBtn')?.addEventListener('click', () => {
      openUnifiedRegistrationModal();
    });

    $('registerStateBtn')?.addEventListener('click', () => {
      openStateAccountsModal();
    });

    $('logoutBtn')?.addEventListener('click', async () => {
      const confirmed = await S.confirmDialog({
        title: 'Sign out of command?',
        body: 'Your tenant session will end and you will return to the secure sign-in page.',
        confirmLabel: 'Sign out'
      });
      if (confirmed) S.logout();
    });

    document.addEventListener('keydown', (event) => {
      const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(document.activeElement?.tagName);
      if (event.key === '/' && !typing) {
        event.preventDefault();
        $('queueSearch')?.focus();
      } else if ((event.key === 'n' || event.key === 'N') && !typing) {
        event.preventDefault();
        openCreateIncident();
      } else if (event.key === 'Escape' && document.activeElement === $('queueSearch')) {
        $('queueSearch').blur();
      }
    });
  }

  // -------------------------------------------------------------------------
  // Boot
  // -------------------------------------------------------------------------
  async function init() {
    // NEMA can hand state staff a one-time access code. It opens the state
    // dashboard directly, then the code is stripped from the URL.
    const accessCode = new URLSearchParams(location.search).get('code');
    if (accessCode) {
      try {
        await S.loginWithCode(accessCode);
        const clean = new URL(location.href);
        clean.searchParams.delete('code');
        location.replace(`${clean.pathname}${clean.search}`);
        return;
      } catch (error) {
        S.toast('Access code failed', error.message, 'error', 8000);
        const clean = new URL(location.href);
        clean.searchParams.delete('code');
        location.replace(`/login?role=state&code=${encodeURIComponent(accessCode)}`);
        return;
      }
    }
    let account;
    try {
      account = await S.requireRole(['superadmin', 'nema', 'state'], { next: location.pathname });
    } catch (error) {
      if (error.message === 'AUTH_REDIRECT') return;
      throw error;
    }
    // Path checks:
    if (location.pathname === '/admin' && account.role !== 'superadmin' && account.username !== 'admin') {
      location.replace('/nema');
      return;
    }
    if (location.pathname === '/nema' && account.role === 'state') {
      location.replace('/state');
      return;
    }
    if (location.pathname === '/state' && account.role !== 'state') {
      location.replace(account.role === 'superadmin' ? '/admin' : '/nema');
      return;
    }
    if (location.pathname === '/dispatch') {
      location.replace(account.role === 'superadmin' ? '/admin' : (account.role === 'nema' ? '/nema' : '/state'));
      return;
    }
    applyTenantUi(account);
    bindUi();
    bindSocket();
    initMap();
    S.setClock($('watClock'));
    $('soundToggle').innerHTML = `<span class="material-symbols-outlined text-[19px]">${state.soundOn ? 'volume_up' : 'volume_off'}</span>`;
    $('soundToggle').classList.toggle('text-alert-soft', state.soundOn);
    updateElapsedLabels();
    setInterval(updateElapsedLabels, 1000);
    setInterval(() => {
      $('queueSync').textContent = `updated ${S.clockTime(new Date().toISOString())}`;
    }, 25000);

    try {
      const data = await api('/api/bootstrap');
      applyBootstrap(data, { initial: true });
    } catch (error) {
      toast('Could not load command data', error.message, 'error', 8000);
    }
    socket.emit('dispatch:subscribe');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }

  window.addEventListener('beforeunload', () => stopViewer());
})();
