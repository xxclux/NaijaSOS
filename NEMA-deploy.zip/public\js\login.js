/* global NaijaSOS */
/**
 * Single sign-in page for the three independent NEMA tenants.
 *
 * Access chain:
 *   NEMA national admin  -> creates the state counterpart login/password
 *   State counterpart    -> creates the responder login/password
 *   First responder      -> signs in with the state-issued field login
 *
 * The server verifies the selected role against the issued account, so a
 * state account can never be promoted to NEMA or used to open a field tablet.
 * There is deliberately no "create password" action on this page.
 */
(() => {
  const S = window.NaijaSOS;
  const $ = (id) => document.getElementById(id);
  const state = { role: 'superadmin', demo: null, busy: false };

  const roleCopy = {
    superadmin: {
      label: 'Enter Super Admin Backend',
      icon: 'admin_panel_settings',
      title: 'Super Admin · Central Backend',
      body: 'Central backend & system registration. Registers NEMA National Command desks, State Counterparts (SEMA) across all 36 states + FCT, and First Responder vehicles with Hytera MNC360 hardware radios.',
      badge: 'Central Backend',
      hint: 'Default super admin credentials: Username admin, Password admin123456789.',
      placeholder: 'admin'
    },
    nema: {
      label: 'Enter NEMA National Command',
      icon: 'account_balance',
      title: 'NEMA National Command Centre',
      body: 'Operational federal emergency dispatch. Monitors nationwide incoming SOS calls, assigns incidents to First Responders on Hytera MNC360 hardware radios, and handles cross-border mutual aid.',
      badge: 'Federal Dispatch',
      hint: 'Use the NEMA command credentials issued by the Super Admin.',
      placeholder: 'e.g. nema.admin'
    },
    state: {
      label: 'Enter State SEMA EOC',
      icon: 'location_city',
      title: 'State Counterpart · SEMA Command',
      body: 'State-level disaster and emergency operations center. Restricted to your state boundary; manages local incidents and field response assets.',
      badge: 'State EOC',
      hint: 'Use the credentials issued by Super Admin / NEMA for your state EOC.',
      placeholder: 'e.g. lagos.eoc'
    },
    responder: {
      label: 'Enter First Responder Dashboard',
      icon: 'local_taxi',
      title: 'First Responder · In-Vehicle / Field Radio',
      body: 'Operational field responder terminal for emergency vehicles & dismounted patrol crews. Signs into /responder dashboard.',
      badge: 'Field Responder',
      hint: 'Enter your field APK username & password provisioned on Admin registry.',
      placeholder: 'e.g. unth.amb.car.12'
    }
  };

  function setRole(role) {
    const valid = ['superadmin', 'nema', 'state', 'responder'];
    const targetRole = valid.includes(role) ? role : 'superadmin';
    state.role = targetRole;
    const copy = roleCopy[targetRole] || roleCopy.superadmin;
    document.querySelectorAll('#roleSelector [data-role]').forEach((button) => {
      const active = button.dataset.role === targetRole;
      button.classList.toggle('is-active', active);
      button.setAttribute('aria-selected', active ? 'true' : 'false');
    });
    $('loginSubmitLabel').textContent = copy.label;
    $('loginSubmitIcon').textContent = copy.icon;
    $('roleContext').dataset.role = targetRole;
    $('roleContextIcon').textContent = copy.icon;
    $('roleContextTitle').textContent = copy.title;
    $('roleContextBody').textContent = copy.body;
    $('roleContextBadge').textContent = copy.badge;
    $('roleContextBadge').className = 'badge badge-ok';
    $('passwordHint').textContent = copy.hint;
    $('username').placeholder = copy.placeholder;
    $('loginError').classList.add('hidden');
    // State staff can open their dashboard with a NEMA-issued access code.
    $('accessCodePanel')?.classList.toggle('hidden', targetRole !== 'state');

    // First responder auto-fill & remember support
    const autoBtn = $('btnAutoFillResponder');
    if (autoBtn) autoBtn.classList.toggle('hidden', targetRole !== 'responder');
    if (targetRole === 'responder') {
      try {
        const saved = JSON.parse(localStorage.getItem('naijasos.remember_responder') || 'null');
        if (saved?.username && saved?.password) {
          $('username').value = saved.username;
          $('password').value = saved.password;
        } else if (state.demo?.demo?.responders?.[0]) {
          const r = state.demo.demo.responders[0];
          $('username').value = r.username;
          $('password').value = r.password;
        }
      } catch {}
    }
  }

  function showError(message, suggestRole = null) {
    const node = $('loginError');
    if (suggestRole) {
      node.innerHTML = `
        <div class="flex flex-col gap-1.5 sm:flex-row sm:items-center sm:justify-between">
          <span>${S.esc(message)}</span>
          <button type="button" id="switchRoleBtn" class="btn btn-sm btn-nema h-7 px-2.5 text-[10px] font-bold shrink-0">Switch to ${roleCopy[suggestRole]?.title || suggestRole}</button>
        </div>`;
      $('switchRoleBtn')?.addEventListener('click', () => {
        setRole(suggestRole);
        $('password').focus();
      });
    } else {
      node.textContent = message;
    }
    node.classList.remove('hidden');
  }

  async function loadPublicData() {
    state.demo = await S.api('/api/auth/demo', { auth: false }).catch(() => null);
    renderDemo();
  }

  function renderDemo() {
    const host = $('demoAccounts');
    if (!state.demo) {
      host.innerHTML = '<p class="text-[10px] text-dim">Demo credentials unavailable.</p>';
      return;
    }
    const card = (role, title, subtitle, username, password, stateCode = '') => `
      <button type="button" class="demo-account" data-role="${role}" data-user="${S.esc(username)}" data-pass="${S.esc(password)}" data-state="${S.esc(stateCode)}">
        <span class="demo-account__badge">${S.esc(title)}</span>
        <span class="min-w-0 flex-1">
          <span class="block truncate text-[11px] font-bold text-text">${S.esc(username)}</span>
          <span class="block truncate text-[9px] text-dim">${S.esc(subtitle)}</span>
        </span>
        <span class="material-symbols-outlined text-[16px] text-dim">arrow_forward</span>
      </button>`;

    const responderCards = (state.demo.demo?.responders || []).map((r) =>
      card('responder', r.callSign || r.username, `Field Responder · ${r.stateCode || 'State'} · Hytera APK`, r.username, r.password || '')
    ).join('');

    host.innerHTML = [
      `<p class="px-1 font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-dim">Super Admin · Central Backend</p>`,
      card('superadmin', 'Super Admin', 'National Entity Registrations', 'admin', 'admin123456789'),
      responderCards ? `<p class="px-1 mt-2.5 font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-dim">First Responder · Field Terminal</p>` + responderCards : '',
    ].join('');
    host.querySelectorAll('[data-user]').forEach((button) => {
      button.addEventListener('click', () => {
        setRole(button.dataset.role);
        $('username').value = button.dataset.user;
        $('password').value = button.dataset.pass;
        $('password').focus();
      });
    });
  }

  function nextPath(role) {
    const requested = new URLSearchParams(location.search).get('next');
    const allowed = {
      superadmin: ['/admin', '/nema', '/dispatch', '/responder'],
      nema: ['/nema', '/dispatch'],
      state: ['/state'],
      responder: ['/responder']
    };
    const base = requested ? requested.split('?')[0] : null;
    if (requested && requested.startsWith('/') && !requested.startsWith('//') && (role === 'superadmin' || allowed[role]?.includes(base))) {
      return requested;
    }
    return S.homeForRole(role);
  }

  async function redeemAccessCode() {
    if (state.busy) return;
    const input = $('accessCodeInput');
    const button = $('accessCodeSubmit');
    const errorBox = $('accessCodeError');
    const code = input.value.trim();
    if (!code) {
      errorBox.textContent = 'Enter the access code NEMA generated for your state.';
      errorBox.classList.remove('hidden');
      input.focus();
      return;
    }
    state.busy = true;
    button.disabled = true;
    button.textContent = 'Opening…';
    errorBox.classList.add('hidden');
    try {
      await S.loginWithCode(code);
      location.replace('/state');
    } catch (error) {
      state.busy = false;
      button.disabled = false;
      button.textContent = 'Open';
      errorBox.textContent = error.message || 'That access code could not be used.';
      errorBox.classList.remove('hidden');
      input.select();
    }
  }

  async function submit(event) {
    event.preventDefault();
    if (state.busy) return;
    const role = state.role;
    const username = $('username').value.trim();
    const password = $('password').value;
    if (!username || !password) {
      showError('Enter your username and password.');
      return;
    }
    state.busy = true;
    $('loginSubmit').disabled = true;
    $('loginSubmitLabel').textContent = 'Verifying…';
    $('loginError').classList.add('hidden');
    try {
      const result = await S.login({ role, username, password });
      const account = result.account;
      if ($('rememberMe')?.checked && role === 'responder') {
        localStorage.setItem('naijasos.remember_responder', JSON.stringify({ username, password }));
      } else if (role === 'responder') {
        localStorage.removeItem('naijasos.remember_responder');
      }
      // Verify role match; allow superadmin crossover to nema, and responder accounts
      const roleOk = account.role === role
        || (role === 'superadmin' && account.username === 'admin')
        || (role === 'nema' && account.role === 'superadmin');
      if (!roleOk) {
        throw new Error('The selected workspace does not match this account');
      }
      location.replace(nextPath(account.role));
    } catch (error) {
      const msg = error.message || 'Sign-in failed. Check your credentials and selected workspace.';
      let suggestRole = null;
      if (/superadmin/i.test(msg) && role !== 'superadmin') suggestRole = 'superadmin';
      else if (/state/i.test(msg) && role !== 'state') suggestRole = 'state';
      else if (/responder/i.test(msg) && role !== 'responder') suggestRole = 'responder';
      else if (/nema/i.test(msg) && role !== 'nema') suggestRole = 'nema';
      showError(msg, suggestRole);
      $('loginSubmit').disabled = false;
      $('loginSubmitLabel').textContent = roleCopy[role]?.label || 'Enter command';
      state.busy = false;
      return;
    }
  }

  function roleFromRequest() {
    const params = new URLSearchParams(location.search);
    const explicit = params.get('role');
    if (explicit === 'superadmin') return 'superadmin';
    if (explicit === 'nema') return 'nema';
    if (explicit === 'state') return 'state';
    if (explicit === 'responder') return 'responder';
    const next = params.get('next') || '';
    if (next.startsWith('/responder')) return 'responder';
    if (next.startsWith('/admin')) return 'superadmin';
    if (next.startsWith('/state')) return 'state';
    if (next.startsWith('/nema') || next.startsWith('/dispatch')) return 'nema';
    return 'superadmin';
  }

  async function boot() {
    setRole(roleFromRequest());
    document.querySelectorAll('#roleSelector [data-role]').forEach((button) => {
      button.addEventListener('click', () => setRole(button.dataset.role));
    });
    $('loginForm').addEventListener('submit', submit);
    $('accessCodeSubmit')?.addEventListener('click', redeemAccessCode);
    $('accessCodeInput')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') {
        event.preventDefault();
        redeemAccessCode();
      }
    });
    $('accessCodeInput')?.addEventListener('input', (event) => {
      const clean = event.target.value.toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 8);
      event.target.value = clean.length > 4 ? `${clean.slice(0, 4)}-${clean.slice(4)}` : clean;
    });
    $('passwordToggle').addEventListener('click', () => {
      const input = $('password');
      input.type = input.type === 'password' ? 'text' : 'password';
      $('passwordToggle').innerHTML = `<span class="material-symbols-outlined text-[18px]">${input.type === 'password' ? 'visibility' : 'visibility_off'}</span>`;
      $('passwordToggle').setAttribute('aria-label', input.type === 'password' ? 'Show password' : 'Hide password');
    });
    $('demoToggle').addEventListener('click', () => {
      const host = $('demoAccounts');
      host.classList.toggle('hidden');
      $('demoToggle').textContent = host.classList.contains('hidden') ? 'Show' : 'Hide';
    });

    // If this browser already has a valid tenant session and was directed here with ?next=,
    // continue to that workspace. If visited directly, show an active session banner so
    // the user can continue or easily sign in as another account.
    const params = new URLSearchParams(location.search);
    const hasNext = params.has('next');
    const targetRole = roleFromRequest();
    const codeParam = params.get('code');
    if (codeParam) {
      setRole('state');
      $('accessCodeInput').value = codeParam;
      await redeemAccessCode();
      return;
    }
    if (S.session()?.token) {
      try {
        const { account } = await S.api('/api/auth/me');
        // Only auto-redirect if existing session matches the requested role
        if (hasNext && (account.role === targetRole || (account.role === 'superadmin' && targetRole === 'superadmin'))) {
          location.replace(nextPath(account.role));
          return;
        }
        const banner = $('activeSessionBanner');
        if (banner) {
          banner.classList.remove('hidden');
          $('activeSessionName').textContent = `${account.displayName || account.username} (${S.roleLabel(account.role)})`;
          $('activeSessionContinue').href = nextPath(account.role);
          $('activeSessionSignout')?.addEventListener('click', async () => {
            await S.logout({ redirect: null });
            banner.classList.add('hidden');
            $('username').value = '';
            $('password').value = '';
            $('username').focus();
          });
        }
      } catch {
        S.clearSession();
      }
    }

    $('btnAutoFillResponder')?.addEventListener('click', () => {
      const r = state.demo?.demo?.responders?.[0] || { username: 'unth.amb.car.12', password: 'RESP-J9RCHW' };
      $('username').value = r.username;
      $('password').value = r.password;
      $('password').focus();
    });

    await loadPublicData();
    setRole(targetRole);
    $('username').focus();
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot, { once: true });
  else boot();
})();
