/* global NaijaSOS */
/**
 * NaijaSOS Super Admin Central Backend
 * ---------------------------------------------------------------------------
 * Sole purpose:
 *  1. Register & govern NEMA Agents / Staff (Federal Command Operators)
 *  2. Register First Responders & Hytera MNC360 radio terminals (+ in-vehicle APK logins)
 *  3. Central Site Database: audit vault linking citizen user SOS records to deployed first responders
 */
(() => {
  const S = window.NaijaSOS;
  const $ = (id) => document.getElementById(id);

  const state = {
    account: null,
    currentTab: 'nema',
    nemaAccounts: [],
    responders: [],
    databaseRecords: [],
    states: [],
    agencies: [],
    map: null,
    mapMarkers: new Map(),
    selectedUnitId: null
  };

  const agencyMeta = {
    MEDICAL: { label: 'Medical', color: '#ef4444', icon: 'medical_services', badgeClass: 'badge-alert' },
    POLICE: { label: 'Police', color: '#3b82f6', icon: 'local_police', badgeClass: 'badge-blue' },
    FIRE: { label: 'Fire', color: '#f97316', icon: 'local_fire_department', badgeClass: 'badge-p2' },
    ROAD_SAFETY: { label: 'Road Safety', color: '#eab308', icon: 'traffic', badgeClass: 'badge-warn' },
    GENERAL: { label: 'General', color: '#7ddba8', icon: 'emergency', badgeClass: 'badge-ok' }
  };

  function updateClock() {
    const el = $('watClock');
    if (!el) return;
    const now = new Date();
    // West Africa Time (UTC+1)
    const wat = new Date(now.getTime() + (1 * 60 + now.getTimezoneOffset()) * 60000);
    el.textContent = [wat.getHours(), wat.getMinutes(), wat.getSeconds()]
      .map((n) => String(n).padStart(2, '0'))
      .join(':');
  }

  // -------------------------------------------------------------------------
  // Tabs
  // -------------------------------------------------------------------------
  function switchTab(tabName) {
    state.currentTab = tabName;
    document.querySelectorAll('[data-tab]').forEach((btn) => {
      const active = btn.dataset.tab === tabName;
      btn.classList.toggle('is-active', active);
      btn.setAttribute('aria-selected', active ? 'true' : 'false');
    });

    $('panelNema')?.classList.toggle('hidden', tabName !== 'nema');
    $('panelResponders')?.classList.toggle('hidden', tabName !== 'responders');
    $('panelDatabase')?.classList.toggle('hidden', tabName !== 'database');

    if (tabName === 'nema' && !state.nemaAccounts.length) loadNemaStaff();
    if (tabName === 'responders') {
      if (!state.responders.length) loadResponders();
      ensureFleetMap();
      // Hidden Leaflet panes size to 0; re-measure once visible.
      requestAnimationFrame(() => state.map?.invalidateSize());
      renderFleetMap();
    }
    if (tabName === 'database' && !state.databaseRecords.length) loadDatabaseRecords();
  }

  // -------------------------------------------------------------------------
  // Overview metrics
  // -------------------------------------------------------------------------
  async function loadOverview() {
    try {
      const data = await S.api('/api/admin/overview');
      if ($('metricNema')) $('metricNema').textContent = data.nemaAccountsCount ?? '—';
      if ($('metricResponders')) $('metricResponders').textContent = data.respondersCount ?? '—';
      if ($('metricIncidents')) $('metricIncidents').textContent = data.liveIncidents ?? '—';
      if ($('metricStates')) $('metricStates').textContent = `${data.stateAccountsCount ?? 0} / ${data.totalStates || 37}`;
    } catch (err) {
      console.warn('Overview load error:', err);
    }
  }

  // -------------------------------------------------------------------------
  // Section 1: NEMA Staff
  // -------------------------------------------------------------------------
  async function loadNemaStaff() {
    const tbody = $('tableBodyNema');
    if (tbody) tbody.innerHTML = '<tr><td colspan="8" class="py-8 text-center text-dim font-mono text-[11px]">Fetching NEMA federal staff accounts…</td></tr>';
    try {
      const res = await S.api('/api/admin/nema-accounts');
      state.nemaAccounts = res.accounts || [];
      if ($('tabCountNema')) $('tabCountNema').textContent = state.nemaAccounts.length;
      if ($('metricNema')) $('metricNema').textContent = state.nemaAccounts.length;
      renderNemaStaff();
    } catch (err) {
      if (tbody) tbody.innerHTML = `<tr><td colspan="8" class="py-8 text-center text-alert text-[11px] font-mono">Failed to load NEMA staff: ${S.esc(err.message)}</td></tr>`;
    }
  }

  function renderNemaStaff() {
    const tbody = $('tableBodyNema');
    if (!tbody) return;
    const query = ($('searchNema')?.value || '').trim().toLowerCase();
    const rows = state.nemaAccounts.filter((acc) => {
      if (!query) return true;
      return (
        acc.username.toLowerCase().includes(query) ||
        (acc.displayName || '').toLowerCase().includes(query) ||
        (acc.role || '').toLowerCase().includes(query)
      );
    });

    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="py-10 text-center text-dim text-[12px]">No NEMA staff accounts found.</td></tr>';
      return;
    }

    tbody.innerHTML = rows.map((acc) => `
      <tr>
        <td>
          <div class="flex items-center gap-2.5">
            <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-nema/30 bg-nema/10 text-nema-soft">
              <span class="material-symbols-outlined text-[17px]">${acc.role === 'superadmin' ? 'admin_panel_settings' : 'account_balance'}</span>
            </span>
            <div class="min-w-0">
              <p class="font-bold text-text text-[12px] truncate">${S.esc(acc.displayName || acc.username)}</p>
              <p class="font-mono text-[8px] text-dim">${acc.role === 'superadmin' ? 'Central System Governance' : 'Federal Operations Desk'}</p>
            </div>
          </div>
        </td>
        <td><code class="font-mono text-[11px] text-[#7ddba8] bg-panel-2 px-1.5 py-0.5 rounded border border-line-soft">${S.esc(acc.username)}</code></td>
        <td>
          ${acc.role === 'superadmin'
            ? '<span class="text-dim text-[10px] font-mono">Bootstrap · hidden</span>'
            : acc.tempPassword
              ? `<div class="flex items-center gap-1.5">
                  <code class="font-mono text-[11px] text-[#f4c430] bg-panel-2 px-1.5 py-0.5 rounded border border-[#f4c430]/30 select-all">${S.esc(acc.tempPassword)}</code>
                  <button type="button" class="btn btn-ghost btn-sm h-6 px-1.5 shrink-0" title="Copy password" onclick="navigator.clipboard?.writeText('${S.esc(acc.tempPassword)}')">
                    <span class="material-symbols-outlined text-[13px]">content_copy</span>
                  </button>
                </div>
                <p class="font-mono text-[8px] text-dim mt-0.5">Visible until first sign-in</p>`
              : `<span class="text-dim text-[10px] font-mono italic">Signed in — cleared</span>`
          }
        </td>
        <td><span class="badge ${acc.role === 'superadmin' ? 'badge-ok' : 'badge-muted'} font-mono">${S.esc(acc.role.toUpperCase())}</span></td>
        <td><span class="data text-[11px] text-text">${acc.activeSessions || 0} active</span></td>
        <td><span class="badge badge-ok"><span class="live-dot mr-1"></span> ACTIVE</span></td>
        <td><span class="data text-[11px] text-dim">${S.relativeTime(acc.createdAt)}</span></td>
        <td class="text-right">
          ${acc.role === 'superadmin' ? '<span class="text-dim text-[10px] font-mono">Master</span>' : `
            <div class="flex items-center justify-end gap-1.5">
              <button class="btn btn-ghost btn-sm h-7 text-[10px] px-2.5" data-edit-nema="${acc.id}" title="Edit username, display name and regenerate password">
                <span class="material-symbols-outlined text-[14px]">edit</span>
                <span>Edit</span>
              </button>
              <button class="btn btn-ghost btn-sm h-7 text-[10px] px-2.5" data-reset-nema="${acc.id}" title="Regenerate a new password now">
                <span class="material-symbols-outlined text-[14px]">lock_reset</span>
                <span>Reset Pass</span>
              </button>
            </div>
          `}
        </td>
      </tr>
    `).join('');
  }

  function openRegisterNemaModal() {
    const dialog = S.modal({
      title: 'Register NEMA Command Staff',
      subtitle: 'Create a federal operator account with national dispatch authority',
      body: `
        <form id="formRegisterNema" class="space-y-3.5">
          <div>
            <label class="field-label" for="nemaUsername">Operator Username</label>
            <input id="nemaUsername" class="input" placeholder="e.g. nema.ibrahim" required minlength="3" maxlength="40" autocomplete="off" />
            <p class="mt-1 text-[9px] text-dim font-mono">Letters, numbers, dot or dash.</p>
          </div>
          <div>
            <label class="field-label" for="nemaDisplayName">Full Name &amp; Title</label>
            <input id="nemaDisplayName" class="input" placeholder="e.g. Capt. Ibrahim Danladi (Federal Dispatcher)" required maxlength="80" />
          </div>
          <div>
            <div class="flex items-center justify-between mb-1.5">
              <label class="field-label !mb-0" for="nemaPassword">Initial Temporary Password</label>
              <button type="button" id="btnGenNemaPass" class="text-[10px] text-nema-soft font-mono hover:underline">Generate secure</button>
            </div>
            <input id="nemaPassword" class="input font-mono" placeholder="Minimum 8 characters" required minlength="8" />
          </div>
          <div class="rounded-xl border border-nema/30 bg-nema/10 p-3 text-[10px] leading-relaxed text-muted">
            <span class="material-symbols-outlined text-[15px] text-nema-soft align-middle mr-1">info</span>
            This account will be authorized to access the <strong>NEMA Federal Operational Command Center</strong> at <span class="data text-text">/nema</span>.
          </div>
          <div class="pt-2 flex justify-end gap-2">
            <button type="button" class="btn btn-ghost" data-close>Cancel</button>
            <button type="submit" class="btn btn-nema" id="btnSubmitNema">
              <span class="material-symbols-outlined text-[17px]">person_add</span>
              <span>Create NEMA Staff</span>
            </button>
          </div>
        </form>
      `
    });

    const form = dialog.el.querySelector('#formRegisterNema');
    const passInput = dialog.el.querySelector('#nemaPassword');
    dialog.el.querySelector('#btnGenNemaPass')?.addEventListener('click', () => {
      passInput.value = 'NEMA-' + Math.random().toString(36).slice(2, 8).toUpperCase();
    });

    // Auto-fill an initial generated password
    passInput.value = 'NEMA-' + Math.random().toString(36).slice(2, 8).toUpperCase();

    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const username = dialog.el.querySelector('#nemaUsername').value.trim();
      const displayName = dialog.el.querySelector('#nemaDisplayName').value.trim();
      const password = passInput.value;
      const submitBtn = dialog.el.querySelector('#btnSubmitNema');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Registering…';

      try {
        const res = await S.api('/api/admin/nema-accounts', {
          method: 'POST',
          body: { username, displayName, password }
        });
        dialog.close();
        S.toast('NEMA Staff Registered', `${res.account.displayName} (${res.account.username})`, 'success');
        openCredentialHandoverModal({
          account: res.account,
          password: res.temporaryPassword,
          title: 'NEMA Staff Credential Ready',
          roleNote: 'Authorised for NEMA Federal Command at /nema'
        });
        loadNemaStaff();
      } catch (err) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span class="material-symbols-outlined text-[17px]">person_add</span><span>Create NEMA Staff</span>';
        S.toast('Registration Failed', err.message, 'error');
      }
    });
  }

  // Edit an existing NEMA desk: change username / display name and
  // regenerate the password in one modal (Super Admin only).
  function openEditNemaModal(account) {
    if (!account) return;
    const gen = () => 'NEMA-' + Math.random().toString(36).slice(2, 8).toUpperCase();
    const dialog = S.modal({
      title: `Edit NEMA desk · ${account.username}`,
      subtitle: 'Change the username, display name, or regenerate the password. Changing username/password revokes every live session for that desk.',
      body: `
        <form id="formEditNema" class="space-y-3.5">
          <div>
            <label class="field-label" for="editNemaUsername">Username</label>
            <input id="editNemaUsername" class="input" value="${S.esc(account.username)}" required minlength="3" maxlength="40" autocomplete="off" />
            <p class="mt-1 text-[9px] text-dim font-mono">Letters, numbers, dot or dash. Must be unique.</p>
          </div>
          <div>
            <label class="field-label" for="editNemaDisplayName">Full Name &amp; Title</label>
            <input id="editNemaDisplayName" class="input" value="${S.esc(account.displayName || '')}" required maxlength="80" />
          </div>
          <div>
            <div class="flex items-center justify-between mb-1.5">
              <label class="field-label !mb-0" for="editNemaPassword">New password <span class="text-dim">(blank = keep current)</span></label>
              <button type="button" id="btnRegenNemaPass" class="text-[10px] text-nema-soft font-mono hover:underline">Regenerate</button>
            </div>
            <input id="editNemaPassword" class="input font-mono" placeholder="Leave blank to keep — or regenerate" autocomplete="new-password" />
          </div>
          <div class="rounded-xl border border-nema/30 bg-nema/10 p-3 text-[10px] leading-relaxed text-muted">
            <span class="material-symbols-outlined text-[15px] text-nema-soft align-middle mr-1">info</span>
            Saving a new username or password signs that desk out everywhere immediately. The new credential is shown once in the handover.
          </div>
          <div class="pt-2 flex justify-end gap-2">
            <button type="button" class="btn btn-ghost" data-close>Cancel</button>
            <button type="submit" class="btn btn-nema" id="btnSubmitEditNema">
              <span class="material-symbols-outlined text-[17px]">save</span>
              <span>Save changes</span>
            </button>
          </div>
        </form>
      `
    });

    const passInput = dialog.el.querySelector('#editNemaPassword');
    dialog.el.querySelector('#btnRegenNemaPass')?.addEventListener('click', () => {
      passInput.value = gen();
    });

    dialog.el.querySelector('#formEditNema').addEventListener('submit', async (e) => {
      e.preventDefault();
      const payload = {
        username: dialog.el.querySelector('#editNemaUsername').value.trim(),
        displayName: dialog.el.querySelector('#editNemaDisplayName').value.trim()
      };
      const password = passInput.value.trim();
      if (password) payload.password = password;
      const submitBtn = dialog.el.querySelector('#btnSubmitEditNema');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Saving…';
      try {
        const res = await S.api(`/api/admin/nema-accounts/${account.id}`, {
          method: 'PATCH',
          body: payload
        });
        dialog.close();
        S.toast('NEMA Desk Updated', `${res.account.displayName} (${res.account.username})`, 'success');
        if (res.temporaryPassword) {
          openCredentialHandoverModal({
            account: res.account,
            password: res.temporaryPassword,
            title: 'NEMA Desk Credential Ready',
            roleNote: 'New username/password for NEMA Federal Command at /nema — old sessions revoked'
          });
        }
        loadNemaStaff();
      } catch (err) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span class="material-symbols-outlined text-[17px]">save</span><span>Save changes</span>';
        S.toast('Update Failed', err.message, 'error');
      }
    });
  }

  // -------------------------------------------------------------------------
  // Section 2: First Responders & Hytera Hardware
  // -------------------------------------------------------------------------
  function syncBadgeFor(unit) {
    const label = S.unitSyncLabel ? S.unitSyncLabel(unit) : (unit.isOnline ? 'ONLINE' : 'OFFLINE');
    const age = S.syncAgeText ? S.syncAgeText(unit) : (unit.gpsSyncAgeSeconds == null ? 'never synced' : `synced ${unit.gpsSyncAgeSeconds}s ago`);
    if (!unit.isLinked) {
      return `<span class="badge badge-warn font-mono" title="No in-vehicle login provisioned yet — issue credentials so the terminal can link."><span class="material-symbols-outlined mr-1 !text-[12px]">link_off</span>UNLINKED</span>
        <p class="mt-1 font-mono text-[8px] text-dim">No login bound</p>`;
    }
    if (label === 'SYNCING LIVE') {
      return `<span class="badge badge-ok font-mono"><span class="live-dot mr-1"></span>SYNCING LIVE</span>
        <p class="mt-1 font-mono text-[8px] text-dim">${S.esc(age)} · ${S.esc(unit.linkedUsername || '')}</p>`;
    }
    if (label === 'ONLINE') {
      return `<span class="badge badge-warn font-mono"><span class="live-dot mr-1"></span>ONLINE · GPS STALE</span>
        <p class="mt-1 font-mono text-[8px] text-dim">${S.esc(age)}</p>`;
    }
    return `<span class="badge badge-muted font-mono"><span class="material-symbols-outlined mr-1 !text-[12px]">link_off</span>OFFLINE</span>
      <p class="mt-1 font-mono text-[8px] text-dim">${S.esc(age)}</p>`;
  }

  function responderQuery() {
    return ($('searchResponders')?.value || '').trim().toLowerCase();
  }

  function responderMatches(unit, query) {
    if (!query) return true;
    return (
      (unit.callSign || '').toLowerCase().includes(query) ||
      (unit.vehicleType || '').toLowerCase().includes(query) ||
      (unit.plateNumber || '').toLowerCase().includes(query) ||
      (unit.station || '').toLowerCase().includes(query) ||
      (unit.account?.username || '').toLowerCase().includes(query) ||
      (unit.linkedUsername || '').toLowerCase().includes(query) ||
      (unit.stateCode || '').toLowerCase().includes(query) ||
      (unit.responderKind || '').toLowerCase().includes(query) ||
      (unit.agencyCode || '').toLowerCase().includes(query) ||
      (unit.status || '').toLowerCase().includes(query)
    );
  }

  function updateLiveSummary() {
    const total = state.responders.length;
    const linked = state.responders.filter((u) => u.isLinked).length;
    const online = state.responders.filter((u) => u.isOnline).length;
    const fresh = state.responders.filter((u) => u.isOnline && u.isGpsFresh).length;
    const el = $('adminLiveText');
    if (el) el.textContent = `${fresh} syncing live · ${online} online · ${linked}/${total} linked`;
    const count = $('adminMapCount');
    if (count) count.textContent = `${total} unit${total === 1 ? '' : 's'}`;
  }

  /** Merge a fleet frame from the socket (no account info) with the
   *  authoritative Admin list so login/username info is never lost. */
  function upsertUnit(incoming, { refetchIfMissing = false } = {}) {
    if (!incoming?.id) return;
    const index = state.responders.findIndex((u) => u.id === incoming.id);
    if (index >= 0) {
      const existing = state.responders[index];
      state.responders[index] = {
        ...existing,
        ...incoming,
        // Socket frames omit `account`; keep the API copy.
        account: incoming.account || existing.account || null,
        // Presence frames omit `linked_username` etc. — never wipe them.
        linkedUsername: incoming.linkedUsername || existing.linkedUsername || null,
        linkedLastLoginAt: incoming.linkedLastLoginAt || existing.linkedLastLoginAt || null,
        isLinked: incoming.isLinked ?? existing.isLinked ?? false
      };
      return state.responders[index];
    }
    if (refetchIfMissing) loadResponders();
    return null;
  }

  function ensureFleetMap() {
    if (state.map) return state.map;
    if (typeof L === 'undefined') return null;
    const map = L.map('adminFleetMap', { zoomControl: false, preferCanvas: true });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'
    }).addTo(map);
    L.control.zoom({ position: 'bottomright' }).addTo(map);
    state.map = map;
    // Fit once data is present; invalidateSize handled on tab switch.
    renderFleetMap();
    return map;
  }

  function renderFleetMap() {
    if (!state.map) return;
    const query = responderQuery();
    const agencyFilter = $('filterAgency')?.value || '';
    // Leaflet's DivIcon markers don't support an "opacity" fade per marker,
    // so non-matching units are simply hidden while a search is active.
    state.mapMarkers.forEach((marker) => state.map.removeLayer(marker));
    state.mapMarkers.clear();
    const visible = [];
    for (const unit of state.responders) {
      if (!Number.isFinite(Number(unit.lat)) || !Number.isFinite(Number(unit.lng))) continue;
      if (agencyFilter && unit.agencyCode !== agencyFilter) continue;
      if (query && !responderMatches(unit, query)) continue;
      visible.push(unit);
      const selected = state.selectedUnitId === unit.id;
      const marker = L.marker([unit.lat, unit.lng], {
        icon: S.unitMarkerIcon ? S.unitMarkerIcon(unit, selected) : null,
        keyboard: false
      });
      const label = S.unitSyncLabel ? S.unitSyncLabel(unit) : (unit.isOnline ? 'ONLINE' : 'OFFLINE');
      const age = S.syncAgeText ? S.syncAgeText(unit) : '';
      marker.bindPopup(`
        <div style="min-width:180px">
          <strong>${S.esc(unit.callSign)}</strong> · ${S.esc(unit.vehicleType || '')}<br/>
          <span>${S.esc(unit.status || '')} · ${S.esc(unit.stateCode || '')} · ${S.esc(unit.agencyCode || '')}</span><br/>
          <strong>${S.esc(label)}</strong> · ${S.esc(age)}<br/>
          <span>${S.formatCoord ? S.esc(S.formatCoord(unit.lat, unit.lng)) : `${unit.lat}, ${unit.lng}`}</span>
        </div>`, { closeButton: true });
      marker.on('click', () => selectUnit(unit.id, { fly: false }));
      marker.addTo(state.map);
      state.mapMarkers.set(unit.id, marker);
    }
    updateLiveSummary();
    if (visible.length === 1) {
      const only = visible[0];
      state.map.flyTo([only.lat, only.lng], Math.max(state.map.getZoom(), 14), { duration: 0.6 });
    } else if (visible.length > 1) {
      S.setMapView ? S.setMapView(state.map, visible, { padding: [40, 40], maxZoom: 12 }) : state.map.fitBounds(visible.map((u) => [u.lat, u.lng]), { padding: [40, 40] });
    } else if (!state.responders.length) {
      state.map.setView(S.LAGOS_CENTRE || [6.5244, 3.3792], 11);
    }
  }

  function selectUnit(unitId, { fly = true } = {}) {
    state.selectedUnitId = unitId;
    const unit = state.responders.find((u) => u.id === unitId);
    if (!unit) return;
    renderResponders();
    renderFleetMap();
    if (fly && Number.isFinite(Number(unit.lat)) && Number.isFinite(Number(unit.lng)) && state.map) {
      state.map.flyTo([unit.lat, unit.lng], Math.max(15, state.map.getZoom()), { duration: 0.7 });
      const marker = state.mapMarkers.get(unitId);
      setTimeout(() => marker?.openPopup(), 720);
    }
  }

  function locateFirstMatch() {
    const query = responderQuery();
    const agencyFilter = $('filterAgency')?.value || '';
    const first = state.responders.find(
      (u) => (!agencyFilter || u.agencyCode === agencyFilter) && responderMatches(u, query)
    );
    if (!first) {
      S.toast('No match', query ? `No live unit matches “${query}”.` : 'No live units to locate.', 'info');
      return;
    }
    selectUnit(first.id, { fly: true });
  }

  function bindLiveSocket() {
    const socket = S.socket;
    if (!socket) return;
    const ensureSubscribe = () => socket.emit('dispatch:subscribe');
    if (socket.connected) ensureSubscribe();
    socket.on('connect', ensureSubscribe);
    socket.on('dispatch:bootstrap', (data) => {
      if (!data?.responders?.length) return;
      // Bootstrap carries the fleet without account details; merge, don't clobber.
      for (const incoming of data.responders) upsertUnit(incoming);
      renderResponders();
      renderFleetMap();
    });
    socket.on('fleet:update', (units) => {
      if (!Array.isArray(units)) return;
      for (const incoming of units) upsertUnit(incoming, { refetchIfMissing: true });
      renderResponders();
      renderFleetMap();
    });
    const onUnit = (incoming) => {
      upsertUnit(incoming, { refetchIfMissing: true });
      renderResponders();
      renderFleetMap();
    };
    socket.on('fleet:unit', onUnit);
    socket.on('unit:presence', onUnit);
  }

  async function loadResponders() {
    const tbody = $('tableBodyResponders');
    if (tbody) tbody.innerHTML = '<tr><td colspan="9" class="py-8 text-center text-dim font-mono text-[11px]">Fetching first responder fleet &amp; hardware terminals…</td></tr>';
    try {
      const res = await S.api('/api/admin/responders');
      state.responders = res.responders || [];
      if ($('tabCountResponders')) $('tabCountResponders').textContent = state.responders.length;
      if ($('metricResponders')) $('metricResponders').textContent = state.responders.length;
      renderResponders();
      ensureFleetMap();
      renderFleetMap();
      updateLiveSummary();
    } catch (err) {
      if (tbody) tbody.innerHTML = `<tr><td colspan="9" class="py-8 text-center text-alert text-[11px] font-mono">Failed to load responders: ${S.esc(err.message)}</td></tr>`;
    }
  }

  function renderResponders() {
    const tbody = $('tableBodyResponders');
    if (!tbody) return;
    const query = responderQuery();
    const agencyFilter = $('filterAgency')?.value || '';

    const rows = state.responders.filter((u) => {
      if (agencyFilter && u.agencyCode !== agencyFilter) return false;
      return responderMatches(u, query);
    });

    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="9" class="py-10 text-center text-dim text-[12px]">No first responders matching criteria.</td></tr>';
      return;
    }

    tbody.innerHTML = rows.map((u) => {
      const meta = agencyMeta[u.agencyCode] || agencyMeta.GENERAL;
      const statusBadge = u.status === 'available'
        ? '<span class="badge badge-ok"><span class="live-dot mr-1"></span> READY</span>'
        : (u.status === 'on_scene'
            ? '<span class="badge badge-alert">ON SCENE</span>'
            : (u.status === 'dispatched' || u.status === 'en_route'
                ? '<span class="badge badge-warn">EN ROUTE</span>'
                : `<span class="badge badge-muted">${S.esc(u.status.toUpperCase())}</span>`));

      const selected = state.selectedUnitId === u.id;
      return `
        <tr class="${selected ? 'bg-nema/10' : ''}">
          <td>
            <div class="flex items-center gap-2.5">
              <span class="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border" style="border-color:${meta.color}55;background:${meta.color}18;color:${meta.color}">
                <span class="material-symbols-outlined text-[17px]">${meta.icon}</span>
              </span>
              <div class="min-w-0">
                <p class="font-bold text-text text-[12px] truncate">${S.esc(u.callSign)}</p>
                <p class="font-mono text-[8px] text-dim">${S.esc(u.vehicleType || 'Unit')} · ${S.esc(u.plateNumber || 'No Plate')}</p>
              </div>
            </div>
          </td>
          <td>
            <span class="badge ${meta.badgeClass} font-mono">${S.esc(meta.label)}</span>
          </td>
          <td><span class="data text-[11px] font-semibold text-text">${S.esc(u.stateCode || 'National')}</span></td>
          <td><span class="text-[11px] text-dim truncate max-w-[140px] block">${S.esc(u.station || 'Base')}</span></td>
          <td>
            <div class="min-w-0">
              <span class="badge badge-warn font-mono text-[8px]">Hytera MNC360</span>
              <p class="font-mono text-[7px] text-dim mt-0.5 truncate">PoC Terminal</p>
            </div>
          </td>
          <td>
            ${u.account?.username
              ? `<code class="font-mono text-[10px] text-[#f4c430] bg-panel-2 px-1.5 py-0.5 rounded border border-line-soft">${S.esc(u.account.username)}</code>`
              : (u.linkedUsername
                ? `<code class="font-mono text-[10px] text-[#f4c430] bg-panel-2 px-1.5 py-0.5 rounded border border-line-soft">${S.esc(u.linkedUsername)}</code>`
                : '<span class="badge badge-muted font-mono text-[8px]">No Login</span>')}
          </td>
          <td>${syncBadgeFor(u)}</td>
          <td>${statusBadge}</td>
          <td class="text-right">
            <div class="flex items-center justify-end gap-1.5">
              <button class="btn btn-ghost btn-sm h-7 text-[10px] px-2" data-locate-unit="${u.id}" title="Fly the map to this live unit" ${Number.isFinite(Number(u.lat)) ? '' : 'disabled'}>
                <span class="material-symbols-outlined text-[14px]">my_location</span>
                <span>Locate</span>
              </button>
              <button class="btn btn-ghost btn-sm h-7 text-[10px] px-2" data-reset-unit="${u.publicId || u.id}" title="Issue or reset Hytera APK credentials">
                <span class="material-symbols-outlined text-[14px]">key</span>
                <span>Credentials</span>
              </button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  async function openRegisterResponderModal() {
    if (!state.states.length) {
      try {
        const res = await S.api('/api/states');
        state.states = res.states || [];
      } catch {}
    }

    const stateOptions = state.states.map((st) => `<option value="${st.code}">${st.name} (${st.code})</option>`).join('');

    const dialog = S.modal({
      title: 'Register First Responder Vehicle & Hardware',
      subtitle: 'Provisions field unit and generates Hytera MNC360 in-vehicle radio APK login',
      body: `
        <form id="formRegisterResponder" class="space-y-3.5">
          <div class="grid gap-3 sm:grid-cols-2">
            <div>
              <label class="field-label" for="respCallSign">Call Sign</label>
              <input id="respCallSign" class="input uppercase font-bold" placeholder="e.g. AMB-08 or POLICE-15" required maxlength="20" />
            </div>
            <div>
              <label class="field-label" for="respAgency">Agency Service</label>
              <select id="respAgency" class="select" required>
                <option value="MEDICAL">Medical / Emergency Ambulance</option>
                <option value="POLICE">Nigeria Police Force</option>
                <option value="FIRE">Federal &amp; State Fire Service</option>
                <option value="ROAD_SAFETY">Federal Road Safety Corps (FRSC)</option>
              </select>
            </div>
          </div>

          <div class="grid gap-3 sm:grid-cols-2">
            <div>
              <label class="field-label" for="respState">State Jurisdiction</label>
              <select id="respState" class="select" required>
                <option value="LA">Lagos State (LA)</option>
                <option value="FC">Federal Capital Territory (FC)</option>
                ${stateOptions}
              </select>
            </div>
            <div>
              <label class="field-label" for="respVehicle">Vehicle Specification</label>
              <input id="respVehicle" class="input" placeholder="e.g. Toyota HiAce ALS Ambulance" required maxlength="60" />
            </div>
          </div>

          <div class="grid gap-3 sm:grid-cols-2">
            <div>
              <label class="field-label" for="respPlate">Plate Number</label>
              <input id="respPlate" class="input uppercase font-mono" placeholder="e.g. KJA-829-XA" maxlength="20" />
            </div>
            <div>
              <label class="field-label" for="respStation">Station / Divisional Base</label>
              <input id="respStation" class="input" placeholder="e.g. Ikeja Central Division Base" required maxlength="80" />
            </div>
          </div>

          <!-- Hardware Radio details -->
          <div class="rounded-xl border border-[#f4c430]/30 bg-[#f4c430]/[0.06] p-3.5 space-y-3">
            <div class="flex items-center gap-2">
              <span class="material-symbols-outlined text-[18px] text-[#f4c430]">radio</span>
              <p class="text-[11px] font-bold text-text">In-Vehicle Hardware Radio Terminal</p>
              <span class="badge badge-warn !text-[7px] ml-auto">Hytera MNC360</span>
            </div>
            <div class="grid gap-2 sm:grid-cols-2">
              <div>
                <label class="field-label" for="respHardwareImei">Radio IMEI / Terminal ID <span class="text-dim">(optional)</span></label>
                <input id="respHardwareImei" class="input input-sm font-mono" placeholder="e.g. 864201048291048" maxlength="30" />
              </div>
              <div>
                <label class="field-label" for="respTerminalUsername">APK Field Username</label>
                <input id="respTerminalUsername" class="input input-sm font-mono" placeholder="e.g. amb.08" />
              </div>
            </div>
          </div>

          <div class="pt-2 flex justify-end gap-2">
            <button type="button" class="btn btn-ghost" data-close>Cancel</button>
            <button type="submit" class="btn btn-nema" id="btnSubmitResponder">
              <span class="material-symbols-outlined text-[17px]">local_taxi</span>
              <span>Register Unit</span>
            </button>
          </div>
        </form>
      `
    });

    const callSignInput = dialog.el.querySelector('#respCallSign');
    const userField = dialog.el.querySelector('#respTerminalUsername');
    callSignInput.addEventListener('input', () => {
      const clean = callSignInput.value.trim().toLowerCase().replace(/[^a-z0-9]/g, '.');
      userField.value = clean;
    });

    dialog.el.querySelector('#formRegisterResponder').addEventListener('submit', async (e) => {
      e.preventDefault();
      const callSign = callSignInput.value.trim();
      const agencyCode = dialog.el.querySelector('#respAgency').value;
      const stateCode = dialog.el.querySelector('#respState').value;
      const vehicleType = dialog.el.querySelector('#respVehicle').value.trim();
      const plateNumber = dialog.el.querySelector('#respPlate').value.trim();
      const station = dialog.el.querySelector('#respStation').value.trim();
      const hardwareImei = dialog.el.querySelector('#respHardwareImei').value.trim();
      const username = userField.value.trim() || callSign.toLowerCase().replace(/[^a-z0-9]/g, '.');

      const submitBtn = dialog.el.querySelector('#btnSubmitResponder');
      submitBtn.disabled = true;
      submitBtn.textContent = 'Registering…';

      try {
        const res = await S.api('/api/admin/responders', {
          method: 'POST',
          body: {
            callSign, agencyCode, stateCode, vehicleType, plateNumber, station,
            hardwareImei, username, hardwareType: 'Hytera MNC360 Smart PoC In-Vehicle Radio Terminal'
          }
        });
        dialog.close();
        S.toast('First Responder Registered', `${callSign} (${agencyCode})`, 'success');
        openCredentialHandoverModal({
          account: res.account,
          password: res.temporaryPassword,
          title: 'First Responder In-Vehicle Login Ready',
          roleNote: `Field Terminal for ${callSign} on dedicated Hytera MNC360 radio APK (/responder)`
        });
        loadResponders();
      } catch (err) {
        submitBtn.disabled = false;
        submitBtn.innerHTML = '<span class="material-symbols-outlined text-[17px]">local_taxi</span><span>Register Unit</span>';
        S.toast('Registration Failed', err.message, 'error');
      }
    });
  }

  // -------------------------------------------------------------------------
  // Section 3: Site Database (Linking User SOS & First Responders)
  // -------------------------------------------------------------------------
  async function loadDatabaseRecords() {
    const tbody = $('tableBodyDatabase');
    if (tbody) tbody.innerHTML = '<tr><td colspan="8" class="py-8 text-center text-dim font-mono text-[11px]">Loading central database records linking citizen SOS and responders…</td></tr>';
    try {
      const res = await S.api('/api/admin/database/records?limit=100');
      state.databaseRecords = res.records || [];
      if ($('tabCountDatabase')) $('tabCountDatabase').textContent = state.databaseRecords.length;
      if ($('metricIncidents')) $('metricIncidents').textContent = res.stats?.totalIncidents ?? state.databaseRecords.length;
      renderDatabaseRecords();
    } catch (err) {
      if (tbody) tbody.innerHTML = `<tr><td colspan="8" class="py-8 text-center text-alert text-[11px] font-mono">Failed to load database records: ${S.esc(err.message)}</td></tr>`;
    }
  }

  function renderDatabaseRecords() {
    const tbody = $('tableBodyDatabase');
    if (!tbody) return;
    const query = ($('searchDatabase')?.value || '').trim().toLowerCase();
    const statusFilter = $('filterDbStatus')?.value || '';

    const rows = state.databaseRecords.filter((rec) => {
      if (statusFilter && rec.status !== statusFilter) return false;
      if (!query) return true;
      const respSigns = (rec.assignedResponders || []).map((r) => r.callSign).join(' ').toLowerCase();
      return (
        (rec.code || '').toLowerCase().includes(query) ||
        (rec.reporter_name || '').toLowerCase().includes(query) ||
        (rec.reporter_phone || '').toLowerCase().includes(query) ||
        (rec.address || '').toLowerCase().includes(query) ||
        (rec.landmark || '').toLowerCase().includes(query) ||
        respSigns.includes(query)
      );
    });

    if (!rows.length) {
      tbody.innerHTML = '<tr><td colspan="8" class="py-10 text-center text-dim text-[12px]">No database records matching query.</td></tr>';
      return;
    }

    tbody.innerHTML = rows.map((rec) => {
      const typeMeta = agencyMeta[rec.agency_code] || agencyMeta.GENERAL;
      const pBadge = rec.priority === 1
        ? '<span class="badge badge-alert">P1 · CRITICAL</span>'
        : (rec.priority === 2
            ? '<span class="badge badge-p2">P2 · URGENT</span>'
            : '<span class="badge badge-muted">P3 · ROUTINE</span>');

      const assignedList = (rec.assignedResponders || []).map((resp) => {
        const meta = agencyMeta[resp.agencyCode] || agencyMeta.GENERAL;
        return `
          <div class="inline-flex items-center gap-1.5 rounded-md border border-line-soft bg-panel-2 px-2 py-1 text-[10px]">
            <span class="material-symbols-outlined text-[13px]" style="color:${meta.color}">${meta.icon}</span>
            <span class="font-bold text-text">${S.esc(resp.callSign)}</span>
            <span class="badge badge-muted !text-[7px] uppercase font-mono">${S.esc(resp.assignmentStatus || 'assigned')}</span>
          </div>
        `;
      }).join(' ');

      const statusBadge = rec.status === 'resolved'
        ? '<span class="badge badge-ok"><span class="material-symbols-outlined text-[11px] mr-1">task_alt</span> RESOLVED</span>'
        : (rec.status === 'on_scene'
            ? '<span class="badge badge-alert"><span class="live-dot live-dot--red mr-1"></span> ON SCENE</span>'
            : (rec.status === 'dispatched' || rec.status === 'en_route'
                ? '<span class="badge badge-warn">DISPATCHED</span>'
                : '<span class="badge badge-p1">NEW ALERT</span>'));

      return `
        <tr>
          <td>
            <div>
              <p class="font-mono text-[12px] font-bold text-text">${S.esc(rec.code)}</p>
              <div class="mt-1">${pBadge}</div>
            </div>
          </td>
          <td>
            <div class="min-w-0 max-w-[240px]">
              <p class="font-bold text-text text-[11px] truncate">${S.esc(rec.reporter_name || 'Citizen SOS User')}</p>
              <p class="font-mono text-[9px] text-[#7ddba8]">${S.esc(rec.reporter_phone || 'Direct SOS link')}</p>
              <p class="text-[10px] text-dim truncate mt-0.5">${S.esc(rec.address || rec.landmark || 'GPS location received')}</p>
            </div>
          </td>
          <td>
            <div class="flex items-center gap-1.5">
              <span class="material-symbols-outlined text-[16px]" style="color:${typeMeta.color}">${typeMeta.icon}</span>
              <span class="font-bold text-[11px] text-text capitalize">${S.esc(rec.type || 'Emergency')}</span>
            </div>
          </td>
          <td>
            <div class="flex flex-wrap gap-1 max-w-[220px]">
              ${assignedList || '<span class="badge badge-muted font-mono !text-[8px]">Pending Dispatch</span>'}
            </div>
          </td>
          <td>
            <div class="min-w-0">
              <p class="font-bold text-[11px] text-text">${S.esc(rec.state_name || rec.state_code)}</p>
              <p class="font-mono text-[8px] text-dim">NEMA Federal Oversight</p>
            </div>
          </td>
          <td>${statusBadge}</td>
          <td>
            <span class="data text-[10px] text-dim whitespace-nowrap">${S.relativeTime(rec.created_at)}</span>
          </td>
          <td class="text-right">
            <button class="btn btn-ghost btn-sm h-7 text-[10px] px-2.5" data-inspect-rec="${rec.id}">
              <span class="material-symbols-outlined text-[14px]">visibility</span>
              <span>Inspect</span>
            </button>
          </td>
        </tr>
      `;
    }).join('');
  }

  async function playAdminRecording(recordingId, audioEl) {
    try {
      if (!audioEl.dataset.loaded) {
        const token = S.authToken?.();
        const response = await fetch(`/api/recordings/${recordingId}/audio`, {
          headers: token ? { Authorization: `Bearer ${token}` } : {}
        });
        if (!response.ok) {
          let message = `Audio unavailable (${response.status})`;
          try { message = (await response.json()).error || message; } catch { /* binary */ }
          throw new Error(message);
        }
        const blob = await response.blob();
        audioEl.src = URL.createObjectURL(blob);
        audioEl.dataset.loaded = '1';
        audioEl.classList.remove('hidden');
      }
      await audioEl.play().catch(() => { });
    } catch (error) {
      S.toast('Recording unavailable', error.message, 'error');
    }
  }

  // ---------------------------------------------------------------------------
  // State EOC management (mirrors the dispatch.js modal — admin has superadmin
  // access to the same /api/nema/state-accounts endpoints)
  // ---------------------------------------------------------------------------
  function slugifyState(name) {
    return name.toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.+|\.+$/g, '');
  }

  async function openStateAccountsModal() {
    let data;
    try {
      data = await S.api('/api/nema/state-accounts');
    } catch (err) {
      S.toast('Could not load state logins', err.message, 'error');
      return;
    }
    const covered = data.states.filter((row) => row.account).length;

    const buildRows = (filter = '') => {
      const q = filter.trim().toLowerCase();
      const rows = data.states.filter((row) => !q
        || row.name.toLowerCase().includes(q)
        || row.code.toLowerCase().includes(q)
        || (row.zone || '').toLowerCase().includes(q));
      if (!rows.length) return '<p class="p-6 text-center text-[10px] text-dim">No states match that search.</p>';
      return `<div class="record-table">
        <div class="record-table__head">
          <span>State counterpart</span>
          <span>Issued login</span>
          <span>Last activity</span>
          <span class="text-right">Action</span>
        </div>
        ${rows.map((row) => {
          const acc = row.account;
          return `<div class="record-row">
            <div class="record-row__main">
              <span class="record-row__icon ${acc ? 'border-nema/30 bg-nema/10 text-nema-soft' : 'border-line bg-panel text-dim'}">
                <span class="material-symbols-outlined text-[18px]">${acc ? 'verified_user' : 'location_city'}</span>
              </span>
              <div class="min-w-0">
                <div class="flex flex-wrap items-center gap-1.5">
                  <p class="record-row__title">${S.esc(row.name)}</p>
                  <span class="badge badge-muted">${S.esc(row.code)}</span>
                  ${acc ? '<span class="badge badge-ok">login active</span>' : '<span class="badge badge-alert">not issued</span>'}
                </div>
                <p class="record-row__meta">${S.esc(row.zone || '')} · ${S.esc(row.capital || '')}</p>
              </div>
            </div>
            <div class="record-row__cell">
              <p class="record-row__label">Username</p>
              <p class="record-row__value">${acc ? S.esc(acc.username) : '—'}</p>
              <p class="record-row__sub">${acc ? `Issued by ${S.esc(acc.createdByName || 'NEMA National Admin')}` : 'NEMA has not issued access'}</p>
            </div>
            <div class="record-row__cell">
              <p class="record-row__label">Last activity</p>
              <p class="record-row__value">${acc?.lastLoginAt ? S.relativeTime(acc.lastLoginAt) : 'Never signed in'}</p>
              <p class="record-row__sub">${acc ? `${acc.activeSessions || 0} session(s) · ${acc.activeIncidents || 0} live incident(s)` : 'No sessions · no live incidents'}</p>
            </div>
            <div class="record-row__action">
              <div class="flex flex-wrap items-center justify-end gap-1.5">
                ${acc ? `<button type="button" class="btn btn-nema btn-sm shrink-0" data-state-access="${acc.id}" title="Generate one-time access code">
                  <span class="material-symbols-outlined text-[14px]">key</span>Access code
                </button>` : ''}
                <button type="button" class="btn ${acc ? 'btn-ghost' : 'btn-nema'} btn-sm shrink-0" data-state-code="${S.esc(row.code)}">
                  ${acc ? 'Reset password' : 'Create login'}
                </button>
              </div>
            </div>
          </div>`;
        }).join('')}
      </div>`;
    };

    const dialog = S.modal({
      title: 'State counterpart logins',
      subtitle: `${covered} of ${data.states.length} states issued · NEMA is the only role that can create them`,
      wide: true,
      body: `<div class="space-y-3">
        <div class="grid grid-cols-3 gap-2">
          <div class="admin-stat" style="--stat-accent:#7ddba8">
            <span class="material-symbols-outlined admin-stat__icon">public</span>
            <p class="admin-stat__value">${data.states.length}</p>
            <p class="admin-stat__label">States + FCT</p>
          </div>
          <div class="admin-stat" style="--stat-accent:#34d399">
            <span class="material-symbols-outlined admin-stat__icon">key</span>
            <p class="admin-stat__value">${covered}</p>
            <p class="admin-stat__label">NEMA-issued logins</p>
          </div>
          <div class="admin-stat" style="--stat-accent:#eab308">
            <span class="material-symbols-outlined admin-stat__icon">pending_actions</span>
            <p class="admin-stat__value">${data.states.length - covered}</p>
            <p class="admin-stat__label">Awaiting NEMA</p>
          </div>
        </div>
        <div class="flex items-start gap-2 rounded-xl border border-[#1f8a5b]/25 bg-[#1f8a5b]/[0.05] px-3 py-2.5">
          <span class="material-symbols-outlined mt-0.5 text-[16px] text-nema-soft">policy</span>
          <p class="text-[9px] leading-relaxed text-muted">A state cannot register itself or set its own password. NEMA creates the account, hands over the one-time password, and remains the only role that can reset it.</p>
        </div>
        <div class="relative">
          <span class="material-symbols-outlined pointer-events-none absolute left-2.5 top-1/2 -translate-y-1/2 text-[16px] text-dim">search</span>
          <input id="adminStateSearch" class="input h-9 pl-8 text-[11px]" placeholder="Search state, code or zone…" autocomplete="off" />
        </div>
        <div id="adminStateList" class="max-h-[420px] overflow-y-auto scroll-thin">${buildRows()}</div>
      </div>`,
      footer: `<button class="btn btn-ghost" data-close>Close</button>`
    });

    const listEl = dialog.el.querySelector('#adminStateList');
    const refreshRows = (filter) => { listEl.innerHTML = buildRows(filter); };
    dialog.el.querySelector('#adminStateSearch')?.addEventListener('input', (e) => refreshRows(e.target.value));
    listEl?.addEventListener('click', (e) => {
      const accessBtn = e.target.closest('[data-state-access]');
      if (accessBtn) {
        const acc = data.accounts.find((a) => String(a.id) === accessBtn.dataset.stateAccess);
        if (acc) openAdminStateAccessCodeModal(acc, data.states);
        return;
      }
      const createBtn = e.target.closest('[data-state-code]');
      if (!createBtn) return;
      const row = data.states.find((r) => r.code === createBtn.dataset.stateCode);
      if (!row) return;
      dialog.close();
      openAdminStateAccountForm(row, () => openStateAccountsModal());
    });
  }

  async function openAdminStateAccessCodeModal(account, states) {
    let result;
    try {
      result = await S.api(`/api/nema/state-accounts/${account.id}/access-code`, {
        method: 'POST', body: { ttlMinutes: 30 }
      });
    } catch (err) {
      S.toast('Could not generate access code', err.message, 'error');
      return;
    }
    const stateLabel = account.stateName ? `${account.stateName} State EOC` : `${account.stateCode} State EOC`;
    const code = result.code;
    const link = `${location.origin}${result.url}`;
    const expires = new Date(result.expiresAt);
    const expiresLabel = expires.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    const dialog = S.modal({
      title: `${stateLabel} access code`,
      subtitle: 'One-time code · opens the state dashboard directly',
      body: `<div class="space-y-3.5">
        <div class="flex items-center justify-between gap-2 rounded-xl border border-nema/30 bg-nema/10 p-3">
          <div class="flex items-center gap-2.5">
            <span class="flex h-9 w-9 items-center justify-center rounded-lg bg-nema/20 text-nema-soft">
              <span class="material-symbols-outlined text-[20px]">location_city</span>
            </span>
            <div>
              <p class="text-[12px] font-bold text-text">${S.esc(stateLabel)}</p>
              <p class="text-[9px] text-dim">${S.esc(account.username)} · issue to state staff on duty</p>
            </div>
          </div>
          <span class="badge badge-ok">login active</span>
        </div>
        <div class="rounded-xl border border-line bg-ink px-4 py-5 text-center">
          <p class="font-mono text-[8px] font-bold uppercase tracking-[0.22em] text-dim">One-time access code</p>
          <p class="mt-2 select-all font-mono text-[34px] font-black tracking-[0.18em] text-nema-soft">${S.esc(code)}</p>
          <p class="mt-2 text-[9px] text-dim">Expires at <span class="font-bold text-text">${S.esc(expiresLabel)} WAT</span> · valid ${result.ttlMinutes} minutes · single use</p>
        </div>
        <div class="rounded-xl border border-line-soft bg-panel-2 p-2.5">
          <p class="font-mono text-[8px] uppercase tracking-wider text-dim">Direct dashboard link</p>
          <p class="mt-1 break-all font-mono text-[10px] text-text">${S.esc(link)}</p>
        </div>
        <p class="flex items-start gap-1.5 text-[9px] leading-relaxed text-dim">
          <span class="material-symbols-outlined !text-[14px] text-[#f4c430]">info</span>
          Send this code or link to the ${S.esc(stateLabel)} duty officer. It works once and can only open the state dashboard.
        </p>
      </div>`,
      footer: `<button type="button" class="btn btn-ghost" id="adminCopyCode"><span class="material-symbols-outlined text-[15px]">content_copy</span>Copy code</button>
        <button type="button" class="btn btn-ghost" id="adminCopyLink"><span class="material-symbols-outlined text-[15px]">link</span>Copy link</button>
        <a class="btn btn-nema" href="${S.esc(link)}" target="_blank" rel="noopener"><span class="material-symbols-outlined text-[16px]">open_in_new</span>Open dashboard</a>`
    });
    dialog.el.querySelector('#adminCopyCode')?.addEventListener('click', () => {
      navigator.clipboard?.writeText(code).catch(() => {});
      S.toast('Access code copied', `Share it securely with ${stateLabel}.`, 'success');
    });
    dialog.el.querySelector('#adminCopyLink')?.addEventListener('click', () => {
      navigator.clipboard?.writeText(link).catch(() => {});
      S.toast('Dashboard link copied', 'The state dashboard opens with this one-time link.', 'success');
    });
  }

  function openAdminStateAccountForm(row, onSuccess) {
    const account = row.account;
    const reset = !!account;
    const suggested = row.code === 'FC' ? 'fct.eoc' : `${slugifyState(row.shortName || row.name).replace(/\./g, '')}.eoc`;
    const dialog = S.modal({
      title: reset ? `Reset ${row.name} password` : `Create ${row.name} state login`,
      subtitle: reset ? 'This revokes every active session for the counterpart' : 'NEMA issues one account per state counterpart',
      body: `<form id="adminStateForm" class="space-y-3">
        <div class="grid gap-3 sm:grid-cols-2">
          <label class="block">
            <span class="field-label">State</span>
            <input class="input" value="${S.esc(row.name)} (${S.esc(row.code)})" disabled />
          </label>
          <label class="block">
            <span class="field-label">Username</span>
            <input id="adminStateUsername" class="input" value="${S.esc(account?.username || suggested)}" ${reset ? 'disabled' : ''} required minlength="3" maxlength="40" />
          </label>
        </div>
        <label class="block">
          <span class="field-label">Display name</span>
          <input id="adminStateDisplayName" class="input" value="${S.esc(account?.displayName || `${row.name} State Emergency Operations Centre`)}" required maxlength="80" />
        </label>
        <label class="block">
          <span class="field-label">Temporary password ${reset ? '(leave blank to generate)' : '(blank generates one)'}</span>
          <input id="adminStatePassword" class="input data" placeholder="At least 8 characters, or leave blank" minlength="8" />
        </label>
        <div id="adminStateError" class="hidden rounded-lg border border-alert/35 bg-alert/10 px-3 py-2 text-[10px] text-alert-soft"></div>
        <p class="text-[9px] leading-relaxed text-dim">The state counterpart sees only ${S.esc(row.name)} incidents, units and applications. It can create field logins for its own responders but cannot sign in as one.</p>
      </form>`,
      footer: `<button class="btn btn-ghost" data-close>Cancel</button>
        <button id="adminStateSubmit" class="btn btn-nema" type="submit" form="adminStateForm">${reset ? 'Reset password' : 'Create state login'}</button>`
    });
    const form = dialog.el.querySelector('#adminStateForm');
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      const submit = dialog.el.querySelector('#adminStateSubmit');
      submit.disabled = true;
      try {
        const password = dialog.el.querySelector('#adminStatePassword').value || undefined;
        let result;
        if (reset) {
          result = await S.api(`/api/nema/state-accounts/${account.id}/reset`, { method: 'POST', body: { password } });
        } else {
          result = await S.api('/api/nema/state-accounts', {
            method: 'POST',
            body: {
              stateCode: row.code,
              username: dialog.el.querySelector('#adminStateUsername').value.trim(),
              displayName: dialog.el.querySelector('#adminStateDisplayName').value.trim(),
              password
            }
          });
        }
        dialog.close();
        openCredentialHandoverModal({
          account: result.account,
          password: result.temporaryPassword,
          title: reset ? `${row.name} EOC Password Reset` : `${row.name} State Login Created`,
          roleNote: `State Emergency Operations Centre login for ${row.name}`
        });
        if (typeof onSuccess === 'function') onSuccess();
      } catch (err) {
        submit.disabled = false;
        const box = dialog.el.querySelector('#adminStateError');
        box.textContent = err.message;
        box.classList.remove('hidden');
      }
    });
  }

  // ---------------------------------------------------------------------------
  // End state EOC management
  // ---------------------------------------------------------------------------

  async function openInspectModal(incidentId) {
    let data;
    try {
      data = await S.api(`/api/admin/database/records/${incidentId}`);
    } catch (err) {
      S.toast('Record Inspection Failed', err.message, 'error');
      return;
    }

    const { incident, events, assignments, aiSession } = data;
    const call = incident.call;
    const callRecordings = call?.recordings || [];
    const typeMeta = agencyMeta[incident.primaryAgency?.code] || agencyMeta.GENERAL;

    const assignmentRows = (assignments || []).map((asg) => `
      <div class="flex items-center justify-between gap-3 rounded-lg border border-line-soft bg-panel-2 p-2.5">
        <div class="flex items-center gap-2">
          <span class="material-symbols-outlined text-[18px] text-[#f4c430]">local_taxi</span>
          <div>
            <p class="font-bold text-text text-[11px]">${S.esc(asg.call_sign)} · ${S.esc(asg.vehicle_type || 'Vehicle')}</p>
            <p class="font-mono text-[8px] text-dim">${S.esc(asg.agency_name)} · Plate ${S.esc(asg.plate_number || '—')}</p>
          </div>
        </div>
        <span class="badge badge-ok font-mono text-[8px] uppercase">${S.esc(asg.status)}</span>
      </div>
    `).join('');

    const eventRows = (events || []).map((ev) => `
      <div class="flex items-start gap-2 text-[10px]">
        <span class="font-mono text-dim shrink-0">${S.clockTime(ev.created_at)}</span>
        <span class="badge badge-muted !text-[7px] uppercase font-mono">${S.esc(ev.actor_type)}</span>
        <span class="text-text">${S.esc(ev.message)}</span>
      </div>
    `).join('');

    const callStatusLabel = !call
      ? 'No call session'
      : call.status === 'connected'
        ? 'State EOC on the line'
        : call.status === 'ringing'
          ? 'Ringing State EOC'
          : 'Call ended';
    const callRecordingRows = callRecordings.length
      ? callRecordings.map((recording) => `<div class="flex items-center justify-between gap-2 rounded-lg border border-line-soft bg-panel p-2">
          <div class="min-w-0">
            <p class="truncate font-mono text-[9px] text-text">${S.esc(recording.fileName || `Recording ${recording.id}`)}</p>
            <p class="mt-0.5 font-mono text-[8px] text-dim">${Math.round(Number(recording.durationSeconds) || 0)}s · ${Math.round(Number(recording.bytes || 0) / 1024)} KB · ${S.esc(recording.status)} · ${S.clockTime(recording.createdAt)}</p>
          </div>
          <button type="button" data-play-recording="${recording.id}" data-audio="adminRecordingAudio-${recording.id}" class="btn btn-ghost btn-sm shrink-0" ${recording.isPlayable ? '' : 'disabled'}>
            <span class="material-symbols-outlined text-[15px]">play_arrow</span>Play
          </button>
          <audio id="adminRecordingAudio-${recording.id}" class="hidden w-full" controls preload="none"></audio>
        </div>`).join('')
      : '<p class="text-[10px] text-dim italic">No call audio recorded for this incident.</p>';

    const dialog = S.modal({
      title: `Database Record: ${incident.code}`,
      subtitle: `Central SQLite record linking Citizen SOS and First Responders · ID #${incident.id}`,
      wide: true,
      body: `
        <div class="space-y-4 max-h-[70vh] overflow-y-auto scroll-thin pr-1">
          <!-- Citizen SOS & Triage header -->
          <div class="rounded-xl border border-line-soft bg-panel-2 p-3.5 space-y-2.5">
            <div class="flex items-center justify-between gap-2 border-b border-line-soft pb-2">
              <div class="flex items-center gap-2">
                <span class="material-symbols-outlined text-[20px]" style="color:${typeMeta.color}">${typeMeta.icon}</span>
                <div>
                  <p class="text-[13px] font-black text-text capitalize">${S.esc(incident.type)} Emergency</p>
                  <p class="text-[9px] font-mono text-dim">Reported by ${S.esc(incident.reporterName || 'Citizen')} (${S.esc(incident.reporterPhone || 'Direct')})</p>
                </div>
              </div>
              <span class="badge ${incident.priority === 1 ? 'badge-alert' : 'badge-warn'} font-mono">PRIORITY ${incident.priority}</span>
            </div>

            ${incident.photoUrl ? `<div class="overflow-hidden rounded-lg border border-line-soft">
              <img src="${S.esc(incident.photoUrl)}?token=${encodeURIComponent(S.authToken() || '')}" alt="Citizen SOS scene photo" class="w-full object-cover" style="max-height:220px" />
              <p class="bg-panel px-2 py-1 font-mono text-[8px] uppercase tracking-wide text-dim">Citizen SOS photo · visible to the State EOC</p>
            </div>` : ''}

            <div class="grid gap-2 text-[10px] sm:grid-cols-2">
              <div><span class="text-dim">GPS Location:</span> <span class="data font-mono text-text">${incident.lat?.toFixed(5)}, ${incident.lng?.toFixed(5)}</span></div>
              <div><span class="text-dim">Landmark:</span> <span class="text-text">${S.esc(incident.address || incident.landmark || '—')}</span></div>
              <div><span class="text-dim">Jurisdiction:</span> <span class="text-text">${S.esc(incident.stateName)} (${incident.stateCode})</span></div>
              <div><span class="text-dim">Reported At:</span> <span class="data text-text">${incident.createdAt}</span></div>
            </div>
            ${incident.description ? `<p class="rounded bg-panel p-2 text-[10px] text-muted italic">"${S.esc(incident.description)}"</p>` : ''}
          </div>

          <!-- Linked First Responders -->
          <div>
            <p class="font-mono text-[9px] font-bold uppercase tracking-[0.14em] text-dim mb-1.5">Linked First Responder Deployments</p>
            ${assignmentRows.length ? `<div class="space-y-1.5">${assignmentRows}</div>` : '<p class="text-[10px] text-dim italic">No first responders assigned yet.</p>'}
          </div>

          <!-- Emergency call + retained audio (NEMA/Super Admin observation) -->
          <div>
            <div class="flex items-center justify-between gap-2 mb-1.5">
              <p class="font-mono text-[9px] font-bold uppercase tracking-[0.14em] text-dim">State EOC Call &amp; Recorded Audio</p>
              <span class="badge ${call?.status === 'connected' ? 'badge-ok' : 'badge-muted'} font-mono text-[8px]">${callStatusLabel}</span>
            </div>
            <div class="rounded-xl border border-line-soft bg-panel-2 p-3 space-y-2">
              ${call ? `<div class="grid gap-2 text-[10px] sm:grid-cols-2">
                <div><span class="text-dim">Claimed by:</span> <span class="text-text">${S.esc(call.claimedByName || 'Unclaimed')}</span></div>
                <div><span class="text-dim">Talk time:</span> <span class="data text-text">${Math.floor((Number(call.durationSeconds) || 0) / 60)}m ${(Number(call.durationSeconds) || 0) % 60}s</span></div>
                <div class="sm:col-span-2"><span class="text-dim">Outcome:</span> <span class="text-text">${S.esc(call.endReason || (call.status === 'connected' ? 'Tracking until first responder is on scene' : 'Waiting for State EOC'))}</span></div>
              </div>` : '<p class="text-[10px] text-dim italic">No call session was opened for this incident.</p>'}
              <div class="space-y-1.5 border-t border-line-soft pt-2">
                ${callRecordingRows}
              </div>
            </div>
          </div>

          <!-- Audit Timeline -->
          <div>
            <p class="font-mono text-[9px] font-bold uppercase tracking-[0.14em] text-dim mb-1.5">Database Audit Trail (Append-Only Events)</p>
            <div class="rounded-xl border border-line-soft bg-panel-2 p-3 space-y-1.5 max-h-[160px] overflow-y-auto">
              ${eventRows || '<p class="text-[10px] text-dim">No logged events.</p>'}
            </div>
          </div>

          <!-- Raw Database Record JSON Inspection -->
          <div>
            <details class="text-[10px]">
              <summary class="font-mono text-[9px] text-[#7ddba8] cursor-pointer hover:underline mb-1">Inspect Raw SQLite JSON Row</summary>
              <pre class="bg-black/60 p-3 rounded-lg font-mono text-[9px] text-[#7ddba8] overflow-x-auto max-h-[140px]">${S.esc(JSON.stringify(incident, null, 2))}</pre>
            </details>
          </div>
        </div>
      `,
      footer: '<button class="btn btn-ghost" data-close>Close Inspection</button>'
    });

    dialog.el.querySelectorAll('[data-play-recording]').forEach((button) => {
      button.addEventListener('click', () => {
        const audio = dialog.el.querySelector(`#${button.dataset.audio}`);
        if (audio) playAdminRecording(button.dataset.playRecording, audio);
      });
    });
  }

  // -------------------------------------------------------------------------
  // -------------------------------------------------------------------------
  // Handover Credential Modal (Key Credentials for Linking Protocol)
  // -------------------------------------------------------------------------
  function openCredentialHandoverModal({ account, password, title = 'Key Credentials Generated', roleNote = '' }) {
    const keyCred = `${account.username}:${password}`;
    const callSign = account.responder?.callSign || account.displayName || account.username;

    const dialog = S.modal({
      title,
      subtitle: 'One-time secure Key Credentials for in-vehicle terminal linking',
      wide: true,
      body: `
        <div class="space-y-3.5">
          <div class="rounded-xl border border-ok/30 bg-ok/[0.06] p-3 text-[11px] leading-relaxed text-muted">
            <span class="material-symbols-outlined text-[16px] text-ok align-middle mr-1">check_circle</span>
            Key Credentials generated and provisioned in the central database. Provide this Key to the field responder or vehicle crew to clip and link this terminal.
          </div>

          <!-- Highlighted Key Credential Box -->
          <div class="rounded-xl border border-nema/40 bg-panel-2 p-3.5">
            <div class="flex items-center justify-between mb-1.5">
              <span class="font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-nema-soft flex items-center gap-1.5">
                <span class="material-symbols-outlined text-[14px]">vpn_key</span>
                In-Vehicle Terminal Linking Key
              </span>
              <span class="badge badge-ok !text-[8px] font-mono uppercase">Ready to Pair</span>
            </div>
            <div class="flex items-center gap-2 mt-2">
              <input type="text" readonly value="${S.esc(keyCred)}" class="input input-sm flex-1 font-mono text-[12px] font-bold text-text bg-panel select-all" id="inputKeyCredVal" />
              <button type="button" class="btn btn-nema btn-sm shrink-0" id="btnQuickCopyKey">
                <span class="material-symbols-outlined text-[15px]">content_copy</span>Copy Key
              </button>
            </div>
            <p class="mt-2 text-[9.5px] text-muted leading-relaxed">
              On the <strong>First Responder Dashboard</strong>, click <strong>Command Centre</strong> → <strong>Command Centre Linking Protocol</strong>, paste this Key into <em>Connect to Admin</em>.
            </p>
          </div>

          <div class="grid gap-2 sm:grid-cols-2">
            <div class="rounded-lg border border-line-soft bg-panel-2 p-2.5">
              <p class="field-label">Field Username</p>
              <p class="data mt-1 text-[13px] font-bold text-text break-all">${S.esc(account.username)}</p>
            </div>
            <div class="rounded-lg border border-line-soft bg-panel-2 p-2.5">
              <p class="field-label">Temporary Access Password</p>
              <p class="data mt-1 text-[13px] font-bold text-[#f4c430] break-all">${S.esc(password)}</p>
            </div>
          </div>
          ${roleNote ? `<p class="rounded-lg border border-line-soft bg-panel-2 p-2 text-[10px] text-dim font-mono">${S.esc(roleNote)}</p>` : ''}
        </div>
      `,
      footer: `
        <button class="btn btn-nema" id="btnCopyLinkKey"><span class="material-symbols-outlined text-[16px]">vpn_key</span>Copy Key Credentials</button>
        <button class="btn btn-ghost" id="btnCopyCreds"><span class="material-symbols-outlined text-[16px]">content_copy</span>Copy Full Details</button>
        <button class="btn btn-primary" data-close>Done</button>
      `
    });

    const copyKeyAction = () => {
      S.copyText(keyCred);
      S.toast('Key Copied', `Key Credential "${keyCred}" copied. Paste into First Responder Linking Protocol.`, 'success', 4000);
    };

    dialog.el.querySelector('#btnQuickCopyKey')?.addEventListener('click', copyKeyAction);
    dialog.el.querySelector('#btnCopyLinkKey')?.addEventListener('click', copyKeyAction);

    dialog.el.querySelector('#btnCopyCreds')?.addEventListener('click', () => {
      S.copyText(`Unit: ${callSign}\nKey Credentials: ${keyCred}\nUsername: ${account.username}\nPassword: ${password}\nURL: ${location.origin}/responder`);
      S.toast('Copied', 'Full credentials copied to clipboard.', 'success');
    });
  }

  // -------------------------------------------------------------------------
  // Boot
  // -------------------------------------------------------------------------
  async function boot() {
    try {
      state.account = await S.requireRole(['superadmin'], { next: '/admin' });
    } catch {
      return; // redirected to login
    }

    if ($('adminUserName')) $('adminUserName').textContent = state.account.displayName || state.account.username;

    // Clock
    updateClock();
    setInterval(updateClock, 1000);

    // Tab buttons
    document.querySelectorAll('[data-tab]').forEach((btn) => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab));
    });

    // Modals
    $('btnOpenNemaModal')?.addEventListener('click', openRegisterNemaModal);
    $('heroNemaBtn')?.addEventListener('click', openRegisterNemaModal);
    $('btnOpenResponderModal')?.addEventListener('click', openRegisterResponderModal);
    $('heroResponderBtn')?.addEventListener('click', openRegisterResponderModal);
    // State EOC logins: hero button + KPI card both open the state accounts modal
    $('heroStateBtn')?.addEventListener('click', openStateAccountsModal);
    $('cardStates')?.addEventListener('click', openStateAccountsModal);

    // Searches & Filters
    $('searchNema')?.addEventListener('input', renderNemaStaff);
    $('searchResponders')?.addEventListener('input', () => { renderResponders(); renderFleetMap(); });
    $('searchResponders')?.addEventListener('keydown', (event) => {
      if (event.key === 'Enter') { event.preventDefault(); locateFirstMatch(); }
      if (event.key === 'Escape') { $('searchResponders').value = ''; renderResponders(); renderFleetMap(); }
    });
    $('filterAgency')?.addEventListener('change', () => { renderResponders(); renderFleetMap(); });
    $('adminMapRecenter')?.addEventListener('click', () => {
      ensureFleetMap();
      // Fit whatever is currently filtered (search + agency), else all units.
      const query = responderQuery();
      const agencyFilter = $('filterAgency')?.value || '';
      const visible = state.responders.filter((u) => Number.isFinite(Number(u.lat)) && (!agencyFilter || u.agencyCode === agencyFilter) && responderMatches(u, query));
      if (visible.length) {
        if (visible.length === 1) state.map.flyTo([visible[0].lat, visible[0].lng], 14, { duration: 0.6 });
        else S.setMapView(state.map, visible, { padding: [40, 40], maxZoom: 12 });
      } else {
        state.map.setView(S.LAGOS_CENTRE || [6.5244, 3.3792], 11);
      }
    });
    $('searchDatabase')?.addEventListener('input', renderDatabaseRecords);
    $('filterDbStatus')?.addEventListener('change', renderDatabaseRecords);
    $('btnRefreshDb')?.addEventListener('click', loadDatabaseRecords);

    // Row clicks
    $('tableBodyNema')?.addEventListener('click', async (e) => {
      const editBtn = e.target.closest('[data-edit-nema]');
      if (editBtn) {
        const acc = state.nemaAccounts.find((a) => String(a.id) === editBtn.dataset.editNema);
        openEditNemaModal(acc);
        return;
      }
      const btn = e.target.closest('[data-reset-nema]');
      if (!btn) return;
      const accId = btn.dataset.resetNema;
      try {
        const res = await S.api(`/api/admin/nema-accounts/${accId}/reset`, { method: 'POST' });
        openCredentialHandoverModal({
          account: res.account,
          password: res.temporaryPassword,
          title: 'NEMA Staff Password Reset',
          roleNote: 'New password for NEMA Federal Operations Desk'
        });
      } catch (err) {
        S.toast('Reset Failed', err.message, 'error');
      }
    });

    $('tableBodyResponders')?.addEventListener('click', async (e) => {
      const locateBtn = e.target.closest('[data-locate-unit]');
      if (locateBtn) {
        const unitId = Number(locateBtn.dataset.locateUnit);
        ensureFleetMap();
        selectUnit(unitId, { fly: true });
        return;
      }
      const btn = e.target.closest('[data-reset-unit]');
      if (!btn) return;
      const unitKey = btn.dataset.resetUnit;
      const pass = 'RESP-' + Math.random().toString(36).slice(2, 8).toUpperCase();
      try {
        const res = await S.api(`/api/state/responders/${unitKey}/credentials`, {
          method: 'POST',
          body: { password: pass }
        });
        openCredentialHandoverModal({
          account: res.account,
          password: res.temporaryPassword || pass,
          title: `Key Credentials Generated · ${res.callSign || unitKey}`,
          roleNote: `In-vehicle radio linking credentials for unit ${res.callSign || unitKey}`
        });
        loadResponders();
      } catch (err) {
        S.toast('Credential Reset Failed', err.message, 'error');
      }
    });

    $('tableBodyDatabase')?.addEventListener('click', (e) => {
      const btn = e.target.closest('[data-inspect-rec]');
      if (!btn) return;
      openInspectModal(btn.dataset.inspectRec);
    });

    // Sign out
    $('logoutBtn')?.addEventListener('click', async () => {
      await S.logout();
      location.replace('/login');
    });

    // Load initial data
    loadOverview();
    loadNemaStaff();
    // Join the live fleet room so LINKED/ONLINE/GPS status (and every map
    // marker) updates without a page refresh. Super Admin is allowed into
    // `dispatch` server-side; bootstrap/fleet frames merge with the API list.
    bindLiveSocket();
  }

  document.addEventListener('DOMContentLoaded', boot);
})();
