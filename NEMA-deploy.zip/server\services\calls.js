/**
 * Emergency call engagement + recording.
 * ---------------------------------------------------------------------------
 * The State EOC owns the citizen call from the moment the SOS lands until the
 * first responder arrives on scene:
 *
 *   SOS -> call session (ringing)
 *       -> state claims / takes over (connected)
 *       -> citizen browser records the conversation (audio chunks)
 *       -> first responder on scene (handoff, call closed)
 *       -> recording retained for NEMA / Super Admin observation.
 *
 * Recording chunks are appended to a file under data/recordings. Only metadata
 * is stored in SQLite; production should point this at object storage.
 */
import fs from 'node:fs';
import path from 'node:path';
import { randomUUID } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { all, get, run, addEvent, nowIso } from '../db.js';
import * as rt from './realtime.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', '..', 'data');
const RECORDINGS_DIR = path.join(DATA_DIR, 'recordings');

export class CallError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

const CALL_ACTIVE = ['ringing', 'connected'];

function ensureRecordingDir(incidentId) {
  const dir = path.join(RECORDINGS_DIR, String(incidentId));
  fs.mkdirSync(dir, { recursive: true });
  return dir;
}

function extensionFor(mimeType) {
  const mime = String(mimeType || '').toLowerCase();
  if (mime.includes('ogg')) return 'ogg';
  if (mime.includes('mp4') || mime.includes('m4a') || mime.includes('aac')) return 'm4a';
  if (mime.includes('wav')) return 'wav';
  return 'webm';
}

function secondsBetween(from, to) {
  if (!from) return 0;
  const start = new Date(from).getTime();
  const end = to ? new Date(to).getTime() : Date.now();
  if (!Number.isFinite(start) || !Number.isFinite(end)) return 0;
  return Math.max(0, Math.round((end - start) / 1000));
}

export function serializeRecording(row) {
  if (!row) return null;
  return {
    id: row.id,
    incidentId: row.incident_id,
    callSessionId: row.call_session_id,
    stateCode: row.state_code,
    source: row.source,
    mimeType: row.mime_type,
    fileName: row.file_name,
    bytes: Number(row.bytes || 0),
    durationSeconds: row.duration_seconds == null ? null : Number(row.duration_seconds),
    status: row.status,
    isPlayable: Number(row.bytes || 0) > 0,
    recordedBy: row.recorded_by,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    finishedAt: row.status === 'ready' ? row.updated_at : null
  };
}

export function serializeCall(row, recordings = []) {
  if (!row) return null;
  return {
    id: row.id,
    incidentId: row.incident_id,
    stateCode: row.state_code,
    status: row.status,
    isActive: CALL_ACTIVE.includes(row.status),
    claimedBy: row.claimed_by,
    claimedByName: row.claimed_by_name,
    claimedAt: row.claimed_at,
    connectedAt: row.connected_at,
    endedAt: row.ended_at,
    endReason: row.end_reason,
    citizenName: row.citizen_name,
    createdAt: row.created_at,
    durationSeconds: secondsBetween(row.connected_at, row.ended_at),
    recordings: recordings.map(serializeRecording)
  };
}

function callRecordings(incidentId) {
  return all(
    'SELECT * FROM incident_recordings WHERE incident_id = ? ORDER BY created_at ASC, id ASC',
    incidentId
  ).map(serializeRecording);
}

export function getCallRow(incidentId) {
  return get(
    'SELECT * FROM call_sessions WHERE incident_id = ? ORDER BY id DESC LIMIT 1',
    Number(incidentId)
  );
}

export function getCallDetail(incidentId) {
  const row = getCallRow(incidentId);
  if (!row) return null;
  const recordings = callRecordings(row.incident_id);
  return {
    ...serializeCall(row, recordings),
    sessionRecordings: recordings.filter((recording) => recording.callSessionId === row.id)
  };
}

function emit(incidentId, stateCode) {
  const call = getCallDetail(incidentId);
  rt.emitCallUpdate(incidentId, call, stateCode);
  return call;
}

export function startCall(incidentId, { citizenName = null, reporterName = null, forceNew = false } = {}) {
  const incident = get('SELECT * FROM incidents WHERE id = ?', Number(incidentId));
  if (!incident) throw new CallError(404, 'Incident not found');
  const latest = getCallRow(incident.id);
  if (latest && CALL_ACTIVE.includes(latest.status) && !forceNew) {
    return getCallDetail(incident.id);
  }
  const at = nowIso();
  run(
    `INSERT INTO call_sessions (incident_id, state_code, status, citizen_name, created_at)
     VALUES (?, ?, 'ringing', ?, ?)`,
    incident.id, incident.state_code, citizenName || reporterName || incident.reporter_name || 'Citizen', at
  );
  addEvent(incident.id, {
    type: 'call_started',
    actorType: 'citizen',
    actorId: citizenName || reporterName || incident.reporter_name || 'Citizen',
    message: 'Emergency call opened — waiting for the State EOC to claim it',
    payload: { callSessionId: getCallRow(incident.id)?.id || null }
  }, at);
  return emit(incident.id, incident.state_code);
}

/**
 * Claim / take over the live call. Only the responsible state (or Super Admin
 * override at the HTTP layer) reaches this function. The newest claim becomes
 * the agent on the line; the handoff is written to the append-only timeline.
 */
export function claimCall(incidentId, { account, actorName } = {}) {
  const incident = get('SELECT * FROM incidents WHERE id = ?', Number(incidentId));
  if (!incident) throw new CallError(404, 'Incident not found');
  let row = getCallRow(incident.id);
  if (!row || row.status === 'ended' || row.status === 'missed') {
    // A citizen can re-open the call after hanging up; create a fresh session.
    startCall(incident.id, {});
    row = getCallRow(incident.id);
  }
  const at = nowIso();
  const name = actorName || account?.displayName || account?.username || 'State EOC agent';
  const takeover = row.status === 'connected' && row.claimed_by && row.claimed_by !== account?.id;
  run(
    `UPDATE call_sessions
     SET status = 'connected', claimed_by = ?, claimed_by_name = ?,
         claimed_at = COALESCE(claimed_at, ?), connected_at = COALESCE(connected_at, ?)
     WHERE id = ?`,
    account?.id ?? null, name, at, at, row.id
  );
  addEvent(incident.id, {
    type: 'call_claimed',
    actorType: 'dispatcher',
    actorId: account?.username || name,
    message: takeover
      ? `${name} took over the citizen call from ${row.claimed_by_name || 'another agent'}`
      : `${name} claimed the emergency call — citizen engaged`,
    payload: { callSessionId: row.id, claimedBy: account?.id ?? null }
  }, at);
  return emit(incident.id, incident.state_code);
}

export function endCall(incidentId, { actor = 'State EOC', reason = 'Call ended', actorType = 'dispatcher' } = {}) {
  const incident = get('SELECT * FROM incidents WHERE id = ?', Number(incidentId));
  if (!incident) throw new CallError(404, 'Incident not found');
  const row = getCallRow(incident.id);
  if (!row || !CALL_ACTIVE.includes(row.status)) return row ? getCallDetail(incident.id) : null;
  const at = nowIso();
  run(
    `UPDATE call_sessions SET status = 'ended', ended_at = ?, end_reason = ? WHERE id = ?`,
    at, String(reason).slice(0, 180), row.id
  );
  addEvent(incident.id, {
    type: 'call_ended',
    actorType,
    actorId: actor,
    message: `Emergency call ended — ${reason}`,
    payload: { callSessionId: row.id }
  }, at);
  return emit(incident.id, incident.state_code);
}

/** First responder reached the scene: the crew takes over caller support. */
export function handoffCallOnScene(incidentId, responderName = 'First responder') {
  const incident = get('SELECT * FROM incidents WHERE id = ?', Number(incidentId));
  if (!incident) return null;
  const row = getCallRow(incident.id);
  if (!row || !CALL_ACTIVE.includes(row.status)) return row ? getCallDetail(incident.id) : null;
  const at = nowIso();
  const reason = `${responderName} on scene — call handed to the crew`;
  run(
    `UPDATE call_sessions SET status = 'ended', ended_at = ?, end_reason = ? WHERE id = ?`,
    at, reason, row.id
  );
  addEvent(incident.id, {
    type: 'call_handoff',
    actorType: 'responder',
    actorId: responderName,
    message: `${responderName} arrived on scene — caller support handed from the State EOC to the crew`,
    payload: { callSessionId: row.id }
  }, at);
  return emit(incident.id, incident.state_code);
}

// ---------------------------------------------------------------------------
// Recordings
// ---------------------------------------------------------------------------

export function listRecordings(incidentId) {
  return callRecordings(Number(incidentId));
}

export function getRecordingRow(id) {
  return get('SELECT * FROM incident_recordings WHERE id = ?', Number(id));
}

export function getRecordingPath(row) {
  if (!row?.file_path) return null;
  const absolute = path.resolve(DATA_DIR, row.file_path);
  const root = path.resolve(DATA_DIR);
  // Refuse any path that escapes the recordings root, even if the DB is bad.
  if (!absolute.startsWith(root + path.sep) && absolute !== root) return null;
  return absolute;
}

export function createRecording(incidentId, {
  callSessionId = null,
  mimeType = 'audio/webm',
  source = 'citizen',
  recordedBy = null
} = {}) {
  const incident = get('SELECT * FROM incidents WHERE id = ?', Number(incidentId));
  if (!incident) throw new CallError(404, 'Incident not found');
  let session = callSessionId
    ? get('SELECT * FROM call_sessions WHERE id = ? AND incident_id = ?', Number(callSessionId), incident.id)
    : getCallRow(incident.id);
  if (callSessionId && !session) throw new CallError(400, 'Call session does not belong to this incident');
  if (!session) {
    startCall(incident.id, {});
    session = getCallRow(incident.id);
  }
  ensureRecordingDir(incident.id);
  const fileName = `${incident.code}-call-${session.id}-${randomUUID()}.${extensionFor(mimeType)}`;
  const relativePath = path.join('recordings', String(incident.id), fileName);
  const absolutePath = path.join(DATA_DIR, relativePath);
  fs.writeFileSync(absolutePath, Buffer.alloc(0));
  const at = nowIso();
  const result = run(
    `INSERT INTO incident_recordings
      (incident_id, call_session_id, state_code, source, mime_type, file_name, file_path, bytes, status, recorded_by, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, 0, 'recording', ?, ?, ?)`,
    incident.id, session.id, incident.state_code, source, String(mimeType || 'audio/webm'), fileName,
    relativePath, recordedBy, at, at
  );
  const row = getRecordingRow(Number(result.lastInsertRowid));
  addEvent(incident.id, {
    type: 'call_recording_started',
    actorType: 'citizen',
    actorId: recordedBy || incident.reporter_name || 'Citizen',
    message: 'Call audio recording started for State EOC / NEMA observation',
    payload: { recordingId: row.id, callSessionId: session.id }
  }, at);
  emit(incident.id, incident.state_code);
  return { recording: serializeRecording(row), call: getCallDetail(incident.id) };
}

export function appendRecordingChunk(id, chunk) {
  const row = getRecordingRow(id);
  if (!row) throw new CallError(404, 'Recording not found');
  if (row.status === 'failed') throw new CallError(409, 'Recording is marked failed');
  if (!Buffer.isBuffer(chunk) || !chunk.length) return serializeRecording(row);
  const absolutePath = getRecordingPath(row);
  if (!absolutePath) throw new CallError(500, 'Recording path is invalid');
  fs.appendFileSync(absolutePath, chunk);
  const bytes = Number(row.bytes || 0) + chunk.length;
  const at = nowIso();
  run(
    'UPDATE incident_recordings SET bytes = ?, updated_at = ? WHERE id = ?',
    bytes, at, row.id
  );
  return serializeRecording(getRecordingRow(row.id));
}

export function finishRecording(id, { durationSeconds = null, status = 'ready', reason = null } = {}) {
  const row = getRecordingRow(id);
  if (!row) throw new CallError(404, 'Recording not found');
  const at = nowIso();
  run(
    `UPDATE incident_recordings
     SET status = ?, duration_seconds = COALESCE(?, duration_seconds), updated_at = ?
     WHERE id = ?`,
    ['ready', 'failed'].includes(status) ? status : 'ready',
    durationSeconds == null ? null : Math.max(0, Number(durationSeconds) || 0),
    at, row.id
  );
  addEvent(row.incident_id, {
    type: status === 'failed' ? 'call_recording_failed' : 'call_recording_saved',
    actorType: 'system',
    actorId: row.recorded_by || 'Citizen browser',
    message: status === 'failed'
      ? `Call audio recording failed${reason ? `: ${reason}` : ''}`
      : `Call audio recording saved (${Math.round(Number(row.bytes || 0) / 1024)} KB) — available to NEMA / Super Admin`,
    payload: { recordingId: row.id, bytes: row.bytes, durationSeconds }
  }, at);
  const updated = getRecordingRow(row.id);
  const call = emit(row.incident_id, row.state_code);
  return { recording: serializeRecording(updated), call };
}

export function getRecordingWithIncident(id) {
  const row = getRecordingRow(id);
  if (!row) return null;
  const incident = get('SELECT * FROM incidents WHERE id = ?', row.incident_id);
  if (!incident) return null;
  return { recording: row, incident };
}
