/* global NaijaSOS, NaijaSOSWebRTC, L */
/**
 * Field responder controller.
 * ---------------------------------------------------------------------------
 * This is the in-vehicle tablet experience. A crew signs on as a specific unit
 * (e.g. AMB-09), subscribes to that unit's private Socket.IO room and then:
 *
 *   dispatch:new  -> full-screen alarm + siren -> accept/decline
 *   accepted      -> route, turn-by-turn, live ETA, geofenced arrival
 *   on scene      -> patient transport / complete status back to dispatch
 *
 * The server owns all state transitions. This controller is deliberately an
 * optimistic-but-confirmed UI: every action calls the REST API and the
 * authoritative result is rendered again.
 */
(() => {
  const S = window.NaijaSOS;
  const { socket, api, toast, esc, typeMeta, agencyMeta, incidentStatus, unitStatus, assignmentStatus } = S;
  const $ = (id) => document.getElementById(id);
  const $$ = S.$$;

  const ACTIVE_ASSIGNMENT = ['alerting', 'accepted', 'en_route', 'on_scene', 'transporting'];
  const UNIT_KEY_STORAGE = 'naijasos.responderUnit';
  const SOUND_STORAGE = 'naijasos.responderSound';
  const GPS_STORAGE = 'naijasos.responderGps';
  const FIELD = { name: 'Field crew', id: 'FLD-001' };

  const state = {
    account: null,
    units: [],
    unitKey: null,
    unit: null,
    detail: null,
    assignment: null,
    incident: null,
    proximitySos: null,
    nearby: [],
    map: null,
    mapReady: false,
    unitLayer: null,
    incidentLayer: null,
    nearbyLayer: null,
    routeLayer: null,
    unitMarker: null,
    incidentMarker: null,
    nearbyMarkers: new Map(),
    joinedIncidentId: null,
    fittedAssignmentId: null,
    renderedStepIndex: -1,
    alarm: null,
    alarmDismissedFor: null,
    sirenStop: null,
    soundOn: localStorage.getItem(SOUND_STORAGE) !== '0',
    viewer: null,
    feedDialog: null,
    busy: false,
    sendingChat: false,
    commsTab: 'chat',
    chatDraft: '',
    unread: 0,
    gpsEnabled: false,
    gpsWatchId: null,
    gps: null,
    gpsStatus: 'idle',
    gpsSource: null,
    gpsError: null,
    gpsSyncAt: null,
    gpsSyncError: null,
    lastGpsPushAt: 0,
    lastGpsPoint: null,
    booting: true,
    lastAssignmentStatus: null,
    refreshPending: false
  };

  // -------------------------------------------------------------------------
  // Small helpers
  // -------------------------------------------------------------------------
  const typeOf = (incident) => typeMeta[incident?.type] || typeMeta.general;
  const agencyOf = (unit) => agencyMeta[unit?.agencyCode] || { label: unit?.agencyName || 'Unit', color: '#a6acac', icon: 'local_taxi' };
  const priorityOf = (incident) => S.priorityMeta[incident?.priority] || S.priorityMeta[2];
  const assignmentOf = (status) => assignmentStatus[status] || { label: status || 'Assigned', color: '#a6acac' };
  const pillStyle = (color) => `style="border-color:${color}55;background:${color}18;color:${color}"`;
  const currentUnit = () => state.unit || state.units.find((u) => u.publicId === state.unitKey) || null;

  function remainingKm(assignment = state.assignment) {
    if (!assignment) return 0;
    return Math.max(0, Number(assignment.distanceKm || 0) * (1 - Math.min(1, Number(assignment.progress) || 0)));
  }

  function elapsedSeconds(iso) {
    if (!iso) return 0;
    return Math.max(0, Math.round((Date.now() - new Date(iso).getTime()) / 1000));
  }

  function updateElapsedLabels() {
    $$('[data-live-since]').forEach((el) => {
      const iso = el.getAttribute('data-live-since');
      if (iso) el.textContent = S.elapsed(elapsedSeconds(iso));
    });
  }

  function stepDistance(metres) {
    const m = Number(metres) || 0;
    return m >= 1000 ? `${(m / 1000).toFixed(1)} km` : `${Math.round(m)} m`;
  }

  function compass(deg) {
    const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
    return dirs[Math.round((((Number(deg) || 0) % 360) + 360) % 360 / 45) % 8];
  }

  // -------------------------------------------------------------------------
  // GPS source (phone / tablet / PC / in-vehicle PTT / external receiver)
  // -------------------------------------------------------------------------
  const GPS_SOURCE_STORAGE = 'naijasos.responderGpsSource';
  const GPS_SOURCE = {
    phone: { type: 'phone', label: 'Phone GPS', icon: 'smartphone' },
    tablet: { type: 'tablet', label: 'Tablet GPS', icon: 'tablet' },
    ptt: { type: 'ptt', label: 'PTT Hardware GPS', icon: 'satellite_alt' },
    external: { type: 'external', label: 'External GPS Device', icon: 'settings_input_antenna' },
    pc: { type: 'pc', label: 'PC GPS', icon: 'computer' }
  };

  function gpsSourceMeta(type) {
    return GPS_SOURCE[type] || GPS_SOURCE.pc;
  }

  function gpsSourceOverride() {
    try {
      const saved = localStorage.getItem(GPS_SOURCE_STORAGE);
      return GPS_SOURCE[saved] ? saved : 'auto';
    } catch {
      return 'auto';
    }
  }

  function detectGpsSource() {
    const override = gpsSourceOverride();
    if (override !== 'auto') return { ...GPS_SOURCE[override], manual: true };
    const ua = navigator.userAgent || '';
    const touch = Number(navigator.maxTouchPoints || 0);
    const shortest = Math.min(Number(window.screen?.width) || 0, Number(window.screen?.height) || 0);
    if (/Hytera|MNC360|TETRA|PoC Radio|PoC-|In-Vehicle/i.test(ua)) return { ...GPS_SOURCE.ptt };
    if (/iPhone|iPod|Android.*Mobile|Windows Phone|Mobile Safari/i.test(ua) || (touch > 1 && shortest > 0 && shortest <= 620)) {
      return { ...GPS_SOURCE.phone };
    }
    if (/iPad|Tablet|Android(?!.*Mobile)/i.test(ua) || touch > 1) return { ...GPS_SOURCE.tablet };
    // Desktop / laptop. Browsers do not expose the physical origin of a
    // geolocation fix, so an attached receiver is declared explicitly with the
    // "GPS source" picker instead of being guessed.
    return { ...GPS_SOURCE.pc };
  }

  function gpsSourceLabel() {
    return gpsSourceMeta(state.gpsSource?.type).label;
  }

  function gpsStatusMeta() {
    if (state.gpsStatus === 'connected' && state.gps) {
      return {
        label: 'Connected',
        icon: gpsSourceMeta(state.gpsSource?.type).icon,
        source: gpsSourceLabel(),
        detail: `Connected to ${gpsSourceLabel()} · ±${Math.round(state.gps.accuracy || 0)} m`
      };
    }
    if (state.gpsStatus === 'scanning') {
      const meta = gpsSourceMeta(detectGpsSource().type);
      return {
        label: 'Detecting…',
        icon: gpsSourceOverride() === 'auto' ? 'location_searching' : meta.icon,
        source: meta.label,
        detail: `Looking for ${meta.label}`
      };
    }
    if (state.gpsStatus === 'error') {
      return { label: 'No fix', icon: 'gps_off', source: gpsSourceLabel(), detail: state.gpsError || 'Location unavailable' };
    }
    const meta = gpsSourceMeta(detectGpsSource().type);
    return { label: 'Detect', icon: meta.icon, source: meta.label, detail: `Tap to detect ${meta.label}` };
  }

  function setGpsSourcePreference(value) {
    const next = GPS_SOURCE[value] ? value : 'auto';
    try { localStorage.setItem(GPS_SOURCE_STORAGE, next); } catch { /* storage may be blocked */ }
    state.gpsSource = detectGpsSource();
    // Re-label the current fix without inventing a new position.
    if (state.gps) state.gps.source = state.gpsSource.label;
    renderHeader();
    renderTelemetry();
    toast(
      'GPS source',
      next === 'auto' ? `Auto-detected ${state.gpsSource.label}.` : `Using ${state.gpsSource.label}.`,
      'info',
      2600
    );
  }

  function directionIcon(direction = '') {
    const d = String(direction).toLowerCase();
    if (d.includes('left')) return 'turn_left';
    if (d.includes('right')) return 'turn_right';
    if (d.includes('arrive') || d.includes('destination')) return 'flag';
    if (d.includes('uturn') || d.includes('u-turn')) return 'u_turn_left';
    if (d.includes('merge')) return 'merge';
    if (d.includes('roundabout')) return 'roundabout_right';
    return 'straight';
  }

  function currentStepIndex() {
    const steps = state.assignment?.steps || [];
    if (!steps.length) return -1;
    if (['on_scene', 'transporting', 'completed'].includes(state.assignment?.status)) return steps.length - 1;
    const progress = Math.min(1, Math.max(0, Number(state.assignment?.progress) || 0));
    return Math.min(steps.length - 1, Math.floor(progress * steps.length));
  }

  // -------------------------------------------------------------------------
  // Boot
  // -------------------------------------------------------------------------
  async function boot() {
    let account = S.session()?.account;
    // Allow responder accounts or superadmin oversight
    if (!account || (account.role !== 'responder' && account.role !== 'superadmin')) {
      // Auto-restore remembered responder credentials if available
      try {
        const saved = JSON.parse(localStorage.getItem('naijasos.remember_responder') || 'null');
        if (saved?.username && saved?.password) {
          const result = await S.login({ role: 'responder', username: saved.username, password: saved.password });
          if (result?.account) {
            account = result.account;
          }
        }
      } catch { /* proceed */ }
    }
    if (!account || (account.role !== 'responder' && account.role !== 'superadmin')) {
      location.replace('/login?role=responder&next=/responder');
      return;
    }
    state.account = account;

    S.setClock($('watClock'));
    wireStaticEvents();
    initOffVehicleUi();
    initDraggablePtt();
    wireSocket();
    setupMap();
    updateSoundUi();
    renderAll();
    restoreGpsPreference();

    try {
      await loadUnits();
    } catch (error) {
      if (error.status === 401) {
        S.clearSession();
        location.replace('/login?role=responder&next=/responder');
        return;
      }
      toast('Unit unavailable', error.message, 'error');
      state.booting = false;
      return;
    }

    const savedKey = localStorage.getItem(UNIT_KEY_STORAGE);
    const initial = (savedKey && state.units.find((u) => u.publicId === savedKey))
      || (state.account?.responder?.publicId && state.units.find((u) => u.publicId === state.account.responder.publicId))
      || state.units[0];
    if (initial) {
      await signOn(initial.publicId, { silent: true, reason: 'auth' });
    } else {
      toast('Terminal ready', 'Select your active vehicle from the unit badge.', 'info');
    }

    state.booting = false;
    updateConnectionUi();
    setInterval(updateElapsedLabels, 1000);
  }

  async function loadUnits() {
    const detail = await api('/api/responder/me');
    state.account = detail.account || state.account;
    if (detail.account?.responder) {
      FIELD.name = detail.account.displayName || detail.account.responder.callSign;
      FIELD.id = detail.account.responder.publicId;
    }
    const unit = detail.unit;
    state.units = detail.fleet?.length ? detail.fleet : (unit ? [unit] : []);
    if (state.unit && unit) {
      state.unit = { ...state.unit, ...unit };
    }
    return state.units;
  }

  /** Binds this tablet to the active unit. */
  async function signOn(unitKey, { silent = false, reason = 'manual' } = {}) {
    if (!unitKey) return;
    const isBound = state.account?.role === 'responder' && state.account?.responder?.publicId && !state.account?.isHardwareTerminal;
    if (isBound && state.account.responder.publicId !== unitKey) {
      toast('Unit not permitted', 'This login is bound to a different first-responder unit.', 'error');
      return;
    }
    if (state.unitKey === unitKey && state.detail) {
      if (!silent) toast('Already signed on', `${currentUnit()?.callSign || unitKey} is already active on this tablet.`, 'info');
      return;
    }

    stopFeed();
    closeAlarm({ stopOnly: true });
    stopSiren();
    if (state.viewer) stopFeed();

    if (state.joinedIncidentId) {
      socket.emit('incident:unsubscribe', { incidentId: state.joinedIncidentId });
      state.joinedIncidentId = null;
    }

    state.unitKey = unitKey;
    state.detail = null;
    state.unit = state.units.find((u) => u.publicId === unitKey) || null;
    state.assignment = null;
    state.incident = null;
    state.nearby = [];
    state.fittedAssignmentId = null;
    state.renderedStepIndex = -1;
    state.lastAssignmentStatus = null;
    localStorage.setItem(UNIT_KEY_STORAGE, unitKey);

    socket.emit('unit:subscribe', { unitKey });
    renderAll();

    try {
      const detail = await api(`/api/responders/${encodeURIComponent(unitKey)}`);
      applyDetail(detail, { silent: true });
    } catch (error) {
      toast('Sign-on failed', error.message, 'error');
      return;
    }

    if (!silent) {
      toast('Signed on', `${state.unit?.callSign || unitKey} is now receiving dispatches.`, 'success');
    } else if (reason === 'auto') {
      toast('Field tablet ready', `${state.unit?.callSign || unitKey} · ${state.unit?.station || 'unit'}`, 'info', 3200);
    }
    if (state.gpsEnabled) startGps({ quiet: true });
  }

  // -------------------------------------------------------------------------
  // Data application
  // -------------------------------------------------------------------------
  function applyDetail(detail, { silent = false } = {}) {
    if (!detail?.unit) return;
    if (state.unitKey && detail.unit.publicId !== state.unitKey) return;

    state.detail = detail;
    state.unit = detail.unit;
    const unitIndex = state.units.findIndex((u) => u.id === detail.unit.id);
    if (unitIndex >= 0) state.units[unitIndex] = { ...state.units[unitIndex], ...detail.unit };
    else state.units.push(detail.unit);

    const previousAssignmentId = state.assignment?.id;
    const previousStatus = state.assignment?.status;
    const previousIncidentId = state.incident?.id;

    state.assignment = detail.assignment || null;
    state.incident = detail.incident || null;
    state.nearby = detail.nearbyIncidents || [];

    if (state.incident?.id) {
      joinIncident(state.incident.id);
    } else if (state.joinedIncidentId) {
      socket.emit('incident:unsubscribe', { incidentId: state.joinedIncidentId });
      state.joinedIncidentId = null;
    }

    if (state.assignment) {
      state.alarmDismissedFor = state.assignment.status === 'alerting' ? state.alarmDismissedFor : null;
      if (state.assignment.id !== previousAssignmentId) state.fittedAssignmentId = null;
    } else {
      state.alarmDismissedFor = null;
    }

    renderAll();

    if (state.assignment?.status === 'alerting') {
      maybeShowAlarm();
    } else {
      closeAlarm({ stopOnly: true });
    }

    if (!silent && state.assignment && state.assignment.id !== previousAssignmentId) {
      S.dispatchTone();
      toast('Dispatch received', `${state.incident.type ? typeOf(state.incident).label : 'Emergency'} · ${state.incident.address}`, 'warning');
    }

    if (!silent && previousIncidentId && !state.incident) {
      toast('Returned to standby', 'You are available for the next dispatch.', 'info');
    }

    if (state.assignment && state.assignment.id !== previousAssignmentId) {
      setTimeout(() => fitRoute(), 180);
    }

    if (previousStatus && state.assignment?.status && previousStatus !== state.assignment.status) {
      state.lastAssignmentStatus = state.assignment.status;
    }
  }

  function applyAssignmentResult(result, successMessage) {
    if (result?.incident) {
      const incident = result.incident;
      const assignment = result.assignment || null;
      state.incident = incident;
      state.assignment = assignment && (ACTIVE_ASSIGNMENT.includes(assignment.status) || assignment.status === 'completed')
        ? assignment
        : null;
      if (state.detail) {
        state.detail.incident = incident;
        state.detail.assignment = state.assignment;
        const filtered = (state.detail.nearbyIncidents || []).filter((i) => i.id !== incident.id);
        state.detail.nearbyIncidents = filtered;
        state.nearby = filtered;
      }
      if (state.assignment?.status === 'alerting') {
        maybeShowAlarm();
      } else {
        closeAlarm({ stopOnly: true });
      }
      state.alarmDismissedFor = null;
      state.fittedAssignmentId = null;
      renderAll();
      setTimeout(() => fitRoute(), 160);
    }
    if (successMessage) toast('Updated', successMessage, 'success');
  }

  async function refreshDetail({ silent = true } = {}) {
    if (!state.unitKey) return;
    try {
      const detail = await api(`/api/responders/${encodeURIComponent(state.unitKey)}`);
      applyDetail(detail, { silent });
    } catch (error) {
      if (!silent) toast('Refresh failed', error.message, 'error');
    }
  }

  function joinIncident(incidentId) {
    if (!incidentId) return;
    if (state.joinedIncidentId === incidentId) return;
    if (state.joinedIncidentId) socket.emit('incident:unsubscribe', { incidentId: state.joinedIncidentId });
    state.joinedIncidentId = incidentId;
    socket.emit('incident:subscribe', { incidentId });
  }

  // -------------------------------------------------------------------------
  // Static events
  // -------------------------------------------------------------------------
  function wireStaticEvents() {
    $('unitButton')?.addEventListener('click', openUnitPicker);
    $('soundToggle')?.addEventListener('click', toggleSound);
    $('testAlarmBtn')?.addEventListener('click', showTestAlarm);
    $('gpsButton')?.addEventListener('click', toggleGps);
    // `#nav-ptt-gps` is wired by the terminal bridge in responder.html, which
    // calls window.detectPttHardwareGps. Binding it here as well would run the
    // geolocation request twice per click.
    $('nav-command-centre')?.addEventListener('click', (e) => {
      e.preventDefault();
      openCommandCentreProtocol();
    });
    $('responderLogoutBtn')?.addEventListener('click', async () => {
      const confirmed = await S.confirmDialog({
        title: 'Sign out of this tablet?',
        body: 'This unit will stop receiving dispatches on this device until you sign in again.',
        confirmLabel: 'Sign out'
      });
      if (confirmed) {
        localStorage.removeItem('naijasos.remember_responder');
        S.logout({ redirect: '/login?role=responder' });
      }
    });

    $('mapRecenter')?.addEventListener('click', () => {
      if (!state.map) return;
      const unit = currentUnit();
      if (unit) state.map.flyTo([unit.lat, unit.lng], 15, { duration: 0.6 });
    });
    $('mapFit')?.addEventListener('click', fitRoute);
    $('mapNorth')?.addEventListener('click', () => {
      const unit = currentUnit();
      if (state.map && unit) state.map.flyTo([unit.lat, unit.lng], state.map.getZoom(), { duration: 0.45 });
    });
    refreshPttLabels();

    // Dynamic actions (buttons are re-rendered frequently).
    document.addEventListener('click', (event) => {
      const button = event.target.closest('[data-action]');
      if (!button) return;
      const action = button.dataset.action;
      if (action === 'accept') acceptAssignment(button);
      else if (action === 'accept-proximity') {
        const prox = state.proximitySos;
        if (!prox) return;
        stopSiren();
        const pi = prox.incident;
        state.proximitySos = null;
        renderCallBanner();
        const unit = currentUnit();
        if (unit) {
          api(`/api/incidents/${pi.id}/assign`, {
            method: 'POST',
            body: { responderId: unit.id, dispatcher: 'In-Vehicle PTT Terminal' }
          }).then(() => {
            toast('Dispatched', 'Proximity emergency accepted. Navigation route loaded.', 'success', 4000);
          }).catch((err) => {
            toast('Assignment Error', err.message, 'error');
          });
        }
      } else if (action === 'review-proximity') {
        const prox = state.proximitySos;
        if (!prox) return;
        openAlarm({ incident: prox.incident, preview: false });
      } else if (action === 'dismiss-proximity') {
        state.proximitySos = null;
        stopSiren();
        renderCallBanner();
      }
      else if (action === 'decline') openDeclineDialog();
      else if (action === 'status') updateStatus(button.dataset.status || '', button);
      else if (action === 'comms-tab') {
        state.commsTab = button.dataset.tab || 'chat';
        if (state.commsTab === 'chat') state.unread = 0;
        renderComms();
      } else if (action === 'feed') openFeedModal();
      else if (action === 'nearby') openNearbyBrief(Number(button.dataset.id));
      else if (action === 'unit-picker') openUnitPicker();
      else if (action === 'test-alarm') showTestAlarm();
      else if (action === 'gps-toggle') toggleGps();
      else if (action === 'gps-once') sendGpsFix();
      else if (action === 'gps-detect') detectPttHardwareGps();
      else if (action === 'ptt-settings') openPttSettings();
      else if (action === 'copy-coords') copyCoords();
      else if (action === 'duty') setDutyStatus(button.dataset.status || 'available');
      else if (action === 'refresh') refreshDetail({ silent: false });
      else if (action === 'quick-message') sendChatBody(button.dataset.message || '');
      else if (action === 'open-chat') {
        state.commsTab = 'chat';
        renderComms();
        $('commsPanel')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }
    });

    document.addEventListener('input', (event) => {
      if (event.target.id === 'responderChatInput') state.chatDraft = event.target.value;
    });

    document.addEventListener('change', (event) => {
      const target = event.target;
      if (target?.matches?.('[data-action="gps-source"]')) setGpsSourcePreference(target.value);
    });

    document.addEventListener('submit', (event) => {
      if (event.target.id !== 'responderChatForm') return;
      event.preventDefault();
      const input = event.target.querySelector('#responderChatInput');
      sendChatBody(input?.value || '');
    });

    window.addEventListener('resize', S.debounce(() => state.map?.invalidateSize(), 180));
    window.addEventListener('beforeunload', () => {
      stopSiren();
      stopFeed();
      if (state.gpsWatchId != null) navigator.geolocation?.clearWatch(state.gpsWatchId);
    });
  }

  // -------------------------------------------------------------------------
  // Socket.IO
  // -------------------------------------------------------------------------
  function wireSocket() {
    socket.on('connect', () => {
      updateConnectionUi();
      if (state.unitKey) socket.emit('unit:subscribe', { unitKey: state.unitKey });
    });
    socket.on('disconnect', updateConnectionUi);

    socket.on('unit:snapshot', (detail) => {
      if (!detail?.unit) return;
      if (state.unitKey && detail.unit.publicId !== state.unitKey) return;
      applyDetail(detail, { silent: state.booting });
    });
    socket.on('unit:error', ({ message } = {}) => toast('Unit error', message || 'The server did not recognise this unit.', 'error'));

    socket.on('assignment:new', ({ incident, assignment } = {}) => {
      if (!incident || !assignment) return;
      const unit = currentUnit();
      if (!unit || Number(assignment.responderId) !== Number(unit.id)) return;

      const previousId = state.assignment?.id;
      state.incident = incident;
      state.assignment = assignment;
      state.detail = state.detail || {};
      state.detail.incident = incident;
      state.detail.assignment = assignment;
      state.detail.nearbyIncidents = (state.detail.nearbyIncidents || []).filter((i) => i.id !== incident.id);
      state.nearby = state.detail.nearbyIncidents;
      state.alarmDismissedFor = null;
      state.fittedAssignmentId = null;
      joinIncident(incident.id);
      renderAll();

      if (assignment.id !== previousId) {
        S.dispatchTone();
        toast('Incoming dispatch', `${priorityOf(incident).short} · ${typeOf(incident).label} · ${incident.address}`, 'warning');
        maybeShowAlarm();
        setTimeout(() => fitRoute(), 200);
      }
    });

    socket.on('proximity:sos', ({ incident, distanceKm, etaMinutes, targetUnitId, unitId } = {}) => {
      if (!incident) return;
      const unit = currentUnit();
      if (!unit || unit.status === 'offline') return;
      const matchId = targetUnitId || unitId;
      if (matchId && Number(matchId) !== Number(unit.id)) return;
      if (state.assignment && ['accepted', 'en_route', 'on_scene'].includes(state.assignment.status)) return;

      state.proximitySos = { incident, distanceKm, etaMinutes };
      if (state.soundOn) {
        S.chime();
        startSiren();
        setTimeout(() => stopSiren(), 7000);
      }
      toast(
        'Incoming Call Protocol · Proximity SOS',
        `${incident.type.toUpperCase()} emergency ${distanceKm} km away. Check incoming call tab at top of map.`,
        'warning',
        9000
      );
      renderCallBanner();
    });

    socket.on('assignment:updated', ({ incident, assignment } = {}) => {
      if (!incident || !assignment) return;
      const unit = currentUnit();
      if (!unit || Number(assignment.responderId) !== Number(unit.id)) return;
      const previousStatus = state.assignment?.status;
      state.incident = incident;
      state.assignment = ACTIVE_ASSIGNMENT.includes(assignment.status) || assignment.status === 'completed' ? assignment : null;
      if (state.detail) {
        state.detail.incident = incident;
        state.detail.assignment = state.assignment;
      }
      if (state.assignment?.status !== 'alerting') closeAlarm({ stopOnly: true });
      state.alarmDismissedFor = null;
      renderAll();
      if (previousStatus !== state.assignment?.status && state.assignment?.status === 'on_scene') {
        toast('Arrival confirmed', 'Dispatch has you on scene. Update patient transport when ready.', 'success');
      }
      if (previousStatus !== state.assignment?.status && state.assignment?.status === 'completed') {
        toast('Assignment complete', 'Dispatch has been notified. You are back in the available pool.', 'success');
      }
    });

    socket.on('incident:updated', (incident) => {
      if (!incident?.id) return;
      const mine = state.incident?.id === incident.id ||
        (state.assignment && Number(state.assignment.incidentId) === Number(incident.id));
      if (!mine) return;

      const unit = currentUnit();
      const ownAssignments = (incident.assignments || []).filter(
        (a) => Number(a.responderId) === Number(unit?.id)
      );
      const active = ownAssignments.find((a) => ACTIVE_ASSIGNMENT.includes(a.status));
      const latest = ownAssignments[ownAssignments.length - 1] || null;
      const closed = ['resolved', 'cancelled'].includes(incident.status);

      state.incident = incident;
      state.assignment = active || (latest && latest.status === 'completed' ? latest : null);

      if (closed) {
        closeAlarm({ stopOnly: true });
        state.alarmDismissedFor = null;
        if (state.detail) {
          state.detail.incident = incident;
          state.detail.assignment = null;
          state.detail.nearbyIncidents = (state.detail.nearbyIncidents || []).filter((i) => i.id !== incident.id);
          state.nearby = state.detail.nearbyIncidents;
        }
        renderAll();
        toast(
          incident.status === 'cancelled' ? 'Incident cancelled' : 'Incident resolved',
          `${incident.code} has been closed by command. You are returning to standby.`,
          'info',
          5500
        );
        setTimeout(() => refreshDetail({ silent: true }), 2200);
        return;
      }

      if (state.detail) {
        state.detail.incident = incident;
        state.detail.assignment = state.assignment;
      }
      renderAll();
    });

    socket.on('incident:location', (payload) => {
      if (!payload || !state.incident || Number(state.incident.id) !== Number(payload.id)) return;
      state.incident.lat = Number(payload.lat);
      state.incident.lng = Number(payload.lng);
      state.incident.accuracyM = payload.accuracyM;
      if (state.incidentMarker) state.incidentMarker.setLatLng([payload.lat, payload.lng]);
    });

    socket.on('message:new', ({ incidentId, message } = {}) => {
      if (!message || !state.incident || Number(state.incident.id) !== Number(incidentId)) return;
      state.incident.messages = state.incident.messages || [];
      if (state.incident.messages.some((m) => m.id === message.id)) return;
      state.incident.messages.push(message);
      const unit = currentUnit();
      const own = message.senderType === 'responder' && String(message.senderId) === String(unit?.publicId);
      if (!own) {
        if (state.soundOn) S.chime();
        if (state.commsTab !== 'chat' || document.hidden) {
          state.unread += 1;
          toast('New message', `${message.senderName}: ${message.body.slice(0, 90)}`, 'info');
        }
      }
      renderComms();
      scrollChatToBottom();
    });

    socket.on('note:new', ({ incidentId, note } = {}) => {
      if (!note || !state.incident || Number(state.incident.id) !== Number(incidentId)) return;
      state.incident.notes = state.incident.notes || [];
      if (!state.incident.notes.some((n) => n.id === note.id)) state.incident.notes.unshift(note);
      if (state.commsTab === 'notes') renderComms();
    });

    socket.on('unit:fleet', (unitUpdate) => applyFleetUpdate(unitUpdate));
    socket.on('fleet:unit', (unitUpdate) => applyFleetUpdate(unitUpdate));
    socket.on('fleet:update', (units) => {
      if (!Array.isArray(units)) return;
      const mine = units.find((u) => Number(u.id) === Number(state.unit?.id));
      if (mine) applyFleetUpdate(mine);
    });
    socket.on('stats:update', () => { /* command-centre KPI payload; not needed in the field */ });

    // PTT Radio Protocol listeners
    socket.on('ptt:rx-start', (p) => handleResponderPttIncoming(p, 'start'));
    socket.on('ptt:rx-audio', (p) => handleResponderPttIncoming(p, 'audio'));
    socket.on('ptt:rx-end', (p) => handleResponderPttIncoming(p, 'end'));
  }

  // -------------------------------------------------------------------------
  // In-Vehicle PTT (Push-To-Talk) Radio Protocol & LiveKit Cloud WebRTC Bridge
  // -------------------------------------------------------------------------
  const responderPttState = {
    transmitting: false,
    receiving: false,
    audioStream: null,
    mediaRecorder: null,
    testStream: null,
    testCtx: null,
    testRaf: null,
    livekitRoom: null,
    livekitConnected: false,
    dismounted: false, // Foot Patrol / Dismounted mode
    currentTarget: {
      id: 'eoc-dispatch',
      name: 'All Units · EOC Dispatch',
      type: 'channel',
      badge: 'BROADCAST'
    },
    groups: [],
    contacts: []
  };

  // ── PTT radio settings (microphone, hardware key, transmission mode) ──────
  const PTT_SETTINGS_KEY = 'naijasos.ptt.settings';
  const DEFAULT_PTT_SETTINGS = {
    deviceId: '',
    mode: 'hold',
    hardwareKey: '',
    spaceKey: true,
    echoCancellation: true,
    noiseSuppression: true
  };

  function loadPttSettings() {
    try {
      const saved = JSON.parse(localStorage.getItem(PTT_SETTINGS_KEY) || '{}');
      return { ...DEFAULT_PTT_SETTINGS, ...(saved && typeof saved === 'object' ? saved : {}) };
    } catch {
      return { ...DEFAULT_PTT_SETTINGS };
    }
  }
  const pttSettings = loadPttSettings();

  function savePttSettings(patch) {
    Object.assign(pttSettings, patch);
    try { localStorage.setItem(PTT_SETTINGS_KEY, JSON.stringify(pttSettings)); } catch { /* storage may be blocked */ }
    // The selected microphone may have changed: drop the cached stream so the
    // next transmission opens the PTT mic that is configured.
    if (responderPttState.audioStream) {
      responderPttState.audioStream.getTracks().forEach((track) => track.stop());
      responderPttState.audioStream = null;
    }
  }

  function pttKeyMatches(event) {
    if (!event) return false;
    if (pttSettings.spaceKey && (event.code === 'Space' || event.key === ' ' || event.key === 'Spacebar')) return true;
    if (pttSettings.hardwareKey) {
      if (
        event.code === pttSettings.hardwareKey ||
        event.key === pttSettings.hardwareKey ||
        String(event.keyCode) === pttSettings.hardwareKey
      ) return true;
    }
    // Common PoC / Hytera MNC360 side-key codes and headset hook. Escape is
    // deliberately excluded so it can still cancel dialogs.
    return [284, 280, 179].includes(Number(event.keyCode))
      || event.code === 'HeadsetHook'
      || event.code === 'F1'
      || event.code === 'F2';
  }

  function pttAudioConstraints() {
    const constraints = {
      echoCancellation: !!pttSettings.echoCancellation,
      noiseSuppression: !!pttSettings.noiseSuppression
    };
    if (pttSettings.deviceId) constraints.deviceId = { exact: pttSettings.deviceId };
    return constraints;
  }

  async function getPttMicrophoneStream() {
    if (!navigator.mediaDevices?.getUserMedia) return null;
    try {
      return await navigator.mediaDevices.getUserMedia({ audio: pttAudioConstraints() });
    } catch (error) {
      if (!pttSettings.deviceId) return null;
      // The saved PTT mic was unplugged — fall back to the system default
      // rather than blocking an emergency transmission.
      console.warn('[ptt] selected microphone unavailable, using default:', error.message);
      try {
        return await navigator.mediaDevices.getUserMedia({
          audio: {
            echoCancellation: !!pttSettings.echoCancellation,
            noiseSuppression: !!pttSettings.noiseSuppression
          }
        });
      } catch {
        return null;
      }
    }
  }

  // True while the settings modal is listening for a hardware PTT key. The
  // global key handlers ignore keys during capture so the radio cannot key up.
  let pttKeyCaptureActive = false;

  function pttDefaultLabel() {
    if (responderPttState.currentTarget && responderPttState.currentTarget.name) {
      const shortName = responderPttState.currentTarget.name.split('·')[0].trim().slice(0, 16);
      return pttSettings.mode === 'latch' ? `TAP PTT · ${shortName}` : `HOLD PTT · ${shortName}`;
    }
    return pttSettings.mode === 'latch' ? 'TAP PTT · EOC' : 'HOLD PTT · EOC';
  }

  function refreshPttLabels() {
    const label = pttDefaultLabel();
    const lbl = $('lblResponderPtt');
    const floatLbl = $('lblFloatingPtt');
    const drawerLbl = $('lblDrawerPtt');
    if (lbl && !responderPttState.transmitting) lbl.textContent = label;
    if (floatLbl && !responderPttState.transmitting) floatLbl.textContent = label;
    if (drawerLbl && !responderPttState.transmitting) drawerLbl.textContent = pttSettings.mode === 'latch' ? 'TAP TO TALK' : 'PRESS & HOLD TO TALK';
  }

  function pttTypingTarget(event) {
    const el = event?.target;
    if (!el || !el.tagName) return false;
    if (['INPUT', 'TEXTAREA', 'SELECT'].includes(el.tagName) || el.isContentEditable) return true;
    // Do not key the radio while any dialog is open (settings, protocol,
    // decline, unit picker) — those surfaces use the keyboard for data entry.
    if (document.querySelector('.modal-backdrop')) return true;
    return !!(el.closest && el.closest('.modal-backdrop'));
  }

  function playResponderRadioBeep(type = 'start') {
    try {
      const AudioCtx = window.AudioContext || window.webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      if (type === 'start') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(880, ctx.currentTime);
        gain.gain.setValueAtTime(0.09, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.08);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.09);
      } else {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(1200, ctx.currentTime);
        osc.frequency.setValueAtTime(850, ctx.currentTime + 0.07);
        gain.gain.setValueAtTime(0.07, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.16);
        osc.start(ctx.currentTime);
        osc.stop(ctx.currentTime + 0.17);
      }
    } catch { }
  }

  async function startResponderPtt() {
    if (responderPttState.transmitting) return;
    const unit = currentUnit();
    if (!unit) return;
    responderPttState.transmitting = true;

    playResponderRadioBeep('start');

    const btn = $('btnResponderPtt');
    const lbl = $('lblResponderPtt');
    if (btn) {
      btn.classList.remove('btn-nema');
      btn.classList.add('bg-alert', 'text-white', 'animate-pulse');
    }
    if (lbl) lbl.textContent = 'TRANSMITTING TO EOC…';

    const floatBtn = $('btnFloatingPtt');
    const floatLbl = $('lblFloatingPtt');
    if (floatBtn) {
      floatBtn.classList.add('!bg-alert', '!border-alert', 'animate-pulse');
    }
    if (floatLbl) floatLbl.textContent = 'TRANSMITTING LIVE…';

    const drawerBtn = $('btnDrawerPtt');
    const drawerLbl = $('lblDrawerPtt');
    if (drawerBtn) {
      drawerBtn.classList.remove('bg-nema/15', 'border-nema/60', 'text-nema-soft');
      drawerBtn.classList.add('bg-alert', 'border-alert', 'text-white', 'animate-pulse');
    }
    if (drawerLbl) drawerLbl.textContent = `TRANSMITTING TO ${responderPttState.currentTarget?.name || 'TARGET'}…`;

    socket.emit('ptt:tx-start', {
      incidentId: state.incident?.id,
      unitId: unit.id,
      unitCallSign: unit.callSign,
      targetId: responderPttState.currentTarget?.id || 'eoc-dispatch',
      targetName: responderPttState.currentTarget?.name || 'All Units · EOC Dispatch',
      targetType: responderPttState.currentTarget?.type || 'channel',
      senderRole: 'responder',
      senderName: unit.callSign
    });

    // Unmute LiveKit mic track if connected to cloud room
    if (responderPttState.livekitRoom && responderPttState.livekitConnected) {
      try {
        await responderPttState.livekitRoom.localParticipant.setMicrophoneEnabled(true);
      } catch (lkErr) {
        console.warn('[livekit] unmute error:', lkErr.message);
      }
    }

    try {
      if (!responderPttState.audioStream) {
        responderPttState.audioStream = await getPttMicrophoneStream();
      }
      if (responderPttState.audioStream) {
        const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus') ? 'audio/webm;codecs=opus' : 'audio/webm';
        responderPttState.mediaRecorder = new MediaRecorder(responderPttState.audioStream, { mimeType });
        responderPttState.mediaRecorder.ondataavailable = async (e) => {
          if (e.data && e.data.size > 0 && responderPttState.transmitting) {
            const buffer = await e.data.arrayBuffer();
            const bytes = new Uint8Array(buffer);
            let binary = '';
            for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
            const base64 = btoa(binary);
            socket.emit('ptt:tx-audio', {
              incidentId: state.incident?.id,
              unitId: unit.id,
              audioData: base64,
              mimeType,
              senderRole: 'responder',
              senderName: unit.callSign
            });
          }
        };
        responderPttState.mediaRecorder.start(250);
      }
    } catch (err) {
      console.warn('[ptt] responder mic stream error:', err.message);
    }
  }

  function stopResponderPtt() {
    if (!responderPttState.transmitting) return;
    const unit = currentUnit();
    responderPttState.transmitting = false;

    playResponderRadioBeep('end');

    if (responderPttState.mediaRecorder && responderPttState.mediaRecorder.state !== 'inactive') {
      try { responderPttState.mediaRecorder.stop(); } catch {}
    }

    const btn = $('btnResponderPtt');
    const lbl = $('lblResponderPtt');
    if (btn) {
      btn.classList.remove('bg-alert', 'text-white', 'animate-pulse');
      btn.classList.add('btn-nema');
    }
    if (lbl) lbl.textContent = pttDefaultLabel();

    const floatBtn = $('btnFloatingPtt');
    const floatLbl = $('lblFloatingPtt');
    if (floatBtn) {
      floatBtn.classList.remove('!bg-alert', '!border-alert', 'animate-pulse');
    }
    if (floatLbl) floatLbl.textContent = pttDefaultLabel();

    const drawerBtn = $('btnDrawerPtt');
    const drawerLbl = $('lblDrawerPtt');
    if (drawerBtn) {
      drawerBtn.classList.remove('bg-alert', 'border-alert', 'text-white', 'animate-pulse');
      drawerBtn.classList.add('bg-nema/15', 'border-nema/60', 'text-nema-soft');
    }
    if (drawerLbl) drawerLbl.textContent = pttSettings.mode === 'latch' ? 'TAP TO TALK' : 'PRESS & HOLD TO TALK';

    socket.emit('ptt:tx-end', {
      incidentId: state.incident?.id,
      unitId: unit?.id,
      unitCallSign: unit?.callSign,
      senderRole: 'responder',
      senderName: unit?.callSign
    });

    // Mute LiveKit mic track when PTT button released
    if (responderPttState.livekitRoom && responderPttState.livekitConnected) {
      try {
        responderPttState.livekitRoom.localParticipant.setMicrophoneEnabled(false);
      } catch {}
    }
  }

  const seenResponderPttEvents = new Set();
  function isDuplicateResponderPtt(payload) {
    const key = payload?.txId
      ? `${payload.txId}:${payload.seq}`
      : `${payload?.socketId}:${payload?.timestamp}:${payload?.audioData?.length || 0}`;
    if (seenResponderPttEvents.has(key)) return true;
    seenResponderPttEvents.add(key);
    if (seenResponderPttEvents.size > 600) seenResponderPttEvents.delete(seenResponderPttEvents.values().next().value);
    return false;
  }

  function handleResponderPttIncoming(payload, eventType) {
    if (isDuplicateResponderPtt(payload)) return;
    if (eventType === 'start') {
      playResponderRadioBeep('start');
      responderPttState.receiving = true;
      toast('Incoming Radio Transmission', 'State EOC dispatch is speaking over radio channel…', 'info', 4000);
      const banner = $('callBannerMap') || $('callBanner');
      if (banner) {
        const tag = banner.querySelector('.incoming-call-tab');
        if (tag) tag.style.borderColor = '#ff5540';
      }
    } else if (eventType === 'audio') {
      if (payload.audioData) {
        try {
          const binary = atob(payload.audioData);
          const bytes = new Uint8Array(binary.length);
          for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
          const blob = new Blob([bytes], { type: payload.mimeType || 'audio/webm' });
          const audio = new Audio(URL.createObjectURL(blob));
          audio.play().catch(() => {});
        } catch {}
      }
    } else if (eventType === 'end') {
      playResponderRadioBeep('end');
      responderPttState.receiving = false;
      const banner = $('callBannerMap') || $('callBanner');
      if (banner) {
        const tag = banner.querySelector('.incoming-call-tab');
        if (tag) tag.style.borderColor = '';
      }
    }
  }

  // ── Make Floating PTT Bar Draggable Anywhere on Screen ───────────────────
  function initDraggablePtt() {
    const wrap = $('floatingPttWrap');
    const handle = $('dragPttHandle');
    if (!wrap) return;

    const PTT_POS_KEY = 'naijasos.ptt.position';
    try {
      const saved = JSON.parse(localStorage.getItem(PTT_POS_KEY) || 'null');
      if (saved && Number.isFinite(saved.x) && Number.isFinite(saved.y)) {
        wrap.style.left = `${Math.max(10, Math.min(window.innerWidth - 180, saved.x))}px`;
        wrap.style.top = `${Math.max(10, Math.min(window.innerHeight - 100, saved.y))}px`;
        wrap.style.bottom = 'auto';
        wrap.style.right = 'auto';
      }
    } catch {}

    let isDragging = false;
    let startX = 0, startY = 0;
    let initialLeft = 0, initialTop = 0;

    const targetEl = handle || wrap;
    targetEl.addEventListener('pointerdown', (e) => {
      // Don't drag if clicking buttons directly
      if (e.target.closest('#btnFloatingPttSettings, #btnFloatingPtt')) return;
      isDragging = true;
      targetEl.setPointerCapture(e.pointerId);
      const rect = wrap.getBoundingClientRect();
      startX = e.clientX;
      startY = e.clientY;
      initialLeft = rect.left;
      initialTop = rect.top;
      wrap.style.bottom = 'auto';
      wrap.style.right = 'auto';
      wrap.style.left = `${initialLeft}px`;
      wrap.style.top = `${initialTop}px`;
      wrap.classList.add('opacity-90', 'scale-105');
      e.preventDefault();
    });

    window.addEventListener('pointermove', (e) => {
      if (!isDragging) return;
      const dx = e.clientX - startX;
      const dy = e.clientY - startY;
      let newX = initialLeft + dx;
      let newY = initialTop + dy;

      // Keep inside screen bounds
      newX = Math.max(8, Math.min(window.innerWidth - wrap.offsetWidth - 8, newX));
      newY = Math.max(8, Math.min(window.innerHeight - wrap.offsetHeight - 8, newY));

      wrap.style.left = `${newX}px`;
      wrap.style.top = `${newY}px`;
    });

    const stopDrag = (e) => {
      if (!isDragging) return;
      isDragging = false;
      wrap.classList.remove('opacity-90', 'scale-105');
      try {
        const rect = wrap.getBoundingClientRect();
        localStorage.setItem(PTT_POS_KEY, JSON.stringify({ x: rect.left, y: rect.top }));
      } catch {}
    };

    window.addEventListener('pointerup', stopDrag);
    window.addEventListener('pointercancel', stopDrag);
  }

  // Pointer & Hardware Key event listeners for Responder PTT button
  // Supports mouse/touch hold or latch, plus PoC Walkie-Talkie hardware
  // buttons & the Space bar as configured in the PTT settings panel.
  document.addEventListener('pointerdown', (e) => {
    const btn = e.target.closest('#btnResponderPtt, #btnFloatingPtt, #btnDrawerPtt, [data-action="ptt-talk"]');
    if (!btn) return;
    e.preventDefault();
    if (pttSettings.mode === 'latch') {
      if (responderPttState.transmitting) stopResponderPtt();
      else startResponderPtt();
    } else {
      startResponderPtt();
    }
  });
  const endRespPtt = () => {
    if (pttSettings.mode === 'hold' && responderPttState.transmitting) stopResponderPtt();
  };
  window.addEventListener('pointerup', endRespPtt);
  window.addEventListener('pointercancel', endRespPtt);

  // Hardware Key mapping for handheld PoC walkie-talkies (F1/F2, HeadsetHook,
  // VolumeDown, Spacebar) — the exact key is configurable in PTT settings.
  window.addEventListener('keydown', (e) => {
    if (pttKeyCaptureActive || pttTypingTarget(e)) return;
    if (!pttKeyMatches(e)) return;
    e.preventDefault();
    if (e.repeat) return;
    if (pttSettings.mode === 'latch') {
      if (responderPttState.transmitting) stopResponderPtt();
      else startResponderPtt();
    } else if (!responderPttState.transmitting) {
      startResponderPtt();
    }
  });
  window.addEventListener('keyup', (e) => {
    if (pttKeyCaptureActive || pttTypingTarget(e)) return;
    if (!pttKeyMatches(e)) return;
    e.preventDefault();
    if (pttSettings.mode === 'hold') endRespPtt();
  });

  function applyFleetUpdate(unitUpdate) {
    if (!unitUpdate || !state.unit || Number(unitUpdate.id) !== Number(state.unit.id)) return;
    const previousStatus = state.unit.status;
    state.unit = { ...state.unit, ...unitUpdate };
    const index = state.units.findIndex((u) => u.id === unitUpdate.id);
    if (index >= 0) state.units[index] = { ...state.units[index], ...unitUpdate };
    if (state.detail?.unit) state.detail.unit = state.unit;

    if (state.assignment && Number(unitUpdate.activeAssignmentId) === Number(state.assignment.id)) {
      if (unitUpdate.progress != null) state.assignment.progress = Number(unitUpdate.progress);
      if (unitUpdate.etaMinutes != null) state.assignment.etaMinutes = Number(unitUpdate.etaMinutes);
      if (unitUpdate.activeAssignmentStatus) state.assignment.status = unitUpdate.activeAssignmentStatus;
    }

    renderHeader();
    renderTelemetry();
    updateNavSummary();
    updateNavMapLight();
    const stepIndex = currentStepIndex();
    if (stepIndex !== state.renderedStepIndex) renderDirections();

    if (previousStatus !== state.unit.status && state.unit.status === 'on_scene') {
      closeAlarm({ stopOnly: true });
    }
    if (
      unitUpdate.activeAssignmentId == null &&
      state.assignment &&
      !['completed', 'declined', 'cancelled'].includes(state.assignment.status) &&
      !state.booting &&
      !state.refreshPending
    ) {
      state.refreshPending = true;
      setTimeout(() => {
        state.refreshPending = false;
        refreshDetail({ silent: true });
      }, 1000);
    }
  }

  function updateConnectionUi() {
    const online = socket.connected;
    $('connectionLabel').textContent = online ? 'Live' : 'Reconnect';
    $('connectionLabel').className = `font-mono text-[9px] font-bold uppercase tracking-[0.12em] ${online ? 'text-ok' : 'text-alert'}`;
    $('connectionBadge').className = online
      ? 'hidden items-center gap-2 rounded-lg border border-ok/25 bg-ok/[0.06] px-2.5 py-1.5 sm:flex'
      : 'hidden items-center gap-2 rounded-lg border border-alert/30 bg-alert/10 px-2.5 py-1.5 sm:flex';
    $('connectionDot').className = online ? 'live-dot' : 'live-dot live-dot--red';
  }

  // -------------------------------------------------------------------------
  // Renderers
  // -------------------------------------------------------------------------
  function renderAll() {
    renderHeader();
    renderCallBanner();
    renderAssignment();
    renderDirections();
    renderNearby();
    renderOffVehicle();
    renderComms();
    renderTelemetry();
    renderMap();
    updateElapsedLabels();
  }

  function renderHeader() {
    const unit = currentUnit();
    const meta = agencyOf(unit);
    $('unitCallSign').textContent = unit?.callSign || 'Select unit';
    $('unitVehicle').textContent = unit
      ? `${unit.vehicleType} · ${unit.plateNumber}`
      : 'Sign on to receive dispatches';
    $('unitBadgeIcon').textContent = meta.icon || 'badge';
    $('unitBadge').style.cssText = unit
      ? `border-color:${meta.color}45;background:${meta.color}15;color:${meta.color}`
      : '';

    const pill = $('unitStatusPill');
    if (unit) {
      const st = unitStatus[unit.status] || { label: unit.status, color: '#a6acac' };
      pill.textContent = st.label;
      pill.className = 'badge';
      pill.style.cssText = `border-color:${st.color}45;background:${st.color}15;color:${st.color}`;
      pill.classList.remove('hidden');
    } else {
      pill.classList.add('hidden');
    }

    const pos = state.gps || (unit ? { lat: unit.lat, lng: unit.lng, accuracy: null, device: false } : null);
    const gpsMeta = gpsStatusMeta();
    const connected = state.gpsStatus === 'connected' && !!state.gps;
    $('gpsCoords').textContent = pos ? S.formatCoord(pos.lat, pos.lng) : 'No GPS fix';
    $('gpsAccuracy').textContent = connected
      ? `±${Math.round(state.gps.accuracy || 0)} m · ${gpsSourceLabel()}`
      : (unit ? 'Unit AVL position' : gpsMeta.label);
    $('gpsIcon').textContent = connected ? gpsSourceMeta(state.gpsSource?.type).icon : gpsMeta.icon;
    $('gpsIcon').style.color = connected ? 'var(--ok)' : state.gpsStatus === 'scanning' ? '#fbbf24' : state.gpsStatus === 'error' ? '#ff5540' : '';
    const gpsButton = $('gpsButton');
    if (gpsButton) {
      gpsButton.title = gpsMeta.detail;
      gpsButton.style.borderColor = connected ? 'rgba(52,211,153,.45)' : '';
      gpsButton.style.background = connected ? 'rgba(52,211,153,.08)' : '';
    }

    const cmdBadge = $('cmdCentreBadge');
    if (cmdBadge) {
      if (state.unitKey) {
        cmdBadge.textContent = 'Linked';
        cmdBadge.className = 'sb-badge ok';
        cmdBadge.style.display = '';
        cmdBadge.title = 'Vehicle & PTT hardware clipped and linked to backend database';
      } else {
        cmdBadge.textContent = 'Backend';
        cmdBadge.className = 'sb-badge';
        cmdBadge.style.display = '';
        cmdBadge.title = 'Command Centre database site backend';
      }
    }

    const pttBadge = $('pttGpsNavBadge');
    const pttIcon = $('pttGpsNavIcon');
    const navItem = $('nav-ptt-gps');
    const gpsSource = gpsSourceMeta((state.gpsSource || detectGpsSource()).type);
    if (pttBadge && pttIcon) {
      const meta = gpsStatusMeta();
      pttBadge.textContent = connected ? 'Connected' : meta.label;
      pttBadge.className = `sb-badge ${connected ? 'ok' : state.gpsStatus === 'scanning' ? 'warn' : ''}`.trim();
      pttBadge.style.display = '';
      pttIcon.textContent = meta.icon;
      pttIcon.style.color = '';
    }
    if (navItem) {
      // Colour indicator: green = linked/connected, amber = detecting,
      // red = error. The rules live in responder.html so they win over the
      // generic sidebar icon colour.
      navItem.classList.toggle('gps-linked', connected);
      navItem.classList.toggle('gps-scanning', state.gpsStatus === 'scanning');
      navItem.classList.toggle('gps-error', state.gpsStatus === 'error');
      navItem.title = gpsStatusMeta().detail;
      const navLabel = navItem.querySelector('.sb-label');
      if (navLabel) navLabel.textContent = connected ? gpsSource.label : 'Detect GPS';
    }

    updateSoundUi();
    updateConnectionUi();
  }

  function renderCallBanner() {
    const host = $('callBannerMap') || $('callBanner');
    if (!host) return;
    const unit = currentUnit();
    const incident = state.incident;
    const assignment = state.assignment;

    // 1. Proximity SOS Tab (Notification when citizen SOS is triggered within proximity)
    if (state.proximitySos && !state.assignment && unit) {
      const prox = state.proximitySos;
      const pi = prox.incident || {};
      const t = typeOf(pi);
      const pr = priorityOf(pi);
      const dist = prox.distanceKm != null ? prox.distanceKm : '?';
      const eta = prox.etaMinutes != null ? prox.etaMinutes : Math.round(Number(dist) * 2.2 || 5);

      host.classList.add('active');
      host.innerHTML = `
        <div class="incoming-call-tab">
          <div class="flex items-center justify-between gap-2">
            <div class="flex items-center gap-2">
              <span class="live-dot live-dot--red"></span>
              <span class="font-mono text-[9px] font-bold uppercase tracking-[0.14em] text-alert">Incoming Call Protocol · Proximity SOS</span>
              <span class="badge" style="background:#ff554018;border:1px solid #ff554040;color:#ff7a68;font-size:8.5px;padding:1px 6px;">${esc(pr.label)}</span>
            </div>
            <div class="flex items-center gap-2 font-mono text-[9.5px]">
              <span class="font-bold text-amber-400 bg-amber-500/15 border border-amber-500/30 px-2 py-0.5 rounded-md flex items-center gap-1">
                <span class="material-symbols-outlined !text-[12px]">near_me</span>
                ${esc(dist)} km · ETA ~${esc(eta)} min
              </span>
              <span class="text-white/40 hidden sm:inline">PTT Link Sync</span>
            </div>
          </div>

          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mt-2 pt-1.5 border-t border-white/10">
            <div class="min-w-0 flex-1">
              <div class="flex items-center gap-1.5">
                <span class="badge" style="${pillStyle(t.color).slice(7, -1)}">${esc(t.label.toUpperCase())}</span>
                <p class="truncate text-[13px] font-bold text-text">${esc(pi.address || 'Citizen Proximity SOS Alert')}</p>
              </div>
              <p class="truncate text-[10.5px] text-muted mt-0.5 font-mono">${esc(pi.landmark || pi.description || 'Verified via NEMA Gateway · Sector ' + (unit.station || unit.stateCode || ''))}</p>
            </div>

            <div class="flex items-center gap-1.5 shrink-0">
              <button class="btn btn-primary btn-sm bg-alert hover:bg-red-600 text-white font-bold" data-action="accept-proximity">
                <span class="material-symbols-outlined text-[15px]">check_circle</span>Accept &amp; Respond
              </button>
              <button class="btn btn-ghost btn-sm text-text hover:bg-white/10" data-action="review-proximity">
                <span class="material-symbols-outlined text-[15px]">visibility</span>Review Alarm
              </button>
              <button class="btn btn-ghost btn-sm text-muted hover:text-white" data-action="dismiss-proximity">
                <span class="material-symbols-outlined text-[15px]">close</span>Dismiss
              </button>
            </div>
          </div>
        </div>`;
      return;
    }

    // 2. Active Incident & Assignment (Dispatched vehicle route)
    if (unit && incident && assignment) {
      const type = typeOf(incident);
      const pr = priorityOf(incident);
      const st = assignmentOf(assignment.status);
      const km = remainingKm(assignment);
      const onScene = ['on_scene', 'transporting', 'completed'].includes(assignment.status);

      host.classList.add('active');
      host.innerHTML = `
        <div class="incoming-call-tab" style="border-color:${type.color}60;box-shadow:0 12px 32px rgba(0,0,0,.5),0 0 20px ${type.color}30">
          <div class="flex items-center justify-between gap-2">
            <div class="flex items-center gap-2">
              <span class="live-dot" style="background:${type.color}"></span>
              <span class="font-mono text-[9px] font-bold uppercase tracking-[0.14em]" style="color:${type.color}">Active Dispatch Route · ${esc(unit.callSign)}</span>
              <span class="badge" style="${pillStyle(st.color).slice(7, -1)}">${esc(st.label)}</span>
              <span class="font-mono text-[9px] text-dim">${esc(incident.code)}</span>
            </div>
            <div class="flex items-center gap-2 font-mono text-[9.5px]">
              <span class="font-bold text-text bg-white/10 border border-white/15 px-2 py-0.5 rounded-md flex items-center gap-1">
                ${onScene ? 'ON SCENE' : `${S.formatDistanceKm(km)} · ETA ${S.formatEta(assignment.etaMinutes)}`}
              </span>
            </div>
          </div>

          <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mt-2 pt-1 border-t border-white/10">
            <div class="min-w-0 flex-1">
              <p class="truncate text-[13px] font-bold text-text">
                ${assignment.status === 'transporting' ? `<span class="text-amber-400 font-black"><span class="material-symbols-outlined !text-[14px] align-middle mr-1">local_shipping</span>Transporting to: </span>${esc(assignment.destination || 'Designated Facility')}` : esc(incident.address)}
              </p>
              <p class="truncate text-[10.5px] text-muted mt-0.5 font-mono">${assignment.status === 'transporting' ? `Origin SOS: ${esc(incident.address)}` : esc(incident.landmark || incident.description || 'Verified via NEMA Gateway')}</p>
            </div>
            <div class="flex items-center gap-1.5 shrink-0">
              <button type="button" class="btn btn-nema btn-sm h-8 px-2.5 font-bold flex items-center gap-1 select-none active:scale-95" id="btnResponderPtt" title="Hold to speak over radio directly to State EOC dispatcher">
                <span class="material-symbols-outlined text-[15px]">radio</span>
                <span id="lblResponderPtt">${pttDefaultLabel()}</span>
              </button>
              <button type="button" class="btn btn-ghost btn-sm h-8 px-2 text-muted hover:text-white" data-action="ptt-settings" title="PTT radio settings — microphone, hardware PTT key &amp; transmission mode" aria-label="PTT radio settings">
                <span class="material-symbols-outlined text-[16px]">settings</span>
              </button>
              ${actionButtonsHtml({ compact: true })}
            </div>
          </div>
        </div>`;
      return;
    }

    // 3. Otherwise hide floating call banner on map
    host.classList.remove('active');
    host.innerHTML = '';
  }

  function actionButtonsHtml({ compact = false } = {}) {
    const a = state.assignment;
    const size = compact ? 'btn-sm' : '';
    if (!a) {
      return `<button class="btn btn-ghost ${size}" data-action="test-alarm">
        <span class="material-symbols-outlined text-[16px] text-alert">notifications_active</span>Test alarm
      </button>`;
    }
    if (a.status === 'alerting') {
      return `<button class="btn btn-primary ${size}" data-action="accept">
          <span class="material-symbols-outlined text-[17px]">check_circle</span>Accept &amp; respond
        </button>
        <button class="btn btn-ghost ${size}" data-action="decline">
          <span class="material-symbols-outlined text-[16px]">close</span>Decline
        </button>`;
    }
    if (['accepted', 'en_route'].includes(a.status)) {
      return `<button class="btn btn-warn ${size}" data-action="status" data-status="on_scene">
          <span class="material-symbols-outlined text-[17px]">location_on</span>Mark on scene
        </button>
        <button class="btn btn-ghost ${size}" data-action="open-chat">
          <span class="material-symbols-outlined text-[16px]">chat</span>Radio
        </button>`;
    }
    if (a.status === 'on_scene') {
      const type = state.incident?.type;
      const isMedical = type === 'medical';
      const isPolice = type === 'police';
      return `<button class="btn btn-warn ${size} font-bold flex items-center gap-1" data-action="status" data-status="transporting">
          <span class="material-symbols-outlined text-[17px]">${isMedical ? 'local_hospital' : isPolice ? 'local_police' : 'local_shipping'}</span>
          ${isMedical ? 'Transport to Hospital' : isPolice ? 'Transfer to Police Station' : 'Transport to Facility'}
        </button>
        <button class="btn btn-ok ${size} font-bold flex items-center gap-1" data-action="status" data-status="completed">
          <span class="material-symbols-outlined text-[17px]">task_alt</span>Conclusive Resolution
        </button>`;
    }
    if (a.status === 'transporting') {
      return `<button class="btn btn-ok ${size} font-bold flex items-center gap-1" data-action="status" data-status="completed">
          <span class="material-symbols-outlined text-[17px]">task_alt</span>Complete Facility Handover
        </button>`;
    }
    return '<span class="badge badge-ok"><span class="material-symbols-outlined !text-[12px]">task_alt</span> Assignment complete</span>';
  }

  function renderAssignment() {
    const host = $('assignmentBody');
    if (!host) return;
    const unit = currentUnit();
    const incident = state.incident;
    const assignment = state.assignment;

    if (!unit) {
      host.innerHTML = `
        <div class="panel-header">
          <div><h2 class="panel-title"><span class="material-symbols-outlined text-[18px] text-alert">assignment</span> Active assignment</h2>
          <p class="mt-1 font-mono text-[8px] uppercase tracking-[0.12em] text-dim">Operational brief</p></div>
        </div>
        <div class="flex flex-col items-center gap-2.5 px-5 py-10 text-center">
          <span class="material-symbols-outlined text-[34px] text-dim">tablet_android</span>
          <p class="text-[13px] font-bold text-text">No tablet signed on</p>
          <p class="max-w-[250px] text-[11px] leading-relaxed text-muted">Select a unit to open its live dispatch brief and navigation.</p>
          <button class="btn btn-primary btn-sm mt-1" data-action="unit-picker">Sign on a unit</button>
        </div>`;
      return;
    }

    if (!incident) {
      const st = unitStatus[unit.status] || { label: unit.status, color: '#a6acac' };
      host.innerHTML = `
        <div class="panel-header">
          <div><h2 class="panel-title"><span class="material-symbols-outlined text-[18px] text-ok">assignment</span> Active assignment</h2>
            <p class="mt-1 font-mono text-[8px] uppercase tracking-[0.12em] text-dim">Operational brief</p></div>
          <span class="badge" style="${pillStyle(st.color).slice(7, -1)}">${esc(st.label)}</span>
        </div>
        <div class="space-y-3 p-3.5">
          <div class="flex items-center gap-3 rounded-xl border border-ok/20 bg-ok/[0.035] p-3">
            <span class="relative flex h-10 w-10 items-center justify-center rounded-full border border-ok/30 bg-ok/10 text-ok">
              <span class="material-symbols-outlined text-[20px]">radio</span>
              <span class="absolute -right-0.5 -top-0.5 h-2.5 w-2.5 rounded-full border-2 border-panel bg-ok"></span>
            </span>
            <div class="min-w-0">
              <p class="text-[12px] font-bold text-text">Radio watch active</p>
              <p class="mt-0.5 text-[10px] leading-relaxed text-muted">No incident assigned. Command can push a dispatch to this tablet at any time.</p>
            </div>
          </div>
          <dl class="divide-y divide-line-soft/70">
            <div class="stat-line"><dt>Call sign</dt><dd>${esc(unit.callSign)}</dd></div>
            <div class="stat-line"><dt>Station</dt><dd class="text-right">${esc(unit.station || '—')}</dd></div>
            <div class="stat-line"><dt>Vehicle</dt><dd class="text-right">${esc(unit.vehicleType || '—')}</dd></div>
            <div class="stat-line"><dt>Plate</dt><dd>${esc(unit.plateNumber || '—')}</dd></div>
            <div class="stat-line"><dt>Shift</dt><dd>${esc(unit.shiftCode || '—')} · 08:00–16:00</dd></div>
            <div class="stat-line"><dt>Battery</dt><dd>${Number(unit.batteryPct) || 0}%</dd></div>
          </dl>
          <div class="grid grid-cols-2 gap-2">
            <button class="btn btn-ghost btn-sm" data-action="test-alarm">
              <span class="material-symbols-outlined text-[16px] text-alert">notifications_active</span>Preview alarm
            </button>
            <button class="btn btn-ghost btn-sm" data-action="unit-picker">
              <span class="material-symbols-outlined text-[16px]">swap_horiz</span>Switch unit
            </button>
          </div>
          <p class="rounded-lg border border-line-soft bg-panel-2 px-3 py-2 text-[9.5px] leading-relaxed text-dim">
            <span class="font-bold text-muted">Demo tip:</span> from the command centre, select an incident, choose this unit's agency and dispatch. The assignment appears here instantly.
          </p>
        </div>`;
      return;
    }

    const type = typeOf(incident);
    const pr = priorityOf(incident);
    const st = assignment ? assignmentOf(assignment.status) : incidentStatus[incident.status] || incidentStatus.dispatched;
    const closed = ['resolved', 'cancelled'].includes(incident.status);
    const hazards = incident.hazards || [];
    const notes = (incident.notes || []).filter((n) => n.pinned).slice(0, 2);
    const unitsOnScene = (incident.assignments || []).filter((a) => ACTIVE_ASSIGNMENT.includes(a.status));

    host.innerHTML = `
      <div class="panel-header">
        <div>
          <h2 class="panel-title"><span class="material-symbols-outlined text-[18px] text-alert">assignment</span> Active assignment</h2>
          <p class="mt-1 font-mono text-[8px] uppercase tracking-[0.12em] text-dim">${esc(incident.code)} · ${esc(closed ? 'closed' : `${unitsOnScene.length} unit${unitsOnScene.length === 1 ? '' : 's'} committed`)}</p>
        </div>
        <span class="badge" style="${pillStyle(st.color).slice(7, -1)}">${esc(closed ? 'CLOSED' : st.label)}</span>
      </div>

      <div class="space-y-3 p-3.5">
        <div class="flex items-start gap-2.5">
          <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border" style="border-color:${type.color}50;background:${type.color}18;color:${type.color}">
            <span class="material-symbols-outlined text-[21px]" style="font-variation-settings:'FILL' 1">${type.icon}</span>
          </span>
          <div class="min-w-0">
            <div class="flex flex-wrap items-center gap-1.5">
              <span class="badge" style="${pillStyle(pr.color).slice(7, -1)}">${esc(pr.label)}</span>
              <span class="badge" style="${pillStyle(type.color).slice(7, -1)}">${esc(type.label)}</span>
            </div>
            <p class="mt-1.5 text-[14px] font-bold leading-tight text-text">${esc(incident.address)}</p>
            <p class="mt-0.5 text-[10px] leading-relaxed text-muted">${esc(incident.landmark || 'No landmark provided')}</p>
          </div>
        </div>

        <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
          <p class="font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-dim">Situation</p>
          <p class="mt-1.5 text-[11.5px] leading-relaxed text-text">${esc(incident.description || 'No further description from the caller.')}</p>
          ${hazards.length ? `<div class="mt-2 flex flex-wrap gap-1">${hazards.map((h) => `<span class="badge badge-p2"><span class="material-symbols-outlined !text-[11px]">warning</span>${esc(h)}</span>`).join('')}</div>` : ''}
        </div>

        <div class="grid grid-cols-2 gap-2">
          <div class="rounded-lg border border-line-soft bg-panel px-2.5 py-2">
            <p class="font-mono text-[7px] font-bold uppercase tracking-[0.14em] text-dim">People affected</p>
            <p class="data mt-0.5 text-[16px] font-bold text-text">${Number(incident.peopleAffected) || 0}</p>
          </div>
          <div class="rounded-lg border border-line-soft bg-panel px-2.5 py-2">
            <p class="font-mono text-[7px] font-bold uppercase tracking-[0.14em] text-dim">Elapsed</p>
            <p class="data mt-0.5 text-[16px] font-bold text-text" data-live-since="${esc(incident.createdAt || '')}">00:00</p>
          </div>
          <div class="rounded-lg border border-line-soft bg-panel px-2.5 py-2">
            <p class="font-mono text-[7px] font-bold uppercase tracking-[0.14em] text-dim">Remaining</p>
            <p class="data mt-0.5 text-[16px] font-bold text-text">${assignment ? (['on_scene', 'transporting', 'completed'].includes(assignment.status) ? '0 m' : S.formatDistanceKm(remainingKm(assignment))) : '—'}</p>
          </div>
          <div class="rounded-lg border border-line-soft bg-panel px-2.5 py-2">
            <p class="font-mono text-[7px] font-bold uppercase tracking-[0.14em] text-dim">ETA</p>
            <p class="data mt-0.5 text-[16px] font-bold text-text">${assignment && !['on_scene', 'transporting', 'completed'].includes(assignment.status) ? S.formatEta(assignment.etaMinutes) : 'On scene'}</p>
          </div>
        </div>

        <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
          <div class="flex items-center justify-between gap-2">
            <p class="font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-dim">Responding units</p>
            <span class="font-mono text-[8px] text-dim">${unitsOnScene.length} active</span>
          </div>
          <div class="mt-2 space-y-1.5">
            ${unitsOnScene.length ? unitsOnScene.map((a) => {
              const meta = agencyMeta[a.agencyCode] || agencyMeta.GENERAL;
              return `<div class="flex items-center gap-2">
                <span class="flex h-6 w-6 items-center justify-center rounded-md" style="background:${meta.color}18;color:${meta.color}">
                  <span class="material-symbols-outlined text-[14px]">${meta.icon}</span>
                </span>
                <span class="text-[10.5px] font-semibold text-text">${esc(a.callSign)}</span>
                <span class="badge badge-muted ml-auto">${esc(assignmentStatus[a.status]?.label || a.status)}</span>
              </div>`;
            }).join('') : '<p class="text-[10px] text-dim">No units attached.</p>'}
          </div>
        </div>

        ${notes.length ? `<div class="rounded-xl border border-road/25 bg-road/[0.04] p-3">
          <p class="flex items-center gap-1.5 font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-road"><span class="material-symbols-outlined !text-[13px]">push_pin</span> Pinned dispatch notes</p>
          ${notes.map((n) => `<p class="mt-1.5 text-[10.5px] leading-relaxed text-muted"><span class="font-bold text-text">${esc(n.authorName)}:</span> ${esc(n.body)}</p>`).join('')}
        </div>` : ''}

        <div class="space-y-1.5">
          <div class="flex flex-wrap gap-1.5">${actionButtonsHtml()}</div>
          <div class="grid grid-cols-3 gap-1.5">
            <button class="btn btn-ghost btn-sm" data-action="feed">
              <span class="material-symbols-outlined text-[16px] text-alert">videocam</span>Live feed
            </button>
            <button class="btn btn-ghost btn-sm" data-action="open-chat">
              <span class="material-symbols-outlined text-[16px]">chat</span>Radio
            </button>
            <button class="btn btn-ghost btn-sm" data-action="copy-coords">
              <span class="material-symbols-outlined text-[16px]">content_copy</span>Coords
            </button>
          </div>
        </div>

        ${incident.reporterName ? `<p class="text-[9px] leading-relaxed text-dim">Caller: <span class="text-muted">${esc(incident.reporterName)}</span>${incident.reporterPhone ? ` · <span class="data text-muted">${esc(incident.reporterPhone)}</span>` : ''} · source ${esc(incident.source || 'app')}</p>` : ''}
      </div>`;
  }

  function renderDirections() {
    const host = $('directionsBody');
    if (!host) return;
    const assignment = state.assignment;
    const steps = assignment?.steps || [];
    const incident = state.incident;
    const stepIndex = currentStepIndex();
    state.renderedStepIndex = stepIndex;

    const sub = $('directionsSub');
    if (sub) {
      sub.textContent = steps.length
        ? `${steps.length} maneuvers · ${incident?.address || 'scene'}`
        : 'No route loaded';
    }
    const src = $('directionsSource');
    if (src) {
      src.textContent = assignment?.routeSource
        ? `${String(assignment.routeSource).toUpperCase()} route`
        : 'Standby';
      src.className = assignment?.routeSource === 'osrm' ? 'badge badge-blue' : 'badge badge-muted';
    }

    if (!assignment || !steps.length) {
      host.innerHTML = `
        <div class="flex flex-col items-center justify-center gap-2 px-5 py-8 text-center">
          <span class="radar"><span class="radar__sweep"></span><span class="radar__dot" style="left:62%;top:35%"></span><span class="radar__dot" style="left:35%;top:60%"></span></span>
          <p class="mt-1 text-[12px] font-bold text-text">No route to display</p>
          <p class="max-w-[250px] text-[10px] leading-relaxed text-muted">Turn-by-turn directions appear when dispatch assigns an incident. The route and ETA are calculated server-side with OSRM.</p>
        </div>`;
      return;
    }

    const arrived = ['on_scene', 'transporting', 'completed'].includes(assignment.status);
    const active = steps[stepIndex] || steps[0];
    host.innerHTML = `
      <div class="mb-2.5 rounded-xl border p-3" style="border-color:${arrived ? '#34d39955' : '#ff554055'};background:${arrived ? '#34d3990d' : '#ff55400d'}">
        <div class="flex items-center gap-2.5">
          <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg" style="background:${arrived ? '#34d39918' : '#ff554018'};color:${arrived ? '#34d399' : '#ff5540'}">
            <span class="material-symbols-outlined text-[23px]">${arrived ? 'flag' : directionIcon(active.direction)}</span>
          </span>
          <div class="min-w-0">
            <p class="font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-dim">${arrived ? 'Arrival' : 'Next maneuver'}</p>
            <p class="mt-0.5 text-[12px] font-bold leading-snug text-text">${esc(arrived ? `You have arrived at ${incident?.address || 'the scene'}` : active.instruction)}</p>
          </div>
        </div>
      </div>
      <div class="space-y-1">
        ${steps.map((step, index) => {
          const isCurrent = index === stepIndex && !arrived;
          const isPast = index < stepIndex || arrived;
          return `<div class="flex items-start gap-2.5 rounded-lg border px-2.5 py-2 transition ${isCurrent ? 'border-alert/45 bg-alert/[0.07]' : 'border-transparent'} ${isPast ? 'opacity-45' : ''}" data-step="${index}">
            <span class="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full border ${isCurrent ? 'border-alert/40 bg-alert/15 text-alert-soft' : 'border-line bg-panel-2 text-muted'}">
              <span class="material-symbols-outlined text-[14px]">${index === steps.length - 1 ? 'flag' : directionIcon(step.direction)}</span>
            </span>
            <div class="min-w-0 flex-1">
              <p class="text-[10.5px] font-semibold leading-snug ${isCurrent ? 'text-text' : 'text-muted'}">${esc(step.instruction)}</p>
              ${step.road ? `<p class="mt-0.5 font-mono text-[8px] uppercase tracking-wide text-dim">${esc(step.road)}</p>` : ''}
            </div>
            <span class="data mt-0.5 shrink-0 text-[9px] text-dim">${step.distanceM ? stepDistance(step.distanceM) : '—'}</span>
          </div>`;
        }).join('')}
      </div>`;
  }

  function renderNearby() {
    const host = $('nearbyBody');
    if (!host) return;
    const unit = currentUnit();
    const list = state.nearby || [];
    const countEl = $('nearbyCount');
    if (countEl) countEl.textContent = String(list.length);

    if (!unit) {
      host.innerHTML = `
        <div class="flex flex-col items-center gap-2 px-4 py-8 text-center">
          <span class="material-symbols-outlined text-[28px] text-dim">radar</span>
          <p class="text-[11px] font-bold text-text">Sign on to scan your sector</p>
          <p class="text-[10px] text-muted">Nearby incidents are ranked from your unit position.</p>
        </div>`;
      return;
    }

    if (!list.length) {
      host.innerHTML = `
        <div class="flex flex-col items-center gap-2 px-4 py-8 text-center">
          <span class="flex h-10 w-10 items-center justify-center rounded-full border border-ok/25 bg-ok/[0.05] text-ok"><span class="material-symbols-outlined text-[21px]">check_circle</span></span>
          <p class="text-[11px] font-bold text-text">No other active incidents nearby</p>
          <p class="max-w-[230px] text-[10px] leading-relaxed text-muted">Your sector is clear beyond the current assignment. Command has the full city picture.</p>
        </div>`;
      return;
    }

    host.innerHTML = list.map((incident) => {
      const type = typeOf(incident);
      const pr = priorityOf(incident);
      return `<button class="w-full rounded-xl border border-line-soft bg-panel-2 p-2.5 text-left transition hover:border-[#4a4f4f] hover:bg-panel-3 active:scale-[0.995]" data-action="nearby" data-id="${incident.id}">
        <div class="flex items-start gap-2">
          <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg" style="background:${type.color}18;color:${type.color}">
            <span class="material-symbols-outlined text-[16px]">${type.icon}</span>
          </span>
          <div class="min-w-0 flex-1">
            <div class="flex items-center gap-1.5">
              <span class="badge" style="${pillStyle(pr.color).slice(7, -1)}">${esc(pr.short)}</span>
              <span class="data text-[9px] font-bold text-dim">${esc(incident.code)}</span>
              <span class="ml-auto data text-[9px] font-bold text-text">${S.formatDistanceKm(incident.distanceKm)}</span>
            </div>
            <p class="mt-1 truncate text-[10.5px] font-semibold text-text">${esc(incident.address)}</p>
            <p class="mt-0.5 truncate text-[9px] text-dim">${esc(incident.description || incident.landmark || '')}</p>
          </div>
        </div>
        <div class="mt-2 flex items-center gap-2 border-t border-line-soft/60 pt-1.5 text-[8px] text-dim">
          <span class="material-symbols-outlined !text-[12px]">schedule</span>
          <span>ETA ${S.formatEta(incident.etaMinutes)}</span>
          <span>·</span>
          <span>${Number(incident.unitCount) || 0} unit(s) attached</span>
          <span class="ml-auto text-alert-soft">View brief →</span>
        </div>
      </button>`;
    }).join('');
  }

  // ── Off-Vehicle Patrol & In-App Zello PTT Bridge ───────────────────────────
  function setPatrolTarget(target) {
    responderPttState.currentTarget = target;
    const nameEl = $('zelloCurrentTargetName');
    const badgeEl = $('zelloTargetBadge');
    if (nameEl) nameEl.textContent = target.name;
    if (badgeEl) {
      badgeEl.textContent = target.badge || (target.type === 'group' ? 'GROUP' : 'DIRECT');
      badgeEl.className = `badge font-mono text-[8px] ${target.type === 'group' ? 'warn' : 'ok'}`;
    }
    refreshPttLabels();
    renderOffVehicle();
    toast('Radio Target Selected', `PTT keyed to ${target.name}. Press & hold to broadcast.`, 'info', 3000);
  }

  function toggleDismountedPatrolMode() {
    responderPttState.dismounted = !responderPttState.dismounted;
    const isFoot = responderPttState.dismounted;

    const iconEl = $('patrolModeIcon');
    const titleEl = $('patrolModeTitle');
    const subEl = $('patrolModeSub');
    const btnEl = $('btnToggleFootPatrol');

    if (iconEl) iconEl.textContent = isFoot ? 'directions_walk' : 'directions_car';
    if (titleEl) titleEl.textContent = isFoot ? 'Foot Patrol Mode (Dismounted)' : 'In-Vehicle Console Mode';
    if (subEl) subEl.textContent = isFoot ? 'Dismounted telemetry · PoC Walkie-Talkie active' : 'Vehicle mount GPS · MNC360 console active';
    if (btnEl) {
      btnEl.textContent = isFoot ? 'FOOT PATROL' : 'VEHICLE';
      btnEl.className = isFoot ? 'btn btn-sm btn-nema !py-1 !px-2.5 !text-[9px]' : 'btn btn-sm btn-ghost !py-1 !px-2.5 !text-[9px] border border-line-soft';
    }

    // Inform backend & State EOC map
    const unit = currentUnit();
    if (unit) {
      socket.emit('unit:mode', {
        unitId: unit.id,
        unitCallSign: unit.callSign,
        dismounted: isFoot,
        modeLabel: isFoot ? 'foot_patrol' : 'in_vehicle'
      });
    }

    toast(
      isFoot ? 'Dismounted Foot Patrol Mode' : 'In-Vehicle Mode',
      isFoot ? 'Switched to Handheld PoC Radio. State EOC informed of foot patrol.' : 'Switched to vehicle navigation & console.',
      'ok',
      3500
    );
  }

  function renderOffVehicle() {
    const groupsHost = $('zelloGroupsList');
    const contactsHost = $('zelloContactsList');
    const peerCountEl = $('livekitPeerCount');
    if (!groupsHost || !contactsHost) return;

    const curTargetId = responderPttState.currentTarget?.id;

    // Render Radio Channels / Groups
    const defaultBroadcast = {
      id: 'eoc-dispatch',
      name: 'All Units · EOC Dispatch',
      type: 'channel',
      badge: 'BROADCAST'
    };
    const allGroups = [defaultBroadcast, ...responderPttState.groups];

    groupsHost.innerHTML = allGroups.map((grp) => {
      const isSelected = curTargetId === grp.id;
      const memberCount = grp.members?.length ? `${grp.members.length} units` : 'All Sector Units';
      return `
        <div class="rounded-xl border ${isSelected ? 'border-nema bg-nema/10 shadow-[0_0_12px_rgba(31,138,91,0.25)]' : 'border-line-soft bg-panel-2'} p-2.5 transition hover:border-[#4a4f4f] flex items-center justify-between">
          <div class="flex items-center gap-2 min-w-0">
            <span class="flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${isSelected ? 'bg-nema text-ink' : 'bg-panel-3 text-nema-soft'}">
              <span class="material-symbols-outlined text-[16px]">${grp.id === 'eoc-dispatch' ? 'podcasts' : 'groups'}</span>
            </span>
            <div class="min-w-0">
              <p class="truncate text-[11px] font-bold ${isSelected ? 'text-white' : 'text-text'}">${esc(grp.name)}</p>
              <p class="text-[9px] text-dim">${memberCount} · Open Audio</p>
            </div>
          </div>
          <button type="button" class="btn ${isSelected ? 'btn-nema !py-1 !px-2.5 !text-[9px]' : 'btn-ghost !py-1 !px-2 !text-[9px] border border-line-soft'}" data-zello-target="${grp.id}" data-zello-type="group">
            ${isSelected ? 'ACTIVE' : 'SELECT'}
          </button>
        </div>`;
    }).join('');

    // Render Real LiveKit Connected Participants
    const realPeers = [];
    if (responderPttState.livekitRoom) {
      // Local self
      const local = responderPttState.livekitRoom.localParticipant;
      if (local) {
        realPeers.push({
          id: local.identity,
          name: `${local.name || local.identity} (This Device)`,
          isSelf: true,
          isSpeaking: local.isSpeaking
        });
      }
      // Remote participants
      responderPttState.livekitRoom.remoteParticipants.forEach((p) => {
        realPeers.push({
          id: p.identity,
          name: p.name || p.identity,
          isSelf: false,
          isSpeaking: p.isSpeaking
        });
      });
    }

    if (peerCountEl) {
      peerCountEl.textContent = `${realPeers.length} Connected`;
    }

    if (!realPeers.length) {
      contactsHost.innerHTML = `
        <div class="rounded-xl border border-line-soft bg-panel-2/60 p-4 text-center">
          <span class="material-symbols-outlined text-[20px] text-dim">wifi_tethering_off</span>
          <p class="text-[10px] font-bold text-text mt-1">Connecting to LiveKit PTT Network…</p>
          <p class="text-[8.5px] text-dim">Active walkie-talkies and dispatchers tuned into this room will appear here automatically.</p>
        </div>`;
    } else {
      contactsHost.innerHTML = realPeers.map((p) => {
        const isSelected = curTargetId === p.id;
        return `
          <div class="rounded-xl border ${isSelected ? 'border-nema bg-nema/10 shadow-[0_0_12px_rgba(31,138,91,0.25)]' : 'border-line-soft bg-panel-2'} p-2.5 transition hover:border-[#4a4f4f] flex items-center justify-between">
            <div class="flex items-center gap-2 min-w-0">
              <div class="relative flex h-7 w-7 shrink-0 items-center justify-center rounded-lg ${p.isSpeaking ? 'bg-alert text-white animate-pulse' : 'bg-panel-3 text-dim'}">
                <span class="material-symbols-outlined text-[16px]">${p.isSelf ? 'person' : 'podcasts'}</span>
                <span class="absolute -bottom-0.5 -right-0.5 h-2 w-2 rounded-full bg-ok border border-panel"></span>
              </div>
              <div class="min-w-0">
                <p class="truncate text-[10.5px] font-bold ${isSelected ? 'text-white' : 'text-text'}">${esc(p.name)}</p>
                <p class="text-[8.5px] text-dim font-mono">${p.isSpeaking ? 'TRANSMITTING LIVE' : (p.isSelf ? 'Your Radio Node' : 'LiveKit PTT Peer')}</p>
              </div>
            </div>
            <div class="flex items-center gap-1.5 shrink-0">
              ${p.isSelf ? `<span class="badge ok font-mono text-[8px]">ONLINE</span>` : `
                <button type="button" class="btn ${isSelected ? 'btn-nema !py-1 !px-2.5 !text-[9px]' : 'btn-ghost !py-1 !px-2 !text-[9px] border border-line-soft'}" data-zello-target="${p.id}" data-zello-type="contact">
                  ${isSelected ? 'KEYED' : 'CALL'}
                </button>
              `}
            </div>
          </div>`;
      }).join('');
    }

    // Attach Selection Handlers
    groupsHost.querySelectorAll('[data-zello-target]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-zello-target');
        const target = allGroups.find((g) => g.id === id);
        if (target) setPatrolTarget(target);
      });
    });

    contactsHost.querySelectorAll('[data-zello-target]').forEach((btn) => {
      btn.addEventListener('click', (e) => {
        e.stopPropagation();
        const id = btn.getAttribute('data-zello-target');
        const target = realPeers.find((c) => c.id === id);
        if (target) {
          setPatrolTarget({
            id: target.id,
            name: target.name,
            type: 'contact',
            badge: 'DIRECT'
          });
        }
      });
    });
  }

  // Bind off-vehicle buttons and group creation modal
  function initOffVehicleUi() {
    const btnToggle = $('btnToggleFootPatrol');
    if (btnToggle) {
      btnToggle.addEventListener('click', toggleDismountedPatrolMode);
    }

    // Phone / SIM number storage for handheld off-vehicle device
    const phoneInput = $('inputPatrolPhone');
    const btnSavePhone = $('btnSavePatrolPhone');
    const PATROL_PHONE_KEY = 'naijasos.patrol.phone';

    if (phoneInput) {
      const savedPhone = localStorage.getItem(PATROL_PHONE_KEY) || '';
      phoneInput.value = savedPhone;
    }

    if (btnSavePhone && phoneInput) {
      btnSavePhone.addEventListener('click', () => {
        const val = phoneInput.value.trim();
        localStorage.setItem(PATROL_PHONE_KEY, val);
        const unit = currentUnit();
        if (unit) {
          socket.emit('unit:mode', {
            unitId: unit.id,
            unitCallSign: unit.callSign,
            dismounted: responderPttState.dismounted,
            modeLabel: responderPttState.dismounted ? 'foot_patrol' : 'in_vehicle',
            patrolPhone: val
          });
        }
        toast('Patrol Phone Saved', val ? `Phone ${val} registered with dispatch.` : 'Patrol phone number cleared.', 'ok', 3000);
      });
    }

    const btnOpenCreate = $('btnOpenCreateGroup');
    const dlgCreate = $('dlgCreateZelloGroup');
    const btnCloseCreate = $('btnCloseCreateGroup');
    const btnCancelCreate = $('btnCancelCreateGroup');
    const formCreate = $('formCreateZelloGroup');
    const pickerHost = $('createGroupContactPicker');
    const searchContactsInput = $('inputSearchGroupContacts');
    const pickerCountLabel = $('pickerCountLabel');

    function populateGroupContactPicker(filterText = '') {
      if (!pickerHost) return;
      const lower = filterText.toLowerCase();

      // Gather candidate contacts:
      // 1. Saved patrol phone number
      const savedPhone = localStorage.getItem(PATROL_PHONE_KEY) || '';
      const candidates = [];

      if (savedPhone) {
        candidates.push({
          id: `phone-${savedPhone.replace(/[^0-9]/g, '')}`,
          name: `Off-Vehicle Handheld (${savedPhone})`,
          detail: 'Your Saved Patrol Phone',
          phone: savedPhone,
          icon: 'smartphone'
        });
      }

      // 2. Units from the fleet list
      (state.units || []).forEach((u) => {
        candidates.push({
          id: `unit-${u.id}`,
          name: u.callSign,
          detail: `${u.vehicleType || 'Unit'} · ${agencyOf(u).label}`,
          phone: u.phone || '',
          icon: 'directions_car'
        });
      });

      // 3. LiveKit peers currently connected
      if (responderPttState.livekitRoom) {
        responderPttState.livekitRoom.remoteParticipants.forEach((p) => {
          candidates.push({
            id: `peer-${p.identity}`,
            name: p.name || p.identity,
            detail: 'Live Radio Node (LiveKit)',
            phone: '',
            icon: 'podcasts'
          });
        });
      }

      const filtered = candidates.filter((c) =>
        !lower ||
        c.name.toLowerCase().includes(lower) ||
        c.detail.toLowerCase().includes(lower) ||
        (c.phone && c.phone.toLowerCase().includes(lower))
      );

      if (pickerCountLabel) {
        pickerCountLabel.textContent = `${filtered.length} found`;
      }

      if (!filtered.length) {
        pickerHost.innerHTML = `
          <div class="py-4 text-center text-dim text-[9.5px]">
            No contacts or saved numbers match "${esc(filterText)}".
          </div>`;
        return;
      }

      pickerHost.innerHTML = filtered.map((c) => `
        <label class="flex items-center gap-2 p-1.5 rounded hover:bg-panel-3 cursor-pointer text-[10px] transition border border-transparent hover:border-line-soft">
          <input type="checkbox" name="zelloGroupContact" value="${c.id}" data-name="${esc(c.name)}" class="accent-nema rounded" />
          <span class="material-symbols-outlined text-[15px] text-nema-soft">${c.icon}</span>
          <div class="min-w-0 flex-1">
            <p class="font-bold text-text truncate">${esc(c.name)}</p>
            <p class="text-[8.5px] text-dim truncate">${esc(c.detail)}</p>
          </div>
        </label>
      `).join('');
    }

    if (searchContactsInput) {
      searchContactsInput.addEventListener('input', (e) => {
        populateGroupContactPicker(e.target.value.trim());
      });
    }

    if (btnOpenCreate && dlgCreate) {
      btnOpenCreate.addEventListener('click', () => {
        if (searchContactsInput) searchContactsInput.value = '';
        populateGroupContactPicker('');
        dlgCreate.showModal();
      });
    }

    const closeDlg = () => { if (dlgCreate) dlgCreate.close(); };
    if (btnCloseCreate) btnCloseCreate.addEventListener('click', closeDlg);
    if (btnCancelCreate) btnCancelCreate.addEventListener('click', closeDlg);

    if (formCreate) {
      formCreate.addEventListener('submit', (e) => {
        e.preventDefault();
        const inputName = $('inputZelloGroupName');
        const name = inputName?.value?.trim();
        if (!name) return;

        const checkedBoxes = Array.from(formCreate.querySelectorAll('input[name="zelloGroupContact"]:checked'));
        const selectedIds = checkedBoxes.map((cb) => cb.value);
        const selectedNames = checkedBoxes.map((cb) => cb.getAttribute('data-name') || cb.value);

        const newGroup = {
          id: `grp-${Date.now()}`,
          name: name,
          members: selectedIds,
          memberNames: selectedNames,
          type: 'group',
          badge: 'GROUP'
        };

        responderPttState.groups.unshift(newGroup);
        if (inputName) inputName.value = '';
        closeDlg();
        setPatrolTarget(newGroup);
        toast('Patrol Group Created', `Created radio group "${name}" with ${selectedIds.length} members.`, 'ok', 3500);
      });
    }

    // Connect to LiveKit Cloud Room for high-fidelity WebRTC voice
    connectLiveKitCloudRoom();
  }

  async function connectLiveKitCloudRoom() {
    if (typeof LivekitClient === 'undefined') {
      console.warn('[livekit] LivekitClient SDK not loaded');
      return;
    }
    const unit = currentUnit();
    const savedPhone = localStorage.getItem('naijasos.patrol.phone') || '';
    const phoneSuffix = savedPhone ? ` · 📞 ${savedPhone}` : '';
    const identity = unit ? `unit-${unit.id}-${unit.callSign.replace(/[^a-zA-Z0-9]/g, '_')}` : `responder-${Date.now()}`;
    const displayName = unit ? `${unit.callSign}${phoneSuffix}` : `First Responder${phoneSuffix}`;

    try {
      const res = await fetch(`/api/livekit/token?room=nema-operations-room&identity=${encodeURIComponent(identity)}&name=${encodeURIComponent(displayName)}`);
      if (!res.ok) {
        console.warn('[livekit] could not get token from server');
        return;
      }
      const data = await res.json();
      const room = new LivekitClient.Room({
        adaptiveStream: true,
        dynacast: true,
        audioCaptureDefaults: {
          autoGainControl: true,
          echoCancellation: true,
          noiseSuppression: true
        }
      });

      // Handle incoming radio audio tracks from other officers/dispatch
      room.on(LivekitClient.RoomEvent.TrackSubscribed, (track, publication, participant) => {
        if (track.kind === 'audio') {
          playResponderRadioBeep('start');
          const element = track.attach();
          element.autoplay = true;
          document.body.appendChild(element);
          toast('Radio Transmission Active', `${participant.name || participant.identity} is speaking on LiveKit radio`, 'info', 3000);
        }
      });

      room.on(LivekitClient.RoomEvent.TrackUnsubscribed, (track) => {
        track.detach();
      });

      // Participant events to update live connected counter & peer list in real time
      const refreshPeers = () => renderOffVehicle();
      room.on(LivekitClient.RoomEvent.ParticipantConnected, (p) => {
        toast('Radio Node Connected', `${p.name || p.identity} joined patrol channel`, 'info', 2500);
        refreshPeers();
      });
      room.on(LivekitClient.RoomEvent.ParticipantDisconnected, (p) => {
        toast('Radio Node Offline', `${p.name || p.identity} left patrol channel`, 'info', 2500);
        refreshPeers();
      });
      room.on(LivekitClient.RoomEvent.ActiveSpeakersChanged, refreshPeers);

      room.on(LivekitClient.RoomEvent.Disconnected, () => {
        responderPttState.livekitConnected = false;
        const statusEl = $('livekitStatusText');
        if (statusEl) {
          statusEl.textContent = 'LIVEKIT DISCONNECTED';
          statusEl.className = 'font-mono text-[9px] font-bold text-alert uppercase tracking-wider';
        }
        refreshPeers();
      });

      await room.connect(data.url, data.token);
      responderPttState.livekitRoom = room;
      responderPttState.livekitConnected = true;

      // Start muted (PTT behavior: hold button to speak, release to mute)
      await room.localParticipant.setMicrophoneEnabled(false);

      const statusEl = $('livekitStatusText');
      if (statusEl) {
        statusEl.textContent = 'LIVEKIT CLOUD CONNECTED';
        statusEl.className = 'font-mono text-[9px] font-bold text-ok uppercase tracking-wider';
      }
      refreshPeers();
      console.log('[livekit] connected successfully to cloud room:', data.room);
    } catch (err) {
      console.warn('[livekit] room connection error:', err.message);
    }
  }

  function renderComms() {
    const host = $('commsBody');
    if (!host) return;
    const unit = currentUnit();
    const incident = state.incident;
    const tabs = [
      ['chat', 'Chat', 'forum'],
      ['notes', 'Dispatch notes', 'push_pin'],
      ['activity', 'Activity', 'history']
    ];
    const unread = state.unread ? `<span class="ml-1 rounded-full bg-alert px-1.5 py-0.5 font-mono text-[8px] font-bold text-[#210603]">${state.unread}</span>` : '';

    host.innerHTML = `
      <div class="panel-header">
        <div>
          <h2 class="panel-title"><span class="material-symbols-outlined text-[18px] text-police">forum</span> Incident comms</h2>
          <p class="mt-1 font-mono text-[8px] uppercase tracking-[0.12em] text-dim">${incident ? `${esc(incident.code)} · dispatch + crew` : 'Radio idle · no incident'}</p>
        </div>
        <button class="btn btn-ghost btn-sm" data-action="feed" ${incident ? '' : 'disabled'} title="View the citizen's live camera feed">
          <span class="material-symbols-outlined text-[16px] ${incident?.media ? 'text-alert' : 'text-dim'}">videocam</span>
          <span class="hidden sm:inline">Feed</span>
          ${incident?.media ? '<span class="live-dot live-dot--red"></span>' : ''}
        </button>
      </div>
      <div class="flex items-center gap-1 overflow-x-auto border-b border-line-soft px-2">
        ${tabs.map(([key, label, icon]) => `
          <button class="tab ${state.commsTab === key ? 'is-active' : ''}" data-action="comms-tab" data-tab="${key}">
            <span class="material-symbols-outlined mr-1 align-[-4px] !text-[14px]">${icon}</span>${label}${key === 'chat' ? unread : ''}
          </button>`).join('')}
      </div>
      <div id="commsTabBody" class="p-3">
        ${incident ? renderCommsTab(unit, incident) : `
          <div class="flex flex-col items-center gap-2 px-4 py-7 text-center">
            <span class="material-symbols-outlined text-[28px] text-dim">radio</span>
            <p class="text-[11px] font-bold text-text">No active incident channel</p>
            <p class="max-w-[240px] text-[10px] leading-relaxed text-muted">Chat, notes and the live feed open automatically when you accept a dispatch.</p>
          </div>`}
      </div>`;
  }

  function renderCommsTab(unit, incident) {
    if (state.commsTab === 'notes') {
      const notes = incident.notes || [];
      if (!notes.length) {
        return `<div class="px-3 py-7 text-center"><span class="material-symbols-outlined text-[26px] text-dim">push_pin</span><p class="mt-1 text-[11px] font-bold text-text">No dispatch notes</p><p class="mt-0.5 text-[10px] text-muted">Command can pin operational notes to this incident.</p></div>`;
      }
      return `<div class="space-y-2">${notes.map((note) => `
        <div class="rounded-lg border px-3 py-2 ${note.pinned ? 'border-road/30 bg-road/[0.045]' : 'border-line-soft bg-panel-2'}">
          <div class="flex items-center gap-1.5">
            ${note.pinned ? '<span class="material-symbols-outlined !text-[13px] text-road">push_pin</span>' : '<span class="material-symbols-outlined !text-[13px] text-dim">notes</span>'}
            <span class="text-[9.5px] font-bold text-text">${esc(note.authorName)}</span>
            <span class="ml-auto font-mono text-[8px] text-dim">${S.relativeTime(note.createdAt)}</span>
          </div>
          <p class="mt-1 text-[10.5px] leading-relaxed text-muted">${esc(note.body)}</p>
        </div>`).join('')}</div>`;
    }

    if (state.commsTab === 'activity') {
      const events = [...(incident.events || [])].reverse().slice(0, 24);
      if (!events.length) return '<p class="px-3 py-7 text-center text-[10px] text-dim">No activity recorded yet.</p>';
      return `<div class="timeline">${events.map((event, index) => {
        const color = event.type === 'dispatched' ? '#f97316'
          : event.type === 'accepted' || event.type === 'en_route' ? '#eab308'
          : event.type === 'on_scene' ? '#34d399'
          : event.type === 'resolved' ? '#727979'
          : event.type === 'created' ? '#ff5540'
          : '#3b82f6';
        return `<div class="timeline-item ${index === 0 ? 'is-current' : ''}" style="--dot:${color}">
          <div class="flex items-baseline gap-2">
            <p class="text-[10.5px] font-semibold text-text">${esc(event.message)}</p>
            <span class="ml-auto shrink-0 font-mono text-[8px] text-dim">${S.clockTime(event.createdAt, true)}</span>
          </div>
          <p class="mt-0.5 font-mono text-[8px] uppercase tracking-wide text-dim">${esc(event.actorType)}${event.actorId ? ` · ${esc(event.actorId)}` : ''}</p>
        </div>`;
      }).join('')}</div>`;
    }

    const messages = incident.messages || [];
    const quick = incident.type === 'medical'
      ? ['On scene', 'Patient stable', 'Transporting to hospital', 'Need backup']
      : incident.type === 'fire'
        ? ['On scene', 'Fire contained', 'Need water tanker', 'Evacuating']
        : incident.type === 'police'
          ? ['On scene', 'Suspect contained', 'Need backup', 'Area secure']
          : ['On scene', 'Lane blocked', 'Need tow', 'Traffic clearing'];

    return `
      <div class="chat-stream mb-2.5 min-h-[90px]" id="responderChatStream">
        ${messages.length ? messages.map((message) => {
          const own = message.senderType === 'responder' && String(message.senderId) === String(unit.publicId);
          const senderIcon = message.senderType === 'dispatcher' ? 'support_agent' : message.senderType === 'citizen' ? 'person' : 'local_taxi';
          return `<div class="chat-bubble ${own ? 'chat-bubble--out' : ''}">
            <div class="chat-bubble__meta">
              <span class="flex items-center gap-1"><span class="material-symbols-outlined !text-[11px]">${senderIcon}</span>${esc(message.senderName)}</span>
              <span class="ml-auto">${S.clockTime(message.createdAt)}</span>
            </div>
            <p>${esc(message.body)}</p>
          </div>`;
        }).join('') : `<div class="py-4 text-center"><p class="text-[10px] text-dim">No messages yet. Send a status update to dispatch.</p></div>`}
      </div>
      <div class="mb-2 flex flex-wrap gap-1">
        ${quick.map((message) => `<button class="filter-chip !h-7 !text-[9px]" data-action="quick-message" data-message="${esc(message)}">${esc(message)}</button>`).join('')}
      </div>
      <form id="responderChatForm" class="flex items-center gap-1.5">
        <input id="responderChatInput" class="input input-sm text-[11px]" placeholder="Message dispatch…" autocomplete="off" value="${esc(state.chatDraft)}" maxlength="1000" aria-label="Message dispatch" />
        <button type="submit" class="btn btn-primary btn-icon h-9 w-9 shrink-0" aria-label="Send message">
          <span class="material-symbols-outlined text-[18px]">send</span>
        </button>
      </form>
      <p class="mt-2 text-center text-[8px] text-dim">Messages are visible to command and the citizen in this incident channel.</p>`;
  }

  function scrollChatToBottom() {
    const stream = $('responderChatStream');
    if (stream) stream.scrollTop = stream.scrollHeight;
  }

  function gpsPanelHtml(unit) {
    const meta = gpsStatusMeta();
    const connected = state.gpsStatus === 'connected' && !!state.gps;
    const pos = state.gps || (unit ? { lat: unit.lat, lng: unit.lng, accuracy: null } : null);
    const fixAge = state.gps?.at ? S.relativeTime(new Date(state.gps.at).toISOString()) : null;
    const syncAge = state.gpsSyncAt ? S.relativeTime(new Date(state.gpsSyncAt).toISOString()) : null;
    const sourceLabel = gpsSourceLabel();
    const sourceIcon = gpsSourceMeta(state.gpsSource?.type).icon;
    const override = gpsSourceOverride();
    const sourceOptions = [
      ['auto', 'Auto-detect'],
      ['phone', 'Phone GPS'],
      ['ptt', 'PTT hardware'],
      ['external', 'External GPS'],
      ['pc', 'PC GPS'],
      ['tablet', 'Tablet']
    ].map(([value, label]) => `<option value="${value}"${override === value ? ' selected' : ''}>${label}</option>`).join('');
    const linkedText = !state.unitKey
      ? 'Not linked · sign on a unit to share with Command Centre'
      : state.gpsSyncError
        ? `Command Centre sync error · ${state.gpsSyncError}`
        : syncAge ? `Linked to Command Centre · ${syncAge}` : 'Linked · waiting for first sync';
    const frame = connected
      ? 'border-ok/30 bg-ok/[0.06]'
      : state.gpsStatus === 'error' ? 'border-alert/30 bg-alert/[0.06]' : 'border-line-soft bg-panel-2';
    const tone = connected ? 'text-ok' : state.gpsStatus === 'error' ? 'text-alert' : 'text-dim';
    const statusText = connected
      ? `Connected to ${esc(sourceLabel)}`
      : state.gpsStatus === 'scanning' ? `Detecting ${esc(sourceLabel)}…`
        : state.gpsStatus === 'error' ? esc(state.gpsError || 'Location unavailable')
          : 'Not connected · tap Detect GPS';

    return `
      <div class="mt-2.5 rounded-xl border ${frame} p-3">
        <div class="flex items-center justify-between gap-2">
          <p class="flex items-center gap-1.5 font-mono text-[8px] font-bold uppercase tracking-[0.14em] ${tone}">
            <span class="material-symbols-outlined !text-[14px]">${connected ? sourceIcon : meta.icon}</span>
            ${esc(sourceLabel)}
          </p>
          <span class="badge ${connected ? 'badge-ok' : state.gpsStatus === 'scanning' ? 'badge-warn' : 'badge-muted'} !text-[8px]">${connected ? 'Connected' : meta.label}</span>
        </div>
        <div class="mt-1.5 flex items-center gap-2 text-[9px] ${tone}">
          <span class="live-dot" style="width:5px;height:5px;background:${connected ? '#34d399' : state.gpsStatus === 'error' ? '#ff5540' : '#727979'}"></span>
          <span>${statusText}</span>
        </div>
        <p class="data mt-1.5 text-[11px] font-semibold text-text">${pos ? S.formatCoord(pos.lat, pos.lng) : 'No fix yet'}</p>
        <div class="mt-1 flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[8.5px] text-dim">
          <span>${state.gps ? `±${Math.round(state.gps.accuracy || 0)} m accuracy` : unit ? `Updated ${S.relativeTime(unit.updatedAt)}` : 'Waiting for a location fix'}</span>
          ${fixAge ? `<span>·</span><span>fix ${fixAge}</span>` : ''}
          ${connected ? `<span>·</span><span>${esc(linkedText)}</span>` : ''}
          ${!state.gpsEnabled && state.gps ? '<span>·</span><span>Telemetry off</span>' : ''}
        </div>
        <div class="mt-2 flex items-center justify-between gap-2 rounded-lg border border-line-soft bg-panel px-2 py-1.5">
          <div class="min-w-0">
            <p class="font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-dim">GPS source</p>
            <p class="mt-0.5 truncate text-[8.5px] text-dim">${override === 'auto' ? `Auto-detected · ${esc(sourceLabel)}` : `Manual · ${esc(sourceLabel)}`}</p>
          </div>
          <select data-action="gps-source" aria-label="GPS source" style="color-scheme:dark" class="shrink-0 rounded-md border border-line-soft bg-panel px-1.5 py-1 text-[9.5px] font-semibold text-text outline-none">
            ${sourceOptions}
          </select>
        </div>
        <div class="mt-2 grid grid-cols-2 gap-1.5">
          <button class="btn btn-ghost btn-sm !text-[9.5px]" data-action="copy-coords" ${pos ? '' : 'disabled'}>
            <span class="material-symbols-outlined text-[14px]">content_copy</span>Copy coords
          </button>
          <button class="btn btn-ghost btn-sm !text-[9.5px]" data-action="gps-once" ${state.gpsEnabled ? 'disabled' : ''}>
            <span class="material-symbols-outlined text-[14px]">my_location</span>Send a fix
          </button>
        </div>
        <button class="btn btn-sm mt-1.5 w-full !text-[9.5px] ${connected ? 'btn-ghost' : 'btn-ok'}" data-action="gps-detect">
          <span class="material-symbols-outlined text-[14px]">${connected ? 'sync' : meta.icon}</span>${connected ? 'Re-detect GPS' : 'Detect GPS'}
        </button>
      </div>`;
  }

  function renderTelemetry() {
    const host = $('telemetryBody');
    const unit = currentUnit();
    const badge = $('telemetryBadge');
    const connected = state.gpsStatus === 'connected' && !!state.gps;
    if (!unit) {
      if (badge) {
        badge.innerHTML = connected
          ? `<span class="live-dot" style="background:#34d399"></span> GPS linked`
          : '<span class="live-dot"></span> No unit';
        badge.style.cssText = connected ? 'border-color:#34d39940;background:#34d39912;color:#34d399' : '';
      }
      if (host) {
        host.innerHTML = `${gpsPanelHtml(null)}
          <p class="mt-2 py-2 text-center text-[10px] text-dim">Sign on a unit to view vehicle telemetry.</p>`;
      }
      return;
    }
    const st = unitStatus[unit.status] || { label: unit.status, color: '#a6acac' };
    if (badge) {
      badge.innerHTML = `<span class="live-dot" style="background:${st.color}"></span> ${esc(st.label)}`;
      badge.style.cssText = `border-color:${st.color}40;background:${st.color}12;color:${st.color}`;
    }
    const busy = !!unit.activeAssignmentId;
    const active = unit.status === 'available' || unit.status === 'offline';

    host.innerHTML = `
      <div class="grid grid-cols-2 gap-2">
        <div class="rounded-lg border border-line-soft bg-panel-2 px-2.5 py-2">
          <p class="font-mono text-[7px] font-bold uppercase tracking-[0.14em] text-dim">Speed</p>
          <p class="data mt-0.5 text-[16px] font-bold text-text">${Math.round(Number(unit.speedKph) || 0)} <span class="text-[9px] text-dim">km/h</span></p>
        </div>
        <div class="rounded-lg border border-line-soft bg-panel-2 px-2.5 py-2">
          <p class="font-mono text-[7px] font-bold uppercase tracking-[0.14em] text-dim">Heading</p>
          <p class="data mt-0.5 text-[16px] font-bold text-text">${compass(unit.heading)} <span class="text-[9px] text-dim">${Math.round(Number(unit.heading) || 0)}°</span></p>
        </div>
        <div class="rounded-lg border border-line-soft bg-panel-2 px-2.5 py-2">
          <p class="font-mono text-[7px] font-bold uppercase tracking-[0.14em] text-dim">Battery</p>
          <div class="mt-1 flex items-center gap-1.5">
            <div class="progress-track flex-1"><div class="progress-fill" style="width:${Math.min(100, Number(unit.batteryPct) || 0)}%;--bar-color:${(Number(unit.batteryPct) || 0) < 25 ? '#ff5540' : '#34d399'}"></div></div>
            <span class="data text-[9px] font-bold text-text">${Number(unit.batteryPct) || 0}%</span>
          </div>
        </div>
        <div class="rounded-lg border border-line-soft bg-panel-2 px-2.5 py-2">
          <p class="font-mono text-[7px] font-bold uppercase tracking-[0.14em] text-dim">Shift</p>
          <p class="data mt-0.5 text-[16px] font-bold text-text">${esc(unit.shiftCode || 'A')} <span class="text-[9px] text-dim">08–16</span></p>
        </div>
      </div>

      ${gpsPanelHtml(unit)}

      <div class="mt-2.5 rounded-xl border border-line-soft bg-panel-2 p-3">
        <div class="flex items-center justify-between gap-2">
          <div>
            <p class="font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-dim">Duty status</p>
            <p class="mt-1 text-[10.5px] font-semibold text-text">${busy ? 'Committed to an incident' : active ? 'On the available board' : 'Hidden from dispatch'}</p>
          </div>
          <div class="flex gap-1">
            <button class="btn btn-sm ${unit.status === 'available' ? 'btn-ok' : 'btn-ghost'}" data-action="duty" data-status="available" ${busy ? 'disabled' : ''}>Available</button>
            <button class="btn btn-sm ${unit.status === 'offline' ? 'btn-outline-red' : 'btn-ghost'}" data-action="duty" data-status="offline" ${busy ? 'disabled' : ''}>Offline</button>
          </div>
        </div>
        <p class="mt-1.5 text-[8.5px] leading-relaxed text-dim">${busy ? 'Finish or hand over the active assignment before changing duty status.' : 'Duty status is shared with command in real time.'}</p>
      </div>`;
  }

  // -------------------------------------------------------------------------
  // Map
  // -------------------------------------------------------------------------
  function setupMap() {
    if (state.map) return;
    const unit = currentUnit();
    const center = unit ? [unit.lat, unit.lng] : S.LAGOS_CENTRE;
    state.map = S.initMap('responderMap', { center, zoom: 13 });
    if (!state.map) return;
    state.mapReady = true;
    state.unitLayer = L.layerGroup().addTo(state.map);
    state.incidentLayer = L.layerGroup().addTo(state.map);
    state.nearbyLayer = L.layerGroup().addTo(state.map);
    state.routeLayer = L.layerGroup().addTo(state.map);
    setTimeout(() => state.map?.invalidateSize(), 180);
  }

  function renderMap() {
    setupMap();
    if (!state.map) return;
    const unit = currentUnit();
    const incident = state.incident;
    const assignment = state.assignment;

    // Unit marker
    if (unit) {
      const icon = S.unitMarkerIcon(unit, false);
      if (!state.unitMarker) {
        state.unitMarker = L.marker([unit.lat, unit.lng], { icon, zIndexOffset: 800 }).addTo(state.unitLayer);
        state.unitMarker.bindTooltip(`${unit.callSign} · ${unit.vehicleType}`, { direction: 'top', offset: [0, -18] });
      } else {
        state.unitMarker.setLatLng([unit.lat, unit.lng]);
        state.unitMarker.setIcon(icon);
      }
    }

    // Active incident marker
    state.incidentLayer.clearLayers();
    state.incidentMarker = null;
    if (incident) {
      state.incidentMarker = L.marker([incident.lat, incident.lng], { icon: S.incidentMarkerIcon(incident, true), zIndexOffset: 700 })
        .addTo(state.incidentLayer)
        .bindTooltip(`${incident.code} · ${incident.address}`, { direction: 'top', offset: [0, -18] });
      if (Number(incident.accuracyM) > 0) {
        L.circle([incident.lat, incident.lng], {
          radius: Math.min(120, Number(incident.accuracyM) || 0),
          color: typeOf(incident).color,
          weight: 1,
          opacity: 0.35,
          fillOpacity: 0.06,
          interactive: false
        }).addTo(state.incidentLayer);
      }
    }

    // Nearby incidents
    const nearbyIds = new Set((state.nearby || []).map((i) => i.id));
    for (const [id, marker] of state.nearbyMarkers) {
      if (!nearbyIds.has(id)) {
        state.nearbyLayer.removeLayer(marker);
        state.nearbyMarkers.delete(id);
      }
    }
    for (const item of state.nearby || []) {
      if (state.nearbyMarkers.has(item.id)) {
        state.nearbyMarkers.get(item.id).setLatLng([item.lat, item.lng]);
        continue;
      }
      const type = typeOf(item);
      const marker = L.marker([item.lat, item.lng], {
        icon: S.markerIcon({ color: type.color, icon: type.icon, label: item.code.replace('INC-', '#'), kind: 'incident' }),
        opacity: 0.78
      }).addTo(state.nearbyLayer);
      marker.bindTooltip(`${item.code} · ${item.address}`, { direction: 'top', offset: [0, -18] });
      marker.on('click', () => openNearbyBrief(item.id));
      state.nearbyMarkers.set(item.id, marker);
    }

    // Route (rebuilt only when the assignment changes shape)
    state.routeLayer.clearLayers();
    if (assignment?.route) {
      const coords = S.escapeRoute(assignment.route);
      if (coords.length > 1) {
        const color = ['on_scene', 'transporting', 'completed'].includes(assignment.status) ? '#34d399' : '#ff5540';
        L.polyline(coords, { color: '#000000', weight: 12, opacity: 0.55, lineCap: 'round', lineJoin: 'round' }).addTo(state.routeLayer);
        L.polyline(coords, { color, weight: 5, opacity: 0.95, lineCap: 'round', lineJoin: 'round' }).addTo(state.routeLayer);
        L.polyline(coords, { color: '#ffffff', weight: 1.5, opacity: 0.25, dashArray: '2 9', lineCap: 'round' }).addTo(state.routeLayer);
      }
      if (state.fittedAssignmentId !== assignment.id) {
        state.fittedAssignmentId = assignment.id;
        setTimeout(() => fitRoute(), 120);
      }
    } else if (state.fittedAssignmentId !== 'standby') {
      state.fittedAssignmentId = 'standby';
      setTimeout(() => {
        if (!state.map) return;
        const points = [unit, ...(state.nearby || [])].filter((p) => p && Number.isFinite(Number(p.lat)));
        if (points.length > 1) {
          S.setMapView(state.map, points, { padding: [50, 50], maxZoom: 13 });
        } else if (unit) {
          state.map.setView([unit.lat, unit.lng], 13);
        }
      }, 250);
    }

    updateNavSummary();
  }

  /** Cheap update for the 2.5s simulator tick. */
  function updateNavMapLight() {
    const unit = currentUnit();
    if (!unit || !state.map) return;
    if (state.unitMarker) state.unitMarker.setLatLng([unit.lat, unit.lng]);
    if (state.incidentMarker && state.incident) state.incidentMarker.setLatLng([state.incident.lat, state.incident.lng]);
  }

  function updateNavSummary() {
    const assignment = state.assignment;
    const incident = state.incident;
    const unit = currentUnit();
    if (!unit) return;
    const iconEl = $('navSummaryIcon');
    const dest = $('navLiveDot');
    if (!assignment || !incident) {
      $('mapMode').textContent = unit.status === 'offline' ? 'OFFLINE' : 'STANDBY GRID';
      $('mapGridLabel').textContent = unit.station || 'Lagos';
      $('navSummaryEyebrow').textContent = unit.status === 'offline' ? 'Unit off duty' : 'Awaiting dispatch';
      $('navDistance').textContent = `${unit.callSign} · ${unit.status === 'available' ? 'available' : unit.status.replaceAll('_', ' ')}`;
      $('navEta').textContent = unit.status === 'offline' ? 'Go available to accept calls' : 'Monitoring dispatch channel';
      $('navSummaryDivider').classList.remove('hidden');
      $('navProgressPct').textContent = '0%';
      $('navProgressBar').style.width = '0%';
      $('navProgressBar').style.setProperty('--bar-color', unit.status === 'offline' ? '#727979' : '#34d399');
      if (iconEl) {
        iconEl.style.cssText = `background:${unit.status === 'offline' ? '#727979' : '#34d399'}18;color:${unit.status === 'offline' ? '#727979' : '#34d399'}`;
        iconEl.innerHTML = `<span class="material-symbols-outlined text-[20px]">${unit.status === 'offline' ? 'portable_wifi_off' : 'navigation'}</span>`;
      }
      $('navRouteSource').textContent = 'GPS · AVL';
      dest.className = unit.status === 'offline' ? 'live-dot live-dot--red' : 'live-dot';
      return;
    }

    const type = typeOf(incident);
    const progress = Math.min(100, Math.round((Number(assignment.progress) || 0) * 100));
    const arrived = ['on_scene', 'transporting', 'completed'].includes(assignment.status);
    const color = arrived ? '#34d399' : type.color;
    $('mapMode').textContent = arrived ? 'ON SCENE' : 'NAVIGATION ACTIVE';
    $('mapGridLabel').textContent = incident.code;
    $('navSummaryEyebrow').textContent = `${type.label} · ${assignmentOf(assignment.status).label}`;
    $('navDistance').textContent = arrived ? incident.address : `${S.formatDistanceKm(remainingKm(assignment))} to scene`;
    $('navEta').textContent = arrived ? 'Arrival confirmed' : `ETA ${S.formatEta(assignment.etaMinutes)}`;
    $('navSummaryDivider').classList.remove('hidden');
    $('navProgressPct').textContent = `${progress}%`;
    $('navProgressBar').style.width = `${progress}%`;
    $('navProgressBar').style.setProperty('--bar-color', color);
    if (iconEl) {
      iconEl.style.cssText = `background:${color}18;color:${color}`;
      iconEl.innerHTML = `<span class="material-symbols-outlined text-[20px]">${arrived ? 'flag' : 'navigation'}</span>`;
    }
    $('navRouteSource').textContent = assignment.routeSource ? `${String(assignment.routeSource).toUpperCase()} · ${assignment.steps?.length || 0} steps` : 'route';
    dest.className = arrived ? 'live-dot' : 'live-dot live-dot--red';
  }

  function fitRoute() {
    if (!state.map) return;
    const assignment = state.assignment;
    const incident = state.incident;
    const unit = currentUnit();
    if (assignment?.route) {
      const coords = S.escapeRoute(assignment.route);
      if (coords.length > 1) {
        state.map.fitBounds(coords, { padding: [48, 48], maxZoom: 15 });
        return;
      }
    }
    const points = [unit, incident].filter((p) => p && Number.isFinite(Number(p.lat)));
    if (points.length > 1) S.setMapView(state.map, points, { padding: [55, 55], maxZoom: 15 });
    else if (unit) state.map.setView([unit.lat, unit.lng], 14);
  }

  // -------------------------------------------------------------------------
  // Actions
  // -------------------------------------------------------------------------
  async function acceptAssignment(button) {
    stopSiren();
    const a = state.assignment || state.alarm?.assignment || (state.alarm?.assignmentId ? { id: state.alarm.assignmentId, status: 'alerting' } : null);
    closeAlarm({ stopOnly: true });
    state.alarmDismissedFor = null;

    if (!a || state.alarm?.preview || String(a?.id).startsWith('preview-')) {
      toast('Dispatch Accepted', 'Ready and standby. Navigation and EOC radio link active.', 'success');
      return;
    }

    if (button) {
      button.disabled = true;
      button.innerHTML = '<span class="material-symbols-outlined animate-spin text-[17px]">progress_activity</span>Accepting…';
    }

    try {
      const result = await api(`/api/assignments/${a.id}/accept`, {
        method: 'POST',
        body: { actor: currentUnit()?.callSign || 'Responder' }
      });
      applyAssignmentResult(result, `Dispatch accepted! Navigating to ${result.incident?.address || 'the scene'}. EOC linked via PTT.`);
      fitRoute();
      if (S.chime) S.chime();
    } catch (error) {
      console.warn('Accept assignment note:', error);
      await refreshDetail({ silent: true });
      if (state.assignment) {
        toast('En Route', `Navigating to ${state.incident?.address || 'the scene'}.`, 'success');
        fitRoute();
      } else {
        toast('Dispatch Cleared', error.message || 'Call acknowledged. Unit ready for next dispatch.', 'info');
      }
    }
  }

  function openDeclineDialog() {
    stopSiren();
    closeAlarm({ stopOnly: true });
    state.alarmDismissedFor = null;

    const a = state.assignment || state.alarm?.assignment || (state.alarm?.assignmentId ? { id: state.alarm.assignmentId, status: 'alerting' } : null);
    const incident = state.incident || state.alarm?.incident;
    if (!a || state.alarm?.preview || String(a?.id).startsWith('preview-')) {
      toast('Dispatch Declined', 'Alarm dismissed. Unit remains available.', 'info');
      return;
    }
    const reasons = [
      'Already committed to another call',
      'Vehicle mechanical issue',
      'Out of jurisdiction',
      'Crew unavailable',
      'Route unsafe / blocked',
      'Other (explain below)'
    ];
    const dialog = S.modal({
      title: 'Decline dispatch',
      subtitle: `${incident?.code || 'Incident'} · ${incident?.address || 'Unknown location'}`,
      body: `
        <div class="rounded-xl border border-alert/30 bg-alert/[0.06] p-3">
          <p class="text-[11px] font-bold text-alert-soft">Command will be notified immediately</p>
          <p class="mt-0.5 text-[10px] leading-relaxed text-muted">If you decline, the dispatcher must assign another unit. Keep the reason short and factual.</p>
        </div>
        <form id="declineForm" class="space-y-3">
          <label class="block">
            <span class="field-label">Reason</span>
            <select id="declineReason" class="select text-[12px]">
              ${reasons.map((r) => `<option>${esc(r)}</option>`).join('')}
            </select>
          </label>
          <label class="block">
            <span class="field-label">Note to dispatch (optional)</span>
            <textarea id="declineNote" class="textarea text-[12px]" placeholder="e.g. blocked at Third Mainland Bridge"></textarea>
          </label>
        </form>`,
      footer: `<button class="btn btn-ghost" data-close>Keep assignment</button>
               <button class="btn btn-primary" id="declineConfirm">Decline dispatch</button>`
    });

    dialog.el.querySelector('#declineConfirm').addEventListener('click', async (event) => {
      const select = dialog.el.querySelector('#declineReason');
      const note = dialog.el.querySelector('#declineNote')?.value.trim();
      const reason = `${select?.value || 'Unit unavailable'}${note ? ` — ${note}` : ''}`;
      const button = event.currentTarget;
      button.disabled = true;
      button.textContent = 'Declining…';
      try {
        const result = await api(`/api/assignments/${a.id}/decline`, {
          method: 'POST',
          body: { reason }
        });
        dialog.close();
        closeAlarm({ stopOnly: true });
        state.alarmDismissedFor = null;
        applyAssignmentResult({ incident: result.incident, assignment: result.assignment }, 'Dispatch declined — command has been notified.');
        setTimeout(() => refreshDetail({ silent: true }), 900);
      } catch (error) {
        toast('Could not decline', error.message, 'error');
        button.disabled = false;
        button.textContent = 'Decline dispatch';
      }
    });
  }

  function openTransportDialog(a, originButton) {
    const inc = state.incident || {};
    const type = inc.type || 'medical';
    const isMedical = type === 'medical';
    const isPolice = type === 'police';

    const hospitalPresets = [
      'University of Nigeria Teaching Hospital (UNTH)',
      'National Hospital Abuja',
      'Lagos University Teaching Hospital (LUTH)',
      'State General Hospital Emergency Ward',
      'Federal Medical Centre (FMC)',
      'Parklane General Hospital, Enugu',
      'Nearest Primary Healthcare Centre (PHC)'
    ];

    const policePresets = [
      'State Police Command Headquarters',
      'Area Command Headquarters',
      'Central Police Station (CPS)',
      'Divisional Police Headquarters',
      'Special Rapid Response Squad Base'
    ];

    const generalPresets = [
      'NEMA State Emergency Relief Centre',
      'State Fire Service Command Station',
      'FRSC Sector Command Base',
      'Designated Safe Haven / Evacuation Center'
    ];

    const presets = isMedical ? hospitalPresets : (isPolice ? policePresets : generalPresets);
    const destType = isMedical ? 'Hospital / Medical Facility' : (isPolice ? 'Police Station / Command' : 'Facility / Station');

    const dialog = S.modal({
      title: isMedical ? 'Transport Patient to Hospital' : (isPolice ? 'Transfer to Police Station' : 'Transport / Handover Protocol'),
      subtitle: `${esc(inc.code || 'Incident')} · ${esc(inc.address || 'Scene')}`,
      body: `
        <div class="rounded-xl border border-line-soft bg-panel-2 p-3 space-y-1">
          <p class="text-[11.5px] font-bold text-text">Select Conclusive Destination: ${destType}</p>
          <p class="text-[10px] text-muted">EOC dispatch and the national tracking map will follow your telemetry from the SOS scene to this destination.</p>
        </div>
        <form id="transportForm" class="space-y-3 mt-3">
          <label class="block">
            <span class="field-label">Pre-registered Facilities</span>
            <select id="transportPreset" class="select text-[12px]">
              ${presets.map((p) => `<option value="${esc(p)}">${esc(p)}</option>`).join('')}
              <option value="custom">Other / Custom facility…</option>
            </select>
          </label>
          <div id="transportCustomBox" class="hidden">
            <span class="field-label">Facility Name &amp; Location</span>
            <input id="transportCustom" class="input text-[12px]" placeholder="e.g. Grace Memorial Clinic, Ogui Road" />
          </div>
          <label class="block">
            <span class="field-label">Patient / Case Condition Note</span>
            <input id="transportNotes" class="input text-[12px]" placeholder="e.g. Patient stable on oxygen, vital signs monitored" />
          </label>
        </form>
      `,
      footer: `
        <button class="btn btn-ghost" data-close>Cancel</button>
        <button class="btn btn-primary" id="btnConfirmTransport">
          <span class="material-symbols-outlined text-[17px]">local_shipping</span>Start Transport
        </button>
      `
    });

    const presetSelect = dialog.el.querySelector('#transportPreset');
    const customBox = dialog.el.querySelector('#transportCustomBox');
    const customInput = dialog.el.querySelector('#transportCustom');

    presetSelect?.addEventListener('change', () => {
      if (presetSelect.value === 'custom') {
        customBox.classList.remove('hidden');
        customInput.focus();
      } else {
        customBox.classList.add('hidden');
      }
    });

    dialog.el.querySelector('#btnConfirmTransport')?.addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      let destination = presetSelect.value;
      if (destination === 'custom') {
        destination = customInput.value.trim() || 'Designated Facility';
      }
      const note = dialog.el.querySelector('#transportNotes')?.value.trim();
      btn.disabled = true;
      btn.textContent = 'Updating…';

      try {
        const result = await api(`/api/assignments/${a.id}/status`, {
          method: 'POST',
          body: {
            status: 'transporting',
            actor: currentUnit()?.callSign || 'Responder',
            destination: `${destination}${note ? ` (${note})` : ''}`,
            destinationType: destType
          }
        });
        dialog.close();
        applyAssignmentResult(result, `Transport in progress to ${destination}. EOC is tracking.`);
      } catch (err) {
        toast('Error', err.message, 'error');
        btn.disabled = false;
        btn.textContent = 'Start Transport';
      }
    });
  }

  function openResolutionDialog(a, originButton) {
    const inc = state.incident || {};
    const dialog = S.modal({
      title: 'Conclusive Handover & Resolution',
      subtitle: `${esc(inc.code || 'Incident')} · ${esc(inc.address || 'Scene')}`,
      body: `
        <div class="rounded-xl border border-ok/30 bg-ok/[0.06] p-3 space-y-1">
          <p class="text-[12px] font-bold text-ok">Complete Incident Lifecycle</p>
          <p class="text-[10px] text-muted">Confirm that patient handover to medical personnel, suspect handover to police officers, or scene resolution is complete. This releases your unit back to standby.</p>
        </div>
        <form class="space-y-3 mt-3">
          <label class="block">
            <span class="field-label">Handover Recipient (Doctor / Police Officer / Official)</span>
            <input id="resolutionOfficer" class="input text-[12px]" placeholder="e.g. Dr. Okafor (ER UNTH) / Insp. Danjuma (Area Command)" />
          </label>
          <label class="block">
            <span class="field-label">Conclusive Handover Summary</span>
            <textarea id="resolutionNotes" class="textarea text-[12px]" placeholder="Patient successfully admitted to trauma center. All vital documents and vitals handed over."></textarea>
          </label>
        </form>
      `,
      footer: `
        <button class="btn btn-ghost" data-close>Keep Active</button>
        <button class="btn btn-ok" id="btnConfirmComplete">
          <span class="material-symbols-outlined text-[17px]">task_alt</span>Complete Handover &amp; Release Unit
        </button>
      `
    });

    dialog.el.querySelector('#btnConfirmComplete')?.addEventListener('click', async (e) => {
      const btn = e.currentTarget;
      const recipient = dialog.el.querySelector('#resolutionOfficer')?.value.trim();
      const notes = dialog.el.querySelector('#resolutionNotes')?.value.trim();
      const destination = recipient ? `Handed over to ${recipient}${notes ? `: ${notes}` : ''}` : (notes || 'Handover completed at destination');

      btn.disabled = true;
      btn.textContent = 'Completing…';

      try {
        const result = await api(`/api/assignments/${a.id}/status`, {
          method: 'POST',
          body: {
            status: 'completed',
            actor: currentUnit()?.callSign || 'Responder',
            destination
          }
        });
        dialog.close();
        applyAssignmentResult(result, 'Incident conclusively resolved and unit returned to standby.');
        setTimeout(() => refreshDetail({ silent: true }), 900);
      } catch (err) {
        toast('Error', err.message, 'error');
        btn.disabled = false;
        btn.textContent = 'Complete Handover & Release Unit';
      }
    });
  }

  async function updateStatus(status, button) {
    const a = state.assignment;
    if (!a || !status || state.busy) return;

    if (status === 'transporting') {
      openTransportDialog(a, button);
      return;
    }

    if (status === 'completed') {
      openResolutionDialog(a, button);
      return;
    }

    state.busy = true;
    if (button) {
      button.disabled = true;
      button.innerHTML = '<span class="material-symbols-outlined animate-spin text-[17px]">progress_activity</span>Updating…';
    }
    try {
      const result = await api(`/api/assignments/${a.id}/status`, {
        method: 'POST',
        body: { status, actor: currentUnit()?.callSign || 'Responder' }
      });
      applyAssignmentResult(result, {
        en_route: 'Dispatch sees you en route.',
        on_scene: 'Arrival confirmed on scene! Use PTT radio to coordinate with EOC.',
        completed: 'Conclusive resolution complete. Unit back on standby.'
      }[status] || 'Status updated.');
      if (status === 'completed') setTimeout(() => refreshDetail({ silent: true }), 900);
      if (status === 'on_scene') closeAlarm({ stopOnly: true });
    } catch (error) {
      toast('Status not updated', error.message, 'error');
      if (button) button.disabled = false;
      renderAssignment();
      renderCallBanner();
    } finally {
      state.busy = false;
    }
  }

  async function setDutyStatus(status) {
    const unit = currentUnit();
    if (!unit || !['available', 'offline'].includes(status)) return;
    if (unit.activeAssignmentId) {
      toast('Cannot change status', 'Finish the active assignment first.', 'warning');
      return;
    }
    try {
      const { unit: updated } = await api(`/api/responders/${encodeURIComponent(unit.publicId)}/status`, {
        method: 'PATCH',
        body: { status }
      });
      state.unit = { ...state.unit, ...updated };
      const index = state.units.findIndex((u) => u.id === updated.id);
      if (index >= 0) state.units[index] = { ...state.units[index], ...updated };
      if (state.detail?.unit) state.detail.unit = state.unit;
      renderAll();
      toast(status === 'available' ? 'On duty' : 'Off duty', status === 'available' ? 'You are visible to dispatch and can receive calls.' : 'Command can no longer dispatch this unit.', status === 'available' ? 'success' : 'info');
    } catch (error) {
      toast('Status not changed', error.message, 'error');
    }
  }

  async function sendChatBody(body) {
    const clean = String(body || '').trim().slice(0, 1000);
    if (!clean || !state.incident || state.sendingChat) return;
    const unit = currentUnit();
    if (!unit) return;
    state.sendingChat = true;
    try {
      const { message } = await api(`/api/incidents/${state.incident.id}/messages`, {
        method: 'POST',
        body: {
          senderType: 'responder',
          senderId: unit.publicId,
          senderName: unit.callSign,
          body: clean
        }
      });
      state.incident.messages = state.incident.messages || [];
      if (!state.incident.messages.some((m) => m.id === message.id)) state.incident.messages.push(message);
      state.chatDraft = '';
      state.unread = 0;
      renderComms();
      scrollChatToBottom();
      $('responderChatInput')?.focus();
    } catch (error) {
      toast('Message not sent', error.message, 'error');
    } finally {
      state.sendingChat = false;
    }
  }

  async function copyCoords() {
    const unit = currentUnit();
    const incident = state.incident;
    const target = incident || unit;
    if (!target) return;
    const text = `${Number(target.lat).toFixed(5)}, ${Number(target.lng).toFixed(5)}`;
    await S.copyText(`${text} · ${incident ? incident.address : unit?.station || ''}`);
  }

  // -------------------------------------------------------------------------
  // GPS telemetry
  // -------------------------------------------------------------------------
  function restoreGpsPreference() {
    if (localStorage.getItem(GPS_STORAGE) !== '1' || !navigator.geolocation) return;
    const start = () => { if (!state.gpsEnabled) startGps({ quiet: true }); };
    if (navigator.permissions?.query) {
      navigator.permissions.query({ name: 'geolocation' })
        .then((status) => {
          if (status.state === 'granted') start();
          status.onchange = () => { if (status.state === 'granted') start(); };
        })
        .catch(() => { /* permission state unknown: wait for an explicit tap */ });
    }
  }

  function gpsApiProblem() {
    if (!navigator.geolocation) return 'This browser does not expose the Geolocation API.';
    if (!window.isSecureContext) {
      return 'Device GPS requires HTTPS (or localhost). Open this page over https:// on the device.';
    }
    return null;
  }

  function gpsErrorMessage(error) {
    if (!error) return 'Location unavailable.';
    if (error.code === 1) return 'Location permission was denied for this device. Allow location access and try again.';
    if (error.code === 2) return 'No location fix yet. Move into the open and try again.';
    if (error.code === 3) return 'Location request timed out. Try again.';
    return error.message || 'Location unavailable.';
  }

  function startGps({ quiet = false } = {}) {
    const source = detectGpsSource();
    state.gpsSource = source;
    const problem = gpsApiProblem();
    if (problem) {
      state.gpsStatus = 'error';
      state.gpsError = problem;
      renderHeader();
      renderTelemetry();
      if (!quiet) toast('GPS unavailable', problem, 'error', 5000);
      return;
    }
    if (state.gpsWatchId != null) {
      if (!quiet) toast('GPS already on', `Already linked to ${source.label}.`, 'info');
      return;
    }
    state.gpsEnabled = true;
    state.gpsStatus = state.gps ? 'connected' : 'scanning';
    state.gpsError = null;
    localStorage.setItem(GPS_STORAGE, '1');
    renderHeader();
    renderTelemetry();
    state.gpsWatchId = navigator.geolocation.watchPosition(
      (position) => applyGpsFix(position.coords, { source }),
      (error) => {
        state.gpsStatus = 'error';
        state.gpsError = gpsErrorMessage(error);
        renderHeader();
        renderTelemetry();
        if (!quiet) toast('GPS error', state.gpsError, 'error', 5000);
        if (error.code === 1) stopGps({ quiet: true });
      },
      { enableHighAccuracy: true, maximumAge: 5000, timeout: 15000 }
    );
    if (!quiet) toast(`Connecting to ${source.label}`, 'Waiting for this device to report its location…', 'info', 3000);
  }

  function stopGps({ quiet = false } = {}) {
    if (state.gpsWatchId != null) navigator.geolocation?.clearWatch(state.gpsWatchId);
    state.gpsWatchId = null;
    state.gpsEnabled = false;
    state.gpsStatus = 'idle';
    state.gpsSyncAt = null;
    localStorage.setItem(GPS_STORAGE, '0');
    if (!quiet) toast('GPS telemetry off', 'Device location is no longer being shared.', 'info');
    renderHeader();
    renderTelemetry();
  }

  function toggleGps() {
    if (state.gpsEnabled) stopGps();
    else startGps();
  }

  function applyGpsFix(coords, { source = null } = {}) {
    if (source) state.gpsSource = source;
    state.gps = {
      lat: coords.latitude,
      lng: coords.longitude,
      accuracy: coords.accuracy,
      heading: Number.isFinite(coords.heading) ? coords.heading : (state.gps?.heading || 0),
      speedKph: Number.isFinite(coords.speed) ? Math.round(coords.speed * 3.6) : (state.gps?.speedKph || 0),
      altitude: coords.altitude,
      at: Date.now(),
      source: gpsSourceLabel()
    };
    state.gpsStatus = 'connected';
    state.gpsError = null;

    const unit = currentUnit();
    if (unit) {
      unit.lat = state.gps.lat;
      unit.lng = state.gps.lng;
      unit.updatedAt = new Date().toISOString();
    }

    renderHeader();
    renderTelemetry();
    return state.gps;
  }

  async function maybePushGps(force = false) {
    if (!state.gps) return false;
    if (!state.unitKey || !currentUnit()) {
      state.gpsSyncAt = null;
      return false;
    }
    const now = Date.now();
    if (!force && now - state.lastGpsPushAt < 12000) return !!state.gpsSyncAt;
    const last = state.lastGpsPoint;
    if (!force && last) {
      const moved = Math.hypot((state.gps.lat - last.lat) * 111, (state.gps.lng - last.lng) * 102);
      if (moved < 0.02) { state.lastGpsPushAt = now; return !!state.gpsSyncAt; }
    }
    state.lastGpsPushAt = now;
    state.lastGpsPoint = { lat: state.gps.lat, lng: state.gps.lng };
    try {
      await api(`/api/responders/${encodeURIComponent(state.unitKey)}/location`, {
        method: 'POST',
        body: {
          lat: state.gps.lat,
          lng: state.gps.lng,
          heading: state.gps.heading || 0,
          speed: state.gps.speedKph || 0
        }
      });
      state.gpsSyncAt = Date.now();
      state.gpsSyncError = null;
      renderTelemetry();
      return true;
    } catch (error) {
      state.gpsSyncError = error.message || 'Telemetry rejected';
      renderTelemetry();
      /* Telemetry is best-effort; navigation continues from the last fix. */
      return false;
    }
  }

  async function sendGpsFix() {
    const source = detectGpsSource();
    state.gpsSource = source;
    const problem = gpsApiProblem();
    if (problem) {
      toast('GPS unavailable', problem, 'error', 5000);
      return;
    }
    state.gpsStatus = 'scanning';
    state.gpsError = null;
    renderHeader();
    renderTelemetry();
    toast('Requesting fix', `Waiting for ${source.label}…`, 'info', 2600);
    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const fix = applyGpsFix(position.coords, { source });
        const synced = await maybePushGps(true);
        toast(
          `Connected to ${source.label}`,
          `${S.formatCoord(fix.lat, fix.lng)} · ±${Math.round(fix.accuracy || 0)} m${synced ? ' · linked to Command Centre' : ''}`,
          'success',
          4200
        );
      },
      (error) => {
        state.gpsStatus = 'error';
        state.gpsError = gpsErrorMessage(error);
        renderHeader();
        renderTelemetry();
        toast('GPS unavailable', state.gpsError, 'error', 5000);
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  }

  // -------------------------------------------------------------------------
  // PTT / device GPS detection
  // -------------------------------------------------------------------------
  async function detectPttHardwareGps() {
    const source = detectGpsSource();
    state.gpsSource = source;
    state.gpsStatus = 'scanning';
    state.gpsError = null;
    renderHeader();
    renderTelemetry();

    const problem = gpsApiProblem();
    if (problem) {
      state.gpsStatus = 'error';
      state.gpsError = problem;
      renderHeader();
      renderTelemetry();
      toast('GPS unavailable', problem, 'error', 5000);
      return;
    }

    toast(`Detecting ${source.label}`, `Scanning for a location fix from ${source.label} on this device…`, 'info', 3200);

    navigator.geolocation.getCurrentPosition(
      async (pos) => {
        const fix = applyGpsFix(pos.coords, { source });

        // Centre the map on the fix and drop a short-lived pulse marker.
        if (state.map) {
          state.map.flyTo([fix.lat, fix.lng], Math.max(state.map.getZoom(), 15), { duration: 1.2 });

          if (typeof L !== 'undefined') {
            const pulseIcon = L.divIcon({
              className: 'ptt-gps-pulse-marker',
              html: `<div style="position:relative;width:44px;height:44px;margin-left:-22px;margin-top:-22px;display:flex;align-items:center;justify-content:center;">
                <span style="position:absolute;inset:0;border-radius:9999px;background:rgba(52,211,153,0.4);animation:ping 1.5s cubic-bezier(0,0,0.2,1) infinite;"></span>
                <span style="position:relative;width:16px;height:16px;border-radius:9999px;background:#10b981;border:2.5px solid #ffffff;box-shadow:0 0 12px #10b981;"></span>
              </div>`,
              iconSize: [44, 44]
            });
            const pulseMarker = L.marker([fix.lat, fix.lng], { icon: pulseIcon }).addTo(state.map);
            setTimeout(() => { try { state.map.removeLayer(pulseMarker); } catch {} }, 6000);
          }
        }

        // Keep the link alive with a continuous watch.
        if (state.gpsWatchId == null) startGps({ quiet: true });

        const synced = await maybePushGps(true);
        toast(
          `Connected to ${source.label}`,
          `${S.formatCoord(fix.lat, fix.lng)} (±${Math.round(fix.accuracy || 0)} m). ${synced ? 'Linked to Command Centre.' : 'GPS linked to this terminal — sign on a unit to share it with Command Centre.'}`,
          'success',
          6000
        );
      },
      (error) => {
        state.gpsStatus = 'error';
        state.gpsError = gpsErrorMessage(error);
        renderHeader();
        renderTelemetry();
        toast('GPS error', state.gpsError, 'error', 5000);
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
    );
  }

  window.detectPttHardwareGps = detectPttHardwareGps;

  // -------------------------------------------------------------------------
  // PTT Radio Settings (microphone, hardware key & transmission mode)
  // -------------------------------------------------------------------------
  async function listPttMicrophones(requestAccess = false) {
    if (!navigator.mediaDevices?.enumerateDevices) return [];
    if (requestAccess) {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true }).catch(() => null);
      stream?.getTracks().forEach((track) => track.stop());
    }
    const devices = await navigator.mediaDevices.enumerateDevices().catch(() => []);
    return devices.filter((device) => device.kind === 'audioinput');
  }

  function hardwareKeyLabel() {
    return pttSettings.hardwareKey || 'Not set';
  }

  function pttModeButtonHtml(mode, label, icon, detail) {
    const active = pttSettings.mode === mode;
    return `<button type="button" data-ptt-mode="${mode}" class="flex-1 rounded-xl border p-3 text-left transition ${active ? 'border-nema bg-nema/10' : 'border-line-soft bg-panel-2 hover:border-nema/50'}">
      <span class="flex items-center gap-2 text-[11px] font-bold text-text">
        <span class="material-symbols-outlined text-[16px] ${active ? 'text-nema-soft' : 'text-dim'}">${icon}</span>${label}
      </span>
      <span class="mt-1 block text-[9.5px] leading-relaxed text-muted">${detail}</span>
    </button>`;
  }

  async function openPttSettings() {
    const inputs = await listPttMicrophones(false);
    const micOptions = [
      `<option value="" ${pttSettings.deviceId ? '' : 'selected'}>Device default microphone</option>`,
      ...inputs.map((device, index) => {
        const name = device.label || `Microphone ${index + 1}`;
        return `<option value="${esc(device.deviceId)}" ${device.deviceId === pttSettings.deviceId ? 'selected' : ''}>${esc(name)}</option>`;
      })
    ].join('');

    const body = `
      <div class="space-y-3">
        <div class="flex items-start gap-3 rounded-xl border border-nema/25 bg-nema/[0.06] p-3">
          <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-nema/40 bg-nema/15 text-nema-soft">
            <span class="material-symbols-outlined text-[22px]">settings_voice</span>
          </span>
          <div class="min-w-0 flex-1">
            <div class="flex items-center gap-2">
              <p class="text-[12px] font-bold text-text">PTT Radio Configuration</p>
              <span id="pttModeBadge" class="badge ${pttSettings.mode === 'latch' ? 'badge-warn' : 'badge-ok'} !text-[8px] uppercase tracking-wider">${pttSettings.mode === 'latch' ? 'Latch mode' : 'Hold mode'}</span>
            </div>
            <p class="mt-0.5 text-[10px] leading-relaxed text-muted">Controls the microphone and the hardware side key this in-vehicle terminal uses to key up the radio. Settings are stored on this device.</p>
          </div>
        </div>

        <!-- Microphone source -->
        <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
          <div class="flex items-center justify-between gap-2">
            <p class="font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-dim flex items-center gap-1.5">
              <span class="material-symbols-outlined text-[14px] text-nema">mic</span>PTT Microphone Source
            </p>
            <span id="pttMicCount" class="font-mono text-[9px] text-dim">${inputs.length} found</span>
          </div>
          <select id="pttMicSelect" class="input input-sm mt-2 w-full text-[11px]">${micOptions}</select>
          <div class="mt-2 flex flex-wrap items-center gap-2">
            <button type="button" id="pttMicScanBtn" class="btn btn-ghost btn-sm">
              <span class="material-symbols-outlined text-[15px]">refresh</span>Scan devices
            </button>
            <button type="button" id="pttTestBtn" class="btn btn-ghost btn-sm">
              <span class="material-symbols-outlined text-[15px]">graphic_eq</span>Test level
            </button>
            <div class="flex h-2 min-w-[70px] flex-1 overflow-hidden rounded-full bg-white/10">
              <div id="pttLevelBar" class="h-full w-0 rounded-full bg-ok transition-[width] duration-75"></div>
            </div>
            <span id="pttLevelText" class="w-10 text-right font-mono text-[9px] text-dim">—</span>
          </div>
          <p id="pttMicNote" class="mt-2 text-[9.5px] leading-relaxed text-dim">Scan devices to grant microphone access and read the radio / headset names attached to this terminal.</p>
        </div>

        <!-- Transmission mode -->
        <div>
          <p class="mb-2 font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-dim flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[14px] text-nema">swap_horiz</span>Transmission Mode
          </p>
          <div class="flex gap-2" id="pttModeGroup">
            ${pttModeButtonHtml('hold', 'Hold to talk', 'pan_tool', 'Keys up while the PTT control or hardware key is held. Release to listen.')}
            ${pttModeButtonHtml('latch', 'Latch / toggle', 'toggle_on', 'Tap once to key up and stay live; tap again to release the channel.')}
          </div>
        </div>

        <!-- Hardware key -->
        <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
          <p class="font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-dim flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[14px] text-nema">keyboard</span>Hardware PTT Key
          </p>
          <div class="mt-2 flex items-center gap-2">
            <code id="pttKeyLabel" class="min-w-0 flex-1 truncate rounded-lg border border-line-soft bg-panel px-2.5 py-1.5 font-mono text-[11px] font-bold text-text">${esc(hardwareKeyLabel())}</code>
            <button type="button" id="pttKeyDetectBtn" class="btn btn-nema btn-sm shrink-0">
              <span class="material-symbols-outlined text-[15px]">sensors</span>Detect key
            </button>
            <button type="button" id="pttKeyClearBtn" class="btn btn-ghost btn-sm shrink-0" title="Clear hardware key">
              <span class="material-symbols-outlined text-[15px]">backspace</span>
            </button>
          </div>
          <p id="pttKeyFeedback" class="mt-1.5 text-[9.5px] leading-relaxed text-dim">Press <strong>Detect key</strong>, then press the side PTT / walkie-talkie key on this device. Space and common PoC keys (F1, F2, headset hook) also key up out of the box.</p>
        </div>

        <!-- Audio toggles -->
        <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
          <p class="mb-2 font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-dim flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[14px] text-nema">tune</span>Audio Processing &amp; Keys
          </p>
          <label class="flex cursor-pointer items-start gap-2.5 py-1">
            <input type="checkbox" id="pttSpaceToggle" class="mt-0.5 accent-[#10b981]" ${pttSettings.spaceKey ? 'checked' : ''}>
            <span class="min-w-0">
              <span class="block text-[10.5px] font-bold text-text">Spacebar keys the radio</span>
              <span class="block text-[9px] text-dim">Use the tablet / PC keyboard Space bar as a PTT control.</span>
            </span>
          </label>
          <label class="flex cursor-pointer items-start gap-2.5 py-1">
            <input type="checkbox" id="pttEchoToggle" class="mt-0.5 accent-[#10b981]" ${pttSettings.echoCancellation ? 'checked' : ''}>
            <span class="min-w-0">
              <span class="block text-[10.5px] font-bold text-text">Echo cancellation</span>
              <span class="block text-[9px] text-dim">Stops the vehicle speaker feeding back into the PTT mic.</span>
            </span>
          </label>
          <label class="flex cursor-pointer items-start gap-2.5 py-1">
            <input type="checkbox" id="pttNoiseToggle" class="mt-0.5 accent-[#10b981]" ${pttSettings.noiseSuppression ? 'checked' : ''}>
            <span class="min-w-0">
              <span class="block text-[10.5px] font-bold text-text">Noise suppression</span>
              <span class="block text-[9px] text-dim">Filters siren and engine noise on the radio channel.</span>
            </span>
          </label>
          <p class="mt-1 font-mono text-[8.5px] text-dim">PTT MIC: <span id="pttFooterMic">${esc(inputs.find((d) => d.deviceId === pttSettings.deviceId)?.label || 'Device default')}</span></p>
        </div>
      </div>
    `;

    const dialog = S.modal({
      title: 'PTT Radio Settings',
      subtitle: 'Microphone, hardware key & transmission mode for this terminal',
      body,
      onClose: () => { stopMicTest(); stopKeyCapture(); },
      footer: `
        <button type="button" class="btn btn-ghost" id="pttResetBtn">
          <span class="material-symbols-outlined text-[15px]">restart_alt</span>Reset defaults
        </button>
        <button type="button" class="btn btn-nema" data-close>
          <span class="material-symbols-outlined text-[15px]">check</span>Done
        </button>
      `
    });

    const el = dialog.el;
    const micSelect = el.querySelector('#pttMicSelect');
    const micCount = el.querySelector('#pttMicCount');
    const micNote = el.querySelector('#pttMicNote');
    const levelBar = el.querySelector('#pttLevelBar');
    const levelText = el.querySelector('#pttLevelText');
    const testBtn = el.querySelector('#pttTestBtn');
    const keyLabel = el.querySelector('#pttKeyLabel');
    const keyFeedback = el.querySelector('#pttKeyFeedback');
    const keyDetectBtn = el.querySelector('#pttKeyDetectBtn');
    const footerMic = el.querySelector('#pttFooterMic');
    const modeBadge = el.querySelector('#pttModeBadge');

    let testStream = null;
    let testCtx = null;
    let testRaf = null;

    function stopMicTest() {
      if (testRaf != null) cancelAnimationFrame(testRaf);
      testRaf = null;
      testStream?.getTracks().forEach((track) => track.stop());
      testStream = null;
      if (testCtx) { try { testCtx.close(); } catch {} }
      testCtx = null;
      if (levelBar) levelBar.style.width = '0%';
      if (levelText) levelText.textContent = '—';
      if (testBtn) testBtn.classList.remove('!border-alert', '!text-alert');
    }

    function syncModeUi() {
      el.querySelectorAll('[data-ptt-mode]').forEach((button) => {
        const active = button.dataset.pttMode === pttSettings.mode;
        button.classList.toggle('border-nema', active);
        button.classList.toggle('bg-nema/10', active);
        button.classList.toggle('border-line-soft', !active);
        button.classList.toggle('bg-panel-2', !active);
        const icon = button.querySelector('.material-symbols-outlined');
        icon?.classList.toggle('text-nema-soft', active);
        icon?.classList.toggle('text-dim', !active);
      });
      if (modeBadge) {
        modeBadge.textContent = pttSettings.mode === 'latch' ? 'Latch mode' : 'Hold mode';
        modeBadge.className = `badge ${pttSettings.mode === 'latch' ? 'badge-warn' : 'badge-ok'} !text-[8px] uppercase tracking-wider`;
      }
      refreshPttLabels();
    }

    function syncMicNote() {
      const selected = inputs.find((device) => device.deviceId === pttSettings.deviceId);
      if (footerMic) footerMic.textContent = selected?.label || 'Device default';
      if (micNote && selected?.label) micNote.textContent = `PTT transmissions will use ${selected.label}.`;
    }

    async function scanMics() {
      if (micNote) micNote.textContent = 'Requesting microphone access…';
      const found = await listPttMicrophones(true);
      inputs.length = 0;
      inputs.push(...found);
      if (!found.length) {
        if (micNote) micNote.textContent = 'No microphone found. Check the radio / headset connection and try again.';
        return;
      }
      // A missing saved device stays selected as the fallback option.
      if (pttSettings.deviceId && !found.some((device) => device.deviceId === pttSettings.deviceId)) {
        savePttSettings({ deviceId: '' });
      }
      micSelect.innerHTML = [
        `<option value="" ${pttSettings.deviceId ? '' : 'selected'}>Device default microphone</option>`,
        ...found.map((device, index) => `<option value="${esc(device.deviceId)}" ${device.deviceId === pttSettings.deviceId ? 'selected' : ''}>${esc(device.label || `Microphone ${index + 1}`)}</option>`)
      ].join('');
      if (micCount) micCount.textContent = `${found.length} found`;
      if (micNote) micNote.textContent = `${found.length} microphone${found.length === 1 ? '' : 's'} detected. Select the radio handset / headset to use for PTT.`;
      syncMicNote();
    }

    micSelect?.addEventListener('change', () => {
      savePttSettings({ deviceId: micSelect.value });
      syncMicNote();
      toast('PTT microphone saved', micSelect.value ? 'The selected microphone will be used for the next transmission.' : 'Using the device default microphone.', 'success', 3000);
    });

    el.querySelector('#pttMicScanBtn')?.addEventListener('click', scanMics);

    testBtn?.addEventListener('click', async () => {
      if (testStream) {
        stopMicTest();
        testBtn.innerHTML = '<span class="material-symbols-outlined text-[15px]">graphic_eq</span>Test level';
        return;
      }
      if (!navigator.mediaDevices?.getUserMedia) {
        toast('Microphone unavailable', 'This browser cannot access microphone devices.', 'error');
        return;
      }
      testBtn.disabled = true;
      try {
        testStream = await navigator.mediaDevices.getUserMedia({ audio: pttAudioConstraints() });
        const AudioCtx = window.AudioContext || window.webkitAudioContext;
        testCtx = new AudioCtx();
        const analyser = testCtx.createAnalyser();
        analyser.fftSize = 512;
        const source = testCtx.createMediaStreamSource(testStream);
        source.connect(analyser);
        const data = new Uint8Array(analyser.fftSize);
        const tick = () => {
          analyser.getByteTimeDomainData(data);
          let peak = 0;
          for (let i = 0; i < data.length; i += 1) {
            const value = Math.abs(data[i] - 128) / 128;
            if (value > peak) peak = value;
          }
          const pct = Math.min(100, Math.round(peak * 170));
          if (levelBar) {
            levelBar.style.width = `${pct}%`;
            levelBar.className = `h-full rounded-full transition-[width] duration-75 ${pct > 78 ? 'bg-alert' : pct > 20 ? 'bg-ok' : 'bg-nema'}`;
          }
          if (levelText) levelText.textContent = `${pct}%`;
          testRaf = requestAnimationFrame(tick);
        };
        tick();
        testBtn.innerHTML = '<span class="material-symbols-outlined text-[15px]">stop_circle</span>Stop test';
        testBtn.classList.add('!border-alert', '!text-alert');
        if (micNote) micNote.textContent = 'Speak into the radio handset to confirm the PTT microphone is picking up audio.';
      } catch (error) {
        stopMicTest();
        toast('Microphone blocked', error.message || 'Unable to open the microphone for testing.', 'error');
      } finally {
        testBtn.disabled = false;
      }
    });

    el.querySelectorAll('[data-ptt-mode]').forEach((button) => {
      button.addEventListener('click', () => {
        savePttSettings({ mode: button.dataset.pttMode === 'latch' ? 'latch' : 'hold' });
        syncModeUi();
        toast('Transmission mode saved', pttSettings.mode === 'latch' ? 'Tap the PTT control once to talk, tap again to release.' : 'Hold the PTT control or hardware key to talk.', 'success', 3200);
      });
    });

    let keyCaptureHandler = null;
    const stopKeyCapture = () => {
      pttKeyCaptureActive = false;
      if (keyCaptureHandler) {
        window.removeEventListener('keydown', keyCaptureHandler, true);
        keyCaptureHandler = null;
      }
      if (keyDetectBtn) {
        keyDetectBtn.disabled = false;
        keyDetectBtn.innerHTML = '<span class="material-symbols-outlined text-[15px]">sensors</span>Detect key';
        keyDetectBtn.classList.remove('animate-pulse');
      }
    };

    keyDetectBtn?.addEventListener('click', () => {
      stopMicTest();
      stopKeyCapture();
      pttKeyCaptureActive = true;
      keyDetectBtn.disabled = true;
      keyDetectBtn.innerHTML = '<span class="material-symbols-outlined text-[15px]">hourglass_top</span>Listening…';
      keyDetectBtn.classList.add('animate-pulse');
      if (keyFeedback) keyFeedback.textContent = 'Listening — press the side PTT / walkie-talkie key now (Esc to cancel).';
      keyCaptureHandler = (event) => {
        event.preventDefault();
        event.stopPropagation();
        if (event.key === 'Escape') {
          stopKeyCapture();
          if (keyFeedback) keyFeedback.textContent = 'Key capture cancelled.';
          return;
        }
        const code = event.code && event.code !== 'Unidentified'
          ? event.code
          : (event.keyCode ? String(event.keyCode) : event.key);
        if (!code || code === 'Unidentified') return;
        const label = event.key && event.key.length === 1 && code === event.code
          ? `${code} (${event.key})`
          : code;
        savePttSettings({ hardwareKey: code });
        if (keyLabel) keyLabel.textContent = label;
        if (keyFeedback) keyFeedback.textContent = `Saved ${label} as the hardware PTT key. It now keys the radio in addition to the on-screen control.`;
        stopKeyCapture();
        toast('Hardware PTT key saved', `${label} will now key up the radio.`, 'success', 3200);
      };
      window.addEventListener('keydown', keyCaptureHandler, true);
    });

    el.querySelector('#pttKeyClearBtn')?.addEventListener('click', () => {
      stopKeyCapture();
      savePttSettings({ hardwareKey: '' });
      if (keyLabel) keyLabel.textContent = hardwareKeyLabel();
      if (keyFeedback) keyFeedback.textContent = 'Hardware key cleared. Use the on-screen PTT control, Space bar or a default PoC key.';
    });

    el.querySelector('#pttSpaceToggle')?.addEventListener('change', (event) => {
      savePttSettings({ spaceKey: event.target.checked });
    });
    el.querySelector('#pttEchoToggle')?.addEventListener('change', (event) => {
      savePttSettings({ echoCancellation: event.target.checked });
    });
    el.querySelector('#pttNoiseToggle')?.addEventListener('change', (event) => {
      savePttSettings({ noiseSuppression: event.target.checked });
    });

    el.querySelector('#pttResetBtn')?.addEventListener('click', () => {
      stopMicTest();
      stopKeyCapture();
      savePttSettings({ ...DEFAULT_PTT_SETTINGS });
      dialog.close();
      openPttSettings();
      toast('PTT settings reset', 'Microphone, transmission mode and hardware key restored to defaults.', 'success', 3200);
    });

    syncModeUi();
    syncMicNote();
  }

  // -------------------------------------------------------------------------
  // Command Centre Linking Protocol Modal
  // -------------------------------------------------------------------------
  async function openCommandCentreProtocol() {
    const unit = currentUnit();
    const account = state.account;
    const kind = S.responderKinds[unit?.responderKind] || S.responderKinds.other;
    const isLinked = !!unit && !!state.unitKey;
    const pos = state.gps || (unit ? { lat: unit.lat, lng: unit.lng } : null);
    const backendHost = window.location.origin;
    const socketState = (typeof socket !== 'undefined' && socket.connected) ? 'Online (Real-time Socket)' : 'Polling (REST fallback)';

    const bodyHtml = `
      <div class="space-y-4">
        <!-- Live Connection & Link Status Banner -->
        <div class="rounded-xl border ${isLinked ? 'border-ok/30 bg-ok/[0.06]' : 'border-road/30 bg-road/[0.06]'} p-3.5">
          <div class="flex items-start justify-between gap-3">
            <div class="flex items-start gap-3">
              <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border ${isLinked ? 'border-ok/40 bg-ok/15 text-ok' : 'border-road/40 bg-road/15 text-[#f4c430]'}">
                <span class="material-symbols-outlined text-[22px]">${isLinked ? 'hub' : 'link_off'}</span>
              </span>
              <div>
                <div class="flex items-center gap-2">
                  <h3 class="text-[13px] font-bold text-text">${isLinked ? 'Terminal Clipped & Linked to Backend' : 'Awaiting Unit Assignment'}</h3>
                  <span class="badge ${isLinked ? 'badge-ok' : 'badge-warn'} !text-[8px] uppercase tracking-wider">${isLinked ? 'Active Handshake' : 'Unlinked'}</span>
                </div>
                <p class="mt-1 text-[10px] text-muted leading-relaxed">
                  ${isLinked
                    ? `Hardware radio terminal is clipped to <strong>${esc(unit.callSign)}</strong> (${esc(unit.vehicleType || 'Emergency Vehicle')}) and registered in the NEMA Central Database.`
                    : 'This field device is running in unassigned mode. Connect to a registered vehicle unit to receive dispatches.'}
                </p>
              </div>
            </div>
          </div>

          <!-- Unit Clip Attributes -->
          ${isLinked ? `
          <div class="mt-3 grid grid-cols-2 sm:grid-cols-4 gap-2 pt-2.5 border-t border-line-soft/80 text-[9.5px]">
            <div>
              <span class="font-mono text-[7.5px] uppercase tracking-wider text-dim block">Call Sign</span>
              <span class="font-bold text-text">${esc(unit.callSign)}</span>
            </div>
            <div>
              <span class="font-mono text-[7.5px] uppercase tracking-wider text-dim block">Vehicle Plate</span>
              <span class="font-mono text-text">${esc(unit.plateNumber || 'MNC360-FLEET')}</span>
            </div>
            <div>
              <span class="font-mono text-[7.5px] uppercase tracking-wider text-dim block">PTT Hardware</span>
              <span class="text-text">Hytera MNC360</span>
            </div>
            <div>
              <span class="font-mono text-[7.5px] uppercase tracking-wider text-dim block">GPS AVL Lock</span>
              <span class="text-ok font-mono">${pos ? S.formatCoord(pos.lat, pos.lng) : 'Standby'}</span>
            </div>
          </div>
          <div class="mt-2.5 rounded-lg border border-ok/20 bg-ok/10 px-2.5 py-1.5 flex items-center gap-2 text-[10px] text-ok">
            <span class="live-dot" style="background:#10b981"></span>
            <span><strong>Live Real-Time Sync Active:</strong> Command Center Admin is receiving this vehicle's live GPS coordinates.</span>
          </div>
          ` : ''}
        </div>

        <!-- Link Terminal via Admin Key Credentials (marked A) -->
        <div class="rounded-xl border border-nema/40 bg-panel-2 p-3.5">
          <div class="flex items-center justify-between mb-1.5">
            <span class="font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-nema-soft flex items-center gap-1.5">
              <span class="material-symbols-outlined text-[14px]">vpn_key</span>
              Link Terminal via Admin Key Credentials
            </span>
            <span class="badge badge-muted !text-[8px] font-mono">STEP 02 HANDSHAKE</span>
          </div>
          <p class="text-[10px] text-muted leading-relaxed mb-2.5">
            Enter the Key Credentials generated by the Admin on the Command Center registry (marked <strong>A</strong> in the backend, e.g. <code>police.04:RESP-XXXXXX</code>) to link this vehicle/PTT terminal to the central database.
          </p>
          <div class="flex flex-col sm:flex-row gap-2">
            <input type="text" id="protocolKeyInput" class="input input-sm flex-1 font-mono text-[11px]" placeholder="Paste Admin Key Credentials (e.g. police.04:RESP-XXXXXX)" />
            <button type="button" class="btn btn-nema btn-sm shrink-0" id="btnConnectToAdmin">
              <span class="material-symbols-outlined text-[15px]">link</span>Connect to Admin
            </button>
          </div>
          <div id="protocolKeyFeedback" class="mt-2 text-[10px] hidden"></div>
        </div>

        <!-- The 3-Step Handshake Protocol -->
        <div>
          <p class="font-mono text-[8px] font-bold uppercase tracking-[0.16em] text-dim mb-2 flex items-center gap-1.5">
            <span class="material-symbols-outlined text-[14px] text-nema">security</span>
            Backend-to-Responder Linking Protocol
          </p>

          <div class="space-y-2">
            <!-- Step 1 -->
            <div class="rounded-xl border border-line-soft bg-panel-2 p-3 flex items-start gap-3">
              <span class="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-white/5 font-mono text-[9px] font-bold text-nema-soft border border-nema/30">01</span>
              <div class="min-w-0 flex-1">
                <p class="text-[11px] font-bold text-text">Command Center Database Asset Registry</p>
                <p class="mt-0.5 text-[9.5px] leading-relaxed text-muted">
                  Super Admins and State EOC desks register the emergency asset on the Command Center portal (<code>/admin</code>), entering the vehicle call sign, response sector, and binding the physical Hytera MNC360 hardware radio / IMEI.
                </p>
              </div>
            </div>

            <!-- Step 2 -->
            <div class="rounded-xl border border-line-soft bg-panel-2 p-3 flex items-start gap-3">
              <span class="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-white/5 font-mono text-[9px] font-bold text-nema-soft border border-nema/30">02</span>
              <div class="min-w-0 flex-1">
                <p class="text-[11px] font-bold text-text">In-Vehicle Terminal Handshake &amp; Channel Clip</p>
                <p class="mt-0.5 text-[9.5px] leading-relaxed text-muted">
                  The in-vehicle terminal connects over 4G/LTE/APN to the backend. It authenticates with the assigned unit credentials and subscribes to the dedicated socket channel (<code>unit:subscribe</code>), clipping the tablet display directly to this vehicle.
                </p>
              </div>
            </div>

            <!-- Step 3 -->
            <div class="rounded-xl border border-line-soft bg-panel-2 p-3 flex items-start gap-3">
              <span class="flex h-6 w-6 shrink-0 items-center justify-center rounded-lg bg-white/5 font-mono text-[9px] font-bold text-nema-soft border border-nema/30">03</span>
              <div class="min-w-0 flex-1">
                <p class="text-[11px] font-bold text-text">Live PTT Telemetry Sync &amp; Dispatch Lock</p>
                <p class="mt-0.5 text-[9.5px] leading-relaxed text-muted">
                  Physical PTT (Push-to-Talk) hardware and vehicle GPS streams real-time AVL telemetry into the Command Center CAD engine every 12s. Emergency dispatches for this sector immediately lock to this unit.
                </p>
              </div>
            </div>
          </div>
        </div>

        <!-- Live Backend Diagnostics Bar -->
        <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
          <div class="flex items-center justify-between text-[9px] font-mono text-dim mb-2">
            <span>LIVE BACKEND DIAGNOSTICS</span>
            <span id="protocolPingResult" class="text-ok">Ready</span>
          </div>
          <div class="grid grid-cols-1 sm:grid-cols-3 gap-2 text-[10px]">
            <div class="rounded-lg bg-panel p-2 border border-line-soft">
              <span class="text-dim text-[8px] font-mono block">DATABASE SERVER</span>
              <span class="font-bold text-text truncate block" title="${esc(backendHost)}">${esc(backendHost)}</span>
            </div>
            <div class="rounded-lg bg-panel p-2 border border-line-soft">
              <span class="text-dim text-[8px] font-mono block">COMM CHANNEL</span>
              <span class="font-bold text-text block">${socketState}</span>
            </div>
            <div class="rounded-lg bg-panel p-2 border border-line-soft">
              <span class="text-dim text-[8px] font-mono block">ASSIGNED UNIT ID</span>
              <span class="font-mono font-bold text-text truncate block">${esc(state.unitKey || 'none')}</span>
            </div>
          </div>
        </div>
      </div>
    `;

    const dialog = S.modal({
      title: 'Command Centre Linking Protocol',
      subtitle: 'Vehicle PTT Terminal · Database Backend Provisioning & Identity Handshake',
      wide: true,
      body: bodyHtml,
      footer: `
        <button type="button" class="btn btn-ghost" id="protocolPingBtn">
          <span class="material-symbols-outlined text-[15px]">sensors</span>Ping Backend
        </button>
        <button type="button" class="btn btn-ghost" id="protocolSwitchBtn">
          <span class="material-symbols-outlined text-[15px]">swap_horiz</span>Switch / Link Unit
        </button>
        <a href="/login" target="_blank" rel="noopener" class="btn btn-nema" id="protocolOpenPortal">
          <span class="material-symbols-outlined text-[15px]">admin_panel_settings</span>Open Command Centre Portal
        </a>
        <button type="button" class="btn btn-quiet" data-close>Close</button>
      `
    });

    // Wire up buttons in the modal
    dialog.el.querySelector('#protocolPingBtn')?.addEventListener('click', async () => {
      const pingStatus = dialog.el.querySelector('#protocolPingResult');
      if (pingStatus) {
        pingStatus.textContent = 'Pinging database...';
        pingStatus.className = 'text-[#f4c430]';
      }
      const t0 = performance.now();
      try {
        await api('/api/health');
        const ms = Math.round(performance.now() - t0);
        if (pingStatus) {
          pingStatus.textContent = `Backend Database Online (${ms} ms)`;
          pingStatus.className = 'text-ok font-bold';
        }
        toast('Database Ping Success', `Command Centre backend responded in ${ms} ms. Handshake valid.`, 'success', 3500);
      } catch {
        if (pingStatus) {
          pingStatus.textContent = 'Backend Ping Failed';
          pingStatus.className = 'text-alert font-bold';
        }
        toast('Ping Error', 'Unable to reach backend database.', 'error', 3500);
      }
    });

    dialog.el.querySelector('#protocolSwitchBtn')?.addEventListener('click', () => {
      dialog.close();
      openUnitPicker();
    });

    // Handle Connect to Admin via Key Credentials
    const keyInput = dialog.el.querySelector('#protocolKeyInput');
    const connectBtn = dialog.el.querySelector('#btnConnectToAdmin');
    const feedback = dialog.el.querySelector('#protocolKeyFeedback');

    const handleConnectAdmin = async () => {
      const activeInput = dialog.el.querySelector('#protocolKeyInput') || document.getElementById('protocolKeyInput');
      const val = activeInput ? activeInput.value.trim() : (keyInput ? keyInput.value.trim() : '');
      console.log('handleConnectAdmin called with key val:', val);
      if (!val) {
        if (feedback) {
          feedback.textContent = 'Please enter or paste the Key Credentials generated by Admin.';
          feedback.className = 'mt-2 text-[10px] text-alert font-bold';
          feedback.classList.remove('hidden');
        }
        return;
      }
      if (feedback) {
        feedback.textContent = 'Authenticating Key Credentials with Command Centre...';
        feedback.className = 'mt-2 text-[10px] text-[#f4c430] font-bold';
        feedback.classList.remove('hidden');
      }
      if (connectBtn) connectBtn.disabled = true;

      try {
        const res = await api('/api/responders/link-key', {
          method: 'POST',
          body: { keyCredential: val }
        });
        if (res.ok && res.account) {
          S.saveSession({ token: res.token, account: res.account });
          state.account = res.account;
          const targetPublicId = res.unit?.publicId || res.account.responder?.publicId;
          if (targetPublicId) {
            await signOn(targetPublicId, { reason: 'key-credential-handshake' });
          }
          if (feedback) {
            feedback.innerHTML = `<span class="material-symbols-outlined text-[14px] text-ok align-middle mr-1">check_circle</span><strong>Terminal Linked!</strong> Assigned to <strong>${esc(res.unit?.callSign || res.account.displayName)}</strong> (${esc(res.unit?.vehicleType || 'Unit')}). Admin can now see this vehicle real-time.`;
            feedback.className = 'mt-2 text-[10px] text-ok font-bold';
          }
          toast('Linked to Admin', `${res.unit?.callSign || 'Unit'} successfully linked to Command Centre backend. Admin sees vehicle real-time.`, 'success', 6000);
          renderHeader();
          renderAll();
          setTimeout(() => {
            dialog.close();
            openCommandCentreProtocol();
          }, 1400);
        }
      } catch (err) {
        if (feedback) {
          feedback.textContent = `Linking Failed: ${err.message || 'Invalid Key Credentials'}`;
          feedback.className = 'mt-2 text-[10px] text-alert font-bold';
          feedback.classList.remove('hidden');
        }
        toast('Linking Error', err.message || 'Failed to authenticate Key Credentials.', 'error');
      } finally {
        if (connectBtn) connectBtn.disabled = false;
      }
    };

    connectBtn?.addEventListener('click', handleConnectAdmin);
    keyInput?.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        e.preventDefault();
        handleConnectAdmin();
      }
    });
  }

  window.openCommandCentreProtocol = openCommandCentreProtocol;
  window.NaijaSOSResponderState = state;

  // -------------------------------------------------------------------------
  // Field identity
  // -------------------------------------------------------------------------
  async function openUnitPicker() {
    const unit = currentUnit();
    const account = state.account;
    const kind = S.responderKinds[unit?.responderKind] || S.responderKinds.other;
    const dialog = S.modal({
      title: 'Your field identity',
      subtitle: 'This tablet is bound to one verified unit · switching is a state EOC action',
      body: `<div class="space-y-3">
        <div class="rounded-xl border border-nema/25 bg-nema/[0.05] p-3">
          <div class="flex items-start gap-2.5">
            <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border" style="border-color:${kind.color}44;background:${kind.color}14;color:${kind.color}">
              <span class="material-symbols-outlined text-[20px]">${kind.icon}</span>
            </span>
            <div class="min-w-0 flex-1">
              <p class="data text-[14px] font-bold text-text">${esc(unit?.callSign || 'Unit pending')}</p>
              <p class="mt-0.5 text-[9px] text-dim">${esc(unit?.vehicleType || kind.label)} · ${esc(unit?.station || '')}</p>
              <div class="mt-1.5 flex flex-wrap gap-1">
                <span class="badge badge-muted">${esc(kind.label)}</span>
                <span class="badge badge-muted">${esc(unit?.plateNumber || 'no plate')}</span>
                <span class="badge badge-ok">${esc(account?.responder?.stateName || account?.stateName || '')}</span>
              </div>
            </div>
          </div>
        </div>
        <dl class="grid gap-2 text-[10px] sm:grid-cols-2">
          <div><dt class="text-dim">Login</dt><dd class="data mt-0.5 text-text">${esc(account?.username || '—')}</dd></div>
          <div><dt class="text-dim">Workspace</dt><dd class="mt-0.5 text-text">First responder (Hytera PoC)</dd></div>
          <div><dt class="text-dim">Unit ID</dt><dd class="data mt-0.5 text-text">${esc(unit?.publicId || '—')}</dd></div>
          <div><dt class="text-dim">Issued by</dt><dd class="mt-0.5 text-text">${esc(account?.responder?.stateName || account?.stateName || 'State EOC')} EOC</dd></div>
        </dl>
        ${state.units.length > 1 ? `
        <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
          <p class="font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-dim mb-2">Switch Active Field Unit (Terminal Mode)</p>
          <div class="grid grid-cols-2 gap-1.5 max-h-40 overflow-y-auto">
            ${state.units.map(u => `
              <button type="button" class="flex items-center gap-2 p-2 rounded-lg border ${u.publicId === state.unitKey ? 'border-ok bg-ok/10 text-ok' : 'border-line bg-panel text-text hover:bg-panel-3'} text-left text-[11px] font-bold transition" data-switch-unit="${esc(u.publicId)}">
                <span class="material-symbols-outlined text-[16px]">${S.responderKinds[u.responderKind]?.icon || 'emergency'}</span>
                <span class="truncate">${esc(u.callSign)}</span>
              </button>
            `).join('')}
          </div>
        </div>
        ` : ''}
        <p class="rounded-lg border border-line-soft bg-panel-2 p-2.5 text-[9px] leading-relaxed text-muted">You only receive dispatches for this unit. Status, GPS, accept/decline and chat are all locked to this unit. Ask your state EOC to rotate your password if this tablet changes hands.</p>
      </div>`,
      footer: `<a href="/register" target="_blank" rel="noopener" class="btn btn-ghost"><span class="material-symbols-outlined text-[16px]">person_add</span>Register another unit</a>
        <button class="btn btn-quiet" id="responderSignOut"><span class="material-symbols-outlined text-[16px]">logout</span>Sign out</button>
        <button class="btn btn-primary" data-close>Done</button>`
    });
    dialog.el.querySelectorAll('[data-switch-unit]').forEach(btn => {
      btn.addEventListener('click', () => {
        signOn(btn.dataset.switchUnit);
        dialog.close();
      });
    });
    dialog.el.querySelector('#responderSignOut')?.addEventListener('click', async () => {
      const confirmed = await S.confirmDialog({
        title: 'Sign out of this tablet?',
        body: 'The unit will stop receiving dispatches on this device until the responder logs in again.',
        confirmLabel: 'Sign out'
      });
      if (confirmed) {
        localStorage.removeItem('naijasos.remember_responder');
        S.logout({ redirect: '/login?role=responder' });
      }
    });
  }

  // -------------------------------------------------------------------------
  // Nearby incident brief
  // -------------------------------------------------------------------------
  async function openNearbyBrief(incidentId) {
    if (!incidentId) return;
    try {
      const { incident } = await api(`/api/incidents/${incidentId}`);
      const type = typeOf(incident);
      const pr = priorityOf(incident);
      const st = incidentStatus[incident.status] || incidentStatus.new;
      const activeUnits = (incident.assignments || []).filter((a) => ACTIVE_ASSIGNMENT.includes(a.status));
      const dialog = S.modal({
        title: `${type.label} · ${incident.code}`,
        subtitle: `${incident.status.replaceAll('_', ' ')} · ${S.relativeTime(incident.createdAt)}`,
        wide: true,
        body: `
          <div class="flex flex-wrap items-center gap-1.5">
            <span class="badge" style="${pillStyle(pr.color).slice(7, -1)}">${esc(pr.label)}</span>
            <span class="badge" style="${pillStyle(type.color).slice(7, -1)}">${esc(type.label)}</span>
            <span class="badge" style="${pillStyle(st.color).slice(7, -1)}">${esc(st.label)}</span>
            ${incident.liveTracking ? '<span class="badge badge-ok"><span class="live-dot"></span> Live GPS</span>' : ''}
            <span class="badge badge-muted">${esc(incident.source || 'app')}</span>
          </div>
          <div class="rounded-xl border border-line-soft bg-panel-2 p-3">
            <p class="text-[13px] font-bold text-text">${esc(incident.address)}</p>
            <p class="mt-0.5 text-[10px] text-muted">${esc(incident.landmark || 'No landmark')}</p>
            <p class="mt-2 text-[11px] leading-relaxed text-muted">${esc(incident.description || 'No description provided.')}</p>
            ${incident.hazards?.length ? `<div class="mt-2 flex flex-wrap gap-1">${incident.hazards.map((h) => `<span class="badge badge-p2">${esc(h)}</span>`).join('')}</div>` : ''}
          </div>
          <div class="grid grid-cols-2 gap-2">
            <div class="rounded-lg border border-line-soft bg-panel-2 px-3 py-2"><p class="font-mono text-[7px] uppercase tracking-wide text-dim">People affected</p><p class="data mt-0.5 text-[15px] font-bold text-text">${Number(incident.peopleAffected) || 0}</p></div>
            <div class="rounded-lg border border-line-soft bg-panel-2 px-3 py-2"><p class="font-mono text-[7px] uppercase tracking-wide text-dim">Elapsed</p><p class="data mt-0.5 text-[15px] font-bold text-text" data-live-since="${esc(incident.createdAt)}">00:00</p></div>
            <div class="rounded-lg border border-line-soft bg-panel-2 px-3 py-2"><p class="font-mono text-[7px] uppercase tracking-wide text-dim">Units attached</p><p class="data mt-0.5 text-[15px] font-bold text-text">${activeUnits.length}</p></div>
            <div class="rounded-lg border border-line-soft bg-panel-2 px-3 py-2"><p class="font-mono text-[7px] uppercase tracking-wide text-dim">Coordinates</p><p class="data mt-0.5 text-[11px] font-bold text-text">${S.formatCoord(incident.lat, incident.lng)}</p></div>
          </div>
          ${activeUnits.length ? `<div class="rounded-xl border border-line-soft bg-panel-2 p-3">
            <p class="font-mono text-[8px] font-bold uppercase tracking-[0.14em] text-dim">Committed units</p>
            <div class="mt-2 flex flex-wrap gap-1.5">${activeUnits.map((a) => `<span class="badge badge-muted">${esc(a.callSign)} · ${esc(assignmentStatus[a.status]?.label || a.status)}</span>`).join('')}</div>
          </div>` : ''}
          <p class="text-[9px] leading-relaxed text-dim">Dispatched to another crew. Do not self-dispatch — contact command if you can assist.</p>`,
        footer: `<button class="btn btn-ghost" data-close>Close</button>
                 <button class="btn btn-ghost" id="nearbyCenter"><span class="material-symbols-outlined text-[16px]">my_location</span>Centre on map</button>`
      });
      dialog.el.querySelector('#nearbyCenter').addEventListener('click', () => {
        if (state.map) state.map.setView([incident.lat, incident.lng], 15, { animate: true });
        dialog.close();
      });
      updateElapsedLabels();
    } catch (error) {
      toast('Could not load incident', error.message, 'error');
    }
  }

  // -------------------------------------------------------------------------
  // Live feed (WebRTC viewer)
  // -------------------------------------------------------------------------
  function stopFeed() {
    if (state.viewer) {
      try { state.viewer.destroy?.(); } catch { /* already stopped */ }
      state.viewer = null;
    }
  }

  function openFeedModal() {
    const incident = state.incident;
    if (!incident) {
      toast('No active incident', 'A live feed is only available while an incident is open.', 'info');
      return;
    }
    stopFeed();
    const dialog = S.modal({
      title: `Live feed · ${incident.code}`,
      subtitle: 'Peer-to-peer WebRTC · the citizen device is the camera',
      wide: true,
      body: `<div class="space-y-3">
        <div class="relative aspect-video overflow-hidden rounded-xl border border-line bg-black">
          <video id="responderFeedVideo" class="h-full w-full object-cover" autoplay playsinline muted></video>
          <div id="feedOverlay" class="absolute inset-0 flex flex-col items-center justify-center gap-2 bg-[radial-gradient(circle_at_50%_40%,#1c2828,#080a0a)] px-6 text-center">
            <span class="flex h-12 w-12 items-center justify-center rounded-full border border-line bg-panel-2 text-dim"><span id="feedOverlayIcon" class="material-symbols-outlined text-[24px]">videocam</span></span>
            <p id="feedOverlayTitle" class="text-[12px] font-bold text-text">Ready to request</p>
            <p id="feedOverlayBody" class="max-w-[320px] text-[10px] leading-relaxed text-dim">Ask the citizen to start their live feed, then request the stream. Media travels directly between devices.</p>
          </div>
          <div class="pointer-events-none absolute inset-x-0 top-0 flex items-center justify-between p-2">
            <span class="badge badge-muted bg-black/60"><span class="material-symbols-outlined !text-[12px]">lock</span> Responders only</span>
            <span id="feedLiveBadge" class="badge badge-alert hidden"><span class="live-dot live-dot--red"></span> LIVE</span>
          </div>
        </div>
        <div class="flex items-center justify-between gap-2 rounded-lg border border-line-soft bg-panel-2 px-3 py-2">
          <p id="feedStatus" class="text-[10px] text-muted">No media requested yet.</p>
          <span class="font-mono text-[8px] text-dim">WebRTC · STUN</span>
        </div>
        <p class="text-[10px] leading-relaxed text-dim">${incident.media ? 'A media session is registered for this incident. Request the stream to join.' : 'No media session is registered yet. Ask the citizen to press “Start feed” on their SOS screen.'}</p>
      </div>`,
      footer: `<button class="btn btn-ghost" data-close>Close</button>
               <button id="feedStop" class="btn btn-ghost hidden">Stop stream</button>
               <button id="feedRequest" class="btn btn-primary"><span class="material-symbols-outlined text-[17px]">play_circle</span>Request stream</button>`,
      onClose: stopFeed
    });
    state.feedDialog = dialog;

    const video = dialog.el.querySelector('#responderFeedVideo');
    const overlay = dialog.el.querySelector('#feedOverlay');
    const overlayIcon = dialog.el.querySelector('#feedOverlayIcon');
    const overlayTitle = dialog.el.querySelector('#feedOverlayTitle');
    const overlayBody = dialog.el.querySelector('#feedOverlayBody');
    const statusEl = dialog.el.querySelector('#feedStatus');
    const liveBadge = dialog.el.querySelector('#feedLiveBadge');
    const requestBtn = dialog.el.querySelector('#feedRequest');
    const stopBtn = dialog.el.querySelector('#feedStop');

    const setViewerState = (name) => {
      const copy = {
        requesting: ['Connecting…', 'Asking the citizen device for its stream.', 'wifi_tethering'],
        waiting: ['Waiting for citizen', 'The request reached the incident room, but the citizen has not started the feed yet.', 'hourglass_top'],
        connecting: ['Negotiating media', 'WebRTC is exchanging session descriptions and ICE candidates.', 'sync'],
        live: ['Live', 'Direct peer-to-peer stream from the citizen device.', 'videocam'],
        ended: ['Stream ended', 'The citizen stopped sharing. You can request again while the incident is open.', 'videocam_off'],
        failed: ['Stream failed', 'Media negotiation failed. Check camera permissions and network connectivity.', 'error'],
        'tap-to-play': ['Tap to play', 'Your browser blocked autoplay. Tap the video to start playback.', 'play_circle'],
        unsupported: ['WebRTC unavailable', 'This browser does not support WebRTC media sessions.', 'block']
      }[name] || ['Waiting', 'No stream is attached yet.', 'videocam'];
      statusEl.textContent = name === 'live' ? 'Live · peer-to-peer' : copy[0];
      overlayIcon.textContent = copy[2];
      overlayTitle.textContent = copy[0];
      overlayBody.textContent = copy[1];
      const isLive = name === 'live';
      liveBadge.classList.toggle('hidden', !isLive);
      overlay.classList.toggle('hidden', isLive);
      if (isLive) {
        video.play().catch(() => {});
        requestBtn.classList.add('hidden');
        stopBtn.classList.remove('hidden');
      } else if (name === 'ended' || name === 'failed') {
        requestBtn.classList.remove('hidden');
        stopBtn.classList.add('hidden');
      }
    };

    const request = () => {
      stopFeed();
      state.viewer = NaijaSOSWebRTC.createViewer({
        socket,
        incidentId: incident.id,
        videoEl: video,
        viewerName: currentUnit()?.callSign || 'Responder',
        onState: setViewerState
      });
      setViewerState('requesting');
      state.viewer.request();
      requestBtn.classList.add('hidden');
      stopBtn.classList.remove('hidden');
    };

    requestBtn.addEventListener('click', request);
    stopBtn.addEventListener('click', () => {
      stopFeed();
      setViewerState('ended');
    });
    video.addEventListener('click', () => video.play().catch(() => {}));
  }

  // -------------------------------------------------------------------------
  // Alarm + siren
  // -------------------------------------------------------------------------
  function maybeShowAlarm() {
    const a = state.assignment;
    if (!a || a.status !== 'alerting') return;
    if (state.alarm?.assignmentId === a.id) return;
    if (state.alarmDismissedFor === a.id) return;
    showAlarm({ preview: false });
  }

  function showTestAlarm() {
    if (state.alarm) {
      toast('Alarm already open', 'Acknowledge or dismiss the current alarm first.', 'info');
      return;
    }
    const unit = currentUnit();
    showAlarm({
      preview: true,
      incident: {
        code: 'INC-TEST-LGS',
        type: 'medical',
        priority: 1,
        address: 'Allen Avenue, Ikeja',
        landmark: 'Beside Ikeja Bus Terminal',
        description: 'TEST DISPATCH — adult male collapsed at the bus stop and is not responding. This is a UI alarm preview only.',
        hazards: ['Crowd gathering', 'Heavy traffic'],
        peopleAffected: 1,
        createdAt: new Date().toISOString()
      },
      assignment: {
        id: `preview-${Date.now()}`,
        status: 'alerting',
        distanceKm: 2.4,
        etaMinutes: 5,
        callSign: unit?.callSign || 'FIELD UNIT'
      }
    });
  }

  function showAlarm({ preview = false, incident = state.incident, assignment = state.assignment } = {}) {
    if (!incident) return;
    if (state.alarm) return;
    const type = typeOf(incident);
    const pr = priorityOf(incident);
    const unit = currentUnit();
    const km = assignment ? Number(assignment.distanceKm) * (1 - Math.min(1, Number(assignment.progress) || 0)) : 0;
    const eta = assignment?.etaMinutes ?? 0;

    const root = document.createElement('div');
    root.className = 'alarm-overlay';
    root.innerHTML = `
      <div class="alarm-card" role="alertdialog" aria-modal="true" aria-label="Incoming emergency dispatch">
        <div class="alarm-stripe"></div>
        <div class="p-5">
          <div class="flex items-center justify-between gap-2">
            <span class="badge badge-alert"><span class="live-dot live-dot--red"></span> Incoming dispatch</span>
            <span class="badge" style="${pillStyle(pr.color).slice(7, -1)}">${esc(pr.label)}</span>
          </div>

          <div class="mt-4 flex items-start gap-3">
            <span class="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border" style="border-color:${type.color}55;background:${type.color}18;color:${type.color};box-shadow:0 0 30px ${type.color}22">
              <span class="material-symbols-outlined text-[30px]" style="font-variation-settings:'FILL' 1">${type.icon}</span>
            </span>
            <div class="min-w-0">
              <p class="font-mono text-[9px] font-bold uppercase tracking-[0.18em] text-dim">${preview ? 'TEST ALARM · NO DISPATCH CREATED' : `Assigned to ${esc(assignment?.callSign || unit?.callSign || 'this unit')}`}</p>
              <h2 class="mt-1 text-[22px] font-black tracking-tight text-text">${esc(type.label)} emergency</h2>
              <p class="mt-1 text-[12px] font-semibold leading-snug text-muted">${esc(incident.address)}</p>
              <p class="mt-0.5 text-[10px] text-dim">${esc(incident.landmark || incident.code)}</p>
            </div>
          </div>

          <div class="mt-4 grid grid-cols-3 gap-2">
            <div class="rounded-xl border border-line-soft bg-panel-2 px-2.5 py-2 text-center">
              <p class="font-mono text-[7px] uppercase tracking-wide text-dim">Distance</p>
              <p class="data mt-0.5 text-[16px] font-bold text-text">${S.formatDistanceKm(km)}</p>
            </div>
            <div class="rounded-xl border border-line-soft bg-panel-2 px-2.5 py-2 text-center">
              <p class="font-mono text-[7px] uppercase tracking-wide text-dim">ETA</p>
              <p class="data mt-0.5 text-[16px] font-bold text-text">${S.formatEta(eta)}</p>
            </div>
            <div class="rounded-xl border border-line-soft bg-panel-2 px-2.5 py-2 text-center">
              <p class="font-mono text-[7px] uppercase tracking-wide text-dim">Priority</p>
              <p class="data mt-0.5 text-[16px] font-bold" style="color:${pr.color}">${esc(pr.short)}</p>
            </div>
          </div>

          <p class="mt-3 rounded-xl border border-line-soft bg-panel-2 px-3 py-2.5 text-[11px] leading-relaxed text-muted">${esc(incident.description || 'No further description provided.')}</p>

          ${incident.hazards?.length ? `<div class="mt-2 flex flex-wrap gap-1">${incident.hazards.map((h) => `<span class="badge badge-p2"><span class="material-symbols-outlined !text-[11px]">warning</span>${esc(h)}</span>`).join('')}</div>` : ''}

          <div class="mt-4 grid gap-2 ${preview ? 'grid-cols-2' : 'grid-cols-2'}">
            ${preview
              ? `<button class="btn btn-ghost" data-alarm-action="preview-close">Close preview</button>
                 <button class="btn btn-primary" data-alarm-action="siren"><span class="material-symbols-outlined text-[17px]">volume_up</span>Siren on/off</button>`
              : `<button class="btn btn-ghost !border-alert/30 !text-alert-soft" data-alarm-action="decline"><span class="material-symbols-outlined text-[17px]">close</span>Decline</button>
                 <button class="btn btn-primary" data-alarm-action="accept"><span class="material-symbols-outlined text-[17px]">check_circle</span>Accept &amp; respond</button>`}
          </div>
          <div class="mt-2 flex items-center justify-between gap-2">
            <button class="btn btn-quiet btn-sm !px-1 !text-[9px] text-dim" data-alarm-action="silence">
              <span class="material-symbols-outlined text-[14px]">volume_off</span>Silence siren
            </button>
            ${preview ? '' : '<button class="btn btn-quiet btn-sm !px-1 !text-[9px] text-dim" data-alarm-action="review">Review without accepting</button>'}
          </div>
          <p class="mt-2 text-center font-mono text-[8px] uppercase tracking-[0.1em] text-dim">Alarm remains active until acknowledged · ${esc(incident.code)}</p>
        </div>
      </div>`;

    $('alarmRoot').appendChild(root);
    state.alarm = {
      el: root,
      assignmentId: assignment?.id || null,
      assignment,
      incident,
      preview,
      silenced: false
    };
    if (state.soundOn) {
      startSiren();
      if (navigator.vibrate) {
        try { navigator.vibrate([420, 160, 420, 160, 420, 160, 420]); } catch { /* not supported */ }
      }
    }

    root.addEventListener('click', (event) => {
      const button = event.target.closest('[data-alarm-action]');
      if (!button) return;
      const action = button.dataset.alarmAction;
      if (action === 'accept') {
        stopSiren();
        acceptAssignment(button);
      } else if (action === 'decline') {
        stopSiren();
        // The full-screen alarm sits above the modal layer; close it first so
        // the decline sheet is visible. The assignment stays pending.
        closeAlarm({ dismissed: true });
        openDeclineDialog();
      } else if (action === 'review') {
        closeAlarm({ dismissed: true });
        toast('Dispatch pending', 'Silence is temporary — accept or decline from the assignment panel.', 'warning');
      } else if (action === 'silence') {
        stopSiren();
        if (state.alarm) state.alarm.silenced = true;
        button.innerHTML = '<span class="material-symbols-outlined text-[14px]">volume_off</span>Siren silenced';
        button.disabled = true;
        if (navigator.vibrate) { try { navigator.vibrate(0); } catch { /* ignore */ } }
      } else if (action === 'preview-close') {
        closeAlarm({ stopOnly: true });
      } else if (action === 'siren') {
        if (state.sirenStop) stopSiren();
        else startSiren();
        button.innerHTML = `<span class="material-symbols-outlined text-[17px]">${state.sirenStop ? 'volume_off' : 'volume_up'}</span>${state.sirenStop ? 'Stop siren' : 'Play siren'}`;
      }
    });
  }

  function closeAlarm({ stopOnly = false, dismissed = false } = {}) {
    if (state.alarm?.el) state.alarm.el.remove();
    const assignmentId = state.alarm?.assignmentId;
    const preview = state.alarm?.preview;
    state.alarm = null;
    stopSiren();
    if (navigator.vibrate) { try { navigator.vibrate(0); } catch { /* ignore */ } }
    if (dismissed && assignmentId && !preview) {
      state.alarmDismissedFor = assignmentId;
    }
    if (!stopOnly && assignmentId && !preview) {
      state.alarmDismissedFor = null;
    }
  }

  function startSiren() {
    if (state.sirenStop) return;
    state.sirenStop = S.startSiren();
  }

  function stopSiren() {
    if (state.sirenStop) {
      try { state.sirenStop(); } catch { /* already stopped */ }
      state.sirenStop = null;
    }
  }

  function updateSoundUi() {
    const icon = $('soundIcon');
    if (icon) icon.textContent = state.soundOn ? 'volume_up' : 'volume_off';
    if (icon) icon.style.color = state.soundOn ? '' : 'var(--dim)';
  }

  function toggleSound() {
    state.soundOn = !state.soundOn;
    localStorage.setItem(SOUND_STORAGE, state.soundOn ? '1' : '0');
    updateSoundUi();
    if (state.soundOn) {
      S.chime();
      if (state.alarm && !state.alarm.silenced) startSiren();
      toast('Alarm sounds on', 'Incoming dispatches will trigger the siren.', 'success');
    } else {
      stopSiren();
      toast('Alarm sounds muted', 'The visual alarm will still appear.', 'info');
    }
  }

  // -------------------------------------------------------------------------
  // Go
  // -------------------------------------------------------------------------
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
