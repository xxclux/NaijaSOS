/**
 * First-responder registration.
 * ---------------------------------------------------------------------------
 * The protocol says every first responder — including private cars, volunteer
 * ambulances and other community responders — must register to use the network.
 * A registration is reviewed by the state EOC (or the relevant agency command)
 * and, once approved, is provisioned as a dispatchable field unit.
 */
import { randomInt } from 'node:crypto';
import { all, get, run, transaction, nowIso } from '../db.js';
import { stateForCode, stateLabel } from '../states.js';
import * as rt from './realtime.js';

export const RESPONDER_KINDS = [
  { code: 'car', label: 'Car', agency: 'GENERAL', icon: 'directions_car', hint: 'Community / private vehicle' },
  { code: 'ambulance', label: 'Ambulance', agency: 'MEDICAL', icon: 'emergency', hint: 'Pre-hospital care' },
  { code: 'police', label: 'Police', agency: 'POLICE', icon: 'local_police', hint: 'Police patrol / division' },
  { code: 'fire', label: 'Fire Service', agency: 'FIRE', icon: 'local_fire_department', hint: 'Fire and rescue' },
  { code: 'hospital', label: 'Hospital', agency: 'MEDICAL', icon: 'local_hospital', hint: 'Hospital response team' },
  { code: 'road_safety', label: 'Road Safety', agency: 'ROAD_SAFETY', icon: 'traffic', hint: 'FRSC / traffic command' },
  { code: 'other', label: 'Others', agency: 'GENERAL', icon: 'volunteer_activism', hint: 'NGO, rescue, community' }
];

const KIND_BY_CODE = new Map(RESPONDER_KINDS.map((kind) => [kind.code, kind]));

const KIND_PREFIX = {
  car: 'CAR',
  ambulance: 'AMB',
  police: 'POLICE',
  fire: 'FIRE',
  hospital: 'HOSP',
  road_safety: 'FRSC',
  other: 'RESQ'
};

export class RegistrationError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function serializeRegistration(row) {
  if (!row) return null;
  return {
    id: row.id,
    publicId: row.public_id,
    fullName: row.full_name,
    phone: row.phone,
    email: row.email,
    responderKind: row.responder_kind,
    responderKindLabel: KIND_BY_CODE.get(row.responder_kind)?.label || row.responder_kind,
    agencyCode: row.agency_code,
    stateCode: row.state_code,
    stateName: stateLabel(stateForCode(row.state_code)),
    vehicleType: row.vehicle_type,
    plateNumber: row.plate_number,
    callsignRequested: row.callsign_requested,
    status: row.status,
    verifiedBy: row.verified_by,
    reviewerNote: row.reviewer_note,
    responderId: row.responder_id,
    callsign: row.call_sign || null,
    createdAt: row.created_at,
    reviewedAt: row.reviewed_at
  };
}

export function listRegistrations({ status = null, stateCode = null, limit = 100 } = {}) {
  const clauses = [];
  const params = [];
  if (status) { clauses.push('g.status = ?'); params.push(status); }
  if (stateCode) { clauses.push('g.state_code = ?'); params.push(stateCode); }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  return all(
    `SELECT g.*, r.call_sign
     FROM registrations g
     LEFT JOIN responders r ON r.id = g.responder_id
     ${where}
     ORDER BY CASE g.status WHEN 'pending' THEN 0 WHEN 'approved' THEN 1 ELSE 2 END,
              g.created_at DESC
     LIMIT ?`,
    ...params, Number(limit)
  ).map(serializeRegistration);
}

export function getRegistration(id) {
  const row = get(
    `SELECT g.*, r.call_sign FROM registrations g
     LEFT JOIN responders r ON r.id = g.responder_id
     WHERE g.id = ? OR g.public_id = ?`,
    Number(id), String(id)
  );
  return serializeRegistration(row);
}

function nextPublicId() {
  for (let i = 0; i < 20; i++) {
    const id = `REG-${randomInt(1000, 9999)}`;
    if (!get('SELECT id FROM registrations WHERE public_id = ?', id)) return id;
  }
  return `REG-${Date.now().toString().slice(-6)}`;
}

function nextCallsign(kind, stateCode) {
  const prefix = KIND_PREFIX[kind] || 'RESQ';
  const suffix = stateCode === 'FC' ? 'FCT' : stateCode;
  for (let i = 1; i < 200; i++) {
    const callsign = `${prefix}-${suffix}-${String(i).padStart(2, '0')}`;
    if (!get('SELECT id FROM responders WHERE call_sign = ?', callsign)) return callsign;
  }
  return `${prefix}-${suffix}-${Date.now().toString().slice(-4)}`;
}

function statePoint(stateCode) {
  const state = stateForCode(stateCode);
  if (!state) return { lat: 6.5244, lng: 3.3792, stateLabel: 'Lagos' };
  return {
    lat: state.lat + (Math.random() - 0.5) * 0.018,
    lng: state.lng + (Math.random() - 0.5) * 0.018,
    stateLabel: stateLabel(state)
  };
}

function provisionUnit(registration, reviewer = 'State EOC') {
  // `provisionUnit` receives a raw SQLite row (snake_case) from review, while
  // createRegistration's auto-approve path can also pass the same shape. Read
  // both shapes so approval never loses the requested kind/state.
  const kindCode = registration.responderKind || registration.responder_kind;
  const stateCode = registration.stateCode || registration.state_code;
  const vehicleType = registration.vehicleType || registration.vehicle_type || kindCode;
  const plateNumber = registration.plateNumber || registration.plate_number || null;
  const requestedCallsign = registration.callsignRequested || registration.callsign_requested || null;
  const state = stateForCode(stateCode);
  const kind = KIND_BY_CODE.get(kindCode) || KIND_BY_CODE.get('other');
  const agency = get('SELECT * FROM agencies WHERE code = ?', kind.agency) || get("SELECT * FROM agencies WHERE code = 'GENERAL'");
  if (!agency) throw new RegistrationError(500, 'Agency catalogue is not seeded');
  const callsign = requestedCallsign || nextCallsign(kindCode, stateCode);
  const point = statePoint(stateCode);
  const station = `${stateLabel(state)} · ${kind.label} network`;
  const at = nowIso();

  const insert = run(
    `INSERT INTO responders
       (public_id, agency_id, call_sign, vehicle_type, responder_kind, state_code, plate_number,
        station, status, lat, lng, heading, speed_kph, shift_code, battery_pct, is_simulated,
        is_community, registration_id, verified_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available', ?, ?, 0, 0, 'A', 100, 1, ?, ?, ?, ?)`,
    callsign, agency.id, callsign, vehicleType, kindCode,
    stateCode, plateNumber, station, point.lat, point.lng,
    kindCode === 'car' || kindCode === 'other' ? 1 : 0,
    registration.id, at, at
  );
  const responderId = Number(insert.lastInsertRowid);
  run(
    `UPDATE registrations SET status = 'approved', verified_by = ?, responder_id = ?, reviewed_at = ?
     WHERE id = ?`,
    reviewer, responderId, at, registration.id
  );
  run(
    `INSERT INTO responder_locations (responder_id, lat, lng, heading, speed_kph, recorded_at)
     VALUES (?, ?, ?, 0, 0, ?)`,
    responderId, point.lat, point.lng, at
  );
  return { responderId, callsign };
}

export function createRegistration(payload = {}, { autoApprove = true, reviewer = 'State EOC (demo)' } = {}) {
  const kind = KIND_BY_CODE.get(String(payload.responderKind || payload.kind || '').toLowerCase());
  if (!kind) throw new RegistrationError(400, 'Choose a valid first responder type');
  const stateCode = String(payload.stateCode || 'LA').toUpperCase();
  if (!stateForCode(stateCode)) throw new RegistrationError(400, 'Choose a valid Nigerian state');
  const fullName = String(payload.fullName || '').trim().slice(0, 80);
  const phone = String(payload.phone || '').trim().slice(0, 30);
  if (fullName.length < 3) throw new RegistrationError(400, 'Full name is required');
  if (phone.length < 7) throw new RegistrationError(400, 'A reachable phone number is required');
  const vehicleType = String(payload.vehicleType || kind.label).trim().slice(0, 80);
  const plate = payload.plateNumber ? String(payload.plateNumber).trim().toUpperCase().slice(0, 20) : null;
  const requested = payload.callsign ? String(payload.callsign).trim().toUpperCase().slice(0, 24) : null;
  if (requested && get('SELECT id FROM responders WHERE call_sign = ?', requested)) {
    throw new RegistrationError(409, 'That callsign is already in use');
  }
  const publicId = nextPublicId();
  const at = nowIso();
  const insert = run(
    `INSERT INTO registrations
       (public_id, full_name, phone, email, responder_kind, agency_code, state_code,
        vehicle_type, plate_number, callsign_requested, status, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?)`,
    publicId, fullName, phone, payload.email ? String(payload.email).slice(0, 120) : null,
    kind.code, kind.agency, stateCode, vehicleType, plate, requested, at
  );
  const registrationId = Number(insert.lastInsertRowid);

  if (autoApprove) {
    const registration = get('SELECT * FROM registrations WHERE id = ?', registrationId);
    provisionUnit(registration, reviewer);
  }

  const registration = getRegistration(registrationId);
  rt.emitSystem('registration:new', registration);
  if (registration.responderId) {
    const unit = get(
      `SELECT r.*, a.code AS agency_code FROM responders r JOIN agencies a ON a.id = r.agency_id WHERE r.id = ?`,
      registration.responderId
    );
    if (unit) {
      rt.emitSystem('registration:approved', registration);
      rt.emitFleetUnit({
        id: unit.id, publicId: unit.public_id, callSign: unit.call_sign,
        agencyCode: unit.agency_code, stateCode: unit.state_code,
        status: unit.status, lat: unit.lat, lng: unit.lng,
        vehicleType: unit.vehicle_type, responderKind: unit.responder_kind,
        isCommunity: !!unit.is_community
      });
    }
  }
  return registration;
}

export function reviewRegistration(id, status, { reviewer = 'State EOC', note = null } = {}) {
  const registration = get('SELECT * FROM registrations WHERE id = ?', Number(id));
  if (!registration) throw new RegistrationError(404, 'Registration not found');
  if (registration.status !== 'pending') {
    throw new RegistrationError(409, `Registration is already ${registration.status}`);
  }
  if (status === 'approved') {
    const result = provisionUnit(registration, reviewer);
    run('UPDATE registrations SET reviewer_note = ? WHERE id = ?', note, registration.id);
    const updated = getRegistration(registration.id);
    rt.emitSystem('registration:approved', updated);
    return updated;
  }
  if (status === 'rejected') {
    run(
      `UPDATE registrations SET status = 'rejected', verified_by = ?, reviewer_note = ?, reviewed_at = ? WHERE id = ?`,
      reviewer, note, nowIso(), registration.id
    );
    const updated = getRegistration(registration.id);
    rt.emitSystem('registration:rejected', updated);
    return updated;
  }
  throw new RegistrationError(400, 'Review status must be approved or rejected');
}

export function getRegistrationStats() {
  const pending = get("SELECT COUNT(*) AS c FROM registrations WHERE status = 'pending'").c;
  const approved = get("SELECT COUNT(*) AS c FROM registrations WHERE status = 'approved'").c;
  const community = get(
    "SELECT COUNT(*) AS c FROM responders WHERE is_community = 1 AND status <> 'offline'"
  ).c;
  return { pending, approved, communityOnline: community };
}

export function seedRegistration(payload, { reviewer = 'State EOC seed' } = {}) {
  return createRegistration(payload, { autoApprove: true, reviewer });
}
