/**
 * Incident + dispatch domain service.
 * ---------------------------------------------------------------------------
 * This is the heart of the prototype:
 *
 *  citizen SOS -> incident (priority + location)
 *      -> radial candidate search & ranking
 *      -> dispatcher assignment -> OSRM/synthetic route + ETA
 *      -> unit alert -> accept -> live movement -> on scene -> resolved
 *
 * Every state change writes an append-only event and is broadcast over
 * Socket.IO, so all three interfaces stay in sync without polling.
 */
import { randomInt } from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { all, get, run, transaction, parseJson, addEvent, addMessage, nowIso } from '../db.js';
import {
  haversineKm, etaMinutes, priorityForType, buildRoute, rankResponders,
  pointAlongRoute, routeLengthKm
} from '../geo.js';
import { stateForPoint, stateForCode, stateLabel, incidentPrefix, listStates, NEMA_NAME } from '../states.js';
import { getAiSession, startAiSupport, handoffOnScene, closeAiSupport, pushAiNote, normalizeIncidentType, getAiStats } from './ai.js';
import { getRegistrationStats, listRegistrations } from './registrations.js';
import { getCallDetail, startCall, handoffCallOnScene, endCall as endCallSession } from './calls.js';
import * as rt from './realtime.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', '..', 'data');
const PHOTO_DIR = path.join(DATA_DIR, 'incident-photos');
const MAX_PHOTO_BYTES = 2.5 * 1024 * 1024;

/**
 * Persist the citizen's SOS scene photo. Accepted as a base64 data URL so the
 * citizen page can send a compressed camera frame or gallery image in the same
 * POST as the alert. Returns the path relative to data/.
 */
function persistIncidentPhoto(code, photo) {
  if (typeof photo !== 'string' || !photo) return null;
  const match = /^data:image\/(jpeg|jpg|png|webp);base64,([A-Za-z0-9+/=\s]+)$/i.exec(photo.trim());
  if (!match) return null;
  const ext = match[1].toLowerCase() === 'png' ? 'png' : match[1].toLowerCase() === 'webp' ? 'webp' : 'jpg';
  const buffer = Buffer.from(match[2].replace(/\s+/g, ''), 'base64');
  if (!buffer.length || buffer.length > MAX_PHOTO_BYTES) return null;
  fs.mkdirSync(PHOTO_DIR, { recursive: true });
  const filename = `${String(code).replace(/[^A-Za-z0-9_-]/g, '')}.${ext}`;
  fs.writeFileSync(path.join(PHOTO_DIR, filename), buffer);
  return path.relative(DATA_DIR, path.join(PHOTO_DIR, filename)).split(path.sep).join('/');
}

export const ACTIVE_STATUSES = ['new', 'triage', 'dispatched', 'en_route', 'on_scene', 'transporting'];
export const ASSIGNMENT_ACTIVE = ['alerting', 'accepted', 'en_route', 'on_scene', 'transporting'];
export const INCIDENT_TYPES = ['medical', 'police', 'fire', 'road_safety', 'general'];

export class HttpError extends Error {
  constructor(status, message, details = null) {
    super(message);
    this.status = status;
    this.details = details;
  }
}

const INCIDENT_JOIN = `
  SELECT i.*, u.full_name AS reporter_full_name,
         ai.mode AS ai_mode, ai.severity AS ai_severity,
         ai.recommended_agency AS ai_agency, ai.human_agent_name AS ai_human_agent
  FROM incidents i
  LEFT JOIN users u ON u.id = i.reporter_user_id
  LEFT JOIN ai_sessions ai ON ai.incident_id = i.id
`;

const RESPONDER_JOIN = `
  SELECT r.*,
         a.code AS agency_code, a.name AS agency_name, a.short_name AS agency_short,
         a.color AS agency_color, a.icon AS agency_icon,
         (SELECT ia.id FROM incident_assignments ia
           WHERE ia.responder_id = r.id AND ia.status IN ('alerting','accepted','en_route','on_scene','transporting')
           ORDER BY ia.id DESC LIMIT 1) AS active_assignment_id,
         (SELECT ia.incident_id FROM incident_assignments ia
           WHERE ia.responder_id = r.id AND ia.status IN ('alerting','accepted','en_route','on_scene','transporting')
           ORDER BY ia.id DESC LIMIT 1) AS active_incident_id,
         (SELECT i.code FROM incident_assignments ia JOIN incidents i ON i.id = ia.incident_id
           WHERE ia.responder_id = r.id AND ia.status IN ('alerting','accepted','en_route','on_scene','transporting')
           ORDER BY ia.id DESC LIMIT 1) AS active_incident_code,
         (SELECT COUNT(*) FROM accounts WHERE responder_id = r.id) AS linked_login_count,
         (SELECT username FROM accounts WHERE responder_id = r.id ORDER BY id ASC LIMIT 1) AS linked_username,
         (SELECT last_login_at FROM accounts WHERE responder_id = r.id ORDER BY id ASC LIMIT 1) AS linked_last_login_at
  FROM responders r
  JOIN agencies a ON a.id = r.agency_id
`;

const GPS_FRESH_SECONDS = 120;

export function serializeResponder(row) {
  if (!row) return null;
  const lat = Number(row.lat);
  const lng = Number(row.lng);
  const hasLocation = Number.isFinite(lat) && Number.isFinite(lng);
  const syncedAt = row.updated_at || null;
  const syncedMs = syncedAt ? new Date(syncedAt).getTime() : NaN;
  const gpsSyncAgeSeconds = Number.isFinite(syncedMs)
    ? Math.max(0, Math.round((Date.now() - syncedMs) / 1000))
    : null;
  const isOnline = rt.isUnitConnected(row.id);
  const isGpsFresh = hasLocation && gpsSyncAgeSeconds != null && gpsSyncAgeSeconds <= GPS_FRESH_SECONDS;
  const linkedLoginCount = Number(row.linked_login_count ?? 0);
  // `isLinked` means an in-vehicle login was provisioned for this unit.
  const isLinked = linkedLoginCount > 0;
  return {
    id: row.id,
    publicId: row.public_id,
    callSign: row.call_sign,
    userId: row.user_id,
    agencyId: row.agency_id,
    agencyCode: row.agency_code,
    agencyName: row.agency_name,
    agencyShort: row.agency_short,
    agencyColor: row.agency_color,
    agencyIcon: row.agency_icon,
    vehicleType: row.vehicle_type,
    responderKind: row.responder_kind,
    stateCode: row.state_code,
    stateName: stateLabel(stateForCode(row.state_code)),
    plateNumber: row.plate_number,
    station: row.station,
    status: row.status,
    isCommunity: !!row.is_community,
    registrationId: row.registration_id,
    verifiedAt: row.verified_at,
    lat: row.lat,
    lng: row.lng,
    heading: row.heading,
    speedKph: row.speed_kph,
    shiftCode: row.shift_code,
    batteryPct: row.battery_pct,
    isSimulated: !!row.is_simulated,
    updatedAt: row.updated_at,
    activeAssignmentId: row.active_assignment_id ?? null,
    activeIncidentId: row.active_incident_id ?? null,
    activeIncidentCode: row.active_incident_code ?? null,
    // Live link / GPS-sync proof (mirrors the first-responder "linked" state).
    isLinked,
    linkedUsername: row.linked_username || null,
    linkedLastLoginAt: row.linked_last_login_at || null,
    hasLocation,
    isOnline,
    online: isOnline,
    gpsSyncedAt: syncedAt,
    gpsSyncAgeSeconds,
    isGpsFresh,
    gpsFreshThresholdSeconds: GPS_FRESH_SECONDS
  };
}

export function serializeAssignment(row) {
  if (!row) return null;
  const progress = Number(row.progress || 0);
  const remainingKm = Number(row.distance_km || 0) * (1 - Math.min(1, progress));
  const active = ['on_scene', 'transporting', 'completed'].includes(row.status);
  return {
    id: row.id,
    incidentId: row.incident_id,
    responderId: row.responder_id,
    responderPublicId: row.responder_public_id,
    callSign: row.call_sign,
    vehicleType: row.vehicle_type,
    plateNumber: row.plate_number,
    station: row.station,
    unitLat: row.unit_lat,
    unitLng: row.unit_lng,
    unitHeading: row.unit_heading,
    unitStatus: row.responder_status,
    agencyId: row.agency_id,
    agencyCode: row.agency_code,
    agencyName: row.agency_name,
    agencyColor: row.agency_color,
    agencyIcon: row.agency_icon,
    status: row.status,
    distanceKm: row.distance_km,
    etaMinutes: active ? 0 : etaMinutes(remainingKm),
    progress,
    route: parseJson(row.route_json, null),
    steps: parseJson(row.steps_json, []),
    routeSource: row.route_source,
    assignedAt: row.assigned_at,
    acceptedAt: row.accepted_at,
    arrivedAt: row.arrived_at,
    completedAt: row.completed_at,
    declineReason: row.decline_reason
  };
}

export function serializeIncident(row) {
  if (!row) return null;
  const created = new Date(row.created_at).getTime();
  return {
    id: row.id,
    code: row.code,
    reporterUserId: row.reporter_user_id,
    reporterName: row.reporter_name || row.reporter_full_name || 'Unknown caller',
    reporterPhone: row.reporter_phone,
    type: row.type,
    priority: row.priority,
    status: row.status,
    lat: row.lat,
    lng: row.lng,
    accuracyM: row.accuracy_m,
    address: row.address,
    landmark: row.landmark,
    stateCode: row.state_code || 'LA',
    stateName: row.state_name || stateLabel(stateForCode(row.state_code || 'LA')),
    humanAgentName: row.human_agent_name || row.ai_human_agent || null,
    humanTakeoverAt: row.human_takeover_at || null,
    aiMode: row.ai_mode || null,
    aiSeverity: row.ai_severity || null,
    aiAgency: row.ai_agency || null,
    aiStatus: row.ai_mode === 'closed' ? 'closed' : row.ai_mode === 'human' ? 'human' : row.ai_mode === 'ai' ? 'active' : null,
    description: row.description,
    hazards: parseJson(row.hazards_json, []),
    photoUrl: row.photo_path ? `/api/incidents/${row.id}/photo` : null,
    peopleAffected: row.people_affected,
    source: row.source,
    liveTracking: !!row.live_tracking,
    createdByRole: row.created_by_role,
    assignedDispatcherId: row.assigned_dispatcher_id,
    createdAt: row.created_at,
    acknowledgedAt: row.acknowledged_at,
    dispatchedAt: row.dispatched_at,
    arrivedAt: row.arrived_at,
    resolvedAt: row.resolved_at,
    elapsedSeconds: Math.max(0, Math.round((Date.now() - created) / 1000)),
    responseSeconds: row.acknowledged_at
      ? Math.max(0, Math.round((new Date(row.acknowledged_at).getTime() - created) / 1000))
      : null,
    isActive: ACTIVE_STATUSES.includes(row.status)
  };
}

export function getAgencies() {
  return all('SELECT * FROM agencies ORDER BY id').map((row) => ({
    id: row.id, code: row.code, name: row.name, shortName: row.short_name,
    jurisdiction: row.jurisdiction, emergencyNumber: row.emergency_number,
    color: row.color, icon: row.icon, isActive: !!row.is_active
  }));
}

export function getResponders({ agencyCode = null, status = null, stateCode = null, responderKind = null, community = null } = {}) {
  const clauses = [];
  const params = [];
  if (agencyCode) { clauses.push('a.code = ?'); params.push(agencyCode); }
  if (status) { clauses.push('r.status = ?'); params.push(status); }
  if (stateCode) { clauses.push('r.state_code = ?'); params.push(String(stateCode).toUpperCase()); }
  if (responderKind) { clauses.push('r.responder_kind = ?'); params.push(responderKind); }
  if (community != null) { clauses.push('r.is_community = ?'); params.push(community ? 1 : 0); }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  return all(`${RESPONDER_JOIN} ${where} ORDER BY a.id, r.call_sign`, ...params).map(serializeResponder);
}

export function getResponder(unitKey) {
  if (!unitKey) return null;
  const keyStr = String(unitKey).trim();
  const row = all(RESPONDER_JOIN).find(
    (candidate) => String(candidate.public_id) === keyStr
      || String(candidate.id) === keyStr
      || String(candidate.call_sign).toUpperCase() === keyStr.toUpperCase()
      || String(candidate.call_sign).toLowerCase().replace(/[^a-z0-9]/g, '.') === keyStr.toLowerCase()
  );
  return row ? serializeResponder(row) : null;
}

function getAssignmentRows(incidentId) {
  return all(
    `SELECT ia.*, r.call_sign, r.vehicle_type, r.plate_number, r.station,
            r.status AS responder_status, r.lat AS unit_lat, r.lng AS unit_lng, r.heading AS unit_heading,
            r.public_id AS responder_public_id,
            a.code AS agency_code, a.name AS agency_name, a.color AS agency_color, a.icon AS agency_icon
     FROM incident_assignments ia
     JOIN responders r ON r.id = ia.responder_id
     JOIN agencies a ON a.id = ia.agency_id
     WHERE ia.incident_id = ?
     ORDER BY ia.assigned_at ASC, ia.id ASC`,
    incidentId
  ).map((row) => {
    const serialized = serializeAssignment(row);
    const latestEvent = get(
      `SELECT payload_json FROM incident_events
       WHERE incident_id = ? AND type IN ('transporting', 'completed')
       ORDER BY id DESC LIMIT 1`,
      incidentId
    );
    if (latestEvent) {
      const p = parseJson(latestEvent.payload_json, {});
      if (p.destination) serialized.destination = p.destination;
      if (p.destinationType) serialized.destinationType = p.destinationType;
    }
    return serialized;
  });
}

export function getIncidentDetail(incidentId) {
  const row = get(`${INCIDENT_JOIN} WHERE i.id = ? OR i.code = ?`, incidentId, String(incidentId));
  if (!row) return null;
  const incident = serializeIncident(row);
  const assignments = getAssignmentRows(incident.id);
  const events = all(
    'SELECT * FROM incident_events WHERE incident_id = ? ORDER BY created_at ASC, id ASC',
    incident.id
  ).map((e) => ({
    id: e.id, type: e.type, actorType: e.actor_type, actorId: e.actor_id,
    message: e.message, payload: parseJson(e.payload_json, {}), createdAt: e.created_at
  }));
  const messages = all(
    `SELECT * FROM incident_messages WHERE incident_id = ? AND channel = 'chat'
     ORDER BY created_at ASC, id ASC`,
    incident.id
  ).map((m) => ({
    id: m.id, channel: m.channel, senderType: m.sender_type, senderId: m.sender_id,
    senderName: m.sender_name, body: m.body, createdAt: m.created_at
  }));
  const notes = all(
    'SELECT * FROM incident_notes WHERE incident_id = ? ORDER BY pinned DESC, created_at DESC',
    incident.id
  ).map((n) => ({
    id: n.id, authorId: n.author_id, authorName: n.author_name, body: n.body,
    pinned: !!n.pinned, createdAt: n.created_at
  }));
  const media = get(
    'SELECT * FROM media_sessions WHERE incident_id = ? ORDER BY id DESC LIMIT 1',
    incident.id
  );
  let nominatedCandidate = null;
  if (!assignments.some((a) => ASSIGNMENT_ACTIVE.includes(a.status))) {
    try {
      const candidateResult = getCandidates(incident.id, { radiusKm: 400, limit: 1 });
      nominatedCandidate = candidateResult.candidates?.[0] || null;
    } catch { /* candidates calculation optional */ }
  }
  return {
    ...incident,
    nominatedCandidate,
    ai: getAiSession(incident.id),
    call: getCallDetail(incident.id),
    assignments,
    activeAssignments: assignments.filter((a) => ASSIGNMENT_ACTIVE.includes(a.status)),
    events,
    messages,
    notes,
    media: media ? {
      id: media.id, kind: media.kind, producerType: media.producer_type,
      producerId: media.producer_id, status: media.status,
      startedAt: media.started_at, endedAt: media.ended_at
    } : null
  };
}

export function listIncidents({ scope = 'active', limit = 50, stateCode = null, aiMode = null } = {}) {
  const params = [];
  const clauses = [];
  if (scope === 'active') {
    clauses.push(`i.status IN (${ACTIVE_STATUSES.map(() => '?').join(',')})`);
    params.push(...ACTIVE_STATUSES);
  } else if (scope === 'resolved') {
    clauses.push("i.status IN ('resolved','cancelled')");
  }
  if (stateCode) {
    clauses.push('i.state_code = ?');
    params.push(String(stateCode).toUpperCase());
  }
  if (aiMode) {
    clauses.push('ai.mode = ?');
    params.push(aiMode);
  }
  const where = clauses.length ? `WHERE ${clauses.join(' AND ')}` : '';
  const rows = all(
    `${INCIDENT_JOIN} ${where} ORDER BY i.priority ASC, i.created_at DESC LIMIT ?`,
    ...params, Number(limit)
  );
  const summaries = new Map();
  for (const a of all(
    `SELECT ia.incident_id, COUNT(*) AS unit_count,
            GROUP_CONCAT(r.call_sign, ', ') AS units,
            GROUP_CONCAT(DISTINCT a.code) AS agency_codes
     FROM incident_assignments ia
     JOIN responders r ON r.id = ia.responder_id
     JOIN agencies a ON a.id = ia.agency_id
     WHERE ia.status IN ('alerting','accepted','en_route','on_scene','transporting')
     GROUP BY ia.incident_id`
  )) {
    summaries.set(a.incident_id, a);
  }
  return rows.map((row) => {
    const summary = summaries.get(row.id);
    return {
      ...serializeIncident(row),
      unitCount: summary?.unit_count || 0,
      units: summary?.units ? summary.units.split(', ') : [],
      agencyCodes: summary?.agency_codes ? summary.agency_codes.split(',') : []
    };
  });
}

export function getStats() {
  const activeCount = get(
    `SELECT COUNT(*) AS c FROM incidents WHERE status IN (${ACTIVE_STATUSES.map(() => '?').join(',')})`,
    ...ACTIVE_STATUSES
  ).c;
  const critical = get(
    `SELECT COUNT(*) AS c FROM incidents WHERE priority = 1 AND status IN (${ACTIVE_STATUSES.map(() => '?').join(',')})`,
    ...ACTIVE_STATUSES
  ).c;
  const unacknowledged = get(`SELECT COUNT(*) AS c FROM incidents WHERE status = 'new'`).c;
  const units = all('SELECT status, agency_id FROM responders');
  const available = units.filter((u) => u.status === 'available').length;
  const onScene = units.filter((u) => u.status === 'on_scene').length;
  const agenciesOnline = new Set(units.filter((u) => u.status !== 'offline').map((u) => u.agency_id)).size;
  const avgResponse = get(
    `SELECT AVG((julianday(acknowledged_at) - julianday(created_at)) * 86400) AS avg
     FROM incidents WHERE acknowledged_at IS NOT NULL
       AND created_at >= datetime('now', '-24 hours')`
  ).avg;
  const resolvedToday = get(
    `SELECT COUNT(*) AS c FROM incidents
     WHERE status = 'resolved' AND resolved_at IS NOT NULL AND resolved_at >= datetime('now', 'start of day')`
  ).c;
  const aiStats = getAiStats();
  const regStats = getRegistrationStats();
  const statesCovered = get(
    `SELECT COUNT(DISTINCT state_code) AS c FROM incidents
     WHERE status IN (${ACTIVE_STATUSES.map(() => '?').join(',')})`,
    ...ACTIVE_STATUSES
  ).c;
  return {
    activeIncidents: activeCount,
    criticalIncidents: critical,
    unacknowledged,
    availableUnits: available,
    totalUnits: units.length,
    unitsOnScene: onScene,
    agenciesOnline,
    avgResponseSeconds: avgResponse ? Math.max(1, Math.round(avgResponse)) : 0,
    resolvedToday,
    openAssignments: get(
      `SELECT COUNT(*) AS c FROM incident_assignments WHERE status IN ('alerting','accepted','en_route','on_scene','transporting')`
    ).c,
    aiActiveSessions: aiStats.activeSessions,
    aiHumanTakeovers: aiStats.humanTakeovers,
    aiRoutedToday: aiStats.routedToday,
    pendingRegistrations: regStats.pending,
    communityResponders: regStats.communityOnline,
    statesCovered,
    serverTime: nowIso()
  };
}

/** State-level rollup used by the dispatch state selector and protocol page. */
export function getCoverage() {
  const states = listStates();
  const active = all(
    `SELECT state_code, COUNT(*) AS c,
            SUM(CASE WHEN priority = 1 THEN 1 ELSE 0 END) AS critical
     FROM incidents WHERE status IN (${ACTIVE_STATUSES.map(() => '?').join(',')})
     GROUP BY state_code`,
    ...ACTIVE_STATUSES
  );
  const units = all('SELECT state_code, status, is_community FROM responders');
  const ai = all(
    `SELECT state_code, mode, COUNT(*) AS c FROM ai_sessions
     WHERE mode IN ('ai','human') GROUP BY state_code, mode`
  );
  const byState = new Map(active.map((row) => [row.state_code, row]));
  const unitByState = new Map();
  for (const unit of units) {
    const entry = unitByState.get(unit.state_code) || { total: 0, available: 0, community: 0 };
    entry.total += 1;
    if (unit.status === 'available') entry.available += 1;
    if (unit.is_community) entry.community += 1;
    unitByState.set(unit.state_code, entry);
  }
  const aiByState = new Map();
  for (const row of ai) {
    const entry = aiByState.get(row.state_code) || { ai: 0, human: 0 };
    entry[row.mode] = row.c;
    aiByState.set(row.state_code, entry);
  }
  return {
    national: {
      activeIncidents: active.reduce((sum, row) => sum + row.c, 0),
      criticalIncidents: active.reduce((sum, row) => sum + (row.critical || 0), 0),
      statesWithActivity: active.length,
      totalUnits: units.length,
      availableUnits: units.filter((u) => u.status === 'available').length,
      aiSessions: [...aiByState.values()].reduce((sum, e) => sum + e.ai + e.human, 0)
    },
    states: states.map((state) => {
      const inc = byState.get(state.code);
      const un = unitByState.get(state.code) || { total: 0, available: 0, community: 0 };
      const aiState = aiByState.get(state.code) || { ai: 0, human: 0 };
      return {
        code: state.code,
        name: state.name,
        label: stateLabel(state),
        zone: state.zone,
        activeIncidents: inc?.c || 0,
        criticalIncidents: inc?.critical || 0,
        totalUnits: un.total,
        availableUnits: un.available,
        communityUnits: un.community,
        aiSessions: aiState.ai + aiState.human,
        humanTakeovers: aiState.human,
        nema: NEMA_NAME
      };
    })
  };
}

export function getFleet() {
  const assignments = all(
    `SELECT ia.responder_id, ia.id AS assignment_id, ia.status AS assignment_status,
            ia.incident_id, ia.eta_minutes, ia.progress, ia.route_json, ia.distance_km,
            i.code AS incident_code
     FROM incident_assignments ia
     JOIN incidents i ON i.id = ia.incident_id
     WHERE ia.status IN ('alerting','accepted','en_route','on_scene','transporting')`
  );
  const byUnit = new Map(assignments.map((a) => [a.responder_id, a]));
  return getResponders().map((unit) => {
    const assignment = byUnit.get(unit.id);
    return {
      ...unit,
      activeAssignmentId: assignment?.assignment_id ?? unit.activeAssignmentId,
      activeAssignmentStatus: assignment?.assignment_status ?? null,
      activeIncidentId: assignment?.incident_id ?? unit.activeIncidentId,
      activeIncidentCode: assignment?.incident_code ?? unit.activeIncidentCode,
      etaMinutes: assignment?.eta_minutes ?? null,
      progress: assignment?.progress ?? null,
      route: parseJson(assignment?.route_json, null)
    };
  });
}

function generateIncidentCode(state) {
  const prefix = incidentPrefix(state);
  for (let i = 0; i < 8; i++) {
    const code = `INC-${randomInt(1000, 9999)}-${prefix}`;
    if (!get('SELECT id FROM incidents WHERE code = ?', code)) return code;
  }
  return `INC-${Date.now().toString().slice(-6)}-${prefix}`;
}

export function createIncident(payload = {}) {
  const type = normalizeIncidentType(payload.type);
  const lat = Number(payload.lat);
  const lng = Number(payload.lng);
  if (!Number.isFinite(lat) || !Number.isFinite(lng)) {
    throw new HttpError(400, 'A valid latitude and longitude are required');
  }
  if (lat < -90 || lat > 90 || lng < -180 || lng > 180) {
    throw new HttpError(400, 'Coordinates are outside the valid WGS84 range');
  }
  const description = String(payload.description || '').trim().slice(0, 1000);
  const hazards = Array.isArray(payload.hazards)
    ? payload.hazards.map((h) => String(h).slice(0, 80)).slice(0, 8)
    : [];
  const priority = Number(payload.priority) >= 1 && Number(payload.priority) <= 4
    ? Number(payload.priority)
    : priorityForType(type, description);
  // Protocol step 1: the AI/routing layer resolves the GPS fix to a state
  // before any agency is alerted. An explicit state is only used for manual
  // phone intake where the caller cannot share a GPS fix.
  const routedState = stateForPoint(lat, lng) || stateForCode(payload.stateCode) || stateForCode('FC');
  const explicitState = payload.stateCode ? stateForCode(payload.stateCode) : null;
  const state = explicitState && !payload.lat ? explicitState : routedState;
  const code = generateIncidentCode(state);
  const created = nowIso();
  const result = run(
    `INSERT INTO incidents
      (code, reporter_user_id, reporter_name, reporter_phone, type, priority, status, lat, lng, accuracy_m,
       address, landmark, state_code, state_name, description, hazards_json, people_affected, source, live_tracking, created_by_role,
       assigned_dispatcher_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 'new', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL, ?)`,
    code,
    payload.reporterUserId ?? null,
    String(payload.reporterName || 'Anonymous citizen').slice(0, 80),
    payload.reporterPhone ? String(payload.reporterPhone).slice(0, 30) : null,
    type, priority, lat, lng,
    Number.isFinite(Number(payload.accuracy)) ? Number(payload.accuracy) : null,
    String(payload.address || `${lat.toFixed(5)}, ${lng.toFixed(5)}`).slice(0, 180),
    payload.landmark ? String(payload.landmark).slice(0, 160) : null,
    state.code,
    stateLabel(state),
    description,
    JSON.stringify(hazards),
    Math.max(1, Math.min(999, Number(payload.peopleAffected) || 1)),
    ['app', 'phone', 'partner', 'iot', 'sms'].includes(payload.source) ? payload.source : 'app',
    payload.liveTracking === false ? 0 : 1,
    payload.createdByRole || 'citizen',
    created
  );
  const id = Number(result.lastInsertRowid);
  const photoPath = persistIncidentPhoto(code, payload.photo);
  if (photoPath) {
    run('UPDATE incidents SET photo_path = ? WHERE id = ?', photoPath, id);
    addEvent(id, {
      type: 'photo_attached', actorType: payload.createdByRole || 'citizen', actorId: payload.reporterName || null,
      message: 'Citizen attached a scene photo with the SOS; visible on the State EOC dashboard',
      payload: {}
    }, created);
  }
  addEvent(id, {
    type: 'created', actorType: payload.createdByRole || 'citizen', actorId: payload.reporterName || null,
    message: `SOS received; AI agent activated and routed to ${stateLabel(state)}`,
    payload: { source: payload.source || 'app', type, priority, stateCode: state.code }
  }, created);
  // Opening the AI session also writes the routing reason and first support
  // messages, so the caller is never left waiting without guidance.
  startAiSupport(id, { createdAt: created });
  // Every SOS also opens an emergency call session. The responsible State EOC
  // claims it and stays on the line until the first responder is on scene.
  try {
    startCall(id, { reporterName: payload.reporterName || 'Citizen' });
  } catch (error) {
    console.warn('[call] could not open call session:', error.message);
  }
  const detail = getIncidentDetail(id);
  rt.emitIncidentNew(detail);
  rt.emitStats(getStats());

  // Proximity Alert to First Responders in close proximity:
  try {
    const fleet = getResponders({ stateCode: state.code });
    for (const unit of fleet) {
      if (unit.lat && unit.lng) {
        const dist = haversineKm({ lat, lng }, { lat: unit.lat, lng: unit.lng });
        if (dist <= 35) {
          const eta = etaMinutes(dist);
          rt.emitToUnit(unit.id, 'proximity:sos', {
            incident: detail,
            distanceKm: Number(dist.toFixed(2)),
            etaMinutes: eta
          });
        }
      }
    }
  } catch (err) {
    console.warn('[proximity:sos] dispatch check error:', err.message);
  }

  // NEMA CAD Proximity Nomination: automatically looks for the nearest
  // proximity first responder to assign to. The responsible State EOC
  // reviews this nomination tab on their dashboard and clicks Dispatch,
  // which then alerts the real first responder in-vehicle terminal.
  let topCandidate = null;
  try {
    const candidateResult = getCandidates(id, { radiusKm: 400, limit: 1 });
    topCandidate = candidateResult.candidates?.[0] || null;
    if (topCandidate) {
      addEvent(id, {
        type: 'nema_nomination',
        actorType: 'system',
        actorId: 'NEMA CAD Auto-Triage',
        message: `NEMA CAD identified nearest proximity responder: ${topCandidate.callSign} (${topCandidate.distanceKm} km away, ETA ${topCandidate.etaMinutes} min) — awaiting State EOC dispatch confirmation.`,
        payload: {
          responderId: topCandidate.id,
          callSign: topCandidate.callSign,
          distanceKm: topCandidate.distanceKm,
          etaMinutes: topCandidate.etaMinutes,
          agencyCode: topCandidate.agencyCode
        }
      });
    }
  } catch (err) {
    console.warn('[nema:nomination] error looking up nearest candidate:', err.message);
  }

  // Only auto-dispatch immediately if explicitly forced via env (default is 0 for State EOC authorization pipeline)
  if (process.env.AI_AUTO_DISPATCH === '1') {
    setTimeout(() => {
      aiAutoDispatch(id).catch((err) => {
        console.warn(`[ai:auto-dispatch] incident ${id} skipped:`, err.message);
      });
    }, 800).unref?.();
  }

  return detail;
}

/**
 * AI automatic dispatch of the nearest available unit.
 * ---------------------------------------------------------------------------
 * Called automatically on every new SOS (unless AI_AUTO_DISPATCH=0) and
 * manually via POST /api/incidents/:id/ai/dispatch when a dispatcher asks
 * the AI to cover for an empty seat.
 *
 * Order of preference:
 *   1. AI-recommended agency for the incident type (MEDICAL for medical…).
 *   2. If that agency has nothing available, try the other agencies nearest-
 *      first so *some* help is always sent (mutual aid included).
 *   3. If the fleet is empty, log an event and tell the caller the dispatcher
 *      has been alerted — never fabricate a unit.
 * Idempotent-ish: if a unit is already assigned, it adds nothing.
 */
export async function aiAutoDispatch(incidentId, { dispatcher = 'ResQLink AI on behalf of State EOC' } = {}) {
  const incident = get('SELECT * FROM incidents WHERE id = ?', Number(incidentId));
  if (!incident) return null;
  if (['resolved', 'cancelled'].includes(incident.status)) return null;

  const existing = get(
    `SELECT id FROM incident_assignments
     WHERE incident_id = ? AND status IN ('alerting','accepted','en_route','on_scene','transporting')
       LIMIT 1`,
    incident.id
  );
  if (existing) return { skipped: true, reason: 'already_assigned' };

  const ai = getAiSession(incident.id);
  const type = normalizeIncidentType(incident.type);
  const primaryAgency = ai?.recommendedAgency || { medical: 'MEDICAL', police: 'POLICE', fire: 'FIRE', road_safety: 'ROAD_SAFETY', general: 'GENERAL' }[type] || 'MEDICAL';

  // Try primary agency first, then fall back to any agency nearest-first.
  const agenciesToTry = [primaryAgency, 'MEDICAL', 'POLICE', 'FIRE', 'ROAD_SAFETY', 'GENERAL'].filter(
    (code, index, list) => list.indexOf(code) === index
  );
  let candidate = null;
  let usedAgency = null;
  for (const agencyCode of agenciesToTry) {
    const result = getCandidates(incident.id, { agencyCode, radiusKm: 400, limit: 1 });
    if (result.candidates?.length) {
      candidate = result.candidates[0];
      usedAgency = agencyCode;
      break;
    }
  }
  // Last resort: any agency, pure distance (already covered above because
  // GENERAL is in the list, but keep this branch for clarity).
  if (!candidate) {
    const result = getCandidates(incident.id, { agencyCode: null, radiusKm: 400, limit: 1 });
    candidate = result.candidates?.[0] || null;
    usedAgency = candidate?.agencyCode || null;
  }

  const at = nowIso();
  if (!candidate) {
    addEvent(incident.id, {
      type: 'ai_dispatch_failed', actorType: 'system', actorId: 'ResQLink AI',
      message: `AI could not auto-dispatch: no available first-responder unit in the national fleet. Awaiting a human dispatcher.`,
      payload: { primaryAgency }
    }, at);
    return { dispatched: false, reason: 'no_available_unit' };
  }

  // assignUnit re-validates availability in a transaction, builds the route,
  // emits assignment:new / incident:updated, and alerts the unit tablet.
  const result = await assignUnit(incident.id, {
    agencyCode: usedAgency || candidate.agencyCode,
    responderId: candidate.id,
    dispatcher
  });

  addEvent(incident.id, {
    type: 'ai_dispatch', actorType: 'system', actorId: 'ResQLink AI',
    message: `AI automatically assigned nearest unit ${candidate.callSign} (${candidate.agencyCode}, ${candidate.distanceKm} km, ETA ${candidate.etaMinutes} min) — no operator at the seat.`,
    payload: { unit: candidate.callSign, agencyCode: candidate.agencyCode, distanceKm: candidate.distanceKm, etaMinutes: candidate.etaMinutes }
  }, at);
  // Tell the citizen the AI sent help, so they don't wait in silence.
  pushAiNote(
    incident.id,
    `I have automatically dispatched ${candidate.callSign} to you — ${candidate.distanceKm} km away, ETA about ${candidate.etaMinutes} minutes. Stay on this line and keep your location open.`,
    ['Where is my help?', 'I am safe']
  );
  return { dispatched: true, incident: result.incident, assignment: result.assignment, candidate };
}

function assertActiveIncident(incidentId) {
  const incident = get('SELECT * FROM incidents WHERE id = ?', Number(incidentId));
  if (!incident) throw new HttpError(404, 'Incident not found');
  if (['resolved', 'cancelled'].includes(incident.status)) {
    throw new HttpError(409, 'This incident is already closed');
  }
  return incident;
}

export function acknowledgeIncident(incidentId, actor = 'Dispatcher 042') {
  const incident = assertActiveIncident(incidentId);
  if (!incident.acknowledged_at) {
    const at = nowIso();
    run(
      `UPDATE incidents SET status = CASE WHEN status = 'new' THEN 'triage' ELSE status END,
              acknowledged_at = ? WHERE id = ?`,
      at, incident.id
    );
    addEvent(incident.id, {
      type: 'acknowledged', actorType: 'dispatcher', actorId: actor,
      message: `Incident acknowledged by ${actor}`
    }, at);
  }
  const detail = getIncidentDetail(incident.id);
  rt.emitIncidentUpdated(detail);
  rt.emitStats(getStats());
  return detail;
}

export function updateIncident(incidentId, patch = {}) {
  const incident = assertActiveIncident(incidentId);
  const fields = [];
  const params = [];
  if (patch.description != null) { fields.push('description = ?'); params.push(String(patch.description).slice(0, 1000)); }
  if (patch.address != null) { fields.push('address = ?'); params.push(String(patch.address).slice(0, 180)); }
  if (patch.landmark != null) { fields.push('landmark = ?'); params.push(String(patch.landmark).slice(0, 160)); }
  if (patch.peopleAffected != null) { fields.push('people_affected = ?'); params.push(Math.max(1, Number(patch.peopleAffected) || 1)); }
  if (Array.isArray(patch.hazards)) { fields.push('hazards_json = ?'); params.push(JSON.stringify(patch.hazards.slice(0, 8))); }
  if (patch.priority != null && Number(patch.priority) >= 1 && Number(patch.priority) <= 4) {
    fields.push('priority = ?'); params.push(Number(patch.priority));
  }
  if (!fields.length) return getIncidentDetail(incident.id);
  params.push(incident.id);
  run(`UPDATE incidents SET ${fields.join(', ')} WHERE id = ?`, ...params);
  addEvent(incident.id, {
    type: 'updated', actorType: 'dispatcher', actorId: patch.actor || 'Dispatcher 042',
    message: 'Incident details updated'
  });
  const detail = getIncidentDetail(incident.id);
  rt.emitIncidentUpdated(detail);
  return detail;
}

/**
 * Live citizen GPS breadcrumb. We only persist one timeline event per minute so
 * a 1 Hz phone GPS feed does not flood the audit log.
 */
export function updateIncidentLocation(incidentId, { lat, lng, accuracy }) {
  const incident = assertActiveIncident(incidentId);
  const latitude = Number(lat);
  const longitude = Number(lng);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    throw new HttpError(400, 'Invalid location update');
  }
  const movedKm = haversineKm(incident, { lat: latitude, lng: longitude });
  const rerouted = stateForPoint(latitude, longitude);
  run(
    'UPDATE incidents SET lat = ?, lng = ?, accuracy_m = ?, live_tracking = 1 WHERE id = ?',
    latitude, longitude,
    Number.isFinite(Number(accuracy)) ? Number(accuracy) : incident.accuracy_m,
    incident.id
  );
  if (rerouted && rerouted.code !== incident.state_code) {
    run('UPDATE incidents SET state_code = ?, state_name = ? WHERE id = ?', rerouted.code, stateLabel(rerouted), incident.id);
    run(
      `UPDATE ai_sessions SET state_code = ?, routing_reason = ? WHERE incident_id = ?`,
      rerouted.code,
      `Live GPS moved across a state line. Re-routed to ${stateLabel(rerouted)} (${rerouted.distanceKm} km from the state reference point).`,
      incident.id
    );
    addEvent(incident.id, {
      type: 'state_rerouted', actorType: 'system', actorId: 'ResQLink AI',
      message: `Live location crossed into ${stateLabel(rerouted)}; incident handed to the state EOC`,
      payload: { fromState: incident.state_code, toState: rerouted.code }
    });
    rt.emitAiUpdate(incident.id, getAiSession(incident.id));
  }
  const last = get(
    `SELECT created_at FROM incident_events
     WHERE incident_id = ? AND type = 'location' ORDER BY id DESC LIMIT 1`,
    incident.id
  );
  if (!last || Date.now() - new Date(last.created_at).getTime() > 60_000 || movedKm > 0.25) {
    addEvent(incident.id, {
      type: 'location', actorType: 'citizen', actorId: incident.reporter_name,
      message: `Live location updated (±${Math.round(Number(accuracy) || 0)} m)`,
      payload: { lat: latitude, lng: longitude, accuracy }
    });
  }
  rt.emitIncidentLocation({
    id: incident.id, code: incident.code, lat: latitude, lng: longitude,
    accuracyM: Number(accuracy) || incident.accuracy_m, stateCode: rerouted?.code || incident.state_code,
    updatedAt: nowIso()
  });
  const detail = getIncidentDetail(incident.id);
  rt.emitIncidentUpdated(detail);
  return detail;
}

export function getCandidates(incidentId, { agencyCode = null, radiusKm = 30, limit = 5 } = {}) {
  const incident = get('SELECT * FROM incidents WHERE id = ?', Number(incidentId));
  if (!incident) throw new HttpError(404, 'Incident not found');
  const responders = getResponders();
  // Nearest-first across the WHOLE fleet (not state-gated): a citizen SOS in
  // one state should still see the closest police / fire / road-safety /
  // ambulance unit even if it belongs to a neighbouring state (mutual aid).
  // We rank nationally and label each candidate's scope so the dispatcher
  // can see at a glance whether it is same-state or mutual aid.
  const point = { lat: incident.lat, lng: incident.lng };
  const rankedAll = rankResponders(responders, point, agencyCode, {
    radiusKm: Number.POSITIVE_INFINITY,
    limit: 50
  }).map((unit) => ({
    ...unit,
    // distanceKm / etaMinutes / score already set by rankResponders.
    scope: unit.stateCode === incident.state_code ? 'state' : 'mutual_aid',
    isSameState: unit.stateCode === incident.state_code,
    // Keep the original radius as a soft preference, not a hard fence: if no
    // unit is inside the radius we still surface the nearest ones (flagged).
    withinRadius: Number(unit.distanceKm) <= radiusKm
  }));
  const within = rankedAll.filter((unit) => unit.withinRadius);
  const ranked = within.length ? within : rankedAll;
  // Legacy `scope`: 'state' if the top pick is same-state, else 'mutual_aid'.
  const scope = ranked[0] ? ranked[0].scope : 'state';
  const ai = getAiSession(incident.id);
  return {
    incidentId: incident.id,
    stateCode: incident.state_code,
    stateName: incident.state_name,
    sosLocation: point,
    agencyCode,
    recommendedAgency: ai?.recommendedAgency || null,
    scope,
    // Sort order is pure proximity (distance → ETA). Same-state units are
    // only preferred on an exact distance tie via the label, never by
    // hiding a nearer out-of-state unit.
    ordering: 'nearest_first_national',
    radiusKm,
    candidates: ranked.slice(0, limit),
    recommended: ranked[0] || null,
    totalAvailable: ranked.length
  };
}

/**
 * Nearest available units to an arbitrary point (used by the Admin / NEMA
 * "locate & search in real time" tools — no incident needed).
 * Returns every agency's nearest `limit` units, plus a flat `nearest` list.
 */
export function getNearestUnits({ lat, lng, agencyCode = null, radiusKm = 120, limit = 5 } = {}) {
  const point = { lat: Number(lat), lng: Number(lng) };
  if (!Number.isFinite(point.lat) || !Number.isFinite(point.lng)) {
    throw new HttpError(400, 'lat and lng are required to find nearest units');
  }
  const responders = getResponders();
  const rankedAll = rankResponders(responders, point, agencyCode, {
    radiusKm: Number.POSITIVE_INFINITY,
    limit: 100
  }).map((unit) => ({
    ...unit,
    withinRadius: Number(unit.distanceKm) <= radiusKm
  }));
  const within = rankedAll.filter((unit) => unit.withinRadius);
  const ranked = within.length ? within : rankedAll;
  const byAgency = {};
  for (const unit of ranked) {
    const list = byAgency[unit.agencyCode] || (byAgency[unit.agencyCode] = []);
    if (list.length < limit) list.push(unit);
  }
  return {
    location: point,
    agencyCode,
    radiusKm,
    ordering: 'nearest_first_national',
    nearest: ranked.slice(0, limit),
    byAgency,
    totalAvailable: ranked.length
  };
}

function addAssignmentEvent(incidentId, { type, actorType, actorId, message, payload }, at = null) {
  addEvent(incidentId, { type, actorType, actorId, message, payload }, at);
}

export async function assignUnit(incidentId, { agencyCode, responderId, dispatcher = 'Dispatcher 042' } = {}) {
  const incident = assertActiveIncident(incidentId);
  let responder;
  if (responderId) {
    responder = getResponders().find((u) => String(u.id) === String(responderId) || u.publicId === String(responderId));
    if (!responder) throw new HttpError(404, 'Responder not found');
    if (responder.status !== 'available') {
      throw new HttpError(409, `${responder.callSign} is currently ${responder.status.replaceAll('_', ' ')}`);
    }
    if (agencyCode && responder.agencyCode !== agencyCode) {
      throw new HttpError(400, 'Selected unit does not belong to the requested agency');
    }
  } else {
    const result = getCandidates(incidentId, { agencyCode, radiusKm: 400, limit: 1 });
    responder = result.recommended;
    if (!responder) {
      throw new HttpError(409, `No available ${agencyCode ? agencyCode.replaceAll('_', ' ').toLowerCase() : ''} units in the national fleet`);
    }
  }
  const existing = get(
    `SELECT * FROM incident_assignments WHERE incident_id = ? AND responder_id = ? AND status IN ('alerting','accepted','en_route','on_scene','transporting')`,
    incident.id, responder.id
  );
  if (existing) throw new HttpError(409, `${responder.callSign} is already assigned to this incident`);

  const route = await buildRoute(
    { lat: responder.lat, lng: responder.lng },
    { lat: incident.lat, lng: incident.lng, address: incident.address, landmark: incident.landmark }
  );
  const assignedAt = nowIso();
  const assignmentId = transaction(() => {
    // Re-check inside the transaction to prevent two dispatchers grabbing the
    // same unit in the same few hundred milliseconds.
    const fresh = get('SELECT status FROM responders WHERE id = ?', responder.id);
    if (fresh.status !== 'available') {
      throw new HttpError(409, `${responder.callSign} was just assigned to another incident`);
    }
    const insert = run(
      `INSERT INTO incident_assignments
        (incident_id, responder_id, agency_id, status, distance_km, eta_minutes, progress,
         route_json, steps_json, route_source, assigned_at)
       VALUES (?, ?, ?, 'alerting', ?, ?, 0, ?, ?, ?, ?)`,
      incident.id, responder.id, responder.agencyId, route.distanceKm, route.durationMin,
      JSON.stringify(route.geometry), JSON.stringify(route.steps), route.routeSource, assignedAt
    );
    const id = Number(insert.lastInsertRowid);
    run(`UPDATE responders SET status = 'dispatched', speed_kph = 0, updated_at = ? WHERE id = ?`, assignedAt, responder.id);
    run(
      `UPDATE incidents SET status = CASE WHEN status IN ('new','triage') THEN 'dispatched' ELSE status END,
              acknowledged_at = COALESCE(acknowledged_at, ?),
              dispatched_at = COALESCE(dispatched_at, ?),
              assigned_dispatcher_id = COALESCE(assigned_dispatcher_id, (SELECT id FROM users WHERE public_id = 'DSP-042'))
       WHERE id = ?`,
      assignedAt, assignedAt, incident.id
    );
    addAssignmentEvent(incident.id, {
      type: 'dispatched', actorType: 'dispatcher', actorId: dispatcher,
      message: `${responder.callSign} assigned — ${route.distanceKm.toFixed(1)} km, ETA ${route.durationMin} min`,
      payload: { unit: responder.callSign, distanceKm: route.distanceKm, etaMinutes: route.durationMin, routeSource: route.routeSource }
    }, assignedAt);
    run(
      `INSERT INTO responder_locations (responder_id, incident_id, lat, lng, heading, speed_kph, recorded_at)
       VALUES (?, ?, ?, ?, ?, 0, ?)`,
      responder.id, incident.id, responder.lat, responder.lng, responder.heading, assignedAt
    );
    return id;
  });

  const detail = getIncidentDetail(incident.id);
  const assignment = detail.assignments.find((a) => a.id === assignmentId);
  rt.emitAssignmentNew(detail, assignment);
  rt.emitIncidentUpdated(detail);
  rt.emitFleetUnit(getResponder(responder.id));
  rt.emitStats(getStats());

  // Demo convenience: if no tablet is connected for that unit, auto-accept
  // after 9 s so the command-centre route animation still progresses. When a
  // real tablet is subscribed, the crew must explicitly accept.
  setTimeout(() => {
    try {
      const current = get('SELECT status FROM incident_assignments WHERE id = ?', assignmentId);
      if (current?.status === 'alerting' && !rt.isUnitConnected(responder.id)) {
        acceptAssignment(assignmentId, 'Auto-dispatch simulator');
      }
    } catch (error) {
      console.warn('[dispatch] auto-accept skipped:', error.message);
    }
  }, 9000).unref?.();

  return { incident: detail, assignment };
}

export function acceptAssignment(assignmentId, actor = 'Responder') {
  const row = get('SELECT * FROM incident_assignments WHERE id = ?', Number(assignmentId));
  if (!row) throw new HttpError(404, 'Assignment not found');
  if (!['alerting', 'accepted'].includes(row.status)) {
    if (row.status === 'en_route') {
      const detail = getIncidentDetail(row.incident_id);
      const assignment = detail.assignments.find((a) => a.id === row.id);
      return { incident: detail, assignment };
    }
    throw new HttpError(409, `Assignment is already ${row.status}`);
  }
  const at = nowIso();
  transaction(() => {
    run(
      `UPDATE incident_assignments SET status = 'en_route', accepted_at = COALESCE(accepted_at, ?) WHERE id = ?`,
      at, row.id
    );
    run(`UPDATE responders SET status = 'en_route', speed_kph = 32, updated_at = ? WHERE id = ?`, at, row.responder_id);
    run(
      `UPDATE incidents SET status = CASE WHEN status IN ('new','triage','dispatched') THEN 'en_route' ELSE status END,
              dispatched_at = COALESCE(dispatched_at, ?) WHERE id = ?`,
      at, row.incident_id
    );
    addAssignmentEvent(row.incident_id, {
      type: 'accepted', actorType: 'responder', actorId: String(row.responder_id),
      message: `${actor} accepted the dispatch`,
      payload: { assignmentId: row.id }
    }, at);
    addAssignmentEvent(row.incident_id, {
      type: 'en_route', actorType: 'responder', actorId: String(row.responder_id),
      message: `${actor} is en route`,
      payload: { assignmentId: row.id }
    }, at);
  });
  const detail = getIncidentDetail(row.incident_id);
  const assignment = detail.assignments.find((a) => a.id === row.id);
  rt.emitAssignmentUpdated(detail, assignment);
  rt.emitIncidentUpdated(detail);
  // State-only dispatch means the State EOC must be told the moment a unit
  // accepts, so it owns the live dispatch — NEMA is oversight only.
  rt.emitResponderAccepted(detail, assignment);
  addAssignmentEvent(detail.id, {
    type: 'state_notified', actorType: 'system', actorId: 'ResQLink',
    message: `State EOC notified: ${assignment?.callSign || actor} accepted and is en route`,
    payload: { assignmentId: row.id, stateCode: detail.stateCode }
  }, at);
  rt.emitFleetUnit(getResponder(row.responder_id));
  rt.emitStats(getStats());
  return { incident: detail, assignment };
}

/**
 * Responder self-assign from a NEMA-triggered proximity SOS.
 * The alert came from NEMA (proximity broadcast); the responder accepts it
 * here, and the system notifies the State EOC that the unit is en route so
 * the state owns the formal dispatch record. Only the signed-in unit itself
 * can call this (enforced at the HTTP layer).
 */
export async function responderSelfAssign(incidentId, { responderId, dispatcher = 'In-Vehicle PTT Terminal' } = {}) {
  const assigned = await assignUnit(incidentId, { responderId, dispatcher });
  const assignmentId = assigned.assignment?.id;
  if (!assignmentId) return assigned;
  const accepted = acceptAssignment(assignmentId, assigned.assignment.callSign || 'Responder');
  return { ...accepted, triggeredBy: 'nema_proximity' };
}

export function declineAssignment(assignmentId, reason = 'Unit unavailable') {
  const row = get('SELECT * FROM incident_assignments WHERE id = ?', Number(assignmentId));
  if (!row) throw new HttpError(404, 'Assignment not found');
  if (!['alerting', 'accepted'].includes(row.status)) {
    throw new HttpError(409, 'Only a new assignment can be declined');
  }
  const at = nowIso();
  transaction(() => {
    run(`UPDATE incident_assignments SET status = 'declined', decline_reason = ?, completed_at = ? WHERE id = ?`, reason, at, row.id);
    run(`UPDATE responders SET status = 'available', speed_kph = 0, updated_at = ? WHERE id = ?`, at, row.responder_id);
    const remaining = get(
      `SELECT COUNT(*) AS c FROM incident_assignments
       WHERE incident_id = ? AND status IN ('alerting','accepted','en_route','on_scene','transporting')`,
      row.incident_id
    ).c;
    if (!remaining) {
      run(
        `UPDATE incidents SET status = CASE WHEN status = 'dispatched' THEN 'triage' ELSE status END WHERE id = ?`,
        row.incident_id
      );
    }
    addAssignmentEvent(row.incident_id, {
      type: 'declined', actorType: 'responder', actorId: String(row.responder_id),
      message: `Dispatch declined: ${reason}`,
      payload: { assignmentId: row.id }
    }, at);
  });
  const detail = getIncidentDetail(row.incident_id);
  rt.emitAssignmentUpdated(detail, detail.assignments.find((a) => a.id === row.id));
  rt.emitIncidentUpdated(detail);
  rt.emitFleetUnit(getResponder(row.responder_id));
  return { incident: detail, assignment: detail.assignments.find((a) => a.id === row.id) };
}

export function updateAssignmentStatus(assignmentId, status, actor = 'Responder', { destination = null, destinationType = null } = {}) {
  const allowed = ['en_route', 'on_scene', 'transporting', 'completed'];
  if (!allowed.includes(status)) throw new HttpError(400, 'Invalid assignment status');
  const row = get('SELECT * FROM incident_assignments WHERE id = ?', Number(assignmentId));
  if (!row) throw new HttpError(404, 'Assignment not found');
  if (['declined', 'completed', 'cancelled'].includes(row.status)) {
    throw new HttpError(409, `Assignment is already ${row.status}`);
  }
  const at = nowIso();
  const incident = get('SELECT * FROM incidents WHERE id = ?', row.incident_id);
  transaction(() => {
    const assignmentSets = ['status = ?'];
    const assignmentParams = [status];
    if (status === 'en_route') {
      assignmentSets.push('accepted_at = COALESCE(accepted_at, ?)');
      assignmentParams.push(at);
    }
    if (status === 'on_scene') {
      assignmentSets.push('arrived_at = COALESCE(arrived_at, ?)', 'progress = 1');
      assignmentParams.push(at);
    }
    if (status === 'completed') {
      assignmentSets.push('completed_at = ?', 'progress = 1');
      assignmentParams.push(at);
    }
    assignmentParams.push(row.id);
    run(`UPDATE incident_assignments SET ${assignmentSets.join(', ')} WHERE id = ?`, ...assignmentParams);

    const unitStatus = status === 'completed' ? 'available' : status;
    run(`UPDATE responders SET status = ?, speed_kph = 0, updated_at = ? WHERE id = ?`, unitStatus, at, row.responder_id);

    if (status === 'en_route') {
      run(
        `UPDATE incidents SET status = CASE WHEN status IN ('new','triage','dispatched') THEN 'en_route' ELSE status END WHERE id = ?`,
        incident.id
      );
    } else if (status === 'on_scene') {
      run(
        `UPDATE incidents SET status = CASE WHEN status IN ('new','triage','dispatched','en_route') THEN 'on_scene' ELSE status END,
                arrived_at = COALESCE(arrived_at, ?) WHERE id = ?`,
        at, incident.id
      );
    } else if (status === 'transporting') {
      run(`UPDATE incidents SET status = 'transporting' WHERE id = ?`, incident.id);
    } else if (status === 'completed') {
      const remaining = get(
        `SELECT COUNT(*) AS c FROM incident_assignments
         WHERE incident_id = ? AND status IN ('alerting','accepted','en_route','on_scene','transporting')`,
        incident.id
      ).c;
      if (!remaining) {
        run(`UPDATE incidents SET status = 'resolved', resolved_at = ? WHERE id = ?`, at, incident.id);
      }
    }

    const messages = {
      en_route: `${actor} is en route`,
      on_scene: `${actor} arrived on scene`,
      transporting: destination
        ? `${actor} is transporting to ${destination}${destinationType ? ` (${destinationType})` : ''}`
        : `${actor} is transporting the patient`,
      completed: destination
        ? `${actor} completed handover at ${destination}`
        : `${actor} completed the assignment`
    };
    addAssignmentEvent(incident.id, {
      type: status, actorType: 'responder', actorId: String(row.responder_id),
      message: messages[status],
      payload: { assignmentId: row.id, destination: destination || null, destinationType: destinationType || null }
    }, at);
    if (status === 'completed') {
      const still = get(
        `SELECT COUNT(*) AS c FROM incident_assignments
         WHERE incident_id = ? AND status IN ('alerting','accepted','en_route','on_scene','transporting')`,
        incident.id
      ).c;
      if (!still) {
        addAssignmentEvent(incident.id, {
          type: 'resolved', actorType: 'system', actorId: null,
          message: 'All assigned units completed — incident resolved'
        }, at);
      }
    }
  });
  if (status === 'on_scene') {
    const unit = get('SELECT call_sign FROM responders WHERE id = ?', row.responder_id);
    handoffOnScene(row.incident_id, unit?.call_sign || 'First responder');
    // The responder is on scene, so the State EOC hands caller support to the
    // crew and the emergency call session closes.
    try {
      handoffCallOnScene(row.incident_id, unit?.call_sign || 'First responder');
    } catch (error) {
      console.warn('[call] on-scene handoff failed:', error.message);
    }
  }
  const detail = getIncidentDetail(row.incident_id);
  const assignment = detail.assignments.find((a) => a.id === row.id);
  rt.emitAssignmentUpdated(detail, assignment);
  rt.emitIncidentUpdated(detail);
  rt.emitFleetUnit(getResponder(row.responder_id));
  rt.emitStats(getStats());
  return { incident: detail, assignment };
}

export function resolveIncident(incidentId, { actor = 'Dispatcher 042', note = 'Incident resolved by command centre', status = 'resolved' } = {}) {
  const incident = assertActiveIncident(incidentId);
  const at = nowIso();
  transaction(() => {
    const assignments = all('SELECT * FROM incident_assignments WHERE incident_id = ?', incident.id);
    for (const a of assignments) {
      run(
        `UPDATE incident_assignments SET status = CASE WHEN status IN ('alerting','accepted','en_route','on_scene','transporting') THEN 'completed' ELSE status END,
                completed_at = COALESCE(completed_at, ?) WHERE id = ?`,
        at, a.id
      );
      const other = get(
        `SELECT COUNT(*) AS c FROM incident_assignments
         WHERE responder_id = ? AND incident_id <> ? AND status IN ('alerting','accepted','en_route','on_scene','transporting')`,
        a.responder_id, incident.id
      ).c;
      if (!other) run(`UPDATE responders SET status = 'available', speed_kph = 0, updated_at = ? WHERE id = ?`, at, a.responder_id);
    }
    run(
      `UPDATE incidents SET status = ?, resolved_at = ? WHERE id = ?`,
      status, at, incident.id
    );
    addAssignmentEvent(incident.id, {
      type: status === 'cancelled' ? 'cancelled' : 'resolved',
      actorType: 'dispatcher', actorId: actor, message: note
    }, at);
  });
  closeAiSupport(incident.id, status === 'cancelled' ? 'Incident cancelled' : 'Incident resolved');
  try {
    endCallSession(incident.id, {
      actor,
      actorType: 'dispatcher',
      reason: status === 'cancelled' ? 'Incident cancelled by command centre' : 'Incident resolved by command centre'
    });
  } catch (error) {
    console.warn('[call] close on resolve failed:', error.message);
  }
  const detail = getIncidentDetail(incident.id);
  rt.emitIncidentUpdated(detail);
  rt.emitStats(getStats());
  return detail;
}

export function addChatMessage(incidentId, { senderType = 'dispatcher', senderId = null, senderName = 'Dispatcher 042', body } = {}) {
  const incident = get('SELECT * FROM incidents WHERE id = ? OR code = ?', incidentId, String(incidentId));
  if (!incident) throw new HttpError(404, 'Incident not found');
  const clean = String(body || '').trim().slice(0, 1000);
  if (!clean) throw new HttpError(400, 'Message cannot be empty');
  if (!['citizen', 'dispatcher', 'responder', 'system'].includes(senderType)) {
    throw new HttpError(400, 'Invalid sender type');
  }
  const at = nowIso();
  const result = addMessage(incident.id, {
    channel: 'chat', senderType, senderId, senderName: String(senderName || 'Unknown').slice(0, 80), body: clean
  }, at);
  const message = {
    id: Number(result.lastInsertRowid), channel: 'chat', senderType, senderId,
    senderName, body: clean, createdAt: at
  };
  rt.emitChat(incident.id, message, incident.state_code);
  return message;
}

export function addNote(incidentId, { body, pinned = false, authorName = 'Dispatcher 042', authorId = 'DSP-042' } = {}) {
  const incident = get('SELECT * FROM incidents WHERE id = ? OR code = ?', incidentId, String(incidentId));
  if (!incident) throw new HttpError(404, 'Incident not found');
  const clean = String(body || '').trim().slice(0, 1500);
  if (!clean) throw new HttpError(400, 'Note cannot be empty');
  const at = nowIso();
  const result = run(
    `INSERT INTO incident_notes (incident_id, author_id, author_name, body, pinned, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    incident.id, authorId, authorName, clean, pinned ? 1 : 0, at
  );
  const note = {
    id: Number(result.lastInsertRowid), authorId, authorName, body: clean,
    pinned: !!pinned, createdAt: at
  };
  addEvent(incident.id, {
    type: 'note', actorType: 'dispatcher', actorId: authorId,
    message: `Dispatcher note added${pinned ? ' (pinned)' : ''}`,
    payload: { noteId: note.id }
  }, at);
  rt.emitNote(incident.id, note, incident.state_code);
  const detail = getIncidentDetail(incident.id);
  rt.emitIncidentUpdated(detail);
  return note;
}

export function updateUnitStatus(unitKey, status) {
  if (!['available', 'offline'].includes(status)) {
    throw new HttpError(400, 'Responder duty status must be available or offline');
  }
  const unit = getResponder(unitKey);
  if (!unit) throw new HttpError(404, 'Responder not found');
  if (unit.activeAssignmentId) {
    throw new HttpError(409, 'Cannot change duty status while assigned to an incident');
  }
  run('UPDATE responders SET status = ?, speed_kph = 0, updated_at = ? WHERE id = ?', status, nowIso(), unit.id);
  const updated = getResponder(unit.id);
  rt.emitFleetUnit(updated);
  rt.emitUnitPresence(updated);
  return updated;
}

export function updateUnitLocation(unitKey, { lat, lng, heading, speed }) {
  const unit = getResponder(unitKey);
  if (!unit) throw new HttpError(404, 'Responder not found');
  const latitude = Number(lat);
  const longitude = Number(lng);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) {
    throw new HttpError(400, 'Invalid coordinates');
  }
  const at = nowIso();
  run(
    `UPDATE responders SET lat = ?, lng = ?, heading = ?, speed_kph = ?, updated_at = ? WHERE id = ?`,
    latitude, longitude, Number(heading) || 0, Number(speed) || 0, at, unit.id
  );
  run(
    `INSERT INTO responder_locations (responder_id, incident_id, lat, lng, heading, speed_kph, recorded_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    unit.id, unit.activeIncidentId, latitude, longitude, Number(heading) || 0, Number(speed) || 0, at
  );
  const updated = getResponder(unit.id);
  rt.emitFleetUnit(updated);
  rt.emitUnitPresence(updated);
  return updated;
}

/** Assignment lookup for tenant checks in the HTTP layer. */
export function getAssignment(assignmentId) {
  return get('SELECT * FROM incident_assignments WHERE id = ?', Number(assignmentId));
}

export function getUnitDetail(unitKey) {
  const unit = getResponder(unitKey);
  if (!unit) return null;
  let activeAssignment = null;
  let incident = null;
  if (unit.activeAssignmentId) {
    const assignment = get('SELECT * FROM incident_assignments WHERE id = ?', unit.activeAssignmentId);
    if (assignment) {
      incident = getIncidentDetail(assignment.incident_id);
      activeAssignment = incident.assignments.find((a) => a.id === assignment.id) || null;
    }
  }
  const nearby = listIncidents({ scope: 'active', limit: 20, stateCode: unit.stateCode })
    .filter((i) => i.id !== incident?.id)
    .map((i) => ({
      ...i,
      distanceKm: Number(haversineKm(unit, i).toFixed(2)),
      etaMinutes: etaMinutes(haversineKm(unit, i))
    }))
    .sort((a, b) => a.distanceKm - b.distanceKm)
    .slice(0, 4);
  return {
    unit,
    assignment: activeAssignment,
    incident,
    nearbyIncidents: nearby,
    serverTime: nowIso()
  };
}

export function getBootstrap({ stateCode = null } = {}) {
  const state = stateForCode(stateCode);
  return {
    agencies: getAgencies(),
    responders: getResponders({ stateCode }),
    incidents: listIncidents({ scope: 'active', limit: 60, stateCode }),
    resolved: listIncidents({ scope: 'resolved', limit: 10, stateCode }),
    stats: getStats(),
    states: listStates(),
    coverage: getCoverage(),
    registrations: listRegistrations({ limit: 50, stateCode }),
    protocol: {
      nema: NEMA_NAME,
      humanOversight: 'Human agents at NEMA and the state EOC keep connectivity of the situation',
      aiRouting: 'AI agent sees the location, assigns the incident to the state and supports the caller until the first responder arrives'
    },
    shift: { code: 'A', label: 'Shift A', window: '08:00 - 16:00', dispatcher: 'Amina Okafor', role: 'Senior Dispatcher, NEMA' },
    jurisdiction: state ? `${stateLabel(state)} State` : 'Federal Republic of Nigeria',
    stateCode: state?.code || null,
    stateName: state ? stateLabel(state) : null,
    emergencyNumbers: ['112', '767', '122'],
    serverTime: nowIso()
  };
}

/** Utility used by the movement simulator. */
export function assignmentRoute(row) {
  const route = parseJson(row.route_json, null);
  const coords = route?.coordinates || [];
  return {
    coords,
    lengthKm: routeLengthKm(coords),
    pointAt: (t) => pointAlongRoute(coords, t)
  };
}

export function getActiveSimulatedAssignments() {
  return all(
    `SELECT ia.*, i.lat AS incident_lat, i.lng AS incident_lng, i.status AS incident_status,
            r.lat AS unit_lat, r.lng AS unit_lng
     FROM incident_assignments ia
     JOIN incidents i ON i.id = ia.incident_id
     JOIN responders r ON r.id = ia.responder_id
     WHERE ia.status IN ('accepted','en_route','transporting')
       AND i.status NOT IN ('resolved','cancelled')
       AND r.is_simulated = 1`
  );
}
