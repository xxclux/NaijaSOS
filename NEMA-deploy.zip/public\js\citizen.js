/* global NaijaSOS, NaijaSOSWebRTC */
/**
 * NaijaSOS Citizen SOS Dashboard — focused call controller.
 * ---------------------------------------------------------------------------
 *  - GPS fix acquisition
 *  - SOS hold-to-send with visual ring progress
 *  - Full-screen emergency call overlay
 *  - Camera toggle (real feed) with dispatch video protocol prompt
 *  - WebRTC producer for live video to responders / dispatch
 *  - Socket.IO incident status sync
 */
(() => {
  const S = window.NaijaSOS;
  const { socket, api, toast, esc, typeMeta, agencyMeta, incidentStatus } = S;

  const ACTIVE_KEY = 'naijasos.activeIncident';
  const HOLD_MS = 2000;

  const state = {
    location: null,
    address: '',
    selectedType: 'medical',
    hazards: new Set(),
    incident: null,
    creating: false,
    holding: false,
    holdComplete: false,
    raf: null,
    watchId: null,
    lastLocationSent: 0,
    activeTimer: null,
    pollTimer: null,
    feedStream: null,
    feedCamera: false,
    feedTimer: null,
    producer: null,
    producerIncidentId: null,
    photoDataUrl: null
  };

  const callState = {
    active: false, connected: false, ringing: false,
    muted: false, speaker: true, seconds: 0,
    timer: null, stopRing: null,
    call: null, callSessionId: null,
    micStream: null, agentStream: null,
    recordingId: null, recorder: null, recordingQueue: Promise.resolve(),
    recordingCtx: null, recordingDest: null, recordingSources: [],
    recordingStopPromise: null, recordingStartedAt: 0, recordingRequested: false
  };

  // ── DOM helpers ────────────────────────────────────────────────────────────
  const $ = (id) => document.getElementById(id);

  // ── GPS Visual State ───────────────────────────────────────────────────────
  function setGpsChip(icon, label, color = 'text-dim') {
    const ic = $('gpsIcon'); const lb = $('gpsChipLabel');
    if (ic) { ic.textContent = icon; ic.className = `material-symbols-outlined text-[15px] ${color}`; }
    if (lb) { lb.textContent = label; lb.className = `font-mono text-[9px] font-bold ${color}`; }
  }

  function updateGeoDisplay() {
    const loc = state.location;
    const geoLabel = $('geoLabel');
    const geoCoords = $('geoCoords');
    const geoAccuracy = $('geoAccuracy');
    const geoLandmark = $('geoLandmark');
    const geoIconMain = $('geoIconMain');
    const geoIconWrap = $('geoIconWrap');
    const geoStatusDot = $('geoStatusDot');

    if (!loc) {
      if (geoLabel) geoLabel.textContent = 'Acquiring live GPS fix…';
      if (geoCoords) geoCoords.textContent = 'Locating…';
      if (geoLandmark) geoLandmark.textContent = 'Waiting for satellite signal…';
      if (geoAccuracy) geoAccuracy.textContent = 'Calculating…';
      if (geoIconMain) {
        geoIconMain.textContent = 'sync';
        geoIconMain.className = 'material-symbols-outlined text-[15px] text-road animate-spin';
      }
      if (geoIconWrap) geoIconWrap.className = 'flex h-7 w-7 items-center justify-center rounded-lg border border-road/30 bg-road/[0.08]';
      if (geoStatusDot) geoStatusDot.className = 'w-1.5 h-1.5 rounded-full bg-road animate-ping';
      setGpsChip('location_searching', 'Acquiring GPS…', 'text-road');
      return;
    }

    const area = state.address || (loc.lat && loc.lng ? `${loc.lat.toFixed(4)}°, ${loc.lng.toFixed(4)}°` : 'Live coordinates locked');
    const accuracyNum = Math.round(loc.accuracy || 10);

    if (geoLabel) geoLabel.textContent = loc.isIp ? 'Network Location · Live' : 'Live Satellite GPS · Locked';
    if (geoCoords) geoCoords.textContent = S.formatCoord ? S.formatCoord(loc.lat, loc.lng) : `${loc.lat.toFixed(5)}°, ${loc.lng.toFixed(5)}°`;
    if (geoAccuracy) geoAccuracy.textContent = `± ${accuracyNum} m`;
    if (geoLandmark) geoLandmark.textContent = area;

    if (geoIconMain) {
      geoIconMain.textContent = 'my_location';
      geoIconMain.className = 'material-symbols-outlined text-[15px] text-ok';
    }
    if (geoIconWrap) geoIconWrap.className = 'flex h-7 w-7 items-center justify-center rounded-lg border border-ok/30 bg-ok/[0.08]';
    if (geoStatusDot) geoStatusDot.className = 'w-1.5 h-1.5 rounded-full bg-ok shadow-[0_0_6px_#34d399]';
    setGpsChip('location_on', 'GPS locked', 'text-ok');
  }

  // ── Dynamic Reverse Geocoding (Any Street / Landmark in Nigeria) ───────────
  async function reverseGeocode(loc) {
    if (!loc || !Number.isFinite(loc.lat) || !Number.isFinite(loc.lng)) return;
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 4500);
      const res = await fetch(`https://nominatim.openstreetmap.org/reverse?format=jsonv2&lat=${loc.lat}&lon=${loc.lng}&zoom=17`, {
        signal: ctrl.signal,
        headers: { 'Accept-Language': 'en' }
      });
      clearTimeout(t);
      if (!res.ok) return;
      const data = await res.json();
      
      const addr = data.address || {};
      const parts = [
        addr.road || addr.suburb || addr.neighbourhood,
        addr.city || addr.town || addr.county || addr.state_district,
        addr.state
      ].filter(Boolean);

      const label = parts.length ? parts.join(', ') : data.display_name?.split(',').slice(0, 3).join(', ');
      if (label) {
        state.address = label;
        updateGeoDisplay();
      }
    } catch {
      // Fallback: keep current address or coordinates
    }
  }

  // ── Accept Real Live Hardware Coordinates ─────────────────────────────────
  function acceptPosition(pos) {
    if (!pos || !pos.coords) return;
    const { latitude: lat, longitude: lng, accuracy } = pos.coords;
    state.location = {
      lat,
      lng,
      accuracy: accuracy || 10,
      isIp: false,
      timestamp: Date.now()
    };
    updateGeoDisplay();
    reverseGeocode(state.location);
  }

  // ── Network / IP Geolocation (Fallback if device GPS sensor unavailable) ──
  async function tryNetworkGeolocation() {
    try {
      const ctrl = new AbortController();
      const t = setTimeout(() => ctrl.abort(), 4000);
      const res = await fetch('https://ipapi.co/json/', { signal: ctrl.signal });
      clearTimeout(t);
      if (!res.ok) return false;
      const d = await res.json();
      if (d && Number.isFinite(d.latitude) && Number.isFinite(d.longitude)) {
        state.location = {
          lat: d.latitude,
          lng: d.longitude,
          accuracy: 1500,
          isIp: true,
          timestamp: Date.now()
        };
        state.address = [d.city, d.region, d.country_name].filter(Boolean).join(', ');
        updateGeoDisplay();
        return true;
      }
    } catch { /* proceed */ }
    return false;
  }

  // ── Locate Once & Continuous GPS Live Watch ────────────────────────────────
  function locateOnce({ userInitiated = false } = {}) {
    const gl = $('geoLabel');
    if (gl) gl.textContent = userInitiated ? 'Refreshing live GPS…' : 'Acquiring satellite fix…';
    setGpsChip('location_searching', 'Acquiring GPS…', 'text-road');

    if (!navigator.geolocation) {
      tryNetworkGeolocation().then((ok) => {
        if (!ok) toast('Geolocation Not Supported', 'Please use a browser with GPS/location support.', 'warning');
      });
      return;
    }

    // High accuracy request to engage device GPS chip
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        acceptPosition(pos);
        if (userInitiated) toast('Live GPS Locked', `Accurate to ±${Math.round(pos.coords.accuracy || 10)}m`, 'ok', 3000);
        startLocationWatch();
      },
      async (err) => {
        console.warn('[gps] Hardware fix failed, attempting network geolocation:', err.message);
        const netOk = await tryNetworkGeolocation();
        if (!netOk) {
          const r = err.code === err.PERMISSION_DENIED
            ? 'Location access was blocked. Please enable location permissions in your browser.'
            : 'Satellite GPS timed out. Please check device location settings.';
          toast('Location Notice', r, 'warning', 5000);
          updateGeoDisplay();
        }
        startLocationWatch();
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0 // Do not use stale cache; always obtain real, fresh fix
      }
    );
  }

  function startLocationWatch() {
    if (state.watchId != null || !navigator.geolocation) return;
    state.watchId = navigator.geolocation.watchPosition(
      (pos) => {
        acceptPosition(pos);
        maybeSendLocation(true);
      },
      (err) => {
        console.warn('[gps] Live watch update error:', err.message);
      },
      {
        enableHighAccuracy: true,
        maximumAge: 2000,
        timeout: 12000
      }
    );
  }

  function stopLocationWatch() {
    if (state.watchId != null && navigator.geolocation) {
      navigator.geolocation.clearWatch(state.watchId);
    }
    state.watchId = null;
  }

  function maybeSendLocation(force = false) {
    if (!state.incident?.isActive || !state.location?.simulated === false) return;
    const now = Date.now();
    if (!force && now - state.lastLocationSent < 5000) return;
    state.lastLocationSent = now;
    api(`/api/incidents/${state.incident.id}/location`, {
      method: 'POST',
      body: { lat: state.location.lat, lng: state.location.lng, accuracy: state.location.accuracy }
    }).catch(() => { });
  }

  // ── SOS button ─────────────────────────────────────────────────────────────
  const CIRC = 2 * Math.PI * 90; // matches r=90 in SVG (≈2π×90 ≈ 565)
  function setProgress(v) {
    const c = $('sosProgressCircle');
    if (c) c.style.strokeDashoffset = String(CIRC * (1 - Math.max(0, Math.min(1, v))));
  }

  function beginHold(event) {
    if (state.creating) return;
    if (event?.type === 'pointerdown' && event.button !== 0) return;
    event?.preventDefault();
    state.holding = true; state.holdComplete = false;
    const btn = $('sosButton');
    btn.classList.add('holding');
    try { btn.setPointerCapture(event.pointerId); } catch { }
    const lbl = $('sosButtonLabel'); if (lbl) lbl.textContent = 'HOLDING…';
    const sub = $('sosButtonSub'); if (sub) sub.textContent = 'SENDING SOS…';
    const hint = $('sosHint'); if (hint) hint.innerHTML = '<span class="font-bold text-alert-soft">Keep holding — release to cancel.</span>';

    const start = performance.now();
    const frame = () => {
      if (!state.holding) return;
      const p = Math.min(1, (performance.now() - start) / HOLD_MS);
      setProgress(p);
      if (p >= 1) {
        state.holdComplete = true; state.holding = false;
        btn.classList.remove('holding'); setProgress(0);
        submitSOS(); return;
      }
      state.raf = requestAnimationFrame(frame);
    };
    state.raf = requestAnimationFrame(frame);
  }

  function cancelHold() {
    if (!state.holding) return;
    state.holding = false;
    if (state.raf) cancelAnimationFrame(state.raf); state.raf = null;
    $('sosButton')?.classList.remove('holding');
    setProgress(0);
    const lbl = $('sosButtonLabel'); if (lbl) lbl.textContent = 'SOS';
    const sub = $('sosButtonSub'); if (sub) sub.textContent = 'HOLD 2 SECONDS';
    const hint = $('sosHint'); if (hint) hint.innerHTML = '<span class="font-bold text-[#b4bcbc]">Press and hold for 2 seconds</span> until the ring completes. We send your location instantly — no call or data plan needed beyond this page.';
  }

  // ── Scene photo (citizen SOS image shown on the State EOC dashboard) ───────
  function scenePhotoFromVideo(video) {
    if (!video || !video.videoWidth || !video.videoHeight) return null;
    const max = 1280;
    const scale = Math.min(1, max / Math.max(video.videoWidth, video.videoHeight));
    const canvas = document.createElement('canvas');
    canvas.width = Math.round(video.videoWidth * scale);
    canvas.height = Math.round(video.videoHeight * scale);
    canvas.getContext('2d').drawImage(video, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.82);
  }

  async function normaliseScenePhoto(dataUrl) {
    const img = new Image();
    await new Promise((resolve, reject) => {
      img.onload = resolve;
      img.onerror = () => reject(new Error('That image could not be read'));
      img.src = dataUrl;
    });
    const max = 1280;
    const scale = Math.min(1, max / Math.max(img.width, img.height));
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(img.width * scale));
    canvas.height = Math.max(1, Math.round(img.height * scale));
    canvas.getContext('2d').drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.82);
  }

  function renderScenePhoto() {
    const wrap = $('scenePhotoPreviewWrap');
    const preview = $('scenePhotoPreview');
    const label = $('scenePhotoLabel');
    if (!wrap || !preview) return;
    const has = !!state.photoDataUrl;
    wrap.classList.toggle('hidden', !has);
    wrap.classList.toggle('flex', has);
    if (has) preview.src = state.photoDataUrl;
    else preview.removeAttribute('src');
    if (label) label.textContent = has ? 'Change photo' : 'Add scene photo';
  }

  function clearScenePhoto() {
    state.photoDataUrl = null;
    const input = $('scenePhotoInput');
    if (input) input.value = '';
    renderScenePhoto();
  }

  async function pickScenePhoto(file) {
    if (!file) return;
    if (!/^image\//i.test(file.type)) { toast('Photo not added', 'Choose an image file.', 'warning'); return; }
    if (file.size > 12 * 1024 * 1024) { toast('Photo too large', 'Choose an image under 12 MB.', 'warning'); return; }
    try {
      const raw = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = () => resolve(String(reader.result || ''));
        reader.onerror = () => reject(new Error('Could not read that photo'));
        reader.readAsDataURL(file);
      });
      state.photoDataUrl = await normaliseScenePhoto(raw);
      renderScenePhoto();
      toast('Scene photo ready', 'It will be sent with your SOS and appear on the State EOC dashboard.', 'success', 5000);
    } catch (error) {
      toast('Photo not added', error.message, 'error');
    }
  }

  async function submitSOS({ demo = false, silent = false } = {}) {
    if (state.creating) return;
    state.creating = true;
    const btn = $('sosButton');
    btn.disabled = true; btn.classList.add('holding');
    const lbl = $('sosButtonLabel'); if (lbl) lbl.textContent = 'SENDING…';

    try {
      let incident;
      if (demo) {
        const data = await api('/api/demo/incident', { method: 'POST', body: { priority: 1 } });
        incident = data.incident;
        toast('Demo alert created', 'Injected into live dispatch queue.', 'info');
      } else {
        const loc = state.location || FALLBACK;
        const note = $('situationInput')?.value?.trim() || '';
        const hazards = [...state.hazards];
        const parts = [];
        if (silent) parts.push('SILENT SOS — text only, do not call back.');
        if (note) parts.push(note);
        if (hazards.length) parts.push(`Hazards: ${hazards.join(', ')}.`);
        // Prefer a photo the citizen attached; otherwise grab a still from the
        // live camera so the State EOC sees the scene before dispatch.
        const photo = state.photoDataUrl || scenePhotoFromVideo($('localVideo'));
        const data = await api('/api/incidents', {
          method: 'POST',
          auth: false,
          body: {
            type: state.selectedType,
            lat: loc.lat, lng: loc.lng, accuracy: loc.accuracy,
            address: state.address || `${nearestArea(loc.lat, loc.lng).name}, Lagos`,
            landmark: loc.simulated ? 'Demo location' : null,
            description: parts.join(' ') || `Citizen requested ${(typeMeta[state.selectedType]?.label || 'emergency')} assistance.`,
            hazards, peopleAffected: 1,
            reporterName: 'Citizen via app', source: 'app',
            liveTracking: !loc.simulated, createdByRole: 'citizen',
            photo: photo || undefined
          }
        });
        incident = data.incident;
        if (photo) clearScenePhoto();
      }
      activateIncident(incident);
      if (!silent) S.chime?.();
      showCallOverlay({ silent });
      toast('SOS sent', `Incident ${incident.code} — dispatch connected.`, 'success', 7000);
    } catch (err) {
      toast('SOS failed', err.message, 'error', 9000);
      btn.disabled = false; btn.classList.remove('holding');
      setProgress(0);
      const lbl2 = $('sosButtonLabel'); if (lbl2) lbl2.textContent = 'SOS';
    } finally {
      state.creating = false;
    }
  }

  // ── Incident activation ────────────────────────────────────────────────────
  function activateIncident(incident) {
    state.incident = incident;
    localStorage.setItem(ACTIVE_KEY, incident.code);
    $('preAlertView')?.classList.add('hidden');
    $('activeBar')?.classList.remove('hidden');
    const bar = $('activeCodeBar'); if (bar) bar.textContent = `${incident.code} · ${incident.type?.toUpperCase()}`;
    socket.emit('incident:subscribe', { incidentId: incident.id });
    startActiveClock();
    startPolling();
    startLocationWatch();
    maybeSendLocation(true);
    updateStepperFromStatus(incident.status);
  }

  function isActiveIncident() {
    return state.incident && !['resolved', 'cancelled'].includes(state.incident.status);
  }

  function startActiveClock() {
    stopActiveClock();
    const tick = () => {
      if (!state.incident) return;
      // While the full-screen call is open the call timer owns this badge.
      if ($('callOverlay')?.classList.contains('active')) return;
      const secs = Math.max(0, (Date.now() - new Date(state.incident.createdAt).getTime()) / 1000);
      const m = Math.floor(secs / 60), s = Math.floor(secs % 60);
      const str = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
      const tb = $('callTimerBadge'); if (tb) tb.textContent = str;
    };
    tick();
    state.activeTimer = setInterval(tick, 1000);
  }
  function stopActiveClock() {
    if (state.activeTimer) clearInterval(state.activeTimer);
    state.activeTimer = null;
  }

  function startPolling() {
    stopPolling();
    state.pollTimer = setInterval(async () => {
      if (!isActiveIncident()) return;
      try {
        const { incident } = await api(`/api/incidents/${state.incident.id}`);
        if (!incident) return;
        state.incident = incident;
        updateStepperFromStatus(incident.status);
        updateCallHeader(incident);
        if (!incident.isActive) onIncidentClosed(incident.status);
      } catch { }
    }, 4000);
  }
  function stopPolling() {
    if (state.pollTimer) clearInterval(state.pollTimer);
    state.pollTimer = null;
  }

  // ── Status stepper in overlay ──────────────────────────────────────────────
  const STEP_ORDER = ['created', 'acknowledged', 'dispatched', 'on_scene'];
  const STATUS_MAP = {
    new: 'created', triage: 'acknowledged', dispatched: 'dispatched',
    en_route: 'dispatched', on_scene: 'on_scene', transporting: 'on_scene',
    resolved: 'on_scene', cancelled: 'created'
  };

  function updateStepperFromStatus(status) {
    const activeStep = STATUS_MAP[status] || 'created';
    const activeIdx = STEP_ORDER.indexOf(activeStep);
    document.querySelectorAll('[data-step]').forEach((node) => {
      const idx = STEP_ORDER.indexOf(node.dataset.step);
      node.classList.remove('done', 'active');
      if (idx < activeIdx) node.classList.add('done');
      if (idx === activeIdx) node.classList.add('active');
    });
  }

  function updateCallHeader(incident) {
    const is = incidentStatus[incident.status] || incidentStatus.new;
    const pill = $('callStatusText');
    if (pill) pill.textContent = is.label?.toUpperCase() || 'ACTIVE';
    const lbl = $('callResponderLabel');
    const sub = $('callResponderSub');
    const assignments = incident.activeAssignments || [];
    if (assignments.length && lbl) {
      lbl.textContent = assignments.map((a) => a.callSign).join(', ') + ' assigned';
      if (sub) sub.textContent = `${(agencyMeta[assignments[0].agencyCode] || agencyMeta.GENERAL).label} · ETA ${S.formatEta ? S.formatEta(assignments[0].etaMinutes) : assignments[0].etaMinutes + ' min'}`;
    }
  }

  // ── Full-screen call overlay ───────────────────────────────────────────────
  function showCallOverlay({ silent = false, autoConnected = false } = {}) {
    const overlay = $('callOverlay');
    if (!overlay) return;
    overlay.classList.add('active');
    overlay.removeAttribute('aria-hidden');
    startEmergencyCallAudio({ silent, autoConnected });
    updateStepperFromStatus(state.incident?.status || 'new');
    // The State EOC owns this call. Open (or rejoin) the call session and let
    // the state hear the caller through the microphone. On a resumed page the
    // incident may already carry a call record — use it instead of opening a
    // second ringing session.
    if (silent) {
      setRecordingNotice('off', 'Silent SOS — voice is suppressed for your safety. The State EOC receives your GPS and incident details.');
      return;
    }
    const existing = state.incident?.call;
    if (existing) {
      callState.call = existing;
      callState.callSessionId = existing.id;
      if (existing.isActive || autoConnected) applyServerCall(existing);
      else { callState.call = null; callState.callSessionId = null; }
    }
    // A resumed page must not silently re-open a line that already concluded
    // (for example, the crew arrived and the State EOC handed over). Opening
    // the call from the active bar is an explicit request and may re-open it.
    if (existing && !existing.isActive && autoConnected) return;
    startCallSession().then((call) => {
      if (!call || !call.isActive) return;
      startCallMedia();
    });
  }

  function hideCallOverlay() {
    $('callOverlay')?.classList.remove('active');
    stopEmergencyCallAudio();
  }

  // ── State EOC call engagement + recording ─────────────────────────────────
  // The citizen browser is the recording point. The State EOC can hear the
  // caller and speak back over WebRTC; both sides are mixed into one recording
  // and stored server-side for NEMA / Super Admin observation.
  function setRecordingNotice(kind, text) {
    const notice = $('callRecordingNotice');
    const icon = $('callRecordingIcon');
    const label = $('callRecordingText');
    if (!notice) return;
    notice.classList.remove('hidden');
    const styles = {
      on: { icon: 'graphic_eq', color: 'text-ok' },
      off: { icon: 'mic_off', color: 'text-road' },
      starting: { icon: 'fiber_manual_record', color: 'text-alert' },
      ended: { icon: 'task_alt', color: 'text-ok' }
    };
    const style = styles[kind] || styles.starting;
    if (icon) { icon.textContent = style.icon; icon.className = `material-symbols-outlined text-[16px] ${style.color}`; }
    if (label) label.textContent = text;
  }

  function resetCallMediaState() {
    callState.micStream?.getTracks?.().forEach((track) => track.stop());
    callState.micStream = null;
    callState.agentStream = null;
    for (const source of callState.recordingSources || []) {
      try { source.disconnect(); } catch { /* already disconnected */ }
    }
    callState.recordingSources = [];
    if (callState.recordingCtx) {
      try { callState.recordingCtx.close(); } catch { /* already closed */ }
    }
    callState.recordingCtx = null;
    callState.recordingDest = null;
    callState.recorder = null;
    callState.recordingId = null;
    callState.recordingQueue = Promise.resolve();
    callState.recordingStopPromise = null;
    callState.recordingStartedAt = 0;
    callState.recordingRequested = false;
    const agentAudio = $('agentAudio');
    if (agentAudio) agentAudio.srcObject = null;
  }

  function connectAgentAudioToRecorder(stream) {
    if (!stream || !callState.recordingCtx || !callState.recordingDest) return;
    try {
      const source = callState.recordingCtx.createMediaStreamSource(stream);
      source.connect(callState.recordingDest);
      callState.recordingSources.push(source);
    } catch (error) {
      console.warn('[call] could not mix agent audio:', error.message);
    }
  }

  function attachAgentAudio(stream) {
    if (!stream) return;
    callState.agentStream = stream;
    const agentAudio = $('agentAudio');
    if (agentAudio) {
      agentAudio.srcObject = stream;
      agentAudio.muted = !callState.speaker;
      agentAudio.play().catch(() => { /* user can tap speaker again */ });
    }
    connectAgentAudioToRecorder(stream);
  }

  function recordingMimeType() {
    if (!window.MediaRecorder) return '';
    const candidates = [
      'audio/webm;codecs=opus', 'audio/webm',
      'audio/ogg;codecs=opus', 'audio/mp4', 'audio/aac'
    ];
    return candidates.find((type) => {
      try { return MediaRecorder.isTypeSupported(type); } catch { return false; }
    }) || '';
  }

  function enqueueRecordingChunk(blob) {
    const incident = state.incident;
    const recordingId = callState.recordingId;
    if (!incident || !recordingId || !blob?.size) return;
    callState.recordingQueue = callState.recordingQueue
      .then(async () => {
        const response = await fetch(
          `/api/incidents/${incident.id}/call/recording/${recordingId}/chunk?code=${encodeURIComponent(incident.code)}`,
          {
            method: 'PUT',
            headers: {
              'Content-Type': blob.type || 'application/octet-stream',
              'x-incident-code': incident.code
            },
            body: blob
          }
        );
        if (!response.ok) {
          let message = `Chunk upload failed (${response.status})`;
          try { message = (await response.json()).error || message; } catch { /* binary/empty */ }
          throw new Error(message);
        }
      })
      .catch((error) => {
        console.warn('[call] recording chunk failed:', error.message);
        setRecordingNotice('off', 'Recording interrupted — NEMA may not receive the full audio.');
      });
  }

  async function startRecording(micStream) {
    if (callState.recorder || !window.MediaRecorder || !state.incident) return;
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) {
      setRecordingNotice('off', 'This browser cannot record call audio.');
      return;
    }
    try {
      const ctx = new AudioCtx();
      await ctx.resume().catch(() => {});
      const destination = ctx.createMediaStreamDestination();
      const micSource = ctx.createMediaStreamSource(micStream);
      micSource.connect(destination);
      callState.recordingCtx = ctx;
      callState.recordingDest = destination;
      callState.recordingSources = [micSource];
      if (callState.agentStream) connectAgentAudioToRecorder(callState.agentStream);

      const mimeType = recordingMimeType();
      const { recording } = await api(`/api/incidents/${state.incident.id}/call/recording`, {
        method: 'POST',
        body: {
          code: state.incident.code,
          callSessionId: callState.callSessionId,
          mimeType: mimeType || 'audio/webm',
          source: 'citizen',
          recordedBy: state.incident.reporterName || 'Citizen'
        }
      });
      callState.recordingId = recording.id;
      const recorder = mimeType
        ? new MediaRecorder(destination.stream, { mimeType })
        : new MediaRecorder(destination.stream);
      callState.recorder = recorder;
      recorder.ondataavailable = (event) => { enqueueRecordingChunk(event.data); };
      recorder.onerror = (event) => {
        console.warn('[call] recorder error', event.error || event);
        setRecordingNotice('off', 'Recording error — audio may be incomplete.');
      };
      recorder.start(4000);
      callState.recordingStartedAt = Date.now();
      setRecordingNotice('on', 'Recording for NEMA oversight · the State EOC can hear you now.');
    } catch (error) {
      console.warn('[call] recording failed to start:', error.message);
      setRecordingNotice('off', 'Call audio recording could not start on this device.');
    }
  }

  function stopRecording() {
    if (callState.recordingStopPromise) return callState.recordingStopPromise;
    const recorder = callState.recorder;
    if (!recorder) return Promise.resolve();
    callState.recordingStopPromise = new Promise((resolve) => {
      let settled = false;
      const finalize = async () => {
        if (settled) return;
        settled = true;
        try { await callState.recordingQueue; } catch { /* already logged */ }
        const incident = state.incident;
        const recordingId = callState.recordingId;
        const duration = Math.max(0, Math.round((Date.now() - (callState.recordingStartedAt || Date.now())) / 1000));
        if (incident && recordingId) {
          try {
            await api(`/api/incidents/${incident.id}/call/recording/${recordingId}/finish`, {
              method: 'POST',
              body: { code: incident.code, durationSeconds: duration }
            });
          } catch (error) {
            console.warn('[call] recording finalize failed:', error.message);
          }
        }
        resetCallMediaState();
        resolve();
      };
      recorder.addEventListener('stop', finalize, { once: true });
      try {
        if (recorder.state === 'inactive') finalize();
        else recorder.stop();
      } catch {
        finalize();
      }
    });
    return callState.recordingStopPromise;
  }

  async function startCallMedia() {
    if (!state.incident || callState.recordingRequested) return;
    if (!navigator.mediaDevices?.getUserMedia) {
      setRecordingNotice('off', 'This browser cannot access the microphone — call audio will not be recorded.');
      return;
    }
    callState.recordingRequested = true;
    setRecordingNotice('starting', 'Requesting microphone so the State EOC can hear you and NEMA can review the call…');
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { echoCancellation: true, noiseSuppression: true, autoGainControl: true }
      });
      callState.micStream = stream;
      callState.muted = false;
      const producer = ensureProducer();
      producer?.setStream(stream);
      await startRecording(stream);
    } catch (error) {
      callState.recordingRequested = false;
      setRecordingNotice('off', error.name === 'NotAllowedError'
        ? 'Microphone blocked — the State EOC cannot hear you and recording is off. You can still use chat.'
        : 'Microphone unavailable — the State EOC cannot hear you and recording is off.');
    }
  }

  async function startCallSession() {
    if (!state.incident) return null;
    if (callState.callSessionId && callState.call?.isActive) return callState.call;
    try {
      const { call } = await api(`/api/incidents/${state.incident.id}/call`, {
        method: 'POST',
        body: { code: state.incident.code, citizenName: state.incident.reporterName }
      });
      callState.call = call;
      callState.callSessionId = call?.id || null;
      applyServerCall(call);
      return call;
    } catch (error) {
      setRecordingNotice('off', `Call channel unavailable — ${error.message}`);
      return null;
    }
  }

  function applyServerCall(call) {
    if (!call) return;
    callState.call = call;
    callState.callSessionId = call.id;
    if (state.incident) state.incident.call = call;
    const pill = $('callStatusText');
    const opLbl = $('callOperatorLabel');
    const respSub = $('callResponderSub');
    if (call.status === 'connected') {
      if (!callState.connected) connectCall();
      if (pill) pill.textContent = 'STATE EOC CONNECTED';
      if (opLbl) opLbl.textContent = `${call.claimedByName || 'State EOC agent'} · on the line`;
      if (respSub) respSub.textContent = 'Stay on the line. The State EOC is tracking your case until the first responder reaches you.';
      setRecordingNotice('on', 'Recording for NEMA oversight · the State EOC is on the line.');
      return;
    }
    if (call.status === 'ended') {
      const onScene = /on scene|handed/i.test(call.endReason || '');
      if (pill) pill.textContent = onScene ? 'CREW ON SCENE' : 'CALL ENDED';
      if (opLbl) opLbl.textContent = onScene ? 'First responder has arrived' : 'State EOC closed the call';
      if (respSub) respSub.textContent = call.endReason || 'The call has ended. Your incident remains active until it is resolved.';
      stopRecording().then(() => {
        setRecordingNotice(onScene ? 'ended' : 'off', onScene
          ? 'First responder on scene — call audio recording saved for NEMA review.'
          : 'Call audio recording saved for NEMA review.');
      });
      callState.active = false;
      callState.connected = false;
      if (callState.stopRing) { callState.stopRing(); callState.stopRing = null; }
      if (callState.timer) { clearInterval(callState.timer); callState.timer = null; }
      toast(onScene ? 'First responder on scene' : 'State EOC ended the call',
        onScene ? 'The crew has taken over from the State EOC. Your incident stays open until resolved.' : (call.endReason || 'The call has ended.'),
        'info', 7000);
      setTimeout(() => {
        if ($('callOverlay')?.classList.contains('active')) {
          hideCallOverlay();
          if (state.incident) {
            $('preAlertView')?.classList.add('hidden');
            $('activeBar')?.classList.remove('hidden');
          }
        }
      }, 1400);
      return;
    }
    if (call.status === 'ringing') {
      if (opLbl) opLbl.textContent = 'Waiting for the State EOC to answer…';
      if (respSub) respSub.textContent = 'Your SOS is in the state queue. Keep this call open — an agent will engage you.';
    }
  }

  async function stopCallMedia({ endSession = false, reason = 'Citizen ended the call' } = {}) {
    const incident = state.incident;
    const wasActive = !!callState.call?.isActive;
    await stopRecording();
    if (endSession && incident && wasActive) {
      try {
        const { call } = await api(`/api/incidents/${incident.id}/call/end`, {
          method: 'POST',
          body: { code: incident.code, reason }
        });
        callState.call = call;
      } catch (error) {
        console.warn('[call] could not close session:', error.message);
      }
    }
    resetCallMediaState();
  }

  // ── Emergency call audio state machine ────────────────────────────────────
  function playRingTone() {
    const ctx = S.audio?.();
    if (!ctx) return () => { };
    let stopped = false;
    let nextTimer = null;
    const ring = () => {
      if (stopped) return;
      try {
        const osc1 = ctx.createOscillator(), osc2 = ctx.createOscillator(), gain = ctx.createGain();
        osc1.frequency.value = 440; osc2.frequency.value = 480;
        gain.gain.setValueAtTime(0.045, ctx.currentTime);
        gain.gain.linearRampToValueAtTime(0.0001, ctx.currentTime + 1.5);
        osc1.connect(gain); osc2.connect(gain); gain.connect(ctx.destination);
        osc1.start(ctx.currentTime); osc2.start(ctx.currentTime);
        osc1.stop(ctx.currentTime + 1.55); osc2.stop(ctx.currentTime + 1.55);
        if (!stopped) nextTimer = setTimeout(ring, 3400);
      } catch { }
    };
    ring();
    return () => { stopped = true; if (nextTimer) clearTimeout(nextTimer); };
  }

  function startEmergencyCallAudio({ silent = false, autoConnected = false } = {}) {
    stopEmergencyCallAudio();
    callState.active = true; callState.connected = false; callState.seconds = 0;
    callState.muted = false; callState.speaker = true;

    const pill = $('callStatusText');
    const opLbl = $('callOperatorLabel');
    const respSub = $('callResponderSub');
    const tb = $('callTimerBadge');

    if (tb) tb.textContent = '00:00';

    if (silent) {
      if (pill) pill.textContent = 'SILENT SOS';
      if (opLbl) opLbl.textContent = 'Silent Dispatch Channel Active';
      if (respSub) respSub.textContent = 'Dispatch notified — voice suppressed for your safety.';
      callState.connected = true;
      startCallTimer();
      return;
    }

    if (pill) pill.textContent = 'NEMA AI VOICE AGENT ACTIVE';
    if (opLbl) opLbl.textContent = 'NEMA AI Voice Assistant · holding line for State EOC';
    if (respSub) respSub.textContent = 'NEMA AI has received your SOS and GPS. Keeping you on the line until the State EOC picks up.';

    callState.ringing = true;
    callState.stopRing = playRingTone();

    // NEMA AI Voice Agent speaks to keep the citizen calm and holding on the line:
    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance('This is NEMA AI Voice Assistant. Your emergency alert and GPS location have been received. We have identified your nearest first responder. Please stay calm and hold the line while I connect you directly to the State Emergency Operations Centre.');
        utt.rate = 1.0; utt.pitch = 1.0; utt.lang = 'en-US';
        window.speechSynthesis.speak(utt);
      } catch { }
    }
  }

  function connectCall() {
    if (!callState.active || callState.connected) return;
    if (callState.stopRing) { callState.stopRing(); callState.stopRing = null; }
    callState.ringing = false; callState.connected = true;

    try {
      const ctx = S.audio?.();
      if (ctx) {
        const osc = ctx.createOscillator(), gain = ctx.createGain();
        osc.frequency.setValueAtTime(520, ctx.currentTime);
        osc.frequency.setValueAtTime(780, ctx.currentTime + 0.12);
        gain.gain.setValueAtTime(0.06, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + 0.35);
        osc.connect(gain).connect(ctx.destination);
        osc.start(ctx.currentTime); osc.stop(ctx.currentTime + 0.38);
      }
    } catch { }

    const pill = $('callStatusText');
    const opLbl = $('callOperatorLabel');
    const respSub = $('callResponderSub');
    if (pill) pill.textContent = 'STATE EOC CONNECTED';
    if (opLbl) opLbl.textContent = 'State EOC dispatcher on the line';
    if (respSub) respSub.textContent = 'NEMA AI handed over to State EOC. Speak clearly — the dispatcher has your GPS and is tracking your first responder.';
    startCallTimer();

    if ('speechSynthesis' in window) {
      try {
        window.speechSynthesis.cancel();
        const utt = new SpeechSynthesisUtterance('State Emergency Operations Centre has connected. NEMA AI handing over to your human dispatcher now.');
        utt.rate = 1.0; utt.pitch = 1.0; utt.lang = 'en-US';
        window.speechSynthesis.speak(utt);
      } catch { }
    }

    // After connection, prompt camera after 4s delay (realistic protocol)
    setTimeout(() => {
      if (!callState.active) return;
      const prompt = $('cameraPermissionPrompt');
      if (prompt && !state.feedCamera) prompt.classList.remove('hidden');
    }, 4000);
  }

  function startCallTimer() {
    if (callState.timer) clearInterval(callState.timer);
    callState.seconds = 0;
    callState.timer = setInterval(() => {
      callState.seconds++;
      const m = Math.floor(callState.seconds / 60), s = callState.seconds % 60;
      const tb = $('callTimerBadge');
      if (tb) tb.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
    }, 1000);
  }

  function stopEmergencyCallAudio() {
    if (callState.stopRing) { callState.stopRing(); callState.stopRing = null; }
    if (callState.timer) { clearInterval(callState.timer); callState.timer = null; }
    if ('speechSynthesis' in window) { try { window.speechSynthesis.cancel(); } catch { } }
    callState.active = false; callState.connected = false; callState.ringing = false;
  }

  function endCall({ keepIncident = true } = {}) {
    // Real hang-up — hide FIRST so the citizen is never trapped on the
    // full-screen overlay even if cleanup below throws.
    const overlay = $('callOverlay');
    const wasVisible = !!overlay?.classList.contains('active');
    const wasActive = callState.active || callState.connected || callState.ringing || wasVisible;
    if (!wasActive && !wasVisible) return;
    if (overlay) {
      overlay.classList.remove('active');
      overlay.setAttribute('aria-hidden', 'true');
    }
    try { stopEmergencyCallAudio(); } catch { /* audio already gone */ }
    try { stopCameraFeed(); } catch { /* camera already gone */ }
    // Close the server-side call session so the State EOC sees the hang-up.
    stopCallMedia({ endSession: true, reason: 'Citizen ended the call' }).catch((error) => {
      console.warn('[call] hang-up cleanup failed:', error.message);
    });
    try { $('cameraPermissionPrompt')?.classList.add('hidden'); } catch { }
    try { const tb = $('callTimerBadge'); if (tb) tb.textContent = '00:00'; } catch { }
    // Return to the active incident bar so the citizen can re-open the call
    // (openCallBtn) or close the incident (resolve/cancel). The incident
    // itself stays open unless the citizen explicitly resolves/cancels.
    if (keepIncident && state.incident) {
      try {
        $('preAlertView')?.classList.add('hidden');
        $('activeBar')?.classList.remove('hidden');
      } catch { /* DOM may already be on the active bar */ }
    }
    toast('Call ended', 'Your SOS is still active — help is on the way. You can re-open the call anytime.', 'info');
  }

  function handleEndCall(event) {
    // Genuine user gesture on the End button — never let it bubble or be
    // swallowed by a still-visible overlay layer.
    if (event) { event.preventDefault(); event.stopPropagation(); }
    endCall({ keepIncident: true });
  }

  function toggleMute() {
    callState.muted = !callState.muted;
    callState.micStream?.getAudioTracks?.().forEach((track) => { track.enabled = !callState.muted; });
    const ic = $('callMuteIcon'), lb = $('callMuteLabel');
    if (ic) ic.textContent = callState.muted ? 'mic_off' : 'mic';
    if (lb) lb.textContent = callState.muted ? 'Unmute' : 'Mute';
    const btn = $('callMuteBtn');
    if (btn) btn.classList.toggle('muted', callState.muted);
    toast(callState.muted ? 'Microphone muted' : 'Microphone live', '', 'info', 2000);
  }

  function toggleSpeaker() {
    callState.speaker = !callState.speaker;
    const agentAudio = $('agentAudio');
    if (agentAudio) agentAudio.muted = !callState.speaker;
    const ic = $('callSpeakerIcon'), lb = $('callSpeakerLabel');
    if (ic) ic.textContent = callState.speaker ? 'volume_up' : 'volume_off';
    if (lb) lb.textContent = callState.speaker ? 'Speaker' : 'Earpiece';
    toast(callState.speaker ? 'Speaker on' : 'Earpiece mode', '', 'info', 2000);
  }

  // ── Camera / Video feed ────────────────────────────────────────────────────
  function setCamState(on) {
    state.feedCamera = on;
    const ic1 = $('callCamIcon'); if (ic1) ic1.textContent = on ? 'videocam' : 'videocam_off';
    const lb1 = $('callCamLabel'); if (lb1) lb1.textContent = on ? 'Camera on' : 'Camera';
    const ic2 = $('camTopIcon'); if (ic2) ic2.textContent = on ? 'videocam' : 'videocam_off';
    const ph = $('camOffPlaceholder');
    if (ph) ph.classList.toggle('hidden', on);
    const live = $('feedLiveBadge'); if (live) live.classList.toggle('hidden', !on);
    const cam1 = $('callCameraBtn'); if (cam1) cam1.classList.toggle('active', on);
    const cam2 = $('callCameraToggleTop'); if (cam2) cam2.classList.toggle('active', on);
  }

  function ensureProducer() {
    if (!state.incident) return null;
    if (state.producer && state.producerIncidentId === state.incident.id) return state.producer;
    state.producer?.destroy?.();
    state.producer = window.NaijaSOSWebRTC.createProducer({
      socket,
      incidentId: state.incident.id,
      onState: () => { },
      onViewerCount: () => { },
      // The State EOC agent's microphone arrives over the same peer
      // connection; play it and mix it into the call recording.
      onRemoteStream: (stream) => { attachAgentAudio(stream); }
    });
    state.producerIncidentId = state.incident.id;
    return state.producer;
  }

  function showLiveStream(stream, camera) {
    state.feedStream = stream; state.feedCamera = camera;
    const video = $('localVideo');
    if (video) { video.srcObject = stream; video.muted = true; video.play().catch(() => { }); }
    setCamState(camera);
    ensureProducer()?.setStream(stream);
    $('cameraPermissionPrompt')?.classList.add('hidden');
  }

  function startSimulatedFeed() {
    const canvas = document.createElement('canvas');
    canvas.width = 960; canvas.height = 540;
    const ctx = canvas.getContext('2d');
    let frame = 0;
    const token = { cancelled: false };
    state.feedTimer = token;
    const dots = Array.from({ length: 20 }, () => ({ x: Math.random(), y: Math.random(), s: 0.3 + Math.random() * 0.7 }));
    const draw = () => {
      if (token.cancelled) return;
      frame++;
      const t = frame / 10;
      const g = ctx.createLinearGradient(0, 0, 960, 540);
      g.addColorStop(0, '#0b1112'); g.addColorStop(1, '#080b0c');
      ctx.fillStyle = g; ctx.fillRect(0, 0, 960, 540);
      ctx.strokeStyle = 'rgba(52,211,153,.08)'; ctx.lineWidth = 1.5;
      for (let i = 0; i < 8; i++) {
        ctx.beginPath(); ctx.moveTo(480 + (i - 4) * 22, 260); ctx.lineTo(480 + (i - 4) * 95, 540); ctx.stroke();
      }
      dots.forEach((d, i) => {
        const x = ((d.x + Math.sin(t * 0.3 + i) * 0.01) % 1) * 960;
        const y = 330 + d.y * 170 + Math.sin(t * 0.5 + i) * 7;
        ctx.fillStyle = i % 5 === 0 ? 'rgba(255,85,64,.45)' : 'rgba(180,200,200,.18)';
        ctx.beginPath(); ctx.ellipse(x, y, 5 + d.s * 6, 11 + d.s * 12, 0, 0, Math.PI * 2); ctx.fill();
      });
      for (let y = 0; y < 540; y += 6) { ctx.fillStyle = 'rgba(255,255,255,.014)'; ctx.fillRect(0, y, 960, 1); }
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(0, 0, 960, 52);
      ctx.fillStyle = '#ff8a75'; ctx.font = 'bold 20px monospace';
      ctx.fillText('● SIMULATED SENSOR FEED', 24, 33);
      ctx.fillStyle = 'rgba(201,210,210,.6)'; ctx.font = '14px monospace';
      ctx.fillText(new Date().toLocaleTimeString('en-NG', { hour12: false }), 760, 33);
      ctx.fillText(`CAM-01 · ${String(frame).padStart(6, '0')}`, 24, 518);
      ctx.fillStyle = 'rgba(239,68,68,.9)';
      ctx.beginPath(); ctx.arc(924, 28, 5 + Math.sin(t * 3) * 1.2, 0, Math.PI * 2); ctx.fill();
      requestAnimationFrame(draw);
    };
    draw();
    const stream = canvas.captureStream(12);
    showLiveStream(stream, false);
    toast('Camera fallback', 'A simulated sensor feed is being shared with dispatch.', 'warning', 5000);
  }

  async function startCameraFeed() {
    if (!navigator.mediaDevices?.getUserMedia) { startSimulatedFeed(); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { width: { ideal: 1280 }, height: { ideal: 720 }, facingMode: 'environment' },
        audio: true
      });
      showLiveStream(stream, true);
      toast('Camera live', 'Dispatch and assigned responders can now see your location.', 'success');
    } catch (err) {
      if (err.name === 'NotAllowedError') {
        toast('Camera blocked', 'Permission denied. Switching to simulated sensor feed.', 'warning');
        startSimulatedFeed();
      } else {
        startSimulatedFeed();
      }
    }
  }

  function stopCameraFeed() {
    if (state.feedTimer) { state.feedTimer.cancelled = true; state.feedTimer = null; }
    if (state.feedStream) { state.feedStream.getTracks().forEach((t) => t.stop()); state.feedStream = null; }
    state.producer?.destroy?.();
    state.producer = null; state.producerIncidentId = null;
    const video = $('localVideo'); if (video) video.srcObject = null;
    setCamState(false);
    $('cameraPermissionPrompt')?.classList.add('hidden');
  }

  async function toggleCamera() {
    if (state.feedCamera || state.feedStream) {
      stopCameraFeed();
      toast('Camera off', 'Stopped sharing video.', 'info', 2000);
    } else {
      await startCameraFeed();
    }
  }

  // ── Close incident ─────────────────────────────────────────────────────────
  function teardownIncident() {
    stopEmergencyCallAudio();
    stopCallMedia({ endSession: true, reason: 'Incident closed' }).catch(() => { });
    stopCameraFeed();
    stopLocationWatch();
    stopActiveClock();
    stopPolling();
    hideCallOverlay();
    socket.emit('incident:unsubscribe', { incidentId: state.incident?.id });
    state.incident = null;
    localStorage.removeItem(ACTIVE_KEY);
  }

  function returnHome() {
    hideCallOverlay();
    $('activeBar')?.classList.add('hidden');
    $('preAlertView')?.classList.remove('hidden');
    const btn = $('sosButton'); if (btn) { btn.disabled = false; btn.classList.remove('holding'); }
    setProgress(0);
    const lbl = $('sosButtonLabel'); if (lbl) lbl.textContent = 'SOS';
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  async function closeIncident(status) {
    if (!state.incident) return;
    const isSafe = status === 'resolved';
    const confirmed = await S.confirmDialog({
      title: isSafe ? 'Close this incident?' : 'Cancel this SOS?',
      body: isSafe
        ? 'This tells dispatch you are safe and closes the incident.'
        : 'This cancels your SOS and releases any assigned units.',
      confirmLabel: isSafe ? "Yes, I'm safe" : 'Cancel SOS',
      danger: isSafe
    });
    if (!confirmed) return;
    try {
      await api(`/api/incidents/${state.incident.id}/citizen-close`, {
        method: 'POST', body: { status: isSafe ? 'resolved' : 'cancelled', code: state.incident.code }
      });
      toast(isSafe ? 'Incident closed' : 'SOS cancelled', isSafe ? 'Dispatch notified you are safe.' : 'Units released.', 'success');
      teardownIncident(); returnHome();
    } catch (err) {
      toast('Could not close incident', err.message, 'error');
    }
  }

  function onIncidentClosed(status) {
    toast('Incident closed', status === 'resolved' ? 'Dispatch has resolved this incident.' : 'Incident cancelled.', 'info', 6000);
    teardownIncident(); returnHome();
  }

  // ── Event binding ──────────────────────────────────────────────────────────
  function bindEvents() {
    // Type selector
    $('typeSelector')?.addEventListener('click', (e) => {
      const chip = e.target.closest('[data-type]'); if (!chip) return;
      state.selectedType = chip.dataset.type;
      document.querySelectorAll('#typeSelector [data-type]').forEach((n) => {
        n.setAttribute('aria-pressed', String(n === chip));
      });
    });

    // Hazard chips (class: haz-chip)
    $('preAlertView')?.addEventListener('click', (e) => {
      const h = e.target.closest('.haz-chip[data-hazard]'); if (!h) return;
      const name = h.dataset.hazard;
      if (state.hazards.has(name)) state.hazards.delete(name); else state.hazards.add(name);
      h.setAttribute('aria-pressed', String(state.hazards.has(name)));
    });

    // GPS refresh
    $('geoRefresh')?.addEventListener('click', () => locateOnce({ userInitiated: true }));

    // SOS button: requires continuous Press-and-Hold (2.0s). Quick clicks are rejected.
    const sos = $('sosButton');
    if (sos) {
      sos.addEventListener('pointerdown', beginHold);
      sos.addEventListener('pointerup', (e) => {
        if (!state.holdComplete && state.holding) {
          // Held for less than 2.0s: cancel hold
          cancelHold();
        }
      });
      sos.addEventListener('pointercancel', cancelHold);
      sos.addEventListener('pointerleave', (e) => {
        if (state.holding) cancelHold();
      });
      // Click event: Single click without holding 2 seconds must NOT trigger SOS
      sos.addEventListener('click', (e) => {
        if (!state.holdComplete && !state.incident && !state.creating) {
          toast('Hold for 2 seconds', 'Press and hold the SOS button continuously for 2 seconds to trigger emergency SOS.', 'info', 3000);
          cancelHold();
        }
      });
      sos.addEventListener('keydown', (e) => { if (e.key === ' ' || e.key === 'Enter') beginHold(e); });
      sos.addEventListener('keyup', (e) => { if (e.key === ' ' || e.key === 'Enter') cancelHold(); });
    }

    $('silentBtn')?.addEventListener('click', () => submitSOS({ silent: true }));
    $('demoSosBtn')?.addEventListener('click', () => submitSOS({ demo: true }));

    // Call overlay controls — End must work even if the overlay is stacked
    // over the main page or a socket tick re-renders underneath it.
    const endBtn = $('endCallBtn');
    if (endBtn) {
      endBtn.addEventListener('click', handleEndCall);
      endBtn.addEventListener('pointerup', (e) => { if (e.pointerType === 'touch') handleEndCall(e); });
      // Fallback delegation if the button node is ever re-created.
      document.addEventListener('click', (e) => {
        if (e.target.closest && e.target.closest('#endCallBtn')) handleEndCall(e);
      });
      document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && $('callOverlay')?.classList.contains('active')) handleEndCall(e);
      });
    }
    $('callMuteBtn')?.addEventListener('click', toggleMute);
    $('callSpeakerBtn')?.addEventListener('click', toggleSpeaker);
    $('callCameraBtn')?.addEventListener('click', toggleCamera);
    $('callCameraToggleTop')?.addEventListener('click', toggleCamera);
    $('allowCameraBtn')?.addEventListener('click', startCameraFeed);

    // Scene photo picker (shown on the State EOC dashboard with the SOS)
    $('scenePhotoPick')?.addEventListener('click', () => $('scenePhotoInput')?.click());
    $('scenePhotoInput')?.addEventListener('change', (event) => pickScenePhoto(event.target.files?.[0]));
    $('scenePhotoRemove')?.addEventListener('click', clearScenePhoto);
    renderScenePhoto();

    // Active bar controls
    $('openCallBtn')?.addEventListener('click', () => showCallOverlay({}));
    $('resolveBtn')?.addEventListener('click', () => closeIncident('resolved'));
    $('cancelSosBtn')?.addEventListener('click', () => closeIncident('cancelled'));

    // Socket.IO events
    socket.on('incident:snapshot', (detail) => {
      if (!state.incident || detail.id !== state.incident.id) return;
      state.incident = detail;
      updateStepperFromStatus(detail.status);
      updateCallHeader(detail);
    });
    socket.on('incident:updated', (detail) => {
      if (!state.incident || detail.id !== state.incident.id) return;
      state.incident = detail;
      updateStepperFromStatus(detail.status);
      updateCallHeader(detail);
      if (!detail.isActive) onIncidentClosed(detail.status);
    });
    socket.on('assignment:new', ({ incident, assignment }) => {
      if (!state.incident || incident.id !== state.incident.id) return;
      state.incident = incident;
      updateStepperFromStatus(incident.status);
      updateCallHeader(incident);
      S.dispatchTone?.();
      toast('Unit dispatched', `${assignment.callSign} is responding — ETA ${S.formatEta ? S.formatEta(assignment.etaMinutes) : assignment.etaMinutes + ' min'}.`, 'success', 7000);
    });
    socket.on('assignment:updated', ({ incident }) => {
      if (!state.incident || incident.id !== state.incident.id) return;
      state.incident = incident;
      updateStepperFromStatus(incident.status);
      updateCallHeader(incident);
    });
    // Dispatch requesting camera / audio (WebRTC protocol)
    socket.on('webrtc:request', ({ viewerSocketId, incidentId: reqId }) => {
      if (!state.incident || String(reqId) !== String(state.incident.id)) return;
      const prompt = $('cameraPermissionPrompt');
      if (!state.feedCamera && prompt) {
        prompt.classList.remove('hidden');
        toast('State EOC requesting your camera', 'Tap "Allow camera" to share a live view with the responder team. Audio is already connected.', 'info', 8000);
      }
      if (state.feedStream) ensureProducer()?.setStream(state.feedStream);
      else if (callState.micStream) ensureProducer()?.setStream(callState.micStream);
    });
    socket.on('call:update', (payload) => {
      if (!state.incident || !payload?.call) return;
      if (String(payload.incidentId) !== String(state.incident.id)) return;
      applyServerCall(payload.call);
    });
    socket.on('stats:update', () => { });
    socket.on('connect', () => {
      if (state.incident?.isActive) socket.emit('incident:subscribe', { incidentId: state.incident.id });
    });
  }

  // ── Resume on reload ───────────────────────────────────────────────────────
  async function resumeIncident() {
    const code = localStorage.getItem(ACTIVE_KEY);
    if (!code) return false;
    try {
      const { incident } = await api(`/api/incidents/${code}`);
      if (incident?.isActive) {
        activateIncident(incident);
        showCallOverlay({ autoConnected: true });
        return true;
      }
    } catch { }
    localStorage.removeItem(ACTIVE_KEY);
    return false;
  }

  // ── Init ───────────────────────────────────────────────────────────────────
  async function init() {
    bindEvents();
    locateOnce();
    const resumed = await resumeIncident();
    if (resumed) toast('SOS restored', 'Your active incident is still open.', 'info', 5000);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init, { once: true });
  } else {
    init();
  }

  window.addEventListener('beforeunload', () => { stopCameraFeed(); stopLocationWatch(); });
})();
