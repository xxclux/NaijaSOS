/* global NaijaSOS */
/**
 * Public first-responder registration.
 *
 * A person can apply for any supported unit type in any Nigerian state. The
 * application is always created as `pending`; the state EOC verifies it before
 * a login is provisioned. This page never sees an existing password.
 */
(() => {
  const S = window.NaijaSOS;
  const $ = (id) => document.getElementById(id);
  const ORDER = ['car', 'ambulance', 'police', 'fire', 'hospital', 'road_safety', 'other'];
  let selectedKind = 'ambulance';
  let states = [];

  function kindMeta(code) {
    return S.responderKinds[code] || S.responderKinds.other;
  }

  function renderKinds() {
    $('kindSelector').innerHTML = ORDER.map((code) => {
      const meta = kindMeta(code);
      const active = code === selectedKind;
      return `<button type="button" class="register-kind ${active ? 'is-active' : ''}" data-kind="${code}" role="radio" aria-checked="${active}" style="--kind-color:${meta.color}">
        <span class="material-symbols-outlined">${meta.icon}</span>
        <span class="register-kind__name">${S.esc(meta.label)}</span>
        <span class="register-kind__hint">${code === 'car' ? 'Private / community car' : code === 'other' ? 'NGO, volunteer, community' : code === 'hospital' ? 'Hospital team' : code === 'road_safety' ? 'FRSC / road safety' : `${meta.label} crew`}</span>
      </button>`;
    }).join('');
    $('kindSelector').querySelectorAll('[data-kind]').forEach((button) => {
      button.addEventListener('click', () => {
        selectedKind = button.dataset.kind;
        renderKinds();
        const vehicle = $('regVehicle');
        if (vehicle && !vehicle.value) vehicle.placeholder = vehicleHint(selectedKind);
      });
    });
  }

  function vehicleHint(code) {
    return {
      car: 'e.g. Toyota Corolla · community responder',
      ambulance: 'e.g. Toyota Hiace ambulance',
      police: 'e.g. Police patrol van',
      fire: 'e.g. Fire engine / rapid response',
      hospital: 'e.g. Hospital medical team',
      road_safety: 'e.g. FRSC patrol / tow',
      other: 'e.g. NGO response vehicle or on-foot team'
    }[code] || 'Vehicle / crew description';
  }

  async function loadStates() {
    const select = $('regState');
    try {
      const data = await S.api('/api/states', { auth: false });
      states = data.states || [];
      const params = new URLSearchParams(location.search);
      const preset = (params.get('state') || '').toUpperCase();
      select.innerHTML = '<option value="">Select your state</option>' + states.map((state) =>
        `<option value="${state.code}"${state.code === preset ? ' selected' : ''}>${S.esc(state.name)}${state.code === 'FC' ? ' · Abuja' : ''}</option>`
      ).join('');
      if (!preset && states.length) {
        const lagos = states.find((state) => state.code === 'LA');
        if (lagos) select.value = 'LA';
      }
    } catch (error) {
      select.innerHTML = '<option value="">Could not load states — retry</option>';
      showError(error.message);
    }
  }

  function showError(message) {
    const box = $('registrationError');
    box.textContent = message;
    box.classList.remove('hidden');
    box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
  }

  function hideError() {
    $('registrationError').classList.add('hidden');
  }

  function clean(value) {
    return String(value || '').trim();
  }

  async function submit(event) {
    event.preventDefault();
    hideError();
    const button = $('registrationSubmit');
    const payload = {
      responderKind: selectedKind,
      stateCode: $('regState').value,
      fullName: clean($('regName').value),
      phone: clean($('regPhone').value),
      email: clean($('regEmail').value) || undefined,
      vehicleType: clean($('regVehicle').value) || undefined,
      plateNumber: clean($('regPlate').value) || undefined,
      callsign: clean($('regCallsign').value) || undefined
    };
    if (!payload.stateCode) return showError('Choose the state where the unit operates.');
    if (payload.fullName.length < 3) return showError('Enter the full name of the person accountable for this unit.');
    if (payload.phone.length < 7) return showError('Enter a reachable phone number.');
    if (!$('regConsent').checked) return showError('Confirm that the unit is real and the contact details are reachable.');

    button.disabled = true;
    const original = button.innerHTML;
    button.innerHTML = '<span class="material-symbols-outlined animate-spin text-[18px]">progress_activity</span> Submitting…';
    try {
      const data = await S.api('/api/registrations', { method: 'POST', body: payload, auth: false });
      const registration = data.registration;
      $('registrationRef').textContent = registration.publicId;
      $('registrationUnit').textContent = registration.callsign
        ? `Provisional unit ${registration.callsign} · created on approval`
        : 'A call sign is assigned when your state EOC approves the unit.';
      $('registrationFormWrap').classList.add('hidden');
      $('registrationSuccess').classList.remove('hidden');
      $('registrationStatusBadge').textContent = 'Pending state review';
      $('registrationStatusBadge').className = 'badge badge-alert';
      window.scrollTo({ top: 0, behavior: 'smooth' });
      S.toast('Application submitted', `${registration.publicId} is pending ${registration.stateName} EOC review.`, 'success', 7000);
    } catch (error) {
      showError(error.message);
      button.disabled = false;
      button.innerHTML = original;
    }
  }

  function resetForm() {
    $('registrationForm').reset();
    $('registrationSuccess').classList.add('hidden');
    $('registrationFormWrap').classList.remove('hidden');
    $('registrationStatusBadge').textContent = 'Pending state review';
    $('registrationStatusBadge').className = 'badge badge-muted';
    const submitBtn = $('registrationSubmit');
    submitBtn.disabled = false;
    submitBtn.innerHTML = '<span class="material-symbols-outlined text-[19px]">how_to_reg</span> Submit application';
    if (states.length) $('regState').value = 'LA';
    $('regVehicle').placeholder = vehicleHint(selectedKind);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }

  function init() {
    renderKinds();
    $('regVehicle').placeholder = vehicleHint(selectedKind);
    loadStates();
    $('registrationForm').addEventListener('submit', submit);
    $('anotherApplication').addEventListener('click', resetForm);
    const params = new URLSearchParams(location.search);
    if (params.get('kind') && S.responderKinds[params.get('kind')]) {
      selectedKind = params.get('kind');
      renderKinds();
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();
