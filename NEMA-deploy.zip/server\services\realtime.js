/**
 * Realtime fan-out.
 * ---------------------------------------------------------------------------
 * Socket.IO rooms keep each audience scoped:
 *   dispatch             — command-centre dashboards
 *   incident:<id>        — citizen, assigned responders, dispatchers
 *   unit:<responderId>   — the in-vehicle tablet for one unit
 *
 * Keeping emission here means business logic (services/incidents.js) does not
 * need to know how transports are wired. Swap Socket.IO for Kafka/NATS/Redis
 * pub-sub later without touching the dispatch rules.
 */
let io = null;
// Socket count per unit (a unit may have tablet + radio on separate sockets).
const connectedUnitCounts = new Map();

export function setIO(serverIo) {
  io = serverIo;
}

export function markUnitConnected(unitId) {
  const key = String(unitId);
  connectedUnitCounts.set(key, (connectedUnitCounts.get(key) || 0) + 1);
  return connectedUnitCounts.get(key);
}

export function markUnitDisconnected(unitId) {
  const key = String(unitId);
  const count = Math.max(0, (connectedUnitCounts.get(key) || 0) - 1);
  if (count <= 0) connectedUnitCounts.delete(key);
  else connectedUnitCounts.set(key, count);
  return count;
}

export function isUnitConnected(unitId) {
  return (connectedUnitCounts.get(String(unitId)) || 0) > 0;
}

export function connectedUnitCount(unitId) {
  return connectedUnitCounts.get(String(unitId)) || 0;
}

export function onlineUnitIds() {
  return [...connectedUnitCounts.keys()].map((id) => Number(id)).filter(Boolean);
}

export function incidentRoom(incidentId) {
  return `incident:${incidentId}`;
}

export function unitRoom(unitId) {
  return `unit:${unitId}`;
}

export function stateRoom(stateCode) {
  return stateCode ? `state:${String(stateCode).toUpperCase()}` : 'state:UNKNOWN';
}

function safeEmit(target, event, payload) {
  if (!io || !target) return;
  try {
    io.to(target).emit(event, payload);
  } catch (error) {
    console.error(`[realtime] emit failed: ${event}`, error.message);
  }
}

function emitIncidentScoped(detail, event, payload) {
  safeEmit('dispatch', event, payload);
  safeEmit(stateRoom(detail?.stateCode), event, payload);
}

export function emitIncidentNew(detail) {
  emitIncidentScoped(detail, 'incident:new', detail);
}

export function emitIncidentUpdated(detail) {
  emitIncidentScoped(detail, 'incident:updated', detail);
  safeEmit(incidentRoom(detail.id), 'incident:updated', detail);
}

export function emitIncidentLocation(payload) {
  safeEmit('dispatch', 'incident:location', payload);
  safeEmit(stateRoom(payload.stateCode), 'incident:location', payload);
  safeEmit(incidentRoom(payload.id), 'incident:location', payload);
}

export function emitAssignmentNew(detail, assignment) {
  emitIncidentScoped(detail, 'assignment:new', { incident: detail, assignment });
  safeEmit(incidentRoom(detail.id), 'assignment:new', { incident: detail, assignment });
  safeEmit(unitRoom(assignment.responderId), 'assignment:new', { incident: detail, assignment });
}

export function emitAssignmentUpdated(detail, assignment) {
  emitIncidentScoped(detail, 'assignment:updated', { incident: detail, assignment });
  safeEmit(incidentRoom(detail.id), 'assignment:updated', { incident: detail, assignment });
  safeEmit(unitRoom(assignment.responderId), 'assignment:updated', { incident: detail, assignment });
}

/**
 * Explicit "first responder accepted — state notified" fan-out.
 * The State EOC is the only workspace allowed to dispatch; when a responder
 * accepts a dispatch (or a NEMA-triggered proximity SOS) the state desk gets
 * this push so it can own the dispatch / ETA in real time.
 */
export function emitResponderAccepted(detail, assignment) {
  const payload = {
    incident: detail,
    assignment,
    callSign: assignment?.callSign,
    stateCode: detail?.stateCode,
    acceptedAt: new Date().toISOString()
  };
  emitIncidentScoped(detail, 'responder:accepted', payload);
  safeEmit(incidentRoom(detail.id), 'responder:accepted', payload);
  safeEmit(unitRoom(assignment?.responderId), 'responder:accepted', payload);
  // Alias for dashboards that only listen for the state-scoped push.
  safeEmit(stateRoom(detail?.stateCode), 'state:notify', payload);
}

export function emitFleet(units) {
  safeEmit('dispatch', 'fleet:update', units);
  // The command centre receives the whole fleet in one frame. A field tablet
  // only needs its own vehicle, so mirror each position into that unit's private
  // room. The state EOC gets the same frame scoped to its own state room.
  const byState = new Map();
  for (const unit of units || []) {
    safeEmit(unitRoom(unit.id), 'unit:fleet', unit);
    if (unit.stateCode) {
      const list = byState.get(unit.stateCode) || [];
      list.push(unit);
      byState.set(unit.stateCode, list);
    }
  }
  for (const [code, list] of byState) safeEmit(stateRoom(code), 'fleet:update', list);
}

export function emitFleetUnit(unit) {
  safeEmit('dispatch', 'fleet:unit', unit);
  safeEmit(stateRoom(unit?.stateCode), 'fleet:unit', unit);
  if (unit?.id) safeEmit(unitRoom(unit.id), 'unit:fleet', unit);
}

/** Presence-only update: is this unit's terminal connected & GPS-syncing now? */
export function emitUnitPresence(unit) {
  if (!unit) return;
  const payload = {
    unitId: unit.id,
    publicId: unit.publicId,
    callSign: unit.callSign,
    isOnline: !!unit.isOnline,
    online: !!unit.isOnline,
    isGpsFresh: !!unit.isGpsFresh,
    gpsSyncedAt: unit.gpsSyncedAt || unit.updatedAt || null,
    gpsSyncAgeSeconds: unit.gpsSyncAgeSeconds ?? null,
    status: unit.status,
    stateCode: unit.stateCode,
    lat: unit.lat,
    lng: unit.lng,
    updatedAt: unit.updatedAt
  };
  safeEmit('dispatch', 'unit:presence', payload);
  safeEmit(stateRoom(unit.stateCode), 'unit:presence', payload);
  if (unit.id) safeEmit(unitRoom(unit.id), 'unit:presence', payload);
}

export function emitChat(incidentId, message, stateCode = null) {
  safeEmit('dispatch', 'message:new', { incidentId, message });
  safeEmit(stateRoom(stateCode), 'message:new', { incidentId, message });
  safeEmit(incidentRoom(incidentId), 'message:new', { incidentId, message });
}

export function emitNote(incidentId, note, stateCode = null) {
  safeEmit('dispatch', 'note:new', { incidentId, note });
  safeEmit(stateRoom(stateCode), 'note:new', { incidentId, note });
  safeEmit(incidentRoom(incidentId), 'note:new', { incidentId, note });
}

/** Call engagement / recording lifecycle. */
export function emitCallUpdate(incidentId, call, stateCode = null) {
  const payload = { incidentId: Number(incidentId), call, stateCode };
  safeEmit('dispatch', 'call:update', payload);
  safeEmit(stateRoom(stateCode || call?.stateCode), 'call:update', payload);
  safeEmit(incidentRoom(incidentId), 'call:update', payload);
}

export function emitAiUpdate(incidentId, ai) {
  safeEmit('dispatch', 'ai:update', { incidentId, ai });
  safeEmit(stateRoom(ai?.stateCode), 'ai:update', { incidentId, ai });
  safeEmit(incidentRoom(incidentId), 'ai:update', { incidentId, ai });
}

export function emitAiMessage(incidentId, sessionId, message, ai = null) {
  safeEmit('dispatch', 'ai:message', { incidentId, sessionId, message, ai });
  safeEmit(stateRoom(ai?.stateCode), 'ai:message', { incidentId, sessionId, message, ai });
  safeEmit(incidentRoom(incidentId), 'ai:message', { incidentId, sessionId, message, ai });
}

export function emitStats(stats) {
  safeEmit('dispatch', 'stats:update', stats);
}

export function emitSystem(event, payload) {
  safeEmit('dispatch', event, payload);
  if (payload?.stateCode) safeEmit(stateRoom(payload.stateCode), event, payload);
  if (payload?.state_code) safeEmit(stateRoom(payload.state_code), event, payload);
}

export function emitToUnit(unitId, event, payload) {
  safeEmit(unitRoom(unitId), event, payload);
  safeEmit('responders:all', event, { ...payload, targetUnitId: unitId });
}

export function emitToIncident(incidentId, event, payload) {
  safeEmit(incidentRoom(incidentId), event, payload);
}

/** Direct socket message used for WebRTC signalling (offer/answer/ICE). */
export function emitToSocket(socketId, event, payload) {
  if (!io || !socketId) return;
  io.to(socketId).emit(event, payload);
}

export function getIO() {
  return io;
}
