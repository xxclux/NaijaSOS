/**
 * Nigerian state routing table.
 * ---------------------------------------------------------------------------
 * The AI agent cannot dispatch into a vacuum: every SOS is first resolved to
 * one of the 36 states or the Federal Capital Territory. The state determines
 * which State Emergency Operations Centre (EOC), NEMA desk and agency commands
 * receive the alert.
 *
 * We keep the reference points in code (WGS84) rather than a database table so
 * the routing table is easy to audit and test. In production this is replaced
 * by the official state boundary polygons / PostGIS `ST_Contains` query.
 */

export const NIGERIA_STATES = [
  { code: 'AB', name: 'Abia', capital: 'Umuahia', zone: 'South East', lat: 5.4309, lng: 7.5247 },
  { code: 'AD', name: 'Adamawa', capital: 'Yola', zone: 'North East', lat: 9.3265, lng: 12.3984 },
  { code: 'AK', name: 'Akwa Ibom', capital: 'Uyo', zone: 'South South', lat: 5.0377, lng: 7.9128 },
  { code: 'AN', name: 'Anambra', capital: 'Awka', zone: 'South East', lat: 6.2105, lng: 6.9378 },
  { code: 'BA', name: 'Bauchi', capital: 'Bauchi', zone: 'North East', lat: 10.3103, lng: 9.8439 },
  { code: 'BY', name: 'Bayelsa', capital: 'Yenagoa', zone: 'South South', lat: 4.7719, lng: 6.0698 },
  { code: 'BE', name: 'Benue', capital: 'Makurdi', zone: 'North Central', lat: 7.3369, lng: 8.7404 },
  { code: 'BO', name: 'Borno', capital: 'Maiduguri', zone: 'North East', lat: 11.8333, lng: 13.15 },
  { code: 'CR', name: 'Cross River', capital: 'Calabar', zone: 'South South', lat: 5.9631, lng: 8.33 },
  { code: 'DE', name: 'Delta', capital: 'Asaba', zone: 'South South', lat: 5.5325, lng: 5.8987 },
  { code: 'EB', name: 'Ebonyi', capital: 'Abakaliki', zone: 'South East', lat: 6.3249, lng: 8.1137 },
  { code: 'ED', name: 'Edo', capital: 'Benin City', zone: 'South South', lat: 6.335, lng: 5.6037 },
  { code: 'EK', name: 'Ekiti', capital: 'Ado Ekiti', zone: 'South West', lat: 7.6211, lng: 5.2214 },
  { code: 'EN', name: 'Enugu', capital: 'Enugu', zone: 'South East', lat: 6.4584, lng: 7.5464 },
  { code: 'FC', name: 'Federal Capital Territory', shortName: 'FCT', capital: 'Abuja', zone: 'North Central', lat: 9.0765, lng: 7.3986 },
  { code: 'GO', name: 'Gombe', capital: 'Gombe', zone: 'North East', lat: 10.2897, lng: 11.1673 },
  { code: 'IM', name: 'Imo', capital: 'Owerri', zone: 'South East', lat: 5.572, lng: 7.0588 },
  { code: 'JI', name: 'Jigawa', capital: 'Dutse', zone: 'North West', lat: 12.228, lng: 9.5616 },
  { code: 'KD', name: 'Kaduna', capital: 'Kaduna', zone: 'North West', lat: 10.5222, lng: 7.4383 },
  { code: 'KN', name: 'Kano', capital: 'Kano', zone: 'North West', lat: 12.0022, lng: 8.592 },
  { code: 'KT', name: 'Katsina', capital: 'Katsina', zone: 'North West', lat: 12.9908, lng: 7.6018 },
  { code: 'KE', name: 'Kebbi', capital: 'Birnin Kebbi', zone: 'North West', lat: 12.4539, lng: 4.1975 },
  { code: 'KO', name: 'Kogi', capital: 'Lokoja', zone: 'North Central', lat: 7.8023, lng: 6.7333 },
  { code: 'KW', name: 'Kwara', capital: 'Ilorin', zone: 'North Central', lat: 8.4966, lng: 4.5421 },
  { code: 'LA', name: 'Lagos', capital: 'Ikeja', zone: 'South West', lat: 6.5244, lng: 3.3792 },
  { code: 'NA', name: 'Nasarawa', capital: 'Lafia', zone: 'North Central', lat: 8.4904, lng: 8.522 },
  { code: 'NI', name: 'Niger', capital: 'Minna', zone: 'North Central', lat: 9.6139, lng: 6.5569 },
  { code: 'OG', name: 'Ogun', capital: 'Abeokuta', zone: 'South West', lat: 7.15, lng: 3.35 },
  { code: 'ON', name: 'Ondo', capital: 'Akure', zone: 'South West', lat: 7.2571, lng: 5.2058 },
  { code: 'OS', name: 'Osun', capital: 'Osogbo', zone: 'South West', lat: 7.5629, lng: 4.52 },
  { code: 'OY', name: 'Oyo', capital: 'Ibadan', zone: 'South West', lat: 7.3775, lng: 3.947 },
  { code: 'PL', name: 'Plateau', capital: 'Jos', zone: 'North Central', lat: 9.8965, lng: 8.8583 },
  { code: 'RI', name: 'Rivers', capital: 'Port Harcourt', zone: 'South South', lat: 4.8156, lng: 7.0498 },
  { code: 'SO', name: 'Sokoto', capital: 'Sokoto', zone: 'North West', lat: 13.0059, lng: 5.2476 },
  { code: 'TA', name: 'Taraba', capital: 'Jalingo', zone: 'North East', lat: 8.0, lng: 10.5 },
  { code: 'YO', name: 'Yobe', capital: 'Damaturu', zone: 'North East', lat: 11.7479, lng: 11.966 },
  { code: 'ZA', name: 'Zamfara', capital: 'Gusau', zone: 'North West', lat: 12.17, lng: 6.66 }
];

export const STATE_BY_CODE = new Map(NIGERIA_STATES.map((state) => [state.code, state]));

export const NATIONAL_EMERGENCY_NUMBER = '112';
export const NEMA_NAME = 'National Emergency Management Agency (NEMA), Nigeria';

export function stateForCode(code) {
  return STATE_BY_CODE.get(String(code || '').toUpperCase()) || null;
}

export function stateLabel(state) {
  if (!state) return 'Unassigned';
  return state.code === 'FC' ? 'FCT' : state.name;
}

export function stateEocName(state) {
  if (!state) return 'State Emergency Operations Centre';
  return `${stateLabel(state)} State Emergency Operations Centre`;
}

/** Nearest-state reference point, used when polygon boundaries are unavailable. */
export function stateForPoint(lat, lng) {
  const latitude = Number(lat);
  const longitude = Number(lng);
  if (!Number.isFinite(latitude) || !Number.isFinite(longitude)) return null;
  let best = null;
  let bestKm = Infinity;
  for (const state of NIGERIA_STATES) {
    const km = distanceKm(latitude, longitude, state.lat, state.lng);
    if (km < bestKm) {
      bestKm = km;
      best = state;
    }
  }
  return best ? { ...best, distanceKm: Number(bestKm.toFixed(2)) } : null;
}

/** Human-readable incident prefix, e.g. LGS for Lagos, FCT for Abuja. */
export function incidentPrefix(state) {
  if (!state) return 'NGA';
  if (state.code === 'FC') return 'FCT';
  if (state.code === 'LA') return 'LGS';
  return `${state.code}S`;
}

export function listStates() {
  return NIGERIA_STATES.map((state) => ({
    ...state,
    label: stateLabel(state),
    eoc: stateEocName(state)
  }));
}

export function distanceKm(lat1, lng1, lat2, lng2) {
  const R = 6371.0088;
  const toRad = (value) => (value * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.min(1, Math.sqrt(h)));
}
