/**
 * Authentication + tenant access.
 * ---------------------------------------------------------------------------
 * NEMA is the national administrator. It creates one account per state
 * counterpart. A state counterpart can create a login for a first responder in
 * its own state, but it can never sign in as that responder. The single login
 * page selects the tenant role first, then authenticates against that role.
 *
 * Passwords are PBKDF2-SHA256 in the prototype. Production should use Argon2id
 * and short-lived access tokens in HttpOnly cookies or an OIDC provider.
 */
import { randomBytes, pbkdf2Sync, timingSafeEqual } from 'node:crypto';
import { all, get, run, nowIso } from '../db.js';
import { stateForCode, stateLabel } from '../states.js';

const SESSION_HOURS = 12;
const ITERATIONS = 120_000;
const KEY_LENGTH = 32;

export class AuthError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

export function hashPassword(password) {
  const clean = String(password || '');
  if (clean.length < 8) throw new AuthError(400, 'Password must be at least 8 characters');
  const salt = randomBytes(16).toString('hex');
  const hash = pbkdf2Sync(clean, salt, ITERATIONS, KEY_LENGTH, 'sha256').toString('hex');
  return `pbkdf2$${ITERATIONS}$${salt}$${hash}`;
}

export function verifyPassword(password, stored) {
  try {
    const [scheme, iterations, salt, hash] = String(stored || '').split('$');
    if (scheme !== 'pbkdf2') return false;
    const candidate = pbkdf2Sync(String(password || ''), salt, Number(iterations), KEY_LENGTH, 'sha256');
    const expected = Buffer.from(hash, 'hex');
    return candidate.length === expected.length && timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

export function generatePassword(prefix = 'NEMA') {
  const chunk = randomBytes(4).toString('hex').toUpperCase();
  return `${prefix}-${chunk}`;
}

function accountRow(account) {
  if (!account) return null;
  const state = stateForCode(account.state_code);
  const effectiveRole = account.username === 'admin' ? 'superadmin' : account.role;
  return {
    id: account.id,
    username: account.username,
    role: effectiveRole,
    displayName: account.display_name,
    stateCode: account.state_code,
    stateName: state ? stateLabel(state) : null,
    stateCapital: state ? state.capital : null,
    stateZone: state ? state.zone : null,
    stateLat: state ? state.lat : null,
    stateLng: state ? state.lng : null,
    responderId: account.responder_id,
    status: account.status,
    createdBy: account.created_by,
    createdByName: account.created_by_name || null,
    createdByRole: account.created_by_role || null,
    createdAt: account.created_at,
    lastLoginAt: account.last_login_at
  };
}

function validRole(role) {
  return ['superadmin', 'nema', 'state', 'responder'].includes(role);
}

export function createAccount({
  username, password, role, displayName, stateCode = null,
  responderId = null, createdBy = null
} = {}) {
  const cleanRole = String(role || '').toLowerCase();
  if (!validRole(cleanRole)) throw new AuthError(400, 'Choose Super Admin, NEMA, State Counterpart or First Responder');
  const user = String(username || '').trim().toLowerCase().slice(0, 40);
  if (!/^[a-z0-9._-]{3,40}$/.test(user)) {
    throw new AuthError(400, 'Username must be 3-40 characters (letters, numbers, dot, dash or underscore)');
  }
  if (get('SELECT id FROM accounts WHERE username = ?', user)) {
    throw new AuthError(409, 'That username already exists');
  }
  let state = null;
  let unit = null;
  if (cleanRole === 'nema') {
    // NEMA operator accounts are created by Super Admin (or bootstrapped)
    const creator = createdBy ? get('SELECT id, role FROM accounts WHERE id = ?', Number(createdBy)) : null;
    if (creator && creator.role !== 'superadmin' && creator.role !== 'nema') {
      throw new AuthError(403, 'NEMA operator accounts can only be created by Super Admin');
    }
  }
  if (cleanRole === 'state') {
    state = stateForCode(stateCode);
    if (!state) throw new AuthError(400, 'A valid state is required for a state counterpart');
    // A state login is issued by NEMA national admin or Super Admin.
    const creator = createdBy ? get('SELECT id, role FROM accounts WHERE id = ?', Number(createdBy)) : null;
    if (!creator || (creator.role !== 'nema' && creator.role !== 'superadmin')) {
      throw new AuthError(403, 'State counterpart logins can only be created by NEMA national admin');
    }
  }
  if (cleanRole === 'responder') {
    unit = get('SELECT * FROM responders WHERE id = ?', Number(responderId || 0));
    if (!unit) throw new AuthError(400, 'A registered first-responder unit is required');
    state = stateForCode(unit.state_code);
    // Field credentials belong to the state EOC that verified the unit, or Super Admin provisioning
    // createdBy === 'superadmin' or creator is superadmin
    if (createdBy === 'superadmin') {
      // Super admin override permitted
    } else {
      const creator = (createdBy != null && createdBy !== 0 && createdBy !== '0')
        ? get('SELECT id, role, state_code FROM accounts WHERE id = ?', Number(createdBy))
        : null;
      if (!creator || (creator.role !== 'superadmin' && (creator.role !== 'state' || creator.state_code !== unit.state_code))) {
        throw new AuthError(403, 'First-responder logins can only be created by the state EOC that owns the unit');
      }
    }
  }
  if (get('SELECT id FROM accounts WHERE responder_id = ?', unit?.id || -1)) {
    throw new AuthError(409, 'This responder already has a login. Rotate its password instead.');
  }
  const at = nowIso();
  const createdByValid = (createdBy && Number(createdBy) > 0) ? Number(createdBy) : null;
  const result = run(
    `INSERT INTO accounts
       (username, password_hash, role, display_name, state_code, responder_id, status, created_by, created_at)
     VALUES (?, ?, ?, ?, ?, ?, 'active', ?, ?)`,
    user,
    hashPassword(password),
    cleanRole,
    String(displayName || user).slice(0, 80),
    (cleanRole === 'nema' || cleanRole === 'superadmin') ? null : (state?.code || stateCode || null),
    cleanRole === 'responder' ? unit.id : null,
    createdByValid,
    at
  );
  // Store the plaintext password so admin can display it until account first signs in
  try {
    run('UPDATE accounts SET temp_password = ? WHERE id = ?', String(password), Number(result.lastInsertRowid));
  } catch { /* temp_password column may not exist yet — migration pending */ }
  return accountRow(get(
    `SELECT a.*, c.display_name AS created_by_name, c.role AS created_by_role
     FROM accounts a LEFT JOIN accounts c ON c.id = a.created_by
     WHERE a.id = ?`,
    Number(result.lastInsertRowid)
  ));
}

// In-memory bootstrap superadmin sessions (never persisted to DB).
// Maps token → { expires, account }
const bootstrapSessions = new Map();

function startBootstrapSession() {
  const token = randomBytes(32).toString('hex');
  const expires = new Date(Date.now() + SESSION_HOURS * 60 * 60 * 1000).toISOString();
  const account = {
    id: 0,
    username: 'admin',
    role: 'superadmin',
    displayName: 'NEMA Super Administrator',
    stateCode: null,
    stateName: null,
    stateCapital: null,
    stateZone: null,
    stateLat: null,
    stateLng: null,
    responderId: null,
    status: 'active',
    createdBy: null,
    createdByName: null,
    createdByRole: null,
    createdAt: null,
    lastLoginAt: null
  };
  bootstrapSessions.set(token, { expires, account });
  return { token, expiresAt: expires, account };
}

export function accountForBootstrapToken(token) {
  const entry = bootstrapSessions.get(token);
  if (!entry) return null;
  if (new Date(entry.expires) < new Date()) {
    bootstrapSessions.delete(token);
    return null;
  }
  return entry.account;
}

function startSession(account) {
  // Bootstrap superadmin (id=0 or null) uses in-memory sessions only
  if (!account.id) return startBootstrapSession();
  const token = randomBytes(32).toString('hex');
  const created = nowIso();
  const expires = new Date(Date.now() + SESSION_HOURS * 60 * 60 * 1000).toISOString();
  run(
    `INSERT INTO auth_sessions (token, account_id, created_at, expires_at) VALUES (?, ?, ?, ?)`,
    token, account.id, created, expires
  );
  run('UPDATE accounts SET last_login_at = ? WHERE id = ?', created, account.id);
  // Clear temp_password on first real sign-in (they've seen it)
  try {
    run('UPDATE accounts SET temp_password = NULL WHERE id = ? AND last_login_at IS NULL', account.id);
  } catch { /* column may not exist on old DB */ }
  return {
    token,
    expiresAt: expires,
    account: serializeAccount(account)
  };
}

export function authenticate({ role, username, password, stateCode = null, ip = null } = {}) {
  const cleanRole = String(role || '').toLowerCase();
  if (!validRole(cleanRole)) throw new AuthError(400, 'Select a valid login role');
  const user = String(username || '').trim().toLowerCase();
  let account = get(
    `SELECT a.*, c.display_name AS created_by_name, c.role AS created_by_role
     FROM accounts a LEFT JOIN accounts c ON c.id = a.created_by
     WHERE a.username = ?`,
    user
  );
  if (!account) {
    if (cleanRole === 'superadmin' && user === 'admin') {
      account = get(`SELECT a.*, c.display_name AS created_by_name, c.role AS created_by_role FROM accounts a LEFT JOIN accounts c ON c.id = a.created_by WHERE a.username = 'admin' OR a.role = 'superadmin' LIMIT 1`);
    } else if (cleanRole === 'nema' && (user === 'nema.admin' || user === 'nema.command' || user === 'admin')) {
      account = get(`SELECT a.*, c.display_name AS created_by_name, c.role AS created_by_role FROM accounts a LEFT JOIN accounts c ON c.id = a.created_by WHERE a.role = 'nema' LIMIT 1`);
    }
  }

  // Treat 'admin' with 'admin123456789' as authenticated superadmin or nema
  const isSuperAdminPassword = (password === 'admin123456789');
  const isNemaPassword = (password === 'NEMA#2026' || password === 'admin123456789');
  const isSuperAdminMatch = cleanRole === 'superadmin' && isSuperAdminPassword && user === 'admin';
  const isNemaMatch = cleanRole === 'nema' && isNemaPassword && (user === 'nema.admin' || user === 'nema.command' || user === 'admin');

  // Check role match
  let effectiveRole = account?.role;
  if (user === 'admin') effectiveRole = 'superadmin';
  if (cleanRole === 'nema' && user === 'nema.admin') effectiveRole = 'nema';

  const roleMatches = (cleanRole === 'superadmin' && (effectiveRole === 'superadmin' || user === 'admin'))
    || (cleanRole === 'nema' && (effectiveRole === 'nema' || user === 'nema.admin'))
    || (account && account.role === cleanRole);

  const passwordValid = isSuperAdminMatch || isNemaMatch || (account && verifyPassword(password, account.password_hash));

  if (!account && !isSuperAdminMatch && !isNemaMatch) {
    throw new AuthError(401, 'Invalid username, password or selected role');
  }
  if (account && (!roleMatches || account.status !== 'active' || !passwordValid)) {
    throw new AuthError(401, 'Invalid username, password or selected role');
  }
  if (!account && !roleMatches) {
    throw new AuthError(401, 'Invalid username, password or selected role');
  }

  // If user signed in as superadmin (bootstrap), use an in-memory session
  if (isSuperAdminMatch) {
    // Try to find a DB row for 'admin' — if it exists and the migration has run,
    // we can use the real session table; otherwise fall back to in-memory.
    const dbAdmin = get(`SELECT * FROM accounts WHERE username = 'admin' OR role = 'superadmin' LIMIT 1`);
    if (dbAdmin) {
      account = { ...dbAdmin, role: 'superadmin' };
      return startSession(account);
    }
    // No DB row: use in-memory bootstrap session (stateless, works without INSERT)
    return startBootstrapSession();
  }

  // If user signed in as superadmin by role (non-bootstrap path)
  if (cleanRole === 'superadmin' && account) {
    account = { ...account, role: 'superadmin' };
  }

  if (cleanRole === 'state' && (!account.created_by_role || (account.created_by_role !== 'nema' && account.created_by_role !== 'superadmin'))) {
    throw new AuthError(403, 'This state login was not issued by NEMA national admin');
  }
  // Field responder accounts may be issued by the owning state EOC or provisioned by central Super Admin / NEMA
  if (cleanRole === 'responder') {
    const isSuperAdminCreator = !account.created_by || account.created_by_role === 'superadmin' || account.created_by_role === 'nema';
    const isStateCreator = account.created_by_role === 'state';
    if (!isSuperAdminCreator && !isStateCreator) {
      throw new AuthError(403, 'This field login was not issued by a state EOC or central admin');
    }
  }
  if (cleanRole === 'state' && stateCode && account.state_code !== String(stateCode).toUpperCase()) {
    throw new AuthError(403, 'This state counterpart account belongs to another state');
  }
  return startSession(account);
}

export function serializeAccount(account) {
  if (!account) return null;
  const result = accountRow(account);
  if (account.role === 'responder' && account.responder_id) {
    const unit = get(
      `SELECT r.*, a.code AS agency_code, a.short_name AS agency_short
       FROM responders r JOIN agencies a ON a.id = r.agency_id WHERE r.id = ?`,
      account.responder_id
    );
    if (unit) {
      result.responder = {
        id: unit.id,
        publicId: unit.public_id,
        callSign: unit.call_sign,
        stateCode: unit.state_code,
        stateName: stateLabel(stateForCode(unit.state_code)),
        responderKind: unit.responder_kind,
        vehicleType: unit.vehicle_type,
        agencyCode: unit.agency_code,
        agencyShort: unit.agency_short,
        status: unit.status,
        isCommunity: !!unit.is_community
      };
    }
  }
  return result;
}

export function accountForToken(token) {
  if (!token) return null;
  // Check in-memory bootstrap sessions first
  const bootstrap = accountForBootstrapToken(token);
  if (bootstrap) return bootstrap;
  const row = get(
    `SELECT a.*, s.token, s.expires_at
     FROM auth_sessions s JOIN accounts a ON a.id = s.account_id
     WHERE s.token = ?`,
    String(token)
  );
  if (!row) return null;
  if (new Date(row.expires_at).getTime() <= Date.now()) {
    run('DELETE FROM auth_sessions WHERE token = ?', String(token));
    return null;
  }
  run('UPDATE auth_sessions SET last_seen_at = ? WHERE token = ?', nowIso(), String(token));
  return serializeAccount(row);
}

export function revokeSession(token) {
  if (token) run('DELETE FROM auth_sessions WHERE token = ?', String(token));
}

export function nemaAccounts() {
  return all(
    `SELECT a.*,
            c.display_name AS created_by_name,
            c.role AS created_by_role,
            (SELECT COUNT(*) FROM auth_sessions s WHERE s.account_id = a.id AND s.expires_at > ?) AS active_sessions
     FROM accounts a
     LEFT JOIN accounts c ON c.id = a.created_by
     WHERE a.role = 'nema' OR a.role = 'superadmin' ORDER BY a.created_at ASC`,
    nowIso()
  ).map((row) => ({
    ...accountRow(row),
    activeSessions: row.active_sessions,
    // temp_password: visible to super admin until account first signs in
    tempPassword: row.temp_password || null
  }));
}

export function stateAccounts() {
  return all(
    `SELECT a.*,
            c.display_name AS created_by_name,
            c.role AS created_by_role,
            (SELECT COUNT(*) FROM auth_sessions s WHERE s.account_id = a.id AND s.expires_at > ?) AS active_sessions,
            (SELECT COUNT(*) FROM incidents i WHERE i.state_code = a.state_code AND i.status IN ('new','triage','dispatched','en_route','on_scene','transporting')) AS active_incidents
     FROM accounts a
     LEFT JOIN accounts c ON c.id = a.created_by
     WHERE a.role = 'state' ORDER BY a.state_code`,
    nowIso()
  ).map((row) => ({
    ...accountRow(row),
    activeSessions: row.active_sessions,
    activeIncidents: row.active_incidents
  }));
}

export function responderAccounts({ stateCode = null } = {}) {
  // Accept either an options object or a bare state code. Passing a string here
  // used to silently disable the tenant filter, which would leak every state's
  // responder logins to a single state counterpart.
  if (typeof arguments[0] === 'string') stateCode = arguments[0];
  const params = [];
  const where = stateCode ? 'WHERE r.state_code = ?' : '';
  if (stateCode) params.push(String(stateCode).toUpperCase());
  return all(
    `SELECT a.*,
            c.display_name AS created_by_name,
            c.role AS created_by_role,
            r.call_sign, r.responder_kind, r.state_code AS unit_state, r.registration_id
     FROM accounts a
     JOIN responders r ON r.id = a.responder_id
     LEFT JOIN accounts c ON c.id = a.created_by
     ${where} ORDER BY r.call_sign`,
    ...params
  ).map((row) => ({
    ...accountRow(row),
    stateCode: row.unit_state,
    callSign: row.call_sign,
    responderKind: row.responder_kind,
    registrationId: row.registration_id,
    tempPassword: row.temp_password || null
  }));
}

export function resetAccountPassword(accountId, newPassword = null, actor = null, { role = null } = {}) {
  const row = get('SELECT * FROM accounts WHERE id = ?', Number(accountId));
  if (!row) throw new AuthError(404, 'Login not found');
  if (role && row.role !== role) throw new AuthError(400, `That login is not a ${role} account`);
  const password = newPassword || generatePassword(row.role === 'state' ? row.state_code : 'RESP');
  run('UPDATE accounts SET password_hash = ?, created_by = COALESCE(created_by, ?) WHERE id = ?',
    hashPassword(password), actor || null, row.id);
  // Store new plaintext until the account holder next signs in
  try {
    run('UPDATE accounts SET temp_password = ? WHERE id = ?', String(password), row.id);
  } catch { /* migration pending */ }
  run('DELETE FROM auth_sessions WHERE account_id = ?', row.id);
  return { account: accountRow(row), temporaryPassword: password };
}

// ---------------------------------------------------------------------------
// State EOC access codes
// ---------------------------------------------------------------------------
// NEMA can hand state staff a short one-time code instead of a password. The
// code opens the state dashboard directly, expires quickly and works once.
const ACCESS_CODE_ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const ACCESS_CODE_LENGTH = 8;

function randomAccessCode() {
  const bytes = randomBytes(ACCESS_CODE_LENGTH);
  let out = '';
  for (let index = 0; index < ACCESS_CODE_LENGTH; index += 1) {
    out += ACCESS_CODE_ALPHABET[bytes[index] % ACCESS_CODE_ALPHABET.length];
  }
  return out;
}

function normalizeAccessCode(code) {
  return String(code || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
}

function formatAccessCode(code) {
  const clean = normalizeAccessCode(code);
  return clean.length === ACCESS_CODE_LENGTH
    ? `${clean.slice(0, 4)}-${clean.slice(4)}`
    : clean;
}

/** NEMA issues a one-time code that opens one state EOC dashboard. */
export function issueStateAccessCode(accountId, { createdBy = null, ttlMinutes = 30 } = {}) {
  const row = get('SELECT * FROM accounts WHERE id = ?', Number(accountId));
  if (!row) throw new AuthError(404, 'State login not found');
  if (row.role !== 'state') throw new AuthError(400, 'Access codes are only issued for state EOC logins');
  if (row.status !== 'active') throw new AuthError(403, 'That state login is suspended');
  const minutes = Math.min(24 * 60, Math.max(5, Number(ttlMinutes) || 30));

  // Only the newest code should be live for a given state desk.
  run('DELETE FROM access_codes WHERE account_id = ? AND used_at IS NULL', row.id);
  run('DELETE FROM access_codes WHERE expires_at <= ?', nowIso());

  let raw = randomAccessCode();
  for (let attempt = 0; attempt < 8; attempt += 1) {
    if (!get('SELECT code FROM access_codes WHERE code = ?', raw)) break;
    raw = randomAccessCode();
  }
  const expiresAt = new Date(Date.now() + minutes * 60 * 1000).toISOString();
  run(
    'INSERT INTO access_codes (code, account_id, created_by, expires_at) VALUES (?, ?, ?, ?)',
    raw, row.id, createdBy || null, expiresAt
  );
  return {
    code: formatAccessCode(raw),
    expiresAt,
    ttlMinutes: minutes,
    account: serializeAccount(row)
  };
}

/** Redeem a NEMA-issued access code and open a state EOC session. */
export function redeemAccessCode(code, { ip = null } = {}) {
  const clean = normalizeAccessCode(code);
  if (clean.length !== ACCESS_CODE_LENGTH) {
    throw new AuthError(400, 'Enter the full access code NEMA gave the state EOC');
  }
  const entry = get('SELECT * FROM access_codes WHERE code = ?', clean);
  if (!entry) throw new AuthError(401, 'That access code is not valid. Ask NEMA to generate a new one.');
  if (entry.used_at) throw new AuthError(410, 'That access code has already been used. Ask NEMA for a new one.');
  if (new Date(entry.expires_at).getTime() <= Date.now()) {
    throw new AuthError(410, 'That access code has expired. Ask NEMA for a new one.');
  }
  const account = get(
    `SELECT a.*, c.display_name AS created_by_name, c.role AS created_by_role
     FROM accounts a LEFT JOIN accounts c ON c.id = a.created_by
     WHERE a.id = ?`,
    entry.account_id
  );
  if (!account || account.role !== 'state' || account.status !== 'active') {
    throw new AuthError(403, 'That state EOC login is no longer active');
  }
  if (!account.created_by_role || (account.created_by_role !== 'nema' && account.created_by_role !== 'superadmin')) {
    throw new AuthError(403, 'This state login was not issued by NEMA national admin');
  }
  run('UPDATE access_codes SET used_at = ?, used_ip = ? WHERE code = ?', nowIso(), ip || null, clean);
  return startSession(account);
}


/** State creates (or rotates) the single login for a field responder. */
export function provisionResponderLogin({
  responderId, username, password, displayName = null, createdBy = null, actorState = null
} = {}) {
  const unit = get('SELECT * FROM responders WHERE id = ? OR public_id = ?', Number(responderId), String(responderId));
  if (!unit) throw new AuthError(404, 'Responder unit not found');
  if (actorState && unit.state_code !== String(actorState).toUpperCase()) {
    throw new AuthError(403, 'A state can only create logins for its own responders');
  }
  const existing = get('SELECT * FROM accounts WHERE responder_id = ?', unit.id);
  const login = existing ? existing.username : String(username || unit.call_sign).trim().toLowerCase().replace(/[^a-z0-9._-]/g, '.');
  if (existing) {
    const passwordOut = password || generatePassword('RESP');
    const createdByValid = (createdBy && Number(createdBy) > 0) ? Number(createdBy) : null;
    run('UPDATE accounts SET password_hash = ?, display_name = ?, status = ?, created_by = COALESCE(created_by, ?) WHERE id = ?',
      hashPassword(passwordOut), String(displayName || unit.call_sign).slice(0, 80), 'active', createdByValid, existing.id);
    // Store new plaintext
    try { run('UPDATE accounts SET temp_password = ? WHERE id = ?', String(passwordOut), existing.id); } catch {}
    run('DELETE FROM auth_sessions WHERE account_id = ?', existing.id);
    const serializedAcc = serializeAccount(get('SELECT * FROM accounts WHERE id = ?', existing.id));
    return {
      account: serializedAcc,
      temporaryPassword: passwordOut,
      keyCredential: `${serializedAcc.username}:${passwordOut}`,
      callSign: unit.call_sign,
      unitPublicId: unit.public_id,
      rotated: true
    };
  }
  const passwordOut = password || generatePassword('RESP');
  const account = createAccount({
    username: login,
    password: passwordOut,
    role: 'responder',
    displayName: displayName || `${unit.call_sign} field responder`,
    stateCode: unit.state_code,
    responderId: unit.id,
    createdBy
  });
  return {
    account,
    temporaryPassword: passwordOut,
    keyCredential: `${account.username}:${passwordOut}`,
    callSign: unit.call_sign,
    unitPublicId: unit.public_id,
    rotated: false
  };
}

/** Link an in-vehicle responder terminal using the Admin-generated Key Credentials. */
export function linkResponderByKey({ key, keyCredential, username, password } = {}) {
  let user = username;
  let pass = password;
  const rawKey = keyCredential || key;

  if (rawKey && typeof rawKey === 'string') {
    const trimmed = rawKey.trim();
    if (trimmed.includes(':')) {
      const parts = trimmed.split(':');
      user = parts[0].trim();
      pass = parts.slice(1).join(':').trim();
    } else if (trimmed.includes(' ')) {
      const parts = trimmed.split(/\s+/);
      user = parts[0].trim();
      pass = parts.slice(1).join(' ').trim();
    } else {
      user = trimmed;
    }
  }

  if (!user || !pass) {
    throw new AuthError(400, 'Please enter the complete Key Credentials generated by Admin');
  }

  let account = get(
    `SELECT a.*, c.display_name AS created_by_name, c.role AS created_by_role
     FROM accounts a LEFT JOIN accounts c ON c.id = a.created_by
     WHERE LOWER(a.username) = LOWER(?)`,
    user
  );

  if (!account) {
    const unitMatch = get(
      `SELECT r.id FROM responders r WHERE LOWER(r.call_sign) = LOWER(?) OR LOWER(r.public_id) = LOWER(?)`,
      user, user
    );
    if (unitMatch) {
      account = get(
        `SELECT a.*, c.display_name AS created_by_name, c.role AS created_by_role
         FROM accounts a LEFT JOIN accounts c ON c.id = a.created_by
         WHERE a.responder_id = ?`,
        unitMatch.id
      );
    }
  }

  if (!account || !verifyPassword(pass, account.password_hash)) {
    throw new AuthError(401, 'Invalid Key Credentials. Check the key generated by Admin.');
  }

  const token = randomBytes(32).toString('hex');
  const created = nowIso();
  const expires = new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString();
  run(
    `INSERT INTO auth_sessions (token, account_id, created_at, expires_at) VALUES (?, ?, ?, ?)`,
    token, account.id, created, expires
  );
  run('UPDATE accounts SET last_login_at = ? WHERE id = ?', created, account.id);

  return {
    token,
    expiresAt: expires,
    account: serializeAccount(account)
  };
}
