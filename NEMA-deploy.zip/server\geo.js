/**
 * Geographic routing utilities
 * ---------------------------------------------------------------------------
 * Everything in this file is pure and unit-testable. The dispatch engine uses
 * three steps:
 *   1. radial candidate search (Haversine) around the incident,
 *   2. suitability score (distance + agency fit + unit readiness),
 *   3. route + ETA (OSRM when reachable, deterministic synthetic fallback).
 *
 * The synthetic fallback keeps the prototype fully functional offline and in
 * demo environments where public routing APIs are rate-limited.
 */

const EARTH_RADIUS_KM = 6371.0088;

export function toRad(deg) {
  return (deg * Math.PI) / 180;
}

export function toDeg(rad) {
  return (rad * 180) / Math.PI;
}

/** Great-circle distance in kilometres. */
export function haversineKm(a, b) {
  const lat1 = Number(a.lat);
  const lng1 = Number(a.lng);
  const lat2 = Number(b.lat);
  const lng2 = Number(b.lng);
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const h =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * EARTH_RADIUS_KM * Math.asin(Math.min(1, Math.sqrt(h)));
}

/** Initial bearing from point A to point B, degrees clockwise from north. */
export function bearingDeg(a, b) {
  const lat1 = toRad(a.lat);
  const lat2 = toRad(b.lat);
  const dLng = toRad(b.lng - a.lng);
  const y = Math.sin(dLng) * Math.cos(lat2);
  const x =
    Math.cos(lat1) * Math.sin(lat2) -
    Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLng);
  return (toDeg(Math.atan2(y, x)) + 360) % 360;
}

export function compass(deg) {
  const dirs = ['N', 'NE', 'E', 'SE', 'S', 'SW', 'W', 'NW'];
  return dirs[Math.round(((deg % 360) + 360) % 360 / 45) % 8];
}

/**
 * Traffic-aware ETA. 38 km/h is a realistic average for Lagos emergency
 * response outside of peak hours; the factor models congestion and turns.
 */
export function etaMinutes(distanceKm, speedKph = 38, trafficFactor = 1.28) {
  if (!Number.isFinite(distanceKm) || distanceKm <= 0) return 1;
  return Math.max(1, Math.round(((distanceKm * trafficFactor) / speedKph) * 60));
}

export function priorityForType(type, description = '') {
  const text = String(description).toLowerCase();
  const critical = /(unconscious|not breathing|cardiac|fire|trapped|weapon|gun|armed|child|bleeding)/;
  if (type === 'medical' || type === 'fire') return critical.test(text) ? 1 : 2;
  if (type === 'police') return critical.test(text) ? 1 : 2;
  if (type === 'road_safety') return critical.test(text) ? 2 : 3;
  return 2;
}

function offsetPoint(origin, bearing, distanceKm) {
  const R = EARTH_RADIUS_KM;
  const brng = toRad(bearing);
  const lat1 = toRad(origin.lat);
  const lng1 = toRad(origin.lng);
  const lat2 = Math.asin(
    Math.sin(lat1) * Math.cos(distanceKm / R) +
      Math.cos(lat1) * Math.sin(distanceKm / R) * Math.cos(brng)
  );
  const lng2 =
    lng1 +
    Math.atan2(
      Math.sin(brng) * Math.sin(distanceKm / R) * Math.cos(lat1),
      Math.cos(distanceKm / R) - Math.sin(lat1) * Math.sin(lat2)
    );
  return { lat: toDeg(lat2), lng: toDeg(lng2) };
}

/**
 * Builds a believable road-shaped polyline between two points. Real roads are
 * not straight, so we bow the path to the right by up to 7% of the trip and add
 * gentle S-curves. Deterministic: same input always produces the same route.
 */
export function syntheticRoute(from, to) {
  const directKm = haversineKm(from, to);
  const bearing = bearingDeg(from, to);
  const steps = Math.max(14, Math.min(48, Math.round(directKm * 4) + 14));
  const coords = [];
  const curvature = Math.min(0.085, 0.02 + directKm * 0.0045);
  for (let i = 0; i <= steps; i++) {
    const t = i / steps;
    // Main bow, strongest at the middle of the trip.
    const bow = Math.sin(t * Math.PI) * directKm * curvature;
    // Secondary wiggle so the line reads like streets, not an arc.
    const wiggle = Math.sin(t * Math.PI * 3.2) * directKm * 0.006;
    const p = offsetPoint(from, bearing + (bow + wiggle > 0 ? 90 : 270), Math.abs(bow + wiggle));
    // Linear interpolation along the direct bearing, then apply the offset.
    const base = {
      lat: from.lat + (to.lat - from.lat) * t,
      lng: from.lng + (to.lng - from.lng) * t
    };
    coords.push([
      Number((base.lng + (p.lng - offsetPoint(from, bearing, 0).lng)).toFixed(6)),
      Number((base.lat + (p.lat - offsetPoint(from, bearing, 0).lat)).toFixed(6))
    ]);
  }
  coords[0] = [Number(from.lng), Number(from.lat)];
  coords[coords.length - 1] = [Number(to.lng), Number(to.lat)];

  // Measure the curve we actually generated. Keeping this derived from the
  // geometry guarantees the distance drawn on the map always matches the
  // distance quoted in the ETA panel (a mismatch here would make the responder
  // progress bar and countdown disagree).
  const distanceKm = Math.max(directKm, routeLengthKm(coords));

  return {
    routeSource: 'synthetic',
    distanceKm: Number(distanceKm.toFixed(2)),
    durationMin: etaMinutes(distanceKm),
    geometry: { type: 'LineString', coordinates: coords },
    steps: buildSteps(coords, from, to, distanceKm)
  };
}

function streetNameFor(lat, lng, index) {
  const streets = [
    'Allen Avenue', 'Opebi Road', 'Awolowo Road', 'Admiralty Way',
    'Ozumba Mbadiwe Avenue', 'Ikorodu Road', 'Ahmadu Bello Way',
    'Bode Thomas Street', 'Marina Road', 'Third Mainland Bridge',
    'Airport Road', 'Ogunnusi Road', 'Lekki-Epe Expressway', 'Adeola Odeku Street'
  ];
  const hash = Math.abs(Math.round((lat * 10000 + lng * 10000 + index * 37))) % streets.length;
  return streets[hash];
}

export function buildSteps(coords, from, to, totalKm) {
  const destination = to.address || to.landmark || 'the incident location';
  const count = Math.min(6, Math.max(3, Math.round(totalKm)));
  const steps = [];
  for (let i = 0; i < count; i++) {
    const a = coords[Math.floor((i / count) * (coords.length - 1))];
    const b = coords[Math.floor(((i + 1) / count) * (coords.length - 1))];
    const brng = bearingDeg({ lat: a[1], lng: a[0] }, { lat: b[1], lng: b[0] });
    const segKm = haversineKm(
      { lat: a[1], lng: a[0] },
      { lat: b[1], lng: b[0] }
    );
    const street = streetNameFor(a[1], a[0], i);
    if (i === 0) {
      steps.push({
        instruction: `Head ${compass(brng)} on ${street} toward ${destination}`,
        distanceM: Math.round(segKm * 1000),
        direction: compass(brng),
        road: street
      });
    } else if (i === count - 1) {
      steps.push({
        instruction: `Arrive at ${destination}`,
        distanceM: 0,
        direction: compass(brng),
        road: street
      });
    } else {
      const turn = Math.sin(i * 1.7) > 0 ? 'right' : 'left';
      steps.push({
        instruction: `Turn ${turn} onto ${street}, continue ${Math.round(segKm * 1000)} m`,
        distanceM: Math.round(segKm * 1000),
        direction: turn,
        road: street
      });
    }
  }
  return steps;
}

/** Calls the public OSRM demo server; falls back without throwing. */
export async function fetchOsrmRoute(from, to) {
  const url =
    `https://router.project-osrm.org/route/v1/driving/` +
    `${from.lng},${from.lat};${to.lng},${to.lat}` +
    `?overview=full&geometries=geojson&steps=true`;
  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(2200) });
    if (!res.ok) throw new Error(`OSRM ${res.status}`);
    const data = await res.json();
    const route = data?.routes?.[0];
    if (!route?.geometry?.coordinates?.length) throw new Error('No OSRM route');
    const distanceKm = Number((route.distance / 1000).toFixed(2));
    const steps = (route.legs?.[0]?.steps || []).map((s) => ({
      instruction: `${s.maneuver?.type || 'Continue'}${s.name ? ` onto ${s.name}` : ''}`,
      distanceM: Math.round(s.distance || 0),
      direction: s.maneuver?.modifier || s.maneuver?.type || 'straight',
      road: s.name || ''
    }));
    return {
      routeSource: 'osrm',
      distanceKm,
      durationMin: Math.max(1, Math.round(route.duration / 60)),
      geometry: { type: 'LineString', coordinates: route.geometry.coordinates },
      steps: steps.length ? steps.slice(0, 10) : buildSteps(route.geometry.coordinates, from, to, distanceKm)
    };
  } catch {
    return syntheticRoute(from, to);
  }
}

/** Choose the best routing engine: OSRM when the network allows, else fallback. */
export async function buildRoute(from, to) {
  return process.env.DISABLE_OSRM === '1' ? syntheticRoute(from, to) : fetchOsrmRoute(from, to);
}

/** Get a point + bearing at progress t (0..1) along a GeoJSON LineString. */
export function pointAlongRoute(coordinates, t) {
  if (!coordinates?.length) return null;
  if (coordinates.length === 1) {
    return { lat: coordinates[0][1], lng: coordinates[0][0], heading: 0 };
  }
  const lengths = [];
  let total = 0;
  for (let i = 1; i < coordinates.length; i++) {
    const d = haversineKm(
      { lat: coordinates[i - 1][1], lng: coordinates[i - 1][0] },
      { lat: coordinates[i][1], lng: coordinates[i][0] }
    );
    lengths.push(d);
    total += d;
  }
  let target = Math.max(0, Math.min(1, t)) * total;
  for (let i = 0; i < lengths.length; i++) {
    if (target <= lengths[i] || i === lengths.length - 1) {
      const frac = lengths[i] === 0 ? 0 : target / lengths[i];
      const a = coordinates[i];
      const b = coordinates[i + 1];
      return {
        lat: a[1] + (b[1] - a[1]) * frac,
        lng: a[0] + (b[0] - a[0]) * frac,
        heading: bearingDeg({ lat: a[1], lng: a[0] }, { lat: b[1], lng: b[0] })
      };
    }
    target -= lengths[i];
  }
  const last = coordinates[coordinates.length - 1];
  return { lat: last[1], lng: last[0], heading: 0 };
}

/** Rank available units for an incident + agency. Lower score is better. */
export function rankResponders(responders, incident, agencyCode, { radiusKm = 30, limit = 5 } = {}) {
  return responders
    .filter((r) => r.status === 'available')
    .filter((r) => !agencyCode || r.agency_code === agencyCode || r.agencyCode === agencyCode)
    .map((r) => {
      const distanceKm = haversineKm(r, incident);
      const eta = etaMinutes(distanceKm);
      // serializeResponder exposes batteryPct; raw rows use battery_pct.
      const battery = r.batteryPct ?? r.battery_pct;
      const batteryPenalty = battery != null && battery < 20 ? 5 : 0;
      // Online + GPS-fresh units are measurably more trustworthy for a live
      // dispatch — tiny preference (0.1 score units) so proximity still wins.
      const syncPenalty = r.isGpsFresh ? 0 : 0.1;
      return {
        ...r,
        distanceKm: Number(distanceKm.toFixed(2)),
        etaMinutes: eta,
        score: Number((distanceKm + batteryPenalty + syncPenalty + (r.status === 'available' ? 0 : 10)).toFixed(3))
      };
    })
    .filter((r) => r.distanceKm <= radiusKm)
    .sort((a, b) => a.score - b.score)
    .slice(0, limit);
}

export function routeLengthKm(coordinates) {
  let total = 0;
  for (let i = 1; i < (coordinates?.length || 0); i++) {
    total += haversineKm(
      { lat: coordinates[i - 1][1], lng: coordinates[i - 1][0] },
      { lat: coordinates[i][1], lng: coordinates[i][0] }
    );
  }
  return total;
}

export function formatDistance(km) {
  return km < 1 ? `${Math.round(km * 1000)} m` : `${km.toFixed(1)} km`;
}
