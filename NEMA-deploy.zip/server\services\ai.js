/**
 * AI response agent.
 * ---------------------------------------------------------------------------
 * Protocol implementation:
 *   1. The AI agent sees the SOS location and assigns the incident to a state.
 *   2. It stays with the caller, providing safety support, until the first
 *      responder arrives or a human agent takes over.
 *   3. NEMA provides national oversight; the state EOC owns the local response.
 *
 * This is deliberately a deterministic, auditable rules engine rather than a
 * remote LLM call. It runs offline in the prototype and has no external data
 * dependency. The public functions are structured so an LLM/telephony gateway
 * can replace `supportReply` without changing the rest of the platform.
 */
import { all, get, run, addEvent, nowIso } from '../db.js';
import { stateForPoint, stateForCode, stateLabel, stateEocName, NEMA_NAME } from '../states.js';
import * as rt from './realtime.js';

export const AI_AGENT_NAME = 'ResQLink AI';
const MAX_MESSAGE = 1200;

const TYPE_LABEL = {
  medical: 'medical',
  police: 'police',
  fire: 'fire',
  road_safety: 'road safety',
  general: 'general emergency'
};

const TRIAGE = {
  medical: {
    agency: 'MEDICAL',
    answer: 'Hospital / ambulance',
    actions: [
      'Check the area is safe before you touch anyone.',
      'Check whether the person is breathing and responsive.',
      'If they are not breathing and you are trained, start CPR.',
      'Keep the person still and warm; do not give food or water.'
    ],
    safety: ['Do not move a suspected spinal injury unless there is immediate danger.', 'Clear space so the ambulance crew can reach the patient.'],
    chips: ['First aid steps', 'Send ambulance', 'Where is my help?', 'I am safe']
  },
  police: {
    agency: 'POLICE',
    answer: 'Police response',
    actions: [
      'Move away from the threat if you can do so safely.',
      'Hide, lock the door and silence your phone.',
      'Do not confront anyone or try to recover property.',
      'Note descriptions only when it is safe to look.'
    ],
    safety: ['Stay out of the line of sight.', 'Keep this page open but silent if you are hiding.'],
    chips: ['I am hiding', 'Send police', 'Where is my help?', 'I am safe']
  },
  fire: {
    agency: 'FIRE',
    answer: 'Fire and rescue',
    actions: [
      'Get everyone out and stay low under smoke.',
      'Close doors behind you if it is safe.',
      'Do not use lifts or go back inside for belongings.',
      'Move to a clear meeting point upwind of the fire.'
    ],
    safety: ['Do not open a door that is hot to the touch.', 'Keep away from gas cylinders and fuel.'],
    chips: ['We are outside', 'Send fire service', 'Where is my help?', 'Someone is trapped']
  },
  road_safety: {
    agency: 'ROAD_SAFETY',
    answer: 'Road safety / traffic response',
    actions: [
      'Move to the shoulder or behind a barrier if it is safe.',
      'Turn on hazard lights if you are in a vehicle.',
      'Do not move an injured person unless there is immediate danger.',
      'Warn approaching traffic without putting yourself in the road.'
    ],
    safety: ['Watch for secondary collisions.', 'Keep children and bystanders away from the carriageway.'],
    chips: ['We are on the shoulder', 'Send road safety', 'Where is my help?', 'Someone is injured']
  },
  general: {
    agency: 'GENERAL',
    answer: 'multi-agency assistance',
    actions: [
      'Move to a visible, safe place if you can.',
      'Keep your phone with you and answer calls from the command centre.',
      'Tell us if anyone is trapped, armed or injured.',
      'Follow the instructions of the first responder on scene.'
    ],
    safety: ['Do not approach fire, weapons or moving traffic.', 'Keep the line open unless it is unsafe to do so.'],
    chips: ['I am safe', 'Send help', 'Where is my help?', 'Add more detail']
  }
};

const INCIDENT_TYPE_ALIASES = {
  hospital: 'medical',
  ambulance: 'medical',
  other: 'general',
  others: 'general',
  sos: 'general'
};

export function normalizeIncidentType(type) {
  const value = String(type || '').toLowerCase();
  return INCIDENT_TYPE_ALIASES[value] || (TRIAGE[value] ? value : 'general');
}

export function triageFor({ type, description = '', hazards = [], state = null, priority = 2 } = {}) {
  const normalized = normalizeIncidentType(type);
  const config = TRIAGE[normalized];
  const p = Number(priority) || 2;
  const summary = String(description || '').trim() ||
    `Citizen requested ${TYPE_LABEL[normalized]} assistance${state ? ` in ${stateLabel(state)}` : ''}.`;
  return {
    type: normalized,
    severity: p === 1 ? 'critical' : p === 2 ? 'urgent' : 'routine',
    priority: p,
    recommendedAgency: config.agency,
    recommendedService: config.answer,
    summary,
    actions: config.actions,
    safety: config.safety,
    chips: config.chips,
    hazards: Array.isArray(hazards) ? hazards : []
  };
}

function nearestEta(incidentId) {
  const row = get(
    `SELECT ia.eta_minutes, ia.status, r.call_sign
     FROM incident_assignments ia
     JOIN responders r ON r.id = ia.responder_id
     WHERE ia.incident_id = ?
       AND ia.status IN ('alerting','accepted','en_route','on_scene','transporting')
     ORDER BY ia.eta_minutes ASC, ia.id ASC LIMIT 1`,
    Number(incidentId)
  );
  return row || null;
}

function getIncidentRow(incidentId) {
  return get('SELECT * FROM incidents WHERE id = ? OR code = ?', Number(incidentId), String(incidentId));
}

function getSessionRow(incidentId) {
  return get(
    `SELECT * FROM ai_sessions WHERE incident_id = (
       SELECT id FROM incidents WHERE id = ? OR code = ?
     )`,
    Number(incidentId), String(incidentId)
  );
}

function messageRow(row) {
  return {
    id: row.id,
    role: row.role,
    body: row.body,
    actions: safeJson(row.actions_json, []),
    createdAt: row.created_at
  };
}

function safeJson(value, fallback) {
  try { return JSON.parse(value); } catch { return fallback; }
}

export function serializeAiSession(row) {
  if (!row) return null;
  const state = stateForCode(row.state_code);
  const messages = all(
    'SELECT * FROM ai_messages WHERE session_id = ? ORDER BY created_at ASC, id ASC',
    row.id
  ).map(messageRow);
  return {
    id: row.id,
    incidentId: row.incident_id,
    mode: row.mode,
    status: row.mode === 'closed' ? 'closed' : row.mode === 'human' ? 'human' : 'active',
    agentName: row.agent_name,
    humanAgentName: row.human_agent_name,
    stateCode: row.state_code,
    stateName: stateLabel(state),
    stateZone: state?.zone || null,
    nema: NEMA_NAME,
    eoc: stateEocName(state),
    summary: row.summary,
    severity: row.severity,
    recommendedAgency: row.recommended_agency,
    routingReason: row.routing_reason,
    guidance: safeJson(row.guidance_json, {}),
    messages,
    createdAt: row.created_at,
    handoffAt: row.handoff_at,
    closedAt: row.closed_at
  };
}

export function getAiSession(incidentId) {
  return serializeAiSession(getSessionRow(incidentId));
}

function addAiMessage(sessionId, role, body, actions = [], at = null) {
  const timestamp = at || nowIso();
  const result = run(
    `INSERT INTO ai_messages (session_id, role, body, actions_json, created_at)
     VALUES (?, ?, ?, ?, ?)`,
    sessionId, role, String(body).slice(0, MAX_MESSAGE), JSON.stringify(actions), timestamp
  );
  return messageRow({
    id: Number(result.lastInsertRowid),
    role,
    body: String(body).slice(0, MAX_MESSAGE),
    actions_json: JSON.stringify(actions),
    created_at: timestamp
  });
}

function emitMessage(incidentId, sessionId, message, ai = null) {
  rt.emitAiMessage(incidentId, sessionId, message, ai);
}

/**
 * Open the AI support session. Safe to call repeatedly: it returns the
 * existing session if one is already open.
 */
export function startAiSupport(incidentId, { createdAt = null, silent = false } = {}) {
  const incident = getIncidentRow(incidentId);
  if (!incident) return null;
  const existing = getSessionRow(incident.id);
  if (existing) return serializeAiSession(existing);

  const state = stateForPoint(incident.lat, incident.lng) || stateForCode(incident.state_code);
  const type = normalizeIncidentType(incident.type);
  const hazards = safeJson(incident.hazards_json, []);
  const triage = triageFor({
    type,
    description: incident.description,
    hazards,
    state,
    priority: incident.priority
  });
  const at = createdAt || incident.created_at || nowIso();
  const routingReason = state
    ? `GPS ${Number(incident.lat).toFixed(4)}, ${Number(incident.lng).toFixed(4)} resolves to ${state.name}${state.code === 'FC' ? ' (FCT)' : ''} (${state.distanceKm ?? 0} km from the state reference point). Routed to ${stateEocName(state)} with NEMA national oversight.`
    : 'Location could not be resolved to a state; routed to the NEMA national desk.';

  const guidance = {
    actions: triage.actions,
    safety: triage.safety,
    chips: triage.chips,
    recommendedService: triage.recommendedService
  };

  const result = run(
    `INSERT INTO ai_sessions
       (incident_id, state_code, mode, agent_name, summary, severity, recommended_agency,
        routing_reason, guidance_json, created_at)
     VALUES (?, ?, 'ai', ?, ?, ?, ?, ?, ?, ?)`,
    incident.id, state?.code || 'FC', AI_AGENT_NAME, triage.summary, triage.severity,
    triage.recommendedAgency, routingReason, JSON.stringify(guidance), at
  );
  const sessionId = Number(result.lastInsertRowid);

  if (state && (!incident.state_code || incident.state_code === 'LA' && state.code !== 'LA')) {
    run('UPDATE incidents SET state_code = ?, state_name = ? WHERE id = ?', state.code, stateLabel(state), incident.id);
  }

  const intro =
    `I am ResQLink AI. I can see your location in ${state ? stateLabel(state) : 'Nigeria'}. ` +
    `I have assigned your ${TYPE_LABEL[type]} alert to ${state ? stateEocName(state) : 'the NEMA national desk'}, ` +
    `with ${NEMA_NAME} providing national oversight. I am also automatically sending the nearest available first responder to you right now, so help comes even if no operator is at the desk. A human agent can join at any time.`;
  const firstMessage = addAiMessage(sessionId, 'ai', intro,
    ['First aid steps', 'Where is my help?', 'I am safe'], at);
  const supportMessage = addAiMessage(
    sessionId,
    'ai',
    `While the first responder is on the way, do this now:\n${triage.actions.map((line, i) => `${i + 1}. ${line}`).join('\n')}`,
    triage.chips,
    new Date(new Date(at).getTime() + 1200).toISOString()
  );

  addEvent(incident.id, {
    type: 'ai_triage',
    actorType: 'system',
    actorId: AI_AGENT_NAME,
    message: `AI agent routed the incident to ${state ? stateLabel(state) : 'NEMA'} and opened caller support`,
    payload: {
      stateCode: state?.code || null,
      stateName: state ? stateLabel(state) : null,
      recommendedAgency: triage.recommendedAgency,
      severity: triage.severity
    }
  }, at);

  if (!silent) {
    emitMessage(incident.id, sessionId, firstMessage);
    emitMessage(incident.id, sessionId, supportMessage);
    rt.emitAiUpdate(incident.id, getAiSession(incident.id));
  }
  return getAiSession(incident.id);
}

export function ensureAiSupport(incidentId, options = {}) {
  const existing = getSessionRow(incidentId);
  if (existing) return serializeAiSession(existing);
  return startAiSupport(incidentId, options);
}

function humanReplyText(incident, ai) {
  if (!ai) return 'The AI support session is not available for this incident.';
  if (ai.mode === 'human') {
    return `${ai.humanAgentName || 'A human agent'} has taken over this conversation. Your message has reached the command centre.`;
  }
  if (ai.mode === 'closed') {
    return 'The AI support session is closed because a responder has arrived. The responding crew and command centre can still see this incident.';
  }
  return null;
}

export function supportReply({ incident, ai, body }) {
  const text = String(body || '').toLowerCase();
  const state = stateForCode(ai?.stateCode) || stateForPoint(incident.lat, incident.lng);
  const type = normalizeIncidentType(incident.type);
  const config = TRIAGE[type];
  const eta = nearestEta(incident.id);
  const assignmentLine = eta
    ? `${eta.call_sign} is ${eta.status === 'on_scene' ? 'on scene' : `responding, ETA ${Math.max(0, Math.round(eta.eta_minutes || 0))} min`}.`
    : `I am tracking the closest available unit for ${state ? stateLabel(state) : 'your state'}.`;

  if (/not breathing|no breath|stopped breathing|choking|choke/.test(text)) {
    return {
      body: `If the person is not breathing normally and you are trained, start chest compressions now. Put the heel of your hand in the centre of the chest, push hard and fast, and do not stop until help arrives. ${assignmentLine}`,
      actions: ['CPR guidance', 'Send ambulance now', 'I am safe']
    };
  }
  if (/bleed|blood/.test(text)) {
    return {
      body: `Apply firm, direct pressure to the wound with a clean cloth. Do not remove an object that is stuck in the wound. Keep the person still and warm. ${assignmentLine}`,
      actions: ['First aid steps', 'Send ambulance', 'Where is my help?']
    };
  }
  if (/burn|fire|smoke/.test(text)) {
    return {
      body: `Get away from the fire and smoke. Stay low, cover your nose and mouth, and do not go back inside. If clothing is burning, stop, drop and roll. ${assignmentLine}`,
      actions: ['We are outside', 'Send fire service', 'Someone is trapped']
    };
  }
  if (/gun|weapon|armed|robbery|shooting/.test(text)) {
    return {
      body: `Do not confront them. Move away, hide behind something solid and put your phone on silent. Keep this line open if you can do so without being seen. ${assignmentLine}`,
      actions: ['I am hiding', 'Send police', 'They are leaving']
    };
  }
  if (/child|baby|infant|pregnan/.test(text)) {
    return {
      body: `Keep the child warm and still. If the child is not breathing, start rescue breaths and chest compressions if you are trained. Tell the dispatcher the child's age and whether they are responsive. ${assignmentLine}`,
      actions: ['Child is breathing', 'Child is not breathing', 'Send ambulance']
    };
  }
  if (/safe|okay|ok\b|fine/.test(text)) {
    return {
      body: `Thank you for telling me. If you no longer need help, tap “I am safe” on the SOS screen so I can close the incident and release the responding units. If anything changes, stay on this line.`,
      actions: ['Close incident', 'I still need help']
    };
  }
  if (/where|eta|how long|help\?|coming/.test(text)) {
    return { body: assignmentLine, actions: ['Refresh status', 'Send another unit', 'I am safe'] };
  }
  if (/first aid|what do i do|help me|steps/.test(text)) {
    return {
      body: `Follow these steps: ${config.actions.join(' ')} ${assignmentLine}`,
      actions: config.chips
    };
  }
  if (/trapped|stuck/.test(text)) {
    return {
      body: `Do not move a trapped person unless there is immediate danger. Tell me what is trapping them and whether they are conscious. I am keeping the rescue crew updated. ${assignmentLine}`,
      actions: ['They are conscious', 'They are unconscious', 'Send fire service']
    };
  }
  if (/police|threat|attack/.test(text)) {
    return {
      body: `Move to a safe place and do not confront anyone. Keep your phone silent if you are hiding. ${assignmentLine}`,
      actions: ['I am hiding', 'Send police', 'I am safe']
    };
  }
  return {
    body: `I have added that to the incident record. ${assignmentLine} If the situation changes, tell me immediately: is anyone unconscious, trapped, armed or in immediate danger?`,
    actions: config.chips
  };
}

export function addCitizenAiMessage(incidentId, body) {
  const incident = getIncidentRow(incidentId);
  if (!incident) return null;
  let ai = getAiSession(incident.id) || startAiSupport(incident.id);
  if (!ai) return null;
  const clean = String(body || '').trim().slice(0, MAX_MESSAGE);
  if (!clean) return ai;
  const session = getSessionRow(incident.id);
  const userMessage = addAiMessage(session.id, 'user', clean, []);
  emitMessage(incident.id, session.id, userMessage, ai);

  const takeover = humanReplyText(incident, ai);
  if (takeover) {
    const reply = addAiMessage(session.id, 'system', takeover, []);
    emitMessage(incident.id, session.id, reply, getAiSession(incident.id));
    return getAiSession(incident.id);
  }

  const reply = supportReply({ incident, ai, body: clean });
  const aiMessage = addAiMessage(session.id, 'ai', reply.body, reply.actions);
  ai = getAiSession(incident.id);
  emitMessage(incident.id, session.id, aiMessage, ai);
  return ai;
}

export function takeOverFromAi(incidentId, agentName = 'Amina Okafor (NEMA)') {
  const incident = getIncidentRow(incidentId);
  if (!incident) return null;
  const ai = getAiSession(incident.id) || startAiSupport(incident.id);
  const session = getSessionRow(incident.id);
  const at = nowIso();
  run(
    `UPDATE ai_sessions SET mode = 'human', human_agent_name = ?, handoff_at = COALESCE(handoff_at, ?)
     WHERE id = ?`,
    agentName, at, session.id
  );
  run('UPDATE incidents SET human_agent_name = ?, human_takeover_at = ? WHERE id = ?', agentName, at, incident.id);
  const message = addAiMessage(
    session.id,
    'human',
    `${agentName} has joined the line. I am a human emergency agent; I can see your location and the AI's notes. Keep this page open.`,
    []
  );
  addEvent(incident.id, {
    type: 'human_takeover',
    actorType: 'dispatcher',
    actorId: agentName,
    message: `${agentName} took over caller support from the AI agent`,
    payload: { aiSessionId: session.id }
  }, at);
  const updated = getAiSession(incident.id);
  emitMessage(incident.id, session.id, message, updated);
  rt.emitAiUpdate(incident.id, updated);
  return updated;
}

export function releaseToAi(incidentId) {
  const incident = getIncidentRow(incidentId);
  if (!incident) return null;
  const session = getSessionRow(incident.id);
  if (!session) return null;
  const at = nowIso();
  run(`UPDATE ai_sessions SET mode = 'ai', human_agent_name = NULL, handoff_at = ? WHERE id = ?`, at, session.id);
  run('UPDATE incidents SET human_agent_name = NULL, human_takeover_at = NULL WHERE id = ?', incident.id);
  const message = addAiMessage(session.id, 'ai', 'The human agent has handed the line back to me. I am still tracking your incident and will stay with you until a responder arrives.', []);
  addEvent(incident.id, {
    type: 'ai_resumed', actorType: 'system', actorId: AI_AGENT_NAME,
    message: 'Caller support returned to the AI agent', payload: {}
  }, at);
  const updated = getAiSession(incident.id);
  emitMessage(incident.id, session.id, message, updated);
  rt.emitAiUpdate(incident.id, updated);
  return updated;
}

export function addHumanAiMessage(incidentId, { body, agentName = 'Amina Okafor (NEMA)' } = {}) {
  const incident = getIncidentRow(incidentId);
  if (!incident) return null;
  const session = getSessionRow(incident.id);
  if (!session) return null;
  const clean = String(body || '').trim().slice(0, MAX_MESSAGE);
  if (!clean) return getAiSession(incident.id);
  const message = addAiMessage(session.id, 'human', clean, []);
  const updated = getAiSession(incident.id);
  emitMessage(incident.id, session.id, message, updated);
  return updated;
}

/** Called by the dispatch service the instant a responder reaches the scene. */
export function handoffOnScene(incidentId, responderName = 'First responder') {
  const incident = getIncidentRow(incidentId);
  if (!incident) return null;
  const session = getSessionRow(incident.id);
  if (!session || session.mode === 'closed') return getAiSession(incident.id);
  const at = nowIso();
  run(
    `UPDATE ai_sessions SET mode = 'closed', handoff_at = COALESCE(handoff_at, ?), closed_at = ? WHERE id = ?`,
    at, at, session.id
  );
  const message = addAiMessage(
    session.id,
    'system',
    `${responderName} has arrived on scene. AI caller support is now handed to the responding crew and the human agent at the command centre.`,
    []
  );
  addEvent(incident.id, {
    type: 'ai_handoff', actorType: 'system', actorId: AI_AGENT_NAME,
    message: `AI support handed to ${responderName} on scene`, payload: {}
  }, at);
  const updated = getAiSession(incident.id);
  emitMessage(incident.id, session.id, message, updated);
  rt.emitAiUpdate(incident.id, updated);
  return updated;
}

export function closeAiSupport(incidentId, note = 'Incident closed') {
  const incident = getIncidentRow(incidentId);
  if (!incident) return null;
  const session = getSessionRow(incident.id);
  if (!session) return null;
  const at = nowIso();
  run(`UPDATE ai_sessions SET mode = 'closed', closed_at = COALESCE(closed_at, ?) WHERE id = ?`, at, session.id);
  addAiMessage(session.id, 'system', `${note}. The AI support session is closed.`, [], at);
  const updated = getAiSession(incident.id);
  rt.emitAiUpdate(incident.id, updated);
  return updated;
}

/** Push a system note from the AI into the caller thread (e.g. auto-dispatch). */
export function pushAiNote(incidentId, body, actions = []) {
  const incident = getIncidentRow(incidentId);
  if (!incident) return null;
  const session = getSessionRow(incident.id);
  if (!session) return null;
  const message = addAiMessage(session.id, 'ai', body, actions);
  const updated = getAiSession(incident.id);
  emitMessage(incident.id, session.id, message, updated);
  return updated;
}

export function getAiStats({ stateCode = null } = {}) {
  const stateClause = stateCode ? 'WHERE a.state_code = ?' : '';
  const params = stateCode ? [stateCode] : [];
  const active = get(
    `SELECT COUNT(*) AS c FROM ai_sessions a JOIN incidents i ON i.id = a.incident_id
     ${stateClause ? `${stateClause} AND` : 'WHERE'} a.mode IN ('ai','human')
       AND i.status NOT IN ('resolved','cancelled')`,
    ...params
  ).c;
  const human = get(
    `SELECT COUNT(*) AS c FROM ai_sessions a JOIN incidents i ON i.id = a.incident_id
     ${stateClause ? `${stateClause} AND` : 'WHERE'} a.mode = 'human'
       AND i.status NOT IN ('resolved','cancelled')`,
    ...params
  ).c;
  const routedToday = get(
    `SELECT COUNT(*) AS c FROM ai_sessions a
     ${stateClause ? `${stateClause} AND` : 'WHERE'} date(a.created_at) = date('now')`,
    ...params
  ).c;
  return { activeSessions: active, humanTakeovers: human, routedToday };
}
