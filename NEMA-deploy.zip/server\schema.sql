-- ============================================================================
-- NaijaSOS / ResQLink — relational schema (SQLite dialect)
-- ----------------------------------------------------------------------------
-- The same shape maps 1:1 to PostgreSQL. For production, swap AUTOINCREMENT for
-- GENERATED ALWAYS AS IDENTITY, TEXT timestamps for TIMESTAMPTZ, and JSON text
-- columns for JSONB. All coordinates are WGS84 (EPSG:4326).
-- ============================================================================

PRAGMA foreign_keys = ON;

-- People using the platform: citizens, dispatchers, field responders, admins.
CREATE TABLE IF NOT EXISTS users (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id       TEXT UNIQUE NOT NULL,
  role            TEXT NOT NULL CHECK (role IN ('citizen','dispatcher','responder','admin')),
  full_name       TEXT NOT NULL,
  phone           TEXT UNIQUE,
  email           TEXT UNIQUE,
  password_hash   TEXT,                    -- demo only; use Argon2id in production
  created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_seen_at    TEXT
);

-- One login page, three tenant roles:
--   nema       national administrator: creates and manages state EOC logins
--   state      state counterpart: sees only its state, provisions responder logins
--   responder  field responder: sees only its own unit and assignments
-- State accounts cannot sign in as responders. NEMA cannot sign in as a state.
CREATE TABLE IF NOT EXISTS accounts (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  username        TEXT UNIQUE NOT NULL,
  password_hash   TEXT NOT NULL,
  role            TEXT NOT NULL CHECK (role IN ('superadmin','nema','state','responder')),
  display_name    TEXT NOT NULL,
  state_code      TEXT,
  responder_id    INTEGER UNIQUE,
  status          TEXT NOT NULL DEFAULT 'active'
                  CHECK (status IN ('active','suspended')),
  created_by      INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
  created_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  last_login_at   TEXT
);

CREATE TABLE IF NOT EXISTS auth_sessions (
  token       TEXT PRIMARY KEY,
  account_id  INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  expires_at  TEXT NOT NULL,
  last_seen_at TEXT
);

-- NEMA issues short one-time access codes for state EOC staff. A code opens the
-- state dashboard without sharing the account password, expires quickly and
-- can only be redeemed once.
CREATE TABLE IF NOT EXISTS access_codes (
  code        TEXT PRIMARY KEY,
  account_id  INTEGER NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
  created_by  INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  expires_at  TEXT NOT NULL,
  used_at     TEXT,
  used_ip     TEXT
);

-- National agencies that operate state commands (Police, Fire, Hospital,
-- Road Safety) plus the community/other responder pool.
CREATE TABLE IF NOT EXISTS agencies (
  id                INTEGER PRIMARY KEY AUTOINCREMENT,
  code              TEXT UNIQUE NOT NULL CHECK (code IN ('POLICE','MEDICAL','FIRE','ROAD_SAFETY','GENERAL')),
  name              TEXT NOT NULL,
  short_name        TEXT NOT NULL,
  jurisdiction      TEXT NOT NULL,         -- e.g. Nigeria (national) or Lagos State
  emergency_number  TEXT,
  color             TEXT NOT NULL DEFAULT '#ff5540',
  icon              TEXT NOT NULL DEFAULT 'emergency',
  is_active         INTEGER NOT NULL DEFAULT 1,
  created_at        TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- First responders register to use the network. Approval provisions a field
-- unit (see services/registrations.js). Official agencies verify their crews;
-- community responders are verified by the state EOC.
CREATE TABLE IF NOT EXISTS registrations (
  id                 INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id          TEXT UNIQUE NOT NULL,       -- REG-0001
  full_name          TEXT NOT NULL,
  phone              TEXT NOT NULL,
  email              TEXT,
  responder_kind     TEXT NOT NULL
                     CHECK (responder_kind IN ('car','ambulance','police','fire','hospital','road_safety','other')),
  agency_code        TEXT NOT NULL DEFAULT 'GENERAL'
                     CHECK (agency_code IN ('POLICE','MEDICAL','FIRE','ROAD_SAFETY','GENERAL')),
  state_code         TEXT NOT NULL,              -- LA, FC, RI, ...
  vehicle_type       TEXT NOT NULL,
  plate_number       TEXT,
  callsign_requested TEXT,
  status             TEXT NOT NULL DEFAULT 'pending'
                     CHECK (status IN ('pending','approved','rejected')),
  verified_by        TEXT,
  reviewer_note      TEXT,
  responder_id       INTEGER,
  created_at         TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  reviewed_at        TEXT
);

-- A responder is a dispatchable FIELD UNIT (vehicle + crew), linked to a user.
CREATE TABLE IF NOT EXISTS responders (
  id              INTEGER PRIMARY KEY AUTOINCREMENT,
  public_id       TEXT UNIQUE NOT NULL,    -- stable API id, e.g. AMB-04
  user_id         INTEGER REFERENCES users(id) ON DELETE SET NULL,
  agency_id       INTEGER NOT NULL REFERENCES agencies(id),
  call_sign       TEXT UNIQUE NOT NULL,   -- e.g. AMB-04
  vehicle_type    TEXT NOT NULL,           -- ambulance | patrol | fire_engine | traffic_van | private_car
  responder_kind  TEXT NOT NULL DEFAULT 'ambulance'
                  CHECK (responder_kind IN ('car','ambulance','police','fire','hospital','road_safety','other')),
  state_code      TEXT NOT NULL DEFAULT 'LA',
  plate_number    TEXT,
  station         TEXT NOT NULL,
  status          TEXT NOT NULL DEFAULT 'available'
                  CHECK (status IN ('available','dispatched','en_route','on_scene','transporting','returning','offline')),
  lat             REAL NOT NULL,
  lng             REAL NOT NULL,
  heading         REAL NOT NULL DEFAULT 0,
  speed_kph       REAL NOT NULL DEFAULT 0,
  shift_code      TEXT NOT NULL DEFAULT 'A',
  battery_pct     INTEGER,
  is_simulated    INTEGER NOT NULL DEFAULT 1,
  is_community    INTEGER NOT NULL DEFAULT 0,
  registration_id INTEGER,
  verified_at     TEXT,
  updated_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- The core alert record. `code` is the human-readable incident reference.
CREATE TABLE IF NOT EXISTS incidents (
  id                    INTEGER PRIMARY KEY AUTOINCREMENT,
  code                  TEXT UNIQUE NOT NULL,      -- INC-8492-LGS
  reporter_user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
  reporter_name         TEXT,
  reporter_phone        TEXT,
  type                  TEXT NOT NULL CHECK (type IN ('medical','police','fire','road_safety','general')),
  priority              INTEGER NOT NULL DEFAULT 2 CHECK (priority BETWEEN 1 AND 4),
  status                TEXT NOT NULL DEFAULT 'new'
                        CHECK (status IN ('new','triage','dispatched','en_route','on_scene','transporting','resolved','cancelled')),
  lat                   REAL NOT NULL,
  lng                   REAL NOT NULL,
  accuracy_m            REAL,
  address               TEXT,
  landmark              TEXT,
  state_code            TEXT NOT NULL DEFAULT 'LA',
  state_name            TEXT NOT NULL DEFAULT 'Lagos',
  human_agent_name      TEXT,
  human_takeover_at     TEXT,
  description           TEXT,
  hazards_json          TEXT NOT NULL DEFAULT '[]', -- JSON array of hazard strings
  photo_path            TEXT,                      -- citizen SOS scene photo (relative to data/)
  people_affected       INTEGER NOT NULL DEFAULT 1,
  source                TEXT NOT NULL DEFAULT 'app'
                        CHECK (source IN ('app','phone','partner','iot','sms')),
  live_tracking         INTEGER NOT NULL DEFAULT 0,
  created_by_role       TEXT NOT NULL DEFAULT 'citizen',
  assigned_dispatcher_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
  created_at            TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  acknowledged_at       TEXT,
  dispatched_at         TEXT,
  arrived_at            TEXT,
  resolved_at           TEXT
);

-- The AI agent opens a support session as soon as an SOS is routed to a
-- state. It stays with the caller until a human dispatcher takes over or the
-- first responder arrives. The transcript is an auditable part of the incident.
CREATE TABLE IF NOT EXISTS ai_sessions (
  id                  INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id         INTEGER UNIQUE NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  state_code          TEXT NOT NULL,
  mode                TEXT NOT NULL DEFAULT 'ai'
                      CHECK (mode IN ('ai','human','closed')),
  agent_name          TEXT NOT NULL DEFAULT 'ResQLink AI',
  summary             TEXT,
  severity            TEXT,
  recommended_agency  TEXT,
  routing_reason      TEXT,
  guidance_json       TEXT NOT NULL DEFAULT '{}',
  human_agent_name    TEXT,
  created_at          TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  handoff_at          TEXT,
  closed_at           TEXT
);

CREATE TABLE IF NOT EXISTS ai_messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  session_id  INTEGER NOT NULL REFERENCES ai_sessions(id) ON DELETE CASCADE,
  role        TEXT NOT NULL CHECK (role IN ('ai','user','system','human')),
  body        TEXT NOT NULL,
  actions_json TEXT NOT NULL DEFAULT '[]',
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- One incident can require several agencies and several units.
CREATE TABLE IF NOT EXISTS incident_assignments (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id    INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  responder_id   INTEGER NOT NULL REFERENCES responders(id) ON DELETE CASCADE,
  agency_id      INTEGER NOT NULL REFERENCES agencies(id),
  status         TEXT NOT NULL DEFAULT 'alerting'
                 CHECK (status IN ('alerting','accepted','declined','en_route','on_scene','transporting','completed','cancelled')),
  distance_km    REAL,
  eta_minutes    REAL,
  progress       REAL NOT NULL DEFAULT 0,  -- 0..1 along route_json
  route_json     TEXT,                     -- GeoJSON LineString
  steps_json     TEXT,                     -- turn-by-turn instruction array
  route_source   TEXT DEFAULT 'synthetic', -- osrm | synthetic
  assigned_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  accepted_at    TEXT,
  arrived_at     TEXT,
  completed_at   TEXT,
  decline_reason TEXT,
  UNIQUE (incident_id, responder_id)
);

-- Append-only incident timeline. Great for audits and realtime replay.
CREATE TABLE IF NOT EXISTS incident_events (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  type        TEXT NOT NULL,                -- created | acknowledged | dispatched | accepted | en_route | on_scene | resolved | note
  actor_type  TEXT NOT NULL DEFAULT 'system', -- citizen | dispatcher | responder | system
  actor_id    TEXT,
  message     TEXT NOT NULL,
  payload_json TEXT NOT NULL DEFAULT '{}',
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Two-way chat between citizen / command centre / field unit. Also holds
-- pinned dispatcher notes (channel = 'note') for simple read performance.
CREATE TABLE IF NOT EXISTS incident_messages (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  channel     TEXT NOT NULL DEFAULT 'chat' CHECK (channel IN ('chat','note','system')),
  sender_type TEXT NOT NULL CHECK (sender_type IN ('citizen','dispatcher','responder','system')),
  sender_id   TEXT,
  sender_name TEXT NOT NULL,
  body        TEXT NOT NULL,
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Dispatcher notes kept separately so they can be pinned, edited and audited.
CREATE TABLE IF NOT EXISTS incident_notes (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  author_id   TEXT,
  author_name TEXT NOT NULL,
  body        TEXT NOT NULL,
  pinned      INTEGER NOT NULL DEFAULT 0,
  created_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Live stream / snapshot session metadata. Media itself should live in S3 /
-- object storage in production, not in SQLite.
CREATE TABLE IF NOT EXISTS media_sessions (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id   INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  kind          TEXT NOT NULL CHECK (kind IN ('video','audio','snapshot','composite')),
  producer_type TEXT NOT NULL,
  producer_id   TEXT,
  status        TEXT NOT NULL DEFAULT 'live' CHECK (status IN ('requested','live','ended','failed')),
  started_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  ended_at      TEXT
);

-- State EOC call engagement. Every SOS opens one call session; the responsible
-- state claims it, stays on the line until the first responder reaches the
-- scene, and the recording is retained for NEMA / Super Admin observation.
CREATE TABLE IF NOT EXISTS call_sessions (
  id             INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id    INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  state_code     TEXT NOT NULL,
  status         TEXT NOT NULL DEFAULT 'ringing'
                 CHECK (status IN ('ringing','connected','ended','missed')),
  claimed_by     INTEGER REFERENCES accounts(id) ON DELETE SET NULL,
  claimed_by_name TEXT,
  claimed_at     TEXT,
  connected_at   TEXT,
  ended_at       TEXT,
  end_reason     TEXT,
  citizen_name   TEXT,
  created_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Audio recordings made in the citizen browser during the emergency call.
-- Chunks are appended to a file under data/recordings and only the metadata
-- lives in SQLite (the same pattern used for media in production object store).
CREATE TABLE IF NOT EXISTS incident_recordings (
  id               INTEGER PRIMARY KEY AUTOINCREMENT,
  incident_id      INTEGER NOT NULL REFERENCES incidents(id) ON DELETE CASCADE,
  call_session_id  INTEGER REFERENCES call_sessions(id) ON DELETE SET NULL,
  state_code       TEXT NOT NULL,
  source           TEXT NOT NULL DEFAULT 'citizen',
  mime_type        TEXT,
  file_name        TEXT NOT NULL,
  file_path        TEXT NOT NULL,
  bytes            INTEGER NOT NULL DEFAULT 0,
  duration_seconds REAL,
  status           TEXT NOT NULL DEFAULT 'recording'
                    CHECK (status IN ('recording','ready','failed')),
  recorded_by      TEXT,
  created_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
  updated_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

-- Time-series GPS breadcrumbs. In production use PostGIS + partitioning or a
-- time-series store such as TimescaleDB.
CREATE TABLE IF NOT EXISTS responder_locations (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  responder_id INTEGER NOT NULL REFERENCES responders(id) ON DELETE CASCADE,
  incident_id  INTEGER REFERENCES incidents(id) ON DELETE SET NULL,
  lat          REAL NOT NULL,
  lng          REAL NOT NULL,
  heading      REAL,
  speed_kph    REAL,
  recorded_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now'))
);

CREATE INDEX IF NOT EXISTS idx_incidents_status       ON incidents(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_accounts_role          ON accounts(role, state_code);
CREATE INDEX IF NOT EXISTS idx_auth_sessions_account  ON auth_sessions(account_id, expires_at);
CREATE INDEX IF NOT EXISTS idx_access_codes_account   ON access_codes(account_id, expires_at);
CREATE INDEX IF NOT EXISTS idx_incidents_created      ON incidents(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_incidents_state        ON incidents(state_code, status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ai_sessions_incident    ON ai_sessions(incident_id);
CREATE INDEX IF NOT EXISTS idx_ai_messages_session     ON ai_messages(session_id, created_at);
CREATE INDEX IF NOT EXISTS idx_registrations_status   ON registrations(status, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_assignments_incident   ON incident_assignments(incident_id, status);
CREATE INDEX IF NOT EXISTS idx_assignments_responder  ON incident_assignments(responder_id, status);
CREATE INDEX IF NOT EXISTS idx_events_incident        ON incident_events(incident_id, created_at);
CREATE INDEX IF NOT EXISTS idx_messages_incident      ON incident_messages(incident_id, created_at);
CREATE INDEX IF NOT EXISTS idx_notes_incident         ON incident_notes(incident_id, created_at);
CREATE INDEX IF NOT EXISTS idx_responders_status      ON responders(status, agency_id);
CREATE INDEX IF NOT EXISTS idx_responders_state       ON responders(state_code, status);
CREATE INDEX IF NOT EXISTS idx_responder_locations    ON responder_locations(responder_id, recorded_at DESC);
CREATE INDEX IF NOT EXISTS idx_call_sessions_incident ON call_sessions(incident_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_recordings_incident    ON incident_recordings(incident_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_recordings_session     ON incident_recordings(call_session_id);
