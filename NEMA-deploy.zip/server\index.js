import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';
import { Server as SocketServer } from 'socket.io';
import dotenv from 'dotenv';
import { AccessToken } from 'livekit-server-sdk';

dotenv.config();

import { seedDatabase } from './seed.js';
import {
  HttpError, getBootstrap, getAgencies, getResponders, getResponder, getUnitDetail,
  listIncidents, getIncidentDetail, createIncident, acknowledgeIncident, updateIncident,
  updateIncidentLocation, getCandidates, getNearestUnits, assignUnit, aiAutoDispatch, responderSelfAssign, acceptAssignment, declineAssignment,
  updateAssignmentStatus, resolveIncident, addChatMessage, addNote, updateUnitStatus,
  updateUnitLocation, getStats, getCoverage, getAssignment
} from './services/incidents.js';
import {
  getAiSession, ensureAiSupport, addCitizenAiMessage, takeOverFromAi, releaseToAi,
  addHumanAiMessage, getAiStats
} from './services/ai.js';
import {
  createRegistration, listRegistrations, getRegistration, reviewRegistration,
  getRegistrationStats, RESPONDER_KINDS, RegistrationError
} from './services/registrations.js';
import {
  AuthError, authenticate, accountForToken, revokeSession, createAccount,
  nemaAccounts, stateAccounts, responderAccounts, resetAccountPassword, provisionResponderLogin,
  serializeAccount, generatePassword, linkResponderByKey, hashPassword,
  issueStateAccessCode, redeemAccessCode
} from './services/auth.js';
import {
  startCall, claimCall, endCall, createRecording, appendRecordingChunk, finishRecording,
  listRecordings, getRecordingRow, getRecordingWithIncident, getRecordingPath, getCallDetail
} from './services/calls.js';
import { run, get, all } from './db.js';
import { listStates, stateForCode } from './states.js';
import { startSimulation, stopSimulation } from './services/simulation.js';
import * as rt from './services/realtime.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const publicDir = path.join(__dirname, '..', 'public');
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
const PORT = Number(process.env.PORT) || 4000;

// Demo seeding is opt-in: the live database now starts with real data and only
// the Super Admin login. Run `npm run seed` explicitly (or SEED_DEMO=1) to load
// the sample fleet and incidents again.
if (process.env.SEED_DEMO === '1') seedDatabase();

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '2mb' }));
app.use((req, _res, next) => {
  const header = req.headers.authorization || '';
  let token = header.startsWith('Bearer ') ? header.slice(7).trim() : null;
  // <img>/<video> cannot set headers. Media endpoints accept the session token
  // as a query parameter for GET requests only.
  if (!token && req.method === 'GET' && typeof req.query.token === 'string') {
    token = req.query.token.trim();
  }
  req.token = token;
  req.account = token ? accountForToken(token) : null;
  next();
});
const ROLE_LABELS = {
  superadmin: 'Super Admin',
  nema: 'NEMA National Command',
  state: 'State EOC',
  responder: 'First Responder'
};
const requireRole = (...roles) => (req, _res, next) => {
  if (!req.account) return next(new AuthError(401, 'Sign in to continue'));
  if (roles.length && !roles.includes(req.account.role)) {
    if (req.account.role === 'superadmin' && (roles.includes('nema') || roles.includes('state') || roles.includes('superadmin'))) {
      return next();
    }
    const current = ROLE_LABELS[req.account.role] || req.account.role;
    const required = [...new Set(roles.map((role) => ROLE_LABELS[role] || role))];
    return next(new AuthError(
      403,
      `This account is signed in to the ${current} workspace, which cannot perform this action. Sign in as ${required.join(' or ')}.`
    ));
  }
  next();
};
const accountState = (req) => req.account?.stateCode || req.account?.responder?.stateCode || null;
const STAFF_ROLES = ['state', 'nema', 'superadmin'];

/**
 * Citizen call/recording endpoints are intentionally usable without a login
 * (the caller is not signed in), but they must prove possession of the incident
 * code shown on their tracker. Signed-in state/NEMA/Super Admin staff bypass
 * the code check and are tenant-scoped by incidentForRequest().
 */
function assertCitizenCode(req, incident) {
  if (req.account && STAFF_ROLES.includes(req.account.role)) return;
  const supplied = req.body?.code || req.query?.code || req.headers['x-incident-code'];
  if (!supplied || String(supplied).toUpperCase() !== String(incident.code).toUpperCase()) {
    throw new HttpError(403, 'The incident code does not match');
  }
}

/**
 * Tenant-scoped incident access. NEMA sees the whole country; a state account
 * sees only its own state; a responder sees only incidents it has been
 * assigned. Public citizen calls are allowed to read a detail by code so the
 * citizen tracker can refresh, but never to perform a command action.
 */
function incidentForRequest(req, id, { write = false } = {}) {
  const incident = getIncidentDetail(id);
  if (!incident) throw new HttpError(404, 'Incident not found');
  if (!req.account) {
    if (write) throw new HttpError(401, 'Sign in to perform this action');
    return incident;
  }
  if (req.account.role === 'nema' || req.account.role === 'superadmin') return incident;
  if (req.account.role === 'state') {
    if (incident.stateCode !== accountState(req)) {
      throw new HttpError(403, 'That incident belongs to another state');
    }
    return incident;
  }
  if (req.account.role === 'responder') {
    const unitId = req.account.responder?.id;
    const mine = incident.assignments?.some((a) => a.responderId === unitId);
    if (!mine) throw new HttpError(403, 'That incident is not assigned to your unit');
    return incident;
  }
  if (write) throw new HttpError(403, 'This account cannot change an incident');
  return incident;
}
app.use((req, _res, next) => {
  if (req.path.startsWith('/api')) {
    console.log(`${new Date().toISOString()} ${req.method} ${req.path}`);
  }
  next();
});

// ---------------------------------------------------------------------------
// Static interfaces
// ---------------------------------------------------------------------------
app.use(express.static(publicDir, {
  extensions: ['html'],
  maxAge: 0,
  setHeaders: (res) => {
    res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
    res.setHeader('Pragma', 'no-cache');
    res.setHeader('Expires', '0');
  }
}));

const sendNoCache = (res, file) => {
  res.setHeader('Cache-Control', 'no-cache, no-store, must-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  res.sendFile(path.join(publicDir, file));
};

app.get('/', (_req, res) => sendNoCache(res, 'index.html'));
app.get('/admin', (_req, res) => sendNoCache(res, 'admin.html'));
app.get('/dispatch', (_req, res) => sendNoCache(res, 'dispatch.html'));
app.get('/nema', (_req, res) => sendNoCache(res, 'dispatch.html'));
app.get('/state', (_req, res) => sendNoCache(res, 'dispatch.html'));
app.get('/responder', (_req, res) => sendNoCache(res, 'responder.html'));
app.get('/citizen', (_req, res) => sendNoCache(res, 'index.html'));
app.get('/protocol', (_req, res) => sendNoCache(res, 'protocol.html'));
app.get('/register', (_req, res) => sendNoCache(res, 'register.html'));
app.get('/login', (_req, res) => sendNoCache(res, 'login.html'));
// Direct role links keep the first-responder and state workspaces easy to reach
// without relying on the user remembering which tab to select.
app.get('/login/admin', (_req, res) => res.redirect('/login?role=superadmin'));
app.get('/login/superadmin', (_req, res) => res.redirect('/login?role=superadmin'));
app.get('/login/nema', (_req, res) => res.redirect('/login?role=nema'));
app.get('/login/state', (_req, res) => res.redirect('/login?role=state'));
app.get('/login/responder', (_req, res) => res.redirect('/login?role=responder'));

// ---------------------------------------------------------------------------
// REST API
// ---------------------------------------------------------------------------
const wrap = (handler) => (req, res, next) => {
  Promise.resolve(handler(req, res, next)).catch(next);
};

app.get('/api/health', (_req, res) => {
  res.json({
    ok: true,
    service: 'naijasos-resqlink',
    time: new Date().toISOString(),
    stats: getStats()
  });
});

// ---------------------------------------------------------------------------
// Authentication + account provisioning
// ---------------------------------------------------------------------------
app.post('/api/auth/login', (req, res) => {
  const session = authenticate({
    role: req.body?.role,
    username: req.body?.username,
    password: req.body?.password,
    stateCode: req.body?.stateCode || null
  });
  res.json(session);
});

// State staff can redeem a NEMA-issued one-time access code instead of a
// username/password. This opens the State EOC dashboard directly.
app.post('/api/auth/access-code', (req, res) => {
  const session = redeemAccessCode(req.body?.code, { ip: req.ip });
  res.json(session);
});

app.get('/api/auth/me', (req, res) => {
  if (!req.account) return res.status(401).json({ error: 'Not signed in' });
  res.json({ account: req.account });
});

app.post('/api/auth/logout', (req, res) => {
  revokeSession(req.token);
  res.json({ ok: true });
});

app.get('/api/auth/demo', (_req, res) => {
  // Publish the Super Admin bootstrap login.
  // For demo builds: also expose registered responder credentials (username + temp password)
  // so the login quick-card can populate the form automatically.
  const respAccounts = responderAccounts();
  const responderDemos = respAccounts.slice(0, 3).map((a) => ({
    username: a.username,
    password: a.tempPassword || null,
    callSign: a.responder?.callSign || a.displayName,
    stateCode: a.stateCode
  }));
  res.json({
    roles: [
      { code: 'nema', label: 'NEMA National Admin', detail: 'Creates and governs state counterpart logins' },
      { code: 'state', label: 'State Counterpart', detail: 'Runs one state EOC and creates responder logins' },
      { code: 'responder', label: 'First Responder', detail: 'Field dashboard for one registered unit' }
    ],
    demo: {
      states: [],
      responders: responderDemos
    }
  });
});

// ---------------------------------------------------------------------------
// Super Admin / Central Backend: Entity Registration & System Infrastructure
// ---------------------------------------------------------------------------
app.get('/api/admin/overview', requireRole('superadmin'), (_req, res) => {
  const nAccounts = nemaAccounts();
  const sAccounts = stateAccounts();
  const allStates = listStates();
  const responders = getResponders();
  const regStats = getRegistrationStats();
  res.json({
    nemaAccountsCount: nAccounts.length,
    stateAccountsCount: sAccounts.length,
    totalStates: allStates.length,
    respondersCount: responders.length,
    pendingRegistrations: regStats.pending,
    approvedRegistrations: regStats.approved,
    liveIncidents: getStats().activeIncidents
  });
});

app.get('/api/admin/nema-accounts', requireRole('superadmin'), (_req, res) => {
  res.json({ accounts: nemaAccounts() });
});

app.post('/api/admin/nema-accounts', requireRole('superadmin'), (req, res) => {
  const username = String(req.body?.username || '').trim().toLowerCase();
  if (!username) throw new HttpError(400, 'Username is required');
  const displayName = String(req.body?.displayName || 'NEMA Federal Command Dispatcher').trim();
  const password = req.body?.password || generatePassword('NEMA');
  const account = createAccount({
    username,
    password,
    role: 'nema',
    displayName,
    createdBy: req.account.id || null
  });
  res.status(201).json({ account, temporaryPassword: password });
});

app.post('/api/admin/nema-accounts/:id/reset', requireRole('superadmin'), (req, res) => {
  res.json(resetAccountPassword(Number(req.params.id), req.body?.password || null, req.account.id || null, { role: 'nema' }));
});

// Super Admin edit: click a NEMA desk to edit username/display name and
// regenerate the password in one place. Only NEMA desks are editable here —
// the Master Super Admin login is never touched from this table.
app.patch('/api/admin/nema-accounts/:id', requireRole('superadmin'), (req, res) => {
  const id = Number(req.params.id);
  const row = get('SELECT * FROM accounts WHERE id = ?', id);
  if (!row) throw new AuthError(404, 'Login not found');
  if (row.role === 'superadmin') throw new AuthError(403, 'The Master Super Admin login cannot be edited here');
  if (row.role !== 'nema') throw new AuthError(400, 'That login is not a NEMA account');
  if (id === req.account.id) throw new AuthError(403, 'You cannot edit your own NEMA desk from here');
  const updates = [];
  const params = [];
  if (req.body?.username !== undefined) {
    const user = String(req.body.username || '').trim().toLowerCase().slice(0, 40);
    if (!/^[a-z0-9._-]{3,40}$/.test(user)) {
      throw new AuthError(400, 'Username must be 3-40 characters (letters, numbers, dot, dash or underscore)');
    }
    const clash = get('SELECT id FROM accounts WHERE username = ? AND id != ?', user, id);
    if (clash) throw new AuthError(409, 'That username already exists');
    updates.push('username = ?');
    params.push(user);
  }
  if (req.body?.displayName !== undefined) {
    const name = String(req.body.displayName || '').trim().slice(0, 80);
    if (!name) throw new AuthError(400, 'Display name is required');
    updates.push('display_name = ?');
    params.push(name);
  }
  let temporaryPassword = null;
  if (req.body?.password) {
    temporaryPassword = String(req.body.password).trim();
    if (temporaryPassword.length < 8) throw new AuthError(400, 'Password must be at least 8 characters');
    updates.push('password_hash = ?');
    params.push(hashPassword(temporaryPassword));
    updates.push('temp_password = ?');
    params.push(temporaryPassword);
  }
  if (!updates.length) throw new AuthError(400, 'Nothing to update');
  params.push(id);
  run(`UPDATE accounts SET ${updates.join(', ')} WHERE id = ?`, ...params);
  // Username/password change invalidates every live session for that desk.
  if (req.body?.username !== undefined || req.body?.password) {
    run('DELETE FROM auth_sessions WHERE account_id = ?', id);
  }
  const updated = get('SELECT * FROM accounts WHERE id = ?', id);
  res.json({ account: serializeAccount(updated), temporaryPassword });
});

// Register First Responder vehicle & Hytera hardware device
app.post('/api/admin/responders', requireRole('superadmin', 'nema', 'state'), (req, res) => {
  const {
    callSign, stateCode = 'LA', agencyCode = 'MEDICAL', responderKind = 'ambulance',
    vehicleType = 'Ambulance', plateNumber = '', station = 'Central Command Base',
    hardwareType = 'Hytera MNC360 Smart PoC In-Vehicle Radio Terminal', hardwareImei = '',
    username = null, password = null, isCommunity = false
  } = req.body || {};

  if (!callSign || !callSign.trim()) {
    throw new HttpError(400, 'Call sign is required (e.g. AMB-05 or POLICE-08)');
  }
  const cleanCallSign = callSign.trim().toUpperCase();
  const state = stateForCode(stateCode);
  if (!state) throw new HttpError(400, 'Valid state is required');

  const agencyRow = get('SELECT id FROM agencies WHERE code = ?', String(agencyCode).toUpperCase())
    || get('SELECT id FROM agencies WHERE id = ?', Number(agencyCode))
    || get("SELECT id FROM agencies WHERE code = 'GENERAL'");

  const publicId = `RESP-${cleanCallSign.replace(/[^A-Z0-9]/g, '-')}`;
  const now = new Date().toISOString();

  // Check if unit already exists by call sign
  let unit = get('SELECT * FROM responders WHERE call_sign = ?', cleanCallSign);
  let unitId;

  if (unit) {
    unitId = unit.id;
    // Update existing unit metadata
    run(
      `UPDATE responders
       SET agency_id = ?, vehicle_type = ?, responder_kind = ?, state_code = ?,
           plate_number = ?, station = ?, is_community = ?, updated_at = ?
       WHERE id = ?`,
      agencyRow.id, vehicleType, responderKind, state.code,
      plateNumber || null, station, isCommunity ? 1 : 0, now, unitId
    );
  } else {
    // Insert into responders table
    const result = run(
      `INSERT INTO responders
         (public_id, agency_id, call_sign, vehicle_type, responder_kind, state_code,
          plate_number, station, status, lat, lng, heading, speed_kph, shift_code,
          battery_pct, is_simulated, is_community, verified_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'available', ?, ?, 0, 0, 'A', 98, 0, ?, ?, ?)`,
      publicId,
      agencyRow.id,
      cleanCallSign,
      vehicleType,
      responderKind,
      state.code,
      plateNumber || null,
      station,
      state.lat,
      state.lng,
      isCommunity ? 1 : 0,
      now,
      now
    );
    unitId = Number(result.lastInsertRowid);
  }

  // Auto-provision field credentials for the Hytera MNC360 in-vehicle APK
  const loginUser = String(username || cleanCallSign.toLowerCase().replace(/[^a-z0-9._-]/g, '.')).slice(0, 40);
  const passwordOut = password || generatePassword('RESP');
  const creatorId = req.account.role === 'superadmin' ? 'superadmin' : req.account.id;
  const provisionResult = provisionResponderLogin({
    responderId: unitId,
    username: loginUser,
    password: passwordOut,
    displayName: `${cleanCallSign} (${vehicleType} - Hytera ${hardwareImei || 'MNC360'})`,
    createdBy: creatorId
  });

  res.status(201).json({
    unit: getResponder(publicId) || getResponder(unitId),
    account: provisionResult.account,
    temporaryPassword: provisionResult.temporaryPassword,
    hardware: {
      type: hardwareType,
      imei: hardwareImei,
      terminalMode: 'Hytera MNC360 In-Vehicle APK'
    }
  });
});

// ── LiveKit PTT Token Generation for Off-Vehicle & Dispatch Radios ─────────
app.get('/api/livekit/token', async (req, res) => {
  try {
    const livekitUrl = process.env.LIVEKIT_URL;
    const apiKey = process.env.LIVEKIT_API_KEY;
    const apiSecret = process.env.LIVEKIT_API_SECRET;

    if (!livekitUrl || !apiKey || !apiSecret) {
      return res.status(500).json({ error: 'LiveKit credentials not configured in .env' });
    }

    const room = String(req.query.room || 'nema-operations-room');
    const identity = String(req.query.identity || `unit-${Date.now()}`);
    const name = String(req.query.name || identity);

    const at = new AccessToken(apiKey, apiSecret, {
      identity,
      name,
      ttl: '24h'
    });

    at.addGrant({
      roomJoin: true,
      room,
      canPublish: true,
      canSubscribe: true,
      canPublishData: true
    });

    const token = await at.toJwt();
    res.json({
      token,
      url: livekitUrl,
      room,
      identity,
      name
    });
  } catch (err) {
    console.error('[livekit] token error:', err);
    res.status(500).json({ error: err.message });
  }
});

// Return all registered responders with their agency and linked field accounts
app.get('/api/admin/responders', requireRole('superadmin'), (_req, res) => {
  const responders = getResponders();
  const accounts = responderAccounts();
  const accountsByResponderId = new Map(accounts.map((a) => [a.responderId, a]));
  const list = responders.map((r) => ({
    ...r,
    account: accountsByResponderId.get(r.id) || null
  }));
  res.json({ responders: list });
});

// Central Database Audit: link Citizen User SOS alerts to First Responders & State/NEMA oversight
app.get('/api/admin/database/records', requireRole('superadmin'), (req, res) => {
  const limit = Math.min(200, Number(req.query.limit) || 100);
  const incidents = all(`
    SELECT i.*, 
           (SELECT COUNT(*) FROM incident_events WHERE incident_id = i.id) AS event_count,
           (SELECT COUNT(*) FROM incident_recordings WHERE incident_id = i.id) AS recording_count,
           (SELECT COALESCE(SUM(bytes), 0) FROM incident_recordings WHERE incident_id = i.id) AS total_recording_bytes,
           (SELECT status FROM call_sessions WHERE incident_id = i.id ORDER BY id DESC LIMIT 1) AS call_status,
           (SELECT claimed_by_name FROM call_sessions WHERE incident_id = i.id ORDER BY id DESC LIMIT 1) AS call_claimed_by,
           (SELECT json_group_array(json_object(
             'id', r.id,
             'publicId', r.public_id,
             'callSign', r.call_sign,
             'vehicleType', r.vehicle_type,
             'responderKind', r.responder_kind,
             'agencyCode', ag.code,
             'assignmentStatus', ia.status,
             'assignedAt', ia.assigned_at,
             'arrivedAt', ia.arrived_at,
             'completedAt', ia.completed_at
           ))
           FROM incident_assignments ia
           JOIN responders r ON r.id = ia.responder_id
           JOIN agencies ag ON ag.id = r.agency_id
           WHERE ia.incident_id = i.id
           ) AS assigned_responders_json
    FROM incidents i
    ORDER BY i.created_at DESC
    LIMIT ?
  `, limit);

  // Incidents do not store an agency column; their emergency type maps to the
  // agency that owns the response (the same mapping used for dispatch).
  const agencyForType = {
    medical: 'MEDICAL', police: 'POLICE', fire: 'FIRE',
    road_safety: 'ROAD_SAFETY', general: 'GENERAL'
  };
  const parsed = incidents.map((row) => {
    let assignedResponders = [];
    try {
      assignedResponders = JSON.parse(row.assigned_responders_json || '[]');
    } catch {}
    return {
      ...row,
      agency_code: agencyForType[row.type] || 'GENERAL',
      recordingCount: Number(row.recording_count || 0),
      totalRecordingBytes: Number(row.total_recording_bytes || 0),
      callStatus: row.call_status || null,
      callClaimedBy: row.call_claimed_by || null,
      assignedResponders
    };
  });

  const totalIncidents = get('SELECT count(*) AS count FROM incidents')?.count || 0;
  const totalResponders = get('SELECT count(*) AS count FROM responders')?.count || 0;
  const totalNema = get("SELECT count(*) AS count FROM accounts WHERE role = 'nema'")?.count || 0;

  res.json({
    records: parsed,
    stats: {
      totalIncidents,
      totalResponders,
      totalNema,
      totalStates: listStates().length
    }
  });
});

app.get('/api/admin/database/records/:id', requireRole('superadmin'), (req, res) => {
  const incident = getIncidentDetail(req.params.id);
  if (!incident) throw new HttpError(404, 'Record not found');
  const events = all('SELECT * FROM incident_events WHERE incident_id = ? ORDER BY id ASC', incident.id);
  const assignments = all(`
    SELECT ia.*, r.call_sign, r.vehicle_type, r.plate_number, r.station, ag.name AS agency_name, ag.code AS agency_code
    FROM incident_assignments ia
    JOIN responders r ON r.id = ia.responder_id
    JOIN agencies ag ON ag.id = ia.agency_id
    WHERE ia.incident_id = ?
    ORDER BY ia.id ASC
  `, incident.id);
  const aiSession = get('SELECT * FROM ai_sessions WHERE incident_id = ?', incident.id);
  const aiMessages = aiSession ? all('SELECT * FROM ai_messages WHERE session_id = ? ORDER BY id ASC', aiSession.id) : [];

  res.json({
    incident,
    events,
    assignments,
    aiSession: aiSession ? { ...aiSession, messages: aiMessages } : null
  });
});

// NEMA / Super Admin: national command, and the authority that creates state logins.
app.get('/api/nema/state-accounts', requireRole('nema', 'superadmin'), (_req, res) => {
  const accounts = stateAccounts();
  const accountsByState = new Map(accounts.map((account) => [account.stateCode, account]));
  res.json({
    states: listStates().map((state) => ({
      ...state,
      account: accountsByState.get(state.code) || null
    })),
    accounts
  });
});

app.post('/api/nema/state-accounts', requireRole('nema', 'superadmin'), (req, res) => {
  const state = stateForCode(req.body?.stateCode);
  if (!state) throw new AuthError(400, 'Choose a valid state');
  const existing = stateAccounts().find((account) => account.stateCode === state.code);
  if (existing) throw new AuthError(409, 'This state already has a counterpart login. Reset the password instead.');
  const password = req.body?.password || generatePassword('STATE');
  const account = createAccount({
    username: req.body?.username,
    password,
    role: 'state',
    displayName: req.body?.displayName || `${state.name} State Emergency Operations Centre`,
    stateCode: state.code,
    createdBy: req.account.id
  });
  res.status(201).json({ account, temporaryPassword: password });
});

app.post('/api/nema/state-accounts/:id/reset', requireRole('nema', 'superadmin'), (req, res) => {
  res.json(resetAccountPassword(Number(req.params.id), req.body?.password || null, req.account.id, { role: 'state' }));
});

// NEMA / Super Admin generates a one-time access code for state staff to open their dashboard
// without sharing the account password. The code expires and only works once.
app.post('/api/nema/state-accounts/:id/access-code', requireRole('nema', 'superadmin'), (req, res) => {
  const issued = issueStateAccessCode(Number(req.params.id), {
    createdBy: req.account.id,
    ttlMinutes: req.body?.ttlMinutes
  });
  res.status(201).json({
    ...issued,
    url: `/state?code=${encodeURIComponent(issued.code)}`
  });
});

app.get('/api/nema/overview', requireRole('nema'), (_req, res) => {
  res.json({
    coverage: getCoverage(),
    stats: getStats(),
    ai: getAiStats(),
    registrations: getRegistrationStats(),
    states: listStates()
  });
});

// State counterpart: only its own state. It can provision responder logins.
app.get('/api/state/overview', requireRole('state'), (req, res) => {
  const stateCode = accountState(req);
  res.json({
    account: req.account,
    responders: responderAccounts({ stateCode }),
    registrations: listRegistrations({ stateCode }),
    coverage: getCoverage().states.find((row) => row.code === stateCode) || null,
    stats: getStats(),
    ai: getAiStats({ stateCode })
  });
});

app.get('/api/state/responders', requireRole('state', 'nema', 'superadmin'), (req, res) => {
  const stateCode = req.account.role === 'state' ? accountState(req) : (req.query.state || null);
  res.json({
    responders: getResponders({ stateCode }),
    accounts: responderAccounts({ stateCode }),
    registrations: listRegistrations({ stateCode })
  });
});

app.post('/api/state/responders/:unitKey/credentials', requireRole('state', 'nema', 'superadmin'), (req, res) => {
  const unit = getResponder(req.params.unitKey);
  if (!unit) throw new HttpError(404, 'Responder not found');
  const result = provisionResponderLogin({
    responderId: unit.id,
    username: req.body?.username,
    password: req.body?.password,
    displayName: req.body?.displayName,
    createdBy: req.account.id,
    actorState: req.account.role === 'state' ? accountState(req) : null
  });
  res.status(201).json(result);
});

// Link First Responder terminal via Admin-generated Key Credentials
app.post('/api/responders/link-key', (req, res) => {
  const session = linkResponderByKey(req.body);
  const publicId = session.account?.responder?.publicId;
  const detail = publicId ? getUnitDetail(publicId) : null;
  res.json({
    ok: true,
    token: session.token,
    expiresAt: session.expiresAt,
    account: session.account,
    unit: detail?.unit || session.account?.responder,
    detail
  });
});

// First responder: own unit only, or superadmin oversight
app.get('/api/responder/me', requireRole('responder', 'superadmin'), (req, res) => {
  const publicId = req.account.responder?.publicId;
  const detail = publicId ? getUnitDetail(publicId) : (req.account.responder_id ? getUnitDetail(req.account.responder_id) : null);
  const fleet = getResponders();
  if (detail) {
    return res.json({ account: serializeAccount(req.account), fleet, ...detail });
  }
  const defaultUnit = fleet[0];
  const unitDetail = defaultUnit ? getUnitDetail(defaultUnit.publicId || defaultUnit.id) : null;
  return res.json({
    account: serializeAccount(req.account),
    fleet,
    unit: defaultUnit || null,
    ...(unitDetail || {})
  });
});

app.get('/api/bootstrap', (req, res) => {
  const stateCode = req.account?.role === 'state' || req.account?.role === 'responder'
    ? accountState(req) : null;
  res.json({ ...getBootstrap({ stateCode }), account: req.account });
});

app.get('/api/agencies', (_req, res) => res.json({ agencies: getAgencies() }));

app.get('/api/responders', (req, res) => {
  res.json({
    responders: getResponders({
      agencyCode: req.query.agency || null,
      status: req.query.status || null,
      stateCode: req.query.state || null,
      responderKind: req.query.kind || null,
      community: req.query.community == null ? null : req.query.community === '1'
    })
  });
});

app.get('/api/states', (_req, res) => {
  res.json({ states: listStates(), coverage: getCoverage() });
});

app.get('/api/coverage', (_req, res) => res.json(getCoverage()));

app.get('/api/registrations', requireRole('nema', 'state'), (req, res) => {
  const stateCode = req.account.role === 'state' ? accountState(req) : (req.query.state || null);
  res.json({
    registrations: listRegistrations({
      status: req.query.status || null,
      stateCode
    }),
    kinds: RESPONDER_KINDS,
    stats: getRegistrationStats()
  });
});

app.post('/api/registrations', (req, res) => {
  // Public application. It stays pending until the state EOC verifies it.
  const registration = createRegistration(req.body || {}, { autoApprove: false });
  res.status(201).json({ registration, kinds: RESPONDER_KINDS });
});

app.get('/api/registrations/:id', requireRole('nema', 'state'), (req, res) => {
  const registration = getRegistration(req.params.id);
  if (!registration) throw new HttpError(404, 'Registration not found');
  if (req.account.role === 'state' && registration.stateCode !== accountState(req)) {
    throw new HttpError(403, 'That registration belongs to another state');
  }
  res.json({ registration });
});

app.post('/api/registrations/:id/review', requireRole('nema', 'state'), (req, res) => {
  const registration = getRegistration(req.params.id);
  if (!registration) throw new HttpError(404, 'Registration not found');
  if (req.account.role === 'state' && registration.stateCode !== accountState(req)) {
    throw new HttpError(403, 'A state can only review its own registrations');
  }
  res.json({
    registration: reviewRegistration(Number(req.params.id), req.body?.status, {
      reviewer: req.body?.reviewer || req.account.displayName,
      note: req.body?.note || null
    })
  });
});

app.get('/api/ai/stats', (_req, res) => res.json(getAiStats()));

app.get('/api/responders/:unitKey', requireRole('nema', 'state', 'responder'), (req, res) => {
  const unit = getResponder(req.params.unitKey);
  if (!unit) throw new HttpError(404, 'Responder not found');
  if (req.account.role === 'responder' && unit.id !== req.account.responder?.id) {
    throw new HttpError(403, 'That unit belongs to another responder');
  }
  if (req.account.role === 'state' && unit.stateCode !== accountState(req)) {
    throw new HttpError(403, 'That unit belongs to another state');
  }
  res.json(getUnitDetail(unit.id));
});

app.patch('/api/responders/:unitKey/status', requireRole('responder'), (req, res) => {
  if (req.account.responder?.publicId !== req.params.unitKey) {
    throw new HttpError(403, 'A responder login can only control its own unit');
  }
  res.json({ unit: updateUnitStatus(req.params.unitKey, req.body?.status) });
});

app.post('/api/responders/:unitKey/location', requireRole('responder'), (req, res) => {
  if (req.account.responder?.publicId !== req.params.unitKey) {
    throw new HttpError(403, 'A responder login can only control its own unit');
  }
  res.json({ unit: updateUnitLocation(req.params.unitKey, req.body || {}) });
});

app.get('/api/incidents', (req, res) => {
  const tenantState = req.account && ['state', 'responder'].includes(req.account.role)
    ? accountState(req) : null;
  res.json({
    incidents: listIncidents({
      scope: req.query.scope || 'active',
      limit: Math.min(200, Number(req.query.limit) || 50),
      stateCode: tenantState || req.query.state || null,
      aiMode: req.query.ai || null
    })
  });
});

app.get('/api/incidents/:id', (req, res) => {
  res.json({ incident: incidentForRequest(req, req.params.id) });
});

// Citizen SOS scene photo. Access follows the same rule as the incident itself:
// the owning State EOC, NEMA oversight and the assigned responder can load it.
app.get('/api/incidents/:id/photo', (req, res) => {
  const incident = incidentForRequest(req, req.params.id);
  const row = get('SELECT photo_path FROM incidents WHERE id = ?', incident.id);
  const relative = String(row?.photo_path || '');
  const root = path.resolve(DATA_DIR);
  const absolute = path.resolve(root, relative);
  if (!relative || !absolute.startsWith(root + path.sep) || !fs.existsSync(absolute)) {
    throw new HttpError(404, 'No scene photo attached to this incident');
  }
  res.setHeader('Cache-Control', 'private, max-age=86400, immutable');
  res.sendFile(absolute);
});

app.post('/api/incidents', (req, res) => {
  const body = { ...(req.body || {}) };
  if (req.account?.role === 'state') body.stateCode = accountState(req);
  res.status(201).json({ incident: createIncident(body) });
});

app.patch('/api/incidents/:id', requireRole('nema', 'state'), (req, res) => {
  incidentForRequest(req, req.params.id, { write: true });
  res.json({ incident: updateIncident(req.params.id, req.body || {}) });
});

app.post('/api/incidents/:id/acknowledge', requireRole('nema', 'state'), (req, res) => {
  incidentForRequest(req, req.params.id, { write: true });
  res.json({ incident: acknowledgeIncident(req.params.id, req.body?.actor || req.account.displayName || 'Dispatcher') });
});

app.post('/api/incidents/:id/location', (req, res) => {
  res.json({ incident: updateIncidentLocation(req.params.id, req.body || {}) });
});

app.get('/api/incidents/:id/ai', (req, res) => {
  const incident = incidentForRequest(req, req.params.id);
  res.json({ ai: getAiSession(incident.id) || ensureAiSupport(incident.id) });
});

app.post('/api/incidents/:id/ai/start', (req, res) => {
  incidentForRequest(req, req.params.id);
  res.status(201).json({ ai: ensureAiSupport(req.params.id) });
});

app.post('/api/incidents/:id/ai/messages', (req, res) => {
  const ai = addCitizenAiMessage(req.params.id, req.body?.body);
  if (!ai) throw new HttpError(404, 'Incident not found');
  res.status(201).json({ ai });
});

app.post('/api/incidents/:id/ai/takeover', requireRole('nema', 'state'), (req, res) => {
  incidentForRequest(req, req.params.id, { write: true });
  const ai = takeOverFromAi(req.params.id, req.body?.agentName || req.account.displayName || 'NEMA human agent');
  if (!ai) throw new HttpError(404, 'Incident not found');
  res.json({ ai });
});

app.post('/api/incidents/:id/ai/release', requireRole('nema', 'state'), (req, res) => {
  incidentForRequest(req, req.params.id, { write: true });
  const ai = releaseToAi(req.params.id);
  if (!ai) throw new HttpError(404, 'Incident not found');
  res.json({ ai });
});

app.post('/api/incidents/:id/ai/agent-message', requireRole('nema', 'state'), (req, res) => {
  incidentForRequest(req, req.params.id, { write: true });
  const ai = addHumanAiMessage(req.params.id, {
    body: req.body?.body,
    agentName: req.body?.agentName || req.account.displayName || 'NEMA human agent'
  });
  if (!ai) throw new HttpError(404, 'Incident not found');
  res.status(201).json({ ai });
});

// AI auto-dispatch trigger: the AI acts for the State EOC, so only the state
// (or Super Admin override) may trigger a manual AI dispatch. NEMA is
// national oversight and cannot dispatch directly.
app.post('/api/incidents/:id/ai/dispatch', requireRole('nema', 'state', 'superadmin'), wrap(async (req, res) => {
  incidentForRequest(req, req.params.id, { write: true });
  if (req.account.role === 'nema') {
    throw new HttpError(403, 'Only the responsible State EOC can dispatch a first responder. NEMA is national oversight — the AI dispatches for the state, not for NEMA.');
  }
  const result = await aiAutoDispatch(req.params.id);
  if (!result || result.dispatched === false) {
    throw new HttpError(409, result?.reason === 'already_assigned' ? 'A unit is already assigned to this incident' : 'No available first-responder unit in the national fleet right now');
  }
  if (result.skipped) return res.json({ skipped: true, reason: result.reason });
  res.status(201).json(result);
}));

app.get('/api/incidents/:id/candidates', requireRole('nema', 'state', 'superadmin'), (req, res) => {
  incidentForRequest(req, req.params.id);
  res.json(getCandidates(req.params.id, {
    agencyCode: req.query.agency || null,
    radiusKm: Math.min(120, Number(req.query.radius) || 40),
    limit: Math.min(10, Number(req.query.limit) || 5)
  }));
});

// Nearest available units to any point — powers the Admin / NEMA locate +
// search tools ("where is my ambulance/car right now, and what is closest
// to this citizen SOS?"). Sorted nationally by distance, nearest first.
app.get('/api/nearest-units', requireRole('nema', 'state', 'superadmin'), (req, res) => {
  res.json(getNearestUnits({
    lat: req.query.lat,
    lng: req.query.lng,
    agencyCode: req.query.agency || null,
    radiusKm: Math.min(500, Number(req.query.radius) || 120),
    limit: Math.min(20, Number(req.query.limit) || 5)
  }));
});

// Only the responsible State EOC may dispatch a first responder. NEMA is
// national oversight (it triggers / sees the SOS); the state dispatches.
// Super Admin is allowed as a backend testing override.
app.post('/api/incidents/:id/dispatch', requireRole('nema', 'state', 'superadmin'), wrap(async (req, res) => {
  if (req.account.role === 'nema') {
    throw new HttpError(403, 'Only the responsible State EOC can dispatch a first responder. NEMA is national oversight — the SOS is live on the state desk; the state dispatches.');
  }
  const { agencyCode, responderId, dispatcher } = req.body || {};
  if (!agencyCode && !responderId) throw new HttpError(400, 'agencyCode or responderId is required');
  if (req.account.role === 'state') {
    const incident = getIncidentDetail(req.params.id);
    if (!incident) throw new HttpError(404, 'Incident not found');
    if (incident.stateCode !== accountState(req)) {
      throw new HttpError(403, 'A state can only dispatch its own incidents');
    }
  }
  const result = await assignUnit(req.params.id, { agencyCode, responderId, dispatcher });
  res.status(201).json(result);
}));

// Responder self-assign: a unit that received a NEMA-triggered proximity SOS
// accepts it here. The state desk is then notified (responder:accepted) so
// it owns the live dispatch. Only the signed-in unit itself may call this.
app.post('/api/incidents/:id/assign', requireRole('responder'), wrap(async (req, res) => {
  const { responderId, dispatcher } = req.body || {};
  const ownId = req.account.responder?.id;
  const requested = responderId ? String(responderId) : String(req.account.responder?.publicId || ownId);
  const ownUnit = req.account.responder;
  const matches = [String(ownId), String(ownUnit?.publicId)].includes(requested) || Number(requested) === Number(ownId);
  if (!matches) throw new HttpError(403, 'A responder can only accept for its own unit');
  const result = await responderSelfAssign(req.params.id, {
    responderId: ownUnit?.publicId || ownId,
    dispatcher: dispatcher || ownUnit?.callSign || 'In-Vehicle PTT Terminal'
  });
  res.status(201).json(result);
}));

app.get('/api/incidents/:id/notes', requireRole('nema', 'state', 'responder'), (req, res) => {
  const incident = incidentForRequest(req, req.params.id);
  res.json({ notes: incident.notes });
});

app.post('/api/incidents/:id/notes', requireRole('nema', 'state', 'responder'), (req, res) => {
  incidentForRequest(req, req.params.id, { write: true });
  res.status(201).json({
    note: addNote(req.params.id, {
      body: req.body?.body,
      pinned: !!req.body?.pinned,
      authorName: req.body?.authorName || req.account.displayName || 'Dispatcher',
      authorId: req.body?.authorId || req.account.username
    })
  });
});

app.get('/api/incidents/:id/messages', (req, res) => {
  // The citizen tracker needs its own conversation without a staff login. It
  // can only read the thread of the incident id it already holds. Staff reads
  // are tenant-scoped below by incidentForRequest().
  const incident = incidentForRequest(req, req.params.id);
  res.json({ messages: incident.messages });
});

app.post('/api/incidents/:id/messages', (req, res) => {
  const incident = incidentForRequest(req, req.params.id, { write: !!req.account });
  if (!req.account && req.body?.senderType !== 'citizen') {
    throw new HttpError(401, 'Only the citizen can post to this thread without signing in');
  }
  res.status(201).json({
    message: addChatMessage(req.params.id, {
      senderType: req.account
        ? (req.account.role === 'responder' ? 'responder' : 'dispatcher')
        : 'citizen',
      senderId: req.account?.responder?.publicId || req.account?.username || 'citizen',
      senderName: req.body?.senderName || req.account?.displayName || 'Citizen',
      body: req.body?.body
    })
  });
});

// Citizen self-service closure. The caller proves possession of the incident
// code shown on their tracker, so a stranger cannot close another person's SOS
// just by guessing a sequential database id.
app.post('/api/incidents/:id/citizen-close', (req, res) => {
  const incident = getIncidentDetail(req.params.id);
  if (!incident) throw new HttpError(404, 'Incident not found');
  if (!req.body?.code || String(req.body.code).toUpperCase() !== incident.code) {
    throw new HttpError(403, 'The incident code does not match');
  }
  const status = req.body?.status === 'cancelled' ? 'cancelled' : 'resolved';
  res.json({
    incident: resolveIncident(req.params.id, {
      actor: 'Citizen',
      note: status === 'resolved' ? 'Citizen marked themselves safe' : 'Citizen cancelled the SOS',
      status
    })
  });
});

app.post('/api/incidents/:id/resolve', requireRole('nema', 'state'), (req, res) => {
  incidentForRequest(req, req.params.id, { write: true });
  res.json({
    incident: resolveIncident(req.params.id, {
      actor: req.body?.actor || req.account.displayName || 'Dispatcher',
      note: req.body?.note || 'Incident resolved by command centre',
      status: req.body?.status === 'cancelled' ? 'cancelled' : 'resolved'
    })
  });
});

// ---------------------------------------------------------------------------
// Emergency call engagement + audio recording
// ---------------------------------------------------------------------------
app.get('/api/incidents/:id/call', (req, res) => {
  const incident = incidentForRequest(req, req.params.id);
  res.json({ call: getCallDetail(incident.id) });
});

app.post('/api/incidents/:id/call', (req, res) => {
  const incident = incidentForRequest(req, req.params.id);
  assertCitizenCode(req, incident);
  res.status(201).json({
    call: startCall(incident.id, {
      citizenName: req.body?.citizenName || incident.reporterName,
      reporterName: incident.reporterName
    })
  });
});

// Only the responsible State EOC (or Super Admin override) may claim the
// citizen call. NEMA is oversight and receives 403.
app.post('/api/incidents/:id/call/claim', requireRole('state', 'superadmin'), (req, res) => {
  const incident = incidentForRequest(req, req.params.id, { write: true });
  res.json({
    call: claimCall(incident.id, {
      account: req.account,
      actorName: req.body?.actorName || req.account.displayName || req.account.username
    })
  });
});

// Either the State EOC/Super Admin closes the call, or the citizen hangs up
// with the incident code.
app.post('/api/incidents/:id/call/end', (req, res) => {
  const incident = incidentForRequest(req, req.params.id, { write: !!req.account });
  if (req.account && !['state', 'superadmin'].includes(req.account.role)) {
    throw new HttpError(403, 'Only the responsible State EOC can end the citizen call. NEMA is national oversight.');
  }
  assertCitizenCode(req, incident);
  const citizen = !req.account;
  res.json({
    call: endCall(incident.id, {
      actor: citizen ? 'Citizen' : (req.account.displayName || req.account.username),
      actorType: citizen ? 'citizen' : 'dispatcher',
      reason: req.body?.reason || (citizen ? 'Citizen ended the call' : 'Call ended by the State EOC')
    })
  });
});

app.get('/api/incidents/:id/recordings', requireRole('nema', 'state', 'superadmin'), (req, res) => {
  const incident = incidentForRequest(req, req.params.id);
  res.json({ recordings: listRecordings(incident.id) });
});

app.post('/api/incidents/:id/call/recording', (req, res) => {
  const incident = incidentForRequest(req, req.params.id);
  assertCitizenCode(req, incident);
  res.status(201).json(createRecording(incident.id, {
    callSessionId: req.body?.callSessionId,
    mimeType: req.body?.mimeType,
    source: req.body?.source || 'citizen',
    recordedBy: req.account?.username || req.body?.recordedBy || incident.reporterName
  }));
});

// Raw browser MediaRecorder chunks are appended in order to one file. The
// incident code travels in the x-incident-code header (or ?code=) because the
// body is binary.
app.put(
  '/api/incidents/:id/call/recording/:recordingId/chunk',
  express.raw({ type: () => true, limit: '30mb' }),
  (req, res) => {
    const incident = incidentForRequest(req, req.params.id);
    assertCitizenCode(req, incident);
    const row = getRecordingRow(Number(req.params.recordingId));
    if (!row || row.incident_id !== incident.id) throw new HttpError(404, 'Recording not found');
    res.json({ recording: appendRecordingChunk(row.id, req.body) });
  }
);

app.post('/api/incidents/:id/call/recording/:recordingId/finish', (req, res) => {
  const incident = incidentForRequest(req, req.params.id);
  assertCitizenCode(req, incident);
  const row = getRecordingRow(Number(req.params.recordingId));
  if (!row || row.incident_id !== incident.id) throw new HttpError(404, 'Recording not found');
  res.json(finishRecording(row.id, {
    durationSeconds: req.body?.durationSeconds,
    status: req.body?.status === 'failed' ? 'failed' : 'ready',
    reason: req.body?.reason || null
  }));
});

// NEMA / State EOC / Super Admin playback. Audio is streamed with Range
// support so the browser recorder can seek without downloading everything.
app.get('/api/recordings/:id/audio', requireRole('nema', 'state', 'superadmin'), (req, res) => {
  const found = getRecordingWithIncident(req.params.id);
  if (!found) throw new HttpError(404, 'Recording not found');
  const { recording, incident } = found;
  incidentForRequest(req, incident.id);
  const filePath = getRecordingPath(recording);
  if (!filePath || !fs.existsSync(filePath)) throw new HttpError(404, 'Recording file is missing');
  const stat = fs.statSync(filePath);
  const headers = {
    'Content-Type': recording.mime_type || 'audio/webm',
    'Accept-Ranges': 'bytes',
    'Cache-Control': 'private, no-store',
    'Content-Disposition': `inline; filename="${recording.file_name}"`
  };
  const range = req.headers.range;
  if (range) {
    const match = /bytes=(\d*)-(\d*)/.exec(range);
    if (match) {
      const start = match[1] ? Number(match[1]) : 0;
      const end = match[2] ? Number(match[2]) : stat.size - 1;
      if (start >= stat.size || end < start) {
        res.status(416).set('Content-Range', `bytes */${stat.size}`).end();
        return;
      }
      const safeEnd = Math.min(end, stat.size - 1);
      res.status(206).set({
        ...headers,
        'Content-Range': `bytes ${start}-${safeEnd}/${stat.size}`,
        'Content-Length': String(safeEnd - start + 1)
      });
      fs.createReadStream(filePath, { start, end: safeEnd }).pipe(res);
      return;
    }
  }
  res.set({ ...headers, 'Content-Length': String(stat.size) });
  fs.createReadStream(filePath).pipe(res);
});

app.post('/api/assignments/:id/accept', requireRole('responder', 'superadmin'), (req, res) => {
  const row = getAssignment(req.params.id);
  if (!row) throw new HttpError(404, 'Assignment not found');
  if (req.account.role !== 'superadmin' && req.account.responder?.id && row.responder_id !== req.account.responder.id) {
    throw new HttpError(403, 'This assignment belongs to another responder');
  }
  res.json(acceptAssignment(Number(req.params.id), req.body?.actor || req.account.displayName || 'Responder'));
});

app.post('/api/assignments/:id/decline', requireRole('responder', 'superadmin'), (req, res) => {
  const row = getAssignment(req.params.id);
  if (!row) throw new HttpError(404, 'Assignment not found');
  if (req.account.role !== 'superadmin' && req.account.responder?.id && row.responder_id !== req.account.responder.id) {
    throw new HttpError(403, 'This assignment belongs to another responder');
  }
  res.json(declineAssignment(Number(req.params.id), req.body?.reason || 'Unit unavailable'));
});

app.post('/api/assignments/:id/status', requireRole('responder', 'superadmin'), (req, res) => {
  const row = getAssignment(req.params.id);
  if (!row) throw new HttpError(404, 'Assignment not found');
  if (req.account.role !== 'superadmin' && req.account.responder?.id && row.responder_id !== req.account.responder.id) {
    throw new HttpError(403, 'This assignment belongs to another responder');
  }
  res.json(updateAssignmentStatus(
    Number(req.params.id),
    req.body?.status,
    req.body?.actor || req.account.displayName || 'Responder',
    { destination: req.body?.destination || null, destinationType: req.body?.destinationType || null }
  ));
});

app.get('/api/stats', (_req, res) => res.json(getStats()));

// Demo generator: injects a realistic SOS near a known Lagos landmark.
const DEMO_LOCATIONS = [
  { address: 'Opebi Road, Ikeja', landmark: 'Near Opebi Roundabout', lat: 6.5965, lng: 3.3589, type: 'medical', description: 'Passenger collapsed inside a commercial bus.', stateCode: 'LA' },
  { address: 'Awolowo Road, Ikoyi', landmark: 'Opposite Falomo Shopping Centre', lat: 6.4500, lng: 3.4310, type: 'police', description: 'Disturbance at a retail plaza, crowd gathering.', stateCode: 'LA' },
  { address: 'Ikorodu Road, Ojota', landmark: 'Ojota interchange outbound', lat: 6.5760, lng: 3.3800, type: 'road_safety', description: 'Broken-down tanker blocking the middle lane.', stateCode: 'LA' },
  { address: 'Ozumba Mbadiwe Avenue, Victoria Island', landmark: 'Near Eko Atlantic gate', lat: 6.4300, lng: 3.4100, type: 'medical', description: 'Cyclist injured after colliding with a taxi.', stateCode: 'LA' },
  { address: 'Ogunnusi Road, Agege', landmark: 'Agege Stadium junction', lat: 6.6150, lng: 3.3230, type: 'fire', description: 'Smoke coming from a row of shops.', stateCode: 'LA' },
  { address: 'Bode Thomas Street, Surulere', landmark: 'Near Teslim Balogun Stadium', lat: 6.4980, lng: 3.3650, type: 'police', description: 'Street fight in progress, bottles thrown.', stateCode: 'LA' },
  { address: 'Lekki-Epe Expressway, Ajah', landmark: 'Ajah market bus stop', lat: 6.4667, lng: 3.5667, type: 'road_safety', description: 'Two-car collision, traffic backing up.', stateCode: 'LA' },
  { address: 'Ahmadu Bello Way, Victoria Island', landmark: 'Eko Hotel south gate', lat: 6.4270, lng: 3.4230, type: 'medical', description: 'Older woman feeling faint and short of breath.', stateCode: 'LA' },
  { address: 'Aminu Kano Crescent, Wuse II', landmark: 'Near Wuse Market', lat: 9.0665, lng: 7.4750, type: 'fire', description: 'Market stall fire spreading toward a row of shops.', stateCode: 'FC' },
  { address: 'Shehu Shagari Way, Maitama', landmark: 'Near Transcorp Hilton junction', lat: 9.0833, lng: 7.4950, type: 'road_safety', description: 'Three-vehicle collision blocking the carriageway.', stateCode: 'FC' },
  { address: 'Garki Model Market', landmark: 'Area 1, Garki', lat: 9.0333, lng: 7.4833, type: 'general', description: 'Crowd surge at a market entrance, people trapped.', stateCode: 'FC' },
  { address: 'Ring Road, Ibadan', landmark: 'Iyaganku junction', lat: 7.3560, lng: 3.8720, type: 'medical', description: 'Motorcyclist down after a hit-and-run.', stateCode: 'OY' }
];

app.post('/api/demo/incident', requireRole('nema', 'state'), (req, res) => {
  const requested = req.account.role === 'state'
    ? accountState(req)
    : (req.body?.stateCode ? String(req.body.stateCode).toUpperCase() : null);
  const pool = requested ? DEMO_LOCATIONS.filter((place) => place.stateCode === requested) : DEMO_LOCATIONS;
  const chosen = (pool.length ? pool : DEMO_LOCATIONS)[Math.floor(Math.random() * (pool.length || DEMO_LOCATIONS.length))];
  const incident = createIncident({
    ...chosen,
    stateCode: requested || chosen.stateCode,
    priority: req.body?.priority,
    reporterName: 'Demo citizen',
    reporterPhone: '+234 800 555 0112',
    source: 'app',
    liveTracking: true,
    peopleAffected: 1 + Math.floor(Math.random() * 3)
  });
  res.status(201).json({ incident });
});

// ---------------------------------------------------------------------------
// Error handling
// ---------------------------------------------------------------------------
app.use('/api', (_req, res) => res.status(404).json({ error: 'API route not found' }));
app.use((err, _req, res, _next) => {
  const status = err instanceof HttpError ? err.status : err.status || 500;
  if (status >= 500) console.error(err);
  res.status(status).json({
    error: err.message || 'Unexpected server error',
    details: err.details || null
  });
});

// ---------------------------------------------------------------------------
// HTTP + Socket.IO
// ---------------------------------------------------------------------------
const server = http.createServer(app);
const io = new SocketServer(server, {
  cors: { origin: true, credentials: true },
  maxHttpBufferSize: 1e6
});
rt.setIO(io);

// PTT fan-out reaches a unit through several rooms (unit room, responders:all,
// incident room). Every copy carries the same txId/seq so clients can drop the
// duplicates and play each voice chunk exactly once.
let pttTransmissionSeed = 0;
function withPttEnvelope(socket, payload, phase) {
  if (phase === 'start' || !socket.data.pttTx) {
    socket.data.pttTx = { id: `ptt-${socket.id}-${++pttTransmissionSeed}`, seq: 0 };
  }
  const tx = socket.data.pttTx;
  const enriched = { ...payload, txId: tx.id, seq: ++tx.seq };
  if (phase === 'end') socket.data.pttTx = null;
  return enriched;
}

io.on('connection', (socket) => {
  let subscribedUnitId = null;
  const socketAccount = accountForToken(socket.handshake.auth?.token);
  socket.data.account = socketAccount;

  socket.emit('server:hello', {
    socketId: socket.id,
    serverTime: new Date().toISOString(),
    stats: getStats(),
    account: socketAccount
  });

  socket.on('dispatch:subscribe', () => {
    if (!socketAccount || !['nema', 'state', 'superadmin'].includes(socketAccount.role)) {
      socket.emit('dispatch:error', { message: 'Sign in as NEMA, a state counterpart, or Super Admin' });
      return;
    }
    if (socketAccount.role === 'nema' || socketAccount.role === 'superadmin') {
      // Super Admin gets the national room too, so /admin can see the same
      // live fleet (fleet:update / fleet:unit / unit:presence) as NEMA.
      socket.join('dispatch');
    } else {
      // A state counterpart is a separate tenant: it receives only events for
      // its own state, never the national dispatch room.
      socket.join(rt.stateRoom(socketAccount.stateCode));
    }
    const stateCode = socketAccount.role === 'state' ? socketAccount.stateCode : null;
    socket.emit('dispatch:bootstrap', {
      ...getBootstrap({ stateCode }),
      account: socketAccount
    });
  });

  socket.on('incident:subscribe', ({ incidentId } = {}) => {
    if (!incidentId) return;
    const incident = getIncidentDetail(incidentId);
    if (!incident) {
      socket.emit('incident:error', { message: 'Incident not found' });
      return;
    }
    if (socketAccount?.role === 'state' && incident.stateCode !== socketAccount.stateCode) {
      socket.emit('incident:error', { message: 'That incident belongs to another state' });
      return;
    }
    if (socketAccount?.role === 'responder') {
      const mine = incident.assignments?.some((a) => a.responderId === socketAccount.responder?.id);
      if (!mine) {
        socket.emit('incident:error', { message: 'That incident is not assigned to your unit' });
        return;
      }
    }
    socket.join(rt.incidentRoom(incidentId));
    socket.emit('incident:snapshot', incident);
  });

  socket.on('incident:unsubscribe', ({ incidentId } = {}) => {
    if (incidentId) socket.leave(rt.incidentRoom(incidentId));
  });

  socket.on('unit:subscribe', ({ unitKey } = {}) => {
    const unit = getResponder(unitKey);
    if (!unit) {
      socket.emit('unit:error', { message: 'Unknown responder' });
      return;
    }
    if (socketAccount?.role === 'responder' && socketAccount.responder?.id !== unit.id) {
      socket.emit('unit:error', { message: 'This login belongs to a different responder unit' });
      return;
    }
    if (subscribedUnitId && subscribedUnitId !== unit.id) {
      socket.leave(rt.unitRoom(subscribedUnitId));
    }
    subscribedUnitId = unit.id;
    socket.join(rt.unitRoom(unit.id));
    if (unit.stateCode) socket.join(rt.stateRoom(unit.stateCode));
    socket.join('responders:all');
    if (unit.activeIncidentId) socket.join(rt.incidentRoom(unit.activeIncidentId));
    rt.markUnitConnected(unit.id);
    // Presence is authoritative from now on: every dashboard (Admin + NEMA +
    // state EOC) flips this unit to ONLINE immediately, before any GPS fix.
    const fresh = getResponder(unit.id);
    rt.emitUnitPresence(fresh);
    rt.emitFleetUnit(fresh);
    socket.emit('unit:snapshot', getUnitDetail(unit.id));
    console.log(`📲 Unit ${unit.callSign} subscribed (socket ${socket.id})`);
  });

  socket.on('unit:location', ({ unitKey, lat, lng, speed, heading, accuracy } = {}) => {
    try {
      const targetKey = unitKey || (subscribedUnitId ? getResponder(subscribedUnitId)?.publicId : null);
      if (!targetKey) return;
      const updated = updateUnitLocation(targetKey, { lat, lng, speed, heading, accuracy });
      socket.emit('unit:location:ack', { ok: true, unitKey: targetKey, time: Date.now() });
    } catch (err) {
      socket.emit('unit:error', { message: err.message });
    }
  });

  socket.on('unit:status', ({ unitKey, status } = {}) => {
    try {
      const targetKey = unitKey || (subscribedUnitId ? getResponder(subscribedUnitId)?.publicId : null);
      if (!targetKey) return;
      const updated = updateUnitStatus(targetKey, status);
      socket.emit('unit:status:ack', { ok: true, unitKey: targetKey, status });
    } catch (err) {
      socket.emit('unit:error', { message: err.message });
    }
  });

  socket.on('unit:panic', ({ unitKey, lat, lng } = {}) => {
    try {
      const targetKey = unitKey || (subscribedUnitId ? getResponder(subscribedUnitId)?.publicId : null);
      const unit = getResponder(targetKey);
      if (!unit) return;
      console.log(`🚨 DISTRESS PANIC TRIGGERED BY UNIT ${unit.callSign}`);
      rt.emitSystem('unit:panic', {
        unitKey: unit.publicId,
        callSign: unit.callSign,
        agencyCode: unit.agencyCode,
        stateCode: unit.stateCode,
        lat: lat ?? unit.lat,
        lng: lng ?? unit.lng,
        gpsSyncedAt: unit.gpsSyncedAt,
        time: Date.now()
      });
    } catch (err) {
      socket.emit('unit:error', { message: err.message });
    }
  });

  // WebRTC signalling for citizen audio/video. The citizen is the producer;
  // dispatchers and responders request a stream, then offers/answers are
  // relayed only to the intended viewer socket.
  socket.on('webrtc:request', ({ incidentId, viewerName } = {}) => {
    if (!incidentId) return;
    socket.to(rt.incidentRoom(incidentId)).emit('webrtc:request', {
      incidentId,
      viewerSocketId: socket.id,
      viewerName: viewerName || 'Command centre'
    });
  });

  socket.on('webrtc:offer', ({ target, incidentId, sdp, renegotiate } = {}) => {
    // `renegotiate` marks an offer the viewer sends after the line is already
    // live (for example, when the State EOC agent enables their microphone).
    // The citizen producer must answer these instead of ignoring them.
    rt.emitToSocket(target, 'webrtc:offer', {
      from: socket.id, incidentId, sdp, renegotiate: !!renegotiate
    });
  });

  socket.on('webrtc:answer', ({ target, incidentId, sdp } = {}) => {
    rt.emitToSocket(target, 'webrtc:answer', { from: socket.id, incidentId, sdp });
  });

  socket.on('webrtc:ice', ({ target, incidentId, candidate } = {}) => {
    rt.emitToSocket(target, 'webrtc:ice', { from: socket.id, incidentId, candidate });
  });

  socket.on('webrtc:end', ({ target, incidentId } = {}) => {
    if (target) rt.emitToSocket(target, 'webrtc:end', { from: socket.id, incidentId });
  });

  // ── Push-to-Talk (PTT) Radio Protocol between State EOC & First Responder ──
  socket.on('unit:mode', (data = {}) => {
    // Broadcast unit foot-patrol / in-vehicle mode change to dispatch rooms
    io.to('dispatch').emit('unit:mode-change', data);
    if (socketAccount?.stateCode) {
      io.to(rt.stateRoom(socketAccount.stateCode)).emit('unit:mode-change', data);
    }
  });

  socket.on('ptt:tx-start', ({ incidentId, unitId, unitCallSign, senderRole, senderName } = {}) => {
    const role = senderRole || socketAccount?.role || 'dispatch';
    const name = senderName || socketAccount?.displayName || socketAccount?.username || 'Operator';
    const payload = withPttEnvelope(socket, { incidentId, unitId, unitCallSign, senderRole: role, senderName: name, socketId: socket.id, timestamp: Date.now() }, 'start');

    if (role === 'responder') {
      // Unit → State EOC. The state desk is in its state room; NEMA and Super
      // Admin watch from the national dispatch room.
      socket.to('dispatch').emit('ptt:rx-start', payload);
      if (socketAccount?.stateCode) socket.to(rt.stateRoom(socketAccount.stateCode)).emit('ptt:rx-start', payload);
    } else {
      // State EOC → one specific unit. Never broadcast a dispatch to the whole
      // fleet: only the alerted crew hears the channel, NEMA can monitor it.
      if (unitId) io.to(rt.unitRoom(unitId)).emit('ptt:rx-start', payload);
      socket.to('dispatch').emit('ptt:rx-start', payload);
    }
  });

  socket.on('ptt:tx-audio', ({ incidentId, unitId, audioData, mimeType, senderRole, senderName } = {}) => {
    const role = senderRole || socketAccount?.role || 'dispatch';
    const payload = withPttEnvelope(socket, { incidentId, unitId, audioData, mimeType: mimeType || 'audio/webm', senderRole: role, senderName, socketId: socket.id }, 'audio');

    if (role === 'responder') {
      socket.to('dispatch').emit('ptt:rx-audio', payload);
      if (socketAccount?.stateCode) socket.to(rt.stateRoom(socketAccount.stateCode)).emit('ptt:rx-audio', payload);
    } else {
      if (unitId) io.to(rt.unitRoom(unitId)).emit('ptt:rx-audio', payload);
      socket.to('dispatch').emit('ptt:rx-audio', payload);
    }
  });

  socket.on('ptt:tx-end', ({ incidentId, unitId, unitCallSign, senderRole, senderName } = {}) => {
    const role = senderRole || socketAccount?.role || 'dispatch';
    const name = senderName || socketAccount?.displayName || socketAccount?.username || 'Operator';
    const payload = withPttEnvelope(socket, { incidentId, unitId, unitCallSign, senderRole: role, senderName: name, socketId: socket.id, timestamp: Date.now() }, 'end');

    if (role === 'responder') {
      socket.to('dispatch').emit('ptt:rx-end', payload);
      if (socketAccount?.stateCode) socket.to(rt.stateRoom(socketAccount.stateCode)).emit('ptt:rx-end', payload);
    } else {
      if (unitId) io.to(rt.unitRoom(unitId)).emit('ptt:rx-end', payload);
      socket.to('dispatch').emit('ptt:rx-end', payload);
    }
  });

  socket.on('disconnect', () => {
    if (subscribedUnitId) {
      const leavingId = subscribedUnitId;
      rt.markUnitDisconnected(leavingId);
      // If other sockets/terminals are still subscribed for this unit, it is
      // still online — only broadcast OFFLINE once the count hits zero.
      const stillOnline = rt.isUnitConnected(leavingId);
      const fresh = getResponder(leavingId);
      if (fresh) {
        // `fresh.isOnline` already reflects the decremented count.
        rt.emitUnitPresence(fresh);
        rt.emitFleetUnit(fresh);
      }
      console.log(`📴 Unit ${leavingId} ${stillOnline ? 'still online via another terminal' : 'disconnected'}`);
    }
  });
});

export { app, server, io };

if (process.env.NETLIFY !== 'true') {
  server.listen(PORT, () => {
    startSimulation();
    console.log('');
    console.log('  ███  NaijaSOS / ResQLink');
    console.log('  Multi-agency emergency response prototype');
    console.log(`  Citizen portal  → http://localhost:${PORT}/`);
    console.log(`  Command centre  → http://localhost:${PORT}/dispatch`);
    console.log(`  Field responder → http://localhost:${PORT}/responder`);
    console.log(`  Health check    → http://localhost:${PORT}/api/health`);
    console.log('');
  });

  function shutdown(signal) {
    console.log(`\n${signal} received — shutting down.`);
    stopSimulation();
    io.close();
    server.close(() => process.exit(0));
    setTimeout(() => process.exit(0), 3000).unref();
  }
  process.on('SIGINT', () => shutdown('SIGINT'));
  process.on('SIGTERM', () => shutdown('SIGTERM'));
}
