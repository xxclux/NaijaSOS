/* global io, L */
/**
 * Shared browser utilities for all three interfaces.
 * Exposed on window.NaijaSOS so each page script can stay focused on its UI.
 */
(() => {
  const AUTH_KEY = 'naijasos.auth';
  const readAuth = () => {
    try { return JSON.parse(localStorage.getItem(AUTH_KEY) || 'null'); } catch { return null; }
  };
  const initialAuth = readAuth();
  const socket = io({ transports: ['websocket', 'polling'], auth: { token: initialAuth?.token || null } });

  // -------------------------------------------------------------------------
  // Domain metadata
  // -------------------------------------------------------------------------
  const typeMeta = {
    medical: { label: 'Hospital / medical', short: 'Hospital', color: '#ef4444', icon: 'medical_services', agency: 'MEDICAL', hint: 'Injury, collapse, breathing' },
    police: { label: 'Police', short: 'Police', color: '#3b82f6', icon: 'local_police', agency: 'POLICE', hint: 'Crime, threat, violence' },
    fire: { label: 'Fire Service', short: 'Fire', color: '#f97316', icon: 'local_fire_department', agency: 'FIRE', hint: 'Fire, smoke, rescue' },
    road_safety: { label: 'Road Safety', short: 'Road', color: '#eab308', icon: 'traffic', agency: 'ROAD_SAFETY', hint: 'Collision, blockage, tow' },
    general: { label: 'General SOS', short: 'SOS', color: '#ff5540', icon: 'sos', agency: 'GENERAL', hint: 'Community / multi-agency' }
  };

  const agencyMeta = {
    POLICE: { label: 'Police', short: 'Police', color: '#3b82f6', icon: 'local_police' },
    MEDICAL: { label: 'Hospital / Ambulance', short: 'Hospital', color: '#ef4444', icon: 'medical_services' },
    FIRE: { label: 'Fire Service', short: 'Fire', color: '#f97316', icon: 'local_fire_department' },
    ROAD_SAFETY: { label: 'Road Safety', short: 'Road', color: '#eab308', icon: 'traffic' },
    GENERAL: { label: 'Others / community', short: 'Others', color: '#a78bfa', icon: 'volunteer_activism' }
  };

  const responderKinds = {
    car: { label: 'Car', icon: 'directions_car', color: '#a78bfa' },
    ambulance: { label: 'Ambulance', icon: 'emergency', color: '#ef4444' },
    police: { label: 'Police', icon: 'local_police', color: '#3b82f6' },
    fire: { label: 'Fire Service', icon: 'local_fire_department', color: '#f97316' },
    hospital: { label: 'Hospital', icon: 'local_hospital', color: '#ef4444' },
    road_safety: { label: 'Road Safety', icon: 'traffic', color: '#eab308' },
    other: { label: 'Others', icon: 'volunteer_activism', color: '#a78bfa' }
  };

  const incidentStatus = {
    new: { label: 'New alert', color: '#ff5540', icon: 'notifications_active' },
    triage: { label: 'Triaged', color: '#eab308', icon: 'fact_check' },
    dispatched: { label: 'Dispatched', color: '#f97316', icon: 'send' },
    en_route: { label: 'Units en route', color: '#f59e0b', icon: 'directions_car' },
    on_scene: { label: 'On scene', color: '#34d399', icon: 'location_on' },
    transporting: { label: 'Transporting', color: '#3b82f6', icon: 'local_hospital' },
    resolved: { label: 'Resolved', color: '#727979', icon: 'check_circle' },
    cancelled: { label: 'Cancelled', color: '#727979', icon: 'cancel' }
  };

  const unitStatus = {
    available: { label: 'Available', color: '#34d399' },
    dispatched: { label: 'Dispatched', color: '#f59e0b' },
    en_route: { label: 'En route', color: '#f59e0b' },
    on_scene: { label: 'On scene', color: '#34d399' },
    transporting: { label: 'Transporting', color: '#3b82f6' },
    returning: { label: 'Returning', color: '#a6acac' },
    offline: { label: 'Offline', color: '#727979' }
  };

  const assignmentStatus = {
    alerting: { label: 'Alerting', color: '#ff5540' },
    accepted: { label: 'Accepted', color: '#eab308' },
    declined: { label: 'Declined', color: '#727979' },
    en_route: { label: 'En route', color: '#f59e0b' },
    on_scene: { label: 'On scene', color: '#34d399' },
    transporting: { label: 'Transporting', color: '#3b82f6' },
    completed: { label: 'Completed', color: '#727979' },
    cancelled: { label: 'Cancelled', color: '#727979' }
  };

  const priorityMeta = {
    1: { label: 'P1 · Critical', short: 'P1', color: '#ff5540' },
    2: { label: 'P2 · Urgent', short: 'P2', color: '#f59e0b' },
    3: { label: 'P3 · Routine', short: 'P3', color: '#a6acac' },
    4: { label: 'P4 · Low', short: 'P4', color: '#727979' }
  };

  // -------------------------------------------------------------------------
  // Formatting
  // -------------------------------------------------------------------------
  const esc = (value) => String(value ?? '')
    .replaceAll('&', '&amp;').replaceAll('<', '&lt;').replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;').replaceAll("'", '&#039;');

  function pad(n) { return String(n).padStart(2, '0'); }

  function elapsed(seconds) {
    const s = Math.max(0, Number(seconds) || 0);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = Math.floor(s % 60);
    return h ? `${h}:${pad(m)}:${pad(sec)}` : `${pad(m)}:${pad(sec)}`;
  }

  function durationText(seconds) {
    const s = Math.max(0, Number(seconds) || 0);
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = Math.floor(s % 60);
    if (h) return `${h}h ${m}m`;
    if (m) return `${m}m ${pad(sec)}s`;
    return `${sec}s`;
  }

  function relativeTime(iso) {
    if (!iso) return '—';
    const diff = Math.max(0, Date.now() - new Date(iso).getTime());
    const mins = Math.floor(diff / 60000);
    if (mins < 1) return 'just now';
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.floor(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    return `${Math.floor(hours / 24)}d ago`;
  }

  function clockTime(iso, withSeconds = false) {
    if (!iso) return '—';
    return new Date(iso).toLocaleTimeString('en-NG', {
      hour: '2-digit', minute: '2-digit', ...(withSeconds ? { second: '2-digit' } : {}), hour12: false
    });
  }

  function watNow(withSeconds = true) {
    return new Intl.DateTimeFormat('en-NG', {
      timeZone: 'Africa/Lagos', hour: '2-digit', minute: '2-digit',
      ...(withSeconds ? { second: '2-digit' } : {}), hour12: false
    }).format(new Date());
  }

  function formatEta(minutes) {
    const m = Math.max(0, Math.round(Number(minutes) || 0));
    return m <= 0 ? 'Arriving' : `${m} min`;
  }

  function formatCoord(lat, lng) {
    if (!Number.isFinite(Number(lat)) || !Number.isFinite(Number(lng))) return '—';
    return `${Number(lat).toFixed(5)}°, ${Number(lng).toFixed(5)}°`;
  }

  function formatDistanceKm(km) {
    if (km == null) return '—';
    return Number(km) < 1 ? `${Math.round(Number(km) * 1000)} m` : `${Number(km).toFixed(1)} km`;
  }

  // -------------------------------------------------------------------------
  // API + notifications
  // -------------------------------------------------------------------------
  async function api(path, options = {}) {
    const { method = 'GET', body, signal, auth = true } = options;
    const token = auth ? readAuth()?.token : null;
    const response = await fetch(path, {
      method,
      signal,
      headers: {
        ...(body ? { 'Content-Type': 'application/json' } : {}),
        ...(token ? { Authorization: `Bearer ${token}` } : {})
      },
      body: body ? JSON.stringify(body) : undefined
    });
    let payload = null;
    try { payload = await response.json(); } catch { /* empty response */ }
    if (!response.ok) {
      const error = new Error(payload?.error || `Request failed (${response.status})`);
      error.status = response.status;
      error.details = payload?.details;
      throw error;
    }
    return payload;
  }

  function ensureToastStack() {
    let stack = document.getElementById('toastStack');
    if (!stack) {
      stack = document.createElement('div');
      stack.id = 'toastStack';
      stack.className = 'toast-stack';
      document.body.appendChild(stack);
    }
    return stack;
  }

  function toast(title, body = '', type = 'info', timeout = 4800) {
    const stack = ensureToastStack();
    const icons = { success: 'check_circle', error: 'error', info: 'info', warning: 'warning' };
    const node = document.createElement('div');
    node.className = `toast toast--${type}`;
    node.innerHTML = `
      <span class="material-symbols-outlined toast__icon">${icons[type] || 'info'}</span>
      <div class="min-w-0 flex-1">
        <p class="toast__title">${esc(title)}</p>
        ${body ? `<p class="toast__body">${esc(body)}</p>` : ''}
      </div>
      <button class="btn-quiet btn h-7 w-7 shrink-0 rounded-md p-0" aria-label="Dismiss">
        <span class="material-symbols-outlined text-[16px]">close</span>
      </button>`;
    node.querySelector('button').addEventListener('click', () => node.remove());
    stack.appendChild(node);
    setTimeout(() => { node.style.opacity = '0'; node.style.transform = 'translateY(8px)'; setTimeout(() => node.remove(), 250); }, timeout);
  }

  // -------------------------------------------------------------------------
  // Audio (siren / chime). Browsers require a user gesture before audio.
  // -------------------------------------------------------------------------
  let audioCtx = null;
  function audio() {
    if (!audioCtx) {
      const Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return null;
      audioCtx = new Ctx();
    }
    if (audioCtx.state === 'suspended') audioCtx.resume().catch(() => {});
    return audioCtx;
  }

  function tone(freq, start, duration, { gain = 0.08, type = 'sine' } = {}) {
    const ctx = audio();
    if (!ctx) return;
    const osc = ctx.createOscillator();
    const vol = ctx.createGain();
    osc.type = type;
    osc.frequency.value = freq;
    vol.gain.setValueAtTime(0, ctx.currentTime + start);
    vol.gain.linearRampToValueAtTime(gain, ctx.currentTime + start + 0.015);
    vol.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + start + duration);
    osc.connect(vol).connect(ctx.destination);
    osc.start(ctx.currentTime + start);
    osc.stop(ctx.currentTime + start + duration + 0.03);
  }

  function chime() {
    tone(880, 0, 0.16, { gain: 0.06 });
    tone(1320, 0.18, 0.2, { gain: 0.055 });
  }

  function dispatchTone() {
    tone(620, 0, 0.18, { gain: 0.09, type: 'square' });
    tone(880, 0.2, 0.18, { gain: 0.075, type: 'square' });
    tone(620, 0.42, 0.18, { gain: 0.09, type: 'square' });
  }

  /** Continuous two-tone emergency siren; returns an idempotent stop function. */
  function startSiren() {
    const ctx = audio();
    if (!ctx) return () => {};
    let stopped = false;
    const gain = ctx.createGain();
    gain.gain.value = 0.035;
    gain.connect(ctx.destination);
    const osc = ctx.createOscillator();
    osc.type = 'triangle';
    osc.frequency.value = 720;
    const lfo = ctx.createOscillator();
    const lfoGain = ctx.createGain();
    lfo.frequency.value = 1.9;
    lfoGain.gain.value = 190;
    lfo.connect(lfoGain).connect(osc.frequency);
    osc.connect(gain);
    osc.start();
    lfo.start();
    return () => {
      if (stopped) return;
      stopped = true;
      try {
        gain.gain.setTargetAtTime(0.0001, ctx.currentTime, 0.04);
        setTimeout(() => { try { osc.stop(); lfo.stop(); gain.disconnect(); } catch { /* already stopped */ } }, 220);
      } catch { /* already stopped */ }
    };
  }

  // -------------------------------------------------------------------------
  // Leaflet helpers
  // -------------------------------------------------------------------------
  const LAGOS_CENTRE = [6.5244, 3.3792];
  let mapSequence = 0;

  function initMap(elementOrId, { center = LAGOS_CENTRE, zoom = 12, interactive = true } = {}) {
    const node = typeof elementOrId === 'string' ? document.getElementById(elementOrId) : elementOrId;
    if (!node) return null;
    if (typeof L === 'undefined') {
      node.innerHTML = `<div class="flex h-full items-center justify-center p-6 text-center text-sm text-muted">Map engine unavailable — check your network connection.</div>`;
      return null;
    }
    const map = L.map(node, {
      center, zoom, zoomControl: false, attributionControl: true,
      preferCanvas: true, ...(interactive ? {} : { dragging: false, scrollWheelZoom: false, doubleClickZoom: false, touchZoom: false })
    });
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener">OpenStreetMap</a> contributors'
    }).addTo(map);
    L.control.zoom({ position: 'bottomright' }).addTo(map);
    mapSequence += 1;
    setTimeout(() => map.invalidateSize(), 120);
    return map;
  }

  function markerIcon({ color = '#ff5540', icon = 'emergency', label = '', selected = false, kind = 'incident' } = {}) {
    return L.divIcon({
      className: `map-marker map-marker--${kind}${selected ? ' map-marker--selected' : ''}`,
      html: `<div class="map-marker__ring" style="--marker-color:${color}"></div>
             <div class="map-marker__pin" style="--marker-color:${color}">
               <span class="material-symbols-outlined">${icon}</span>
             </div>
             ${label ? `<span class="map-marker__label">${esc(label)}</span>` : ''}`,
      iconSize: [40, 40],
      iconAnchor: [20, 20]
    });
  }

  function incidentMarkerIcon(incident, selected = false) {
    const meta = typeMeta[incident.type] || typeMeta.general;
    return markerIcon({
      color: meta.color, icon: meta.icon,
      label: incident.code.replace('INC-', '#'),
      selected, kind: 'incident'
    });
  }

  function unitMarkerIcon(unit, selected = false) {
    const meta = agencyMeta[unit.agencyCode] || { color: '#a6acac', icon: 'local_taxi' };
    // Offline / stale units render washed-out so the live (online + fresh)
    // fleet reads at a glance on both the Admin and NEMA maps.
    const dimmed = unit && !unit.isOnline && !unit.isGpsFresh;
    return markerIcon({
      color: dimmed ? '#6b7280' : meta.color,
      icon: meta.icon,
      label: unit.callSign,
      selected: selected || !!unit?.isGpsFresh,
      kind: 'unit'
    });
  }

  /** Short, human sync state used across Admin + NEMA: LINKED/ONLINE/FRESH etc. */
  function unitSyncLabel(unit) {
    if (!unit) return '—';
    if (!unit.isLinked) return 'UNLINKED';
    if (unit.isOnline && unit.isGpsFresh) return 'SYNCING LIVE';
    if (unit.isOnline) return 'ONLINE';
    return 'OFFLINE';
  }

  /** "last sync 45s ago" style text for badges/tooltips. */
  function syncAgeText(unit) {
    if (!unit) return '—';
    if (unit.gpsSyncAgeSeconds == null) return 'never synced';
    const seconds = Number(unit.gpsSyncAgeSeconds);
    if (seconds < 60) return `synced ${seconds}s ago`;
    const mins = Math.round(seconds / 60);
    if (mins < 60) return `synced ${mins}m ago`;
    const hours = Math.round(mins / 60);
    return `synced ${hours}h ago`;
  }

  function setMapView(map, points, { padding = [40, 40], maxZoom = 14 } = {}) {
    if (!map || !points?.length) return;
    const clean = points.filter((p) => p && Number.isFinite(Number(p.lat)) && Number.isFinite(Number(p.lng)));
    if (!clean.length) return;
    if (clean.length === 1) { map.setView([clean[0].lat, clean[0].lng], Math.max(map.getZoom(), 14)); return; }
    map.fitBounds(clean.map((p) => [p.lat, p.lng]), { padding, maxZoom });
  }

  function escapeRoute(route) {
    return Array.isArray(route?.coordinates) ? route.coordinates.map(([lng, lat]) => [lat, lng]) : [];
  }

  // -------------------------------------------------------------------------
  // Misc UI
  // -------------------------------------------------------------------------
  function setClock(el) {
    if (!el) return;
    const tick = () => { el.textContent = watNow(true); };
    tick();
    return setInterval(tick, 1000);
  }

  function startElapsed(el, iso) {
    if (!el) return () => {};
    const start = new Date(iso).getTime();
    const update = () => { el.textContent = elapsed((Date.now() - start) / 1000); };
    update();
    const id = setInterval(update, 1000);
    return () => clearInterval(id);
  }

  function copyText(text) {
    if (navigator.clipboard?.writeText) {
      return navigator.clipboard.writeText(text).then(() => toast('Copied', 'Coordinates copied to clipboard.', 'success'));
    }
    toast('Copy unavailable', 'Your browser blocked clipboard access.', 'error');
    return Promise.resolve();
  }

  function debounce(fn, ms = 220) {
    let t;
    return (...args) => { clearTimeout(t); t = setTimeout(() => fn(...args), ms); };
  }

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];

  function modal({ title, subtitle = '', body = '', footer = '', wide = false, onClose = null }) {
    const backdrop = document.createElement('div');
    backdrop.className = 'modal-backdrop';
    backdrop.innerHTML = `
      <div class="modal ${wide ? 'sm:max-w-3xl' : ''}" role="dialog" aria-modal="true" aria-label="${esc(title)}">
        <div class="modal-header">
          <div>
            <h2 class="text-base font-bold text-text">${esc(title)}</h2>
            ${subtitle ? `<p class="mt-0.5 text-[11px] text-muted">${esc(subtitle)}</p>` : ''}
          </div>
          <button type="button" class="btn btn-quiet btn-icon" data-close aria-label="Close">
            <span class="material-symbols-outlined">close</span>
          </button>
        </div>
        <div class="modal-body">${body}</div>
        ${footer ? `<div class="flex items-center justify-end gap-2 border-t border-line-soft px-5 py-4">${footer}</div>` : ''}
      </div>`;
    document.body.appendChild(backdrop);
    let closed = false;
    const close = () => {
      if (closed) return;
      closed = true;
      backdrop.remove();
      onClose?.();
    };
    backdrop.addEventListener('click', (event) => { if (event.target === backdrop || event.target.closest('[data-close]')) close(); });
    document.addEventListener('keydown', function onKey(event) {
      if (event.key === 'Escape') { close(); document.removeEventListener('keydown', onKey); }
    });
    return { el: backdrop, close };
  }

  function confirmDialog({ title, body, confirmLabel = 'Confirm', danger = false }) {
    return new Promise((resolve) => {
      const dialog = modal({
        title,
        body: `<p class="text-sm leading-relaxed text-muted">${body}</p>`,
        footer: `<button class="btn btn-ghost" data-cancel>Cancel</button>
                 <button class="btn ${danger ? 'btn-primary' : 'btn-ok'}" data-confirm>${esc(confirmLabel)}</button>`
      });
      dialog.el.querySelector('[data-cancel]').addEventListener('click', () => { dialog.close(); resolve(false); });
      dialog.el.querySelector('[data-confirm]').addEventListener('click', () => { dialog.close(); resolve(true); });
      dialog.el.querySelector('[data-close]')?.addEventListener('click', () => resolve(false));
      dialog.el.addEventListener('click', (event) => { if (event.target === dialog.el) resolve(false); });
    });
  }

  function makeId() {
    return `el-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`;
  }

  // -------------------------------------------------------------------------
  // Tenant session (one login page, three independent workspaces)
  // -------------------------------------------------------------------------
  function session() {
    return readAuth();
  }

  function account() {
    return readAuth()?.account || null;
  }

  function authToken() {
    return readAuth()?.token || null;
  }

  function saveSession(data) {
    localStorage.setItem(AUTH_KEY, JSON.stringify(data));
    socket.auth = { token: data?.token || null };
    if (socket.connected) {
      socket.disconnect().connect();
    }
  }

  function clearSession() {
    localStorage.removeItem(AUTH_KEY);
    socket.auth = { token: null };
    if (socket.connected) socket.disconnect();
  }

  async function login(credentials) {
    const data = await api('/api/auth/login', { method: 'POST', body: credentials, auth: false });
    saveSession(data);
    return data;
  }

  /** Redeem a NEMA-issued one-time state EOC access code. */
  async function loginWithCode(code) {
    const data = await api('/api/auth/access-code', { method: 'POST', body: { code }, auth: false });
    saveSession(data);
    return data;
  }

  async function logout({ redirect = '/login' } = {}) {
    try { await api('/api/auth/logout', { method: 'POST' }); } catch { /* session may already be gone */ }
    clearSession();
    if (redirect) location.href = redirect;
  }

  function homeForRole(role) {
    if (role === 'superadmin') return '/admin';
    if (role === 'nema') return '/nema';
    if (role === 'state') return '/state';
    if (role === 'responder') return '/responder';
    return '/login';
  }

  function roleForPath(pathname = location.pathname) {
    if (pathname.startsWith('/admin')) return 'superadmin';
    if (pathname.startsWith('/responder')) return 'responder';
    if (pathname.startsWith('/state')) return 'state';
    if (pathname.startsWith('/nema') || pathname.startsWith('/dispatch')) return 'nema';
    return null;
  }

  function loginUrl(next, role = null) {
    const params = new URLSearchParams({ next });
    const hint = role || roleForPath(next);
    if (hint) params.set('role', hint);
    return `/login?${params.toString()}`;
  }

  /** Page guard for dashboard scripts. Returns the signed-in account. */
  async function requireRole(roles, { next = location.pathname } = {}) {
    const local = account();
    const hint = local?.role || roles?.[0] || roleForPath(next);
    if (!local) {
      location.replace(loginUrl(next, hint));
      throw new Error('AUTH_REDIRECT');
    }
    const roleAllowed = (role, targetRoles) => {
      if (!targetRoles?.length) return true;
      if (targetRoles.includes(role)) return true;
      if (role === 'superadmin') return true;
      return false;
    };
    if (!roleAllowed(local.role, roles)) {
      location.replace(homeForRole(local.role));
      throw new Error('AUTH_REDIRECT');
    }
    try {
      const { account: fresh } = await api('/api/auth/me');
      saveSession({ ...(session() || {}), account: fresh });
      if (!roleAllowed(fresh.role, roles)) {
        location.replace(homeForRole(fresh.role));
        throw new Error('AUTH_REDIRECT');
      }
      return fresh;
    } catch (error) {
      if (error.status === 401) {
        clearSession();
        location.replace(loginUrl(next, hint));
        throw new Error('AUTH_REDIRECT');
      }
      throw error;
    }
  }

  function roleLabel(role) {
    return role === 'superadmin' ? 'Super Admin / Central Backend'
      : role === 'nema' ? 'NEMA National Command'
      : role === 'state' ? 'State Counterpart (SEMA)'
      : role === 'responder' ? 'First Responder (Hytera APK)' : 'Guest';
  }

  function stateText(code, name = null) {
    if (name) return name === 'FCT' ? 'FCT · Abuja' : name;
    if (code === 'FC') return 'FCT · Abuja';
    return code || '—';
  }

  window.NaijaSOS = {
    socket, api, toast, esc, elapsed, durationText, relativeTime, clockTime, watNow,
    formatEta, formatCoord, formatDistanceKm, typeMeta, agencyMeta, responderKinds, incidentStatus,
    unitStatus, assignmentStatus, priorityMeta, chime, dispatchTone, startSiren, audio,
    unitSyncLabel, syncAgeText,
    initMap, markerIcon, incidentMarkerIcon, unitMarkerIcon, setMapView, escapeRoute,
    LAGOS_CENTRE, setClock, startElapsed, copyText, debounce, $, $$, modal,
    confirmDialog, makeId, mapSequence,
    session, account, authToken, saveSession, clearSession, login, loginWithCode, logout,
    homeForRole, requireRole, roleLabel, stateText
  };
})();
