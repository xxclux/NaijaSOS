import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

export const DB_PATH = process.env.DB_PATH || path.join(DATA_DIR, 'naijasos.db');

// SQLite is the zero-config local store. The schema is deliberately portable
// to PostgreSQL + PostGIS (see docs/ARCHITECTURE.md).
export const db = new DatabaseSync(DB_PATH);
db.exec('PRAGMA journal_mode = WAL;');
db.exec('PRAGMA foreign_keys = ON;');
db.exec('PRAGMA busy_timeout = 5000;');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

// ---------------------------------------------------------------------------
// Inline migrations — applied once at startup, idempotent.
// ---------------------------------------------------------------------------
function migrateOnce() {
  // 1. Add temp_password column (stores the last-issued plaintext password so
  //    admin can display it; cleared on first sign-in)
  const cols = db.prepare("PRAGMA table_info(accounts)").all().map((c) => c.name);
  if (!cols.includes('temp_password')) {
    db.exec('ALTER TABLE accounts ADD COLUMN temp_password TEXT');
    console.log('[db] Migration: added accounts.temp_password');
    // Back-fill known seed passwords for existing accounts so admin can see them right away
    const knownPasswords = {
      'nema.admin':     'NEMA#2026',
      'lagos.eoc':      'Lagos#2026',
      'fct.eoc':        'FCT#2026',
      'amb.ikeja':      'RESP#2026',
      'police.lekki':   'RESP#2026',
      'amb.wuse':       'RESP#2026',
      'car.lekki':      'RESP#2026',
    };
    for (const [uname, pwd] of Object.entries(knownPasswords)) {
      db.prepare('UPDATE accounts SET temp_password = ? WHERE username = ?').run(pwd, uname);
    }
    // Back-fill state accounts: pattern is {StateName}#2026
    // We'll derive from username: e.g. 'adamawa.eoc' → 'Adamawa#2026'
    const stateRows = db.prepare("SELECT id, username FROM accounts WHERE role = 'state'").all();
    for (const row of stateRows) {
      const prefix = row.username.replace('.eoc', '');
      const capitalized = prefix.charAt(0).toUpperCase() + prefix.slice(1);
      const guessed = `${capitalized}#2026`;
      db.prepare('UPDATE accounts SET temp_password = ? WHERE id = ? AND temp_password IS NULL').run(guessed, row.id);
    }
    console.log('[db] Migration: back-filled temp_password for seeded accounts');
  }

  // 2. Citizen SOS scene photo. Older databases predate the column, so add it
  //    in place; new databases already get it from schema.sql.
  const incidentCols = db.prepare('PRAGMA table_info(incidents)').all().map((c) => c.name);
  if (!incidentCols.includes('photo_path')) {
    db.exec('ALTER TABLE incidents ADD COLUMN photo_path TEXT');
    console.log('[db] Migration: added incidents.photo_path');
  }

  // 3. Fix old databases that have the accounts role CHECK without 'superadmin'.
  //    In modern SQLite, sqlite_master is read-only. But since superadmin authentication
  //    is handled statelessly via startBootstrapSession(), we don't need a DB superadmin row.
}

migrateOnce();

export function all(sql, ...params) {
  return db.prepare(sql).all(...params);
}

export function get(sql, ...params) {
  return db.prepare(sql).get(...params);
}

export function run(sql, ...params) {
  return db.prepare(sql).run(...params);
}

export function transaction(fn) {
  db.exec('BEGIN IMMEDIATE');
  try {
    const result = fn();
    db.exec('COMMIT');
    return result;
  } catch (error) {
    try { db.exec('ROLLBACK'); } catch { /* already rolled back */ }
    throw error;
  }
}

export function parseJson(value, fallback) {
  if (value == null) return fallback;
  try { return JSON.parse(value); } catch { return fallback; }
}

export function nowIso() {
  return new Date().toISOString();
}

/** Insert an append-only incident timeline event. */
export function addEvent(incidentId, { type, actorType = 'system', actorId = null, message, payload = {} }, timestamp = null) {
  const at = timestamp || nowIso();
  return run(
    `INSERT INTO incident_events (incident_id, type, actor_type, actor_id, message, payload_json, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    incidentId, type, actorType, actorId, message, JSON.stringify(payload), at
  );
}

/** Chat / note message. */
export function addMessage(incidentId, { channel = 'chat', senderType, senderId = null, senderName, body }, timestamp = null) {
  const at = timestamp || nowIso();
  return run(
    `INSERT INTO incident_messages (incident_id, channel, sender_type, sender_id, sender_name, body, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    incidentId, channel, senderType, senderId, senderName, body, at
  );
}
