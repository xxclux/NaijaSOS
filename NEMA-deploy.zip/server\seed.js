/**
 * Development seed data (mock). The live database no longer auto-seeds.
 * Run `npm run seed` explicitly, or start the server with SEED_DEMO=1, to load
 * this sample fleet and incidents into an empty database.
 *
 * Coordinates are real Lagos locations so the routing and ETA calculations look
 * believable out of the box.
 */
import {
  get, run, transaction, addEvent, addMessage
} from './db.js';
import { syntheticRoute, pointAlongRoute, etaMinutes } from './geo.js';
import { startAiSupport, handoffOnScene, closeAiSupport } from './services/ai.js';
import { stateForPoint, stateLabel, NIGERIA_STATES } from './states.js';
import { createAccount } from './services/auth.js';

const CENTRE = { lat: 6.5244, lng: 3.3792, address: 'Lagos, Nigeria' };

function isoAgo(minutes) {
  return new Date(Date.now() - minutes * 60_000).toISOString();
}

function insertUser({ publicId, role, fullName, phone = null, email = null }) {
  const result = run(
    `INSERT INTO users (public_id, role, full_name, phone, email, created_at)
     VALUES (?, ?, ?, ?, ?, ?)`,
    publicId, role, fullName, phone, email, isoAgo(60 * 24 * 30)
  );
  return Number(result.lastInsertRowid);
}

function insertAgency({ code, name, shortName, jurisdiction, emergencyNumber, color, icon }) {
  const result = run(
    `INSERT INTO agencies (code, name, short_name, jurisdiction, emergency_number, color, icon)
     VALUES (?, ?, ?, ?, ?, ?, ?)`,
    code, name, shortName, jurisdiction, emergencyNumber, color, icon
  );
  return Number(result.lastInsertRowid);
}

function insertResponder({ publicId, agencyId, callSign, vehicleType, plate, station, status, lat, lng, heading = 0, speed = 0, shift = 'A', battery = 82, simulated = 1, stateCode = 'LA', kind = 'ambulance', community = 0, registrationId = null }) {
  const result = run(
    `INSERT INTO responders
       (public_id, agency_id, call_sign, vehicle_type, responder_kind, state_code,
        plate_number, station, status, lat, lng, heading, speed_kph, shift_code, battery_pct,
        is_simulated, is_community, registration_id, verified_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    publicId, agencyId, callSign, vehicleType, kind, stateCode, plate, station, status,
    lat, lng, heading, speed, shift, battery, simulated, community, registrationId, isoAgo(0), isoAgo(0)
  );
  return Number(result.lastInsertRowid);
}

function insertIncident(incident) {
  const state = stateForPoint(incident.lat, incident.lng);
  const result = run(
    `INSERT INTO incidents
       (code, reporter_user_id, reporter_name, reporter_phone, type, priority, status, lat, lng, accuracy_m,
        address, landmark, state_code, state_name, description, hazards_json, people_affected, source, live_tracking, created_by_role,
        assigned_dispatcher_id, created_at, acknowledged_at, dispatched_at, arrived_at, resolved_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    incident.code, incident.reporterUserId ?? null, incident.reporterName ?? null, incident.reporterPhone ?? null,
    incident.type, incident.priority, incident.status, incident.lat, incident.lng, incident.accuracy ?? 12,
    incident.address, incident.landmark ?? null, incident.stateCode || state?.code || 'LA',
    incident.stateName || stateLabel(state) || 'Lagos',
    incident.description, JSON.stringify(incident.hazards ?? []),
    incident.peopleAffected ?? 1, incident.source ?? 'app', incident.liveTracking ? 1 : 0,
    incident.createdByRole ?? 'citizen', incident.dispatcherId ?? null,
    incident.createdAt, incident.acknowledgedAt ?? null, incident.dispatchedAt ?? null,
    incident.arrivedAt ?? null, incident.resolvedAt ?? null
  );
  return Number(result.lastInsertRowid);
}

function insertAssignment({ incidentId, responder, agencyId, status, progress = 0, assignedAt, acceptedAt = null, arrivedAt = null, completedAt = null }) {
  const incident = get('SELECT * FROM incidents WHERE id = ?', incidentId);
  const route = syntheticRoute(
    { lat: responder.lat, lng: responder.lng },
    { lat: incident.lat, lng: incident.lng, address: incident.address, landmark: incident.landmark }
  );
  const progressPoint = pointAlongRoute(route.geometry.coordinates, progress);
  const remainingKm = Math.max(0.05, route.distanceKm * (1 - progress));
  const eta = status === 'on_scene' || status === 'completed' ? 0 : etaMinutes(remainingKm);

  // Keep the simulated vehicle on the route at its seed progress.
  if (status !== 'completed') {
    run(
      `UPDATE responders SET lat = ?, lng = ?, heading = ?, speed_kph = ?, status = ?, updated_at = ?
       WHERE id = ?`,
      progressPoint.lat, progressPoint.lng, progressPoint.heading,
      status === 'on_scene' ? 0 : 34, status === 'on_scene' ? 'on_scene' : 'en_route', isoAgo(0), responder.id
    );
  }

  const result = run(
    `INSERT INTO incident_assignments
       (incident_id, responder_id, agency_id, status, distance_km, eta_minutes, progress, route_json, steps_json,
        route_source, assigned_at, accepted_at, arrived_at, completed_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    incidentId, responder.id, agencyId, status, route.distanceKm, eta, progress,
    JSON.stringify(route.geometry), JSON.stringify(route.steps), route.routeSource,
    assignedAt, acceptedAt, arrivedAt, completedAt
  );
  return Number(result.lastInsertRowid);
}

export function seedDatabase({ force = false } = {}) {
  const existing = get('SELECT COUNT(*) AS count FROM agencies');
  if (existing.count > 0 && !force) return false;
  const seededIncidentIds = [];

  transaction(() => {
    // Delete child tables first; this also makes `npm run seed` idempotent.
    for (const table of [
      'auth_sessions', 'accounts',
      'ai_messages', 'ai_sessions', 'registrations',
      'responder_locations', 'media_sessions', 'incident_notes', 'incident_messages',
      'incident_events', 'incident_assignments', 'incidents', 'responders', 'agencies', 'users'
    ]) {
      run(`DELETE FROM ${table}`);
    }
    run("DELETE FROM sqlite_sequence WHERE name NOT IN ('')");

    const dispatcherId = insertUser({
      publicId: 'DSP-042', role: 'dispatcher', fullName: 'Amina Okafor',
      phone: '+2348030000042', email: 'amina.okafor@naijasos.gov.ng'
    });
    insertUser({
      publicId: 'SUP-001', role: 'dispatcher', fullName: 'Femi Adeleke',
      phone: '+2348030000001', email: 'femi.adeleke@naijasos.gov.ng'
    });
    insertUser({
      publicId: 'NEMA-01', role: 'dispatcher', fullName: 'NEMA National EOC',
      phone: '+2348030000112', email: 'eoc@nema.gov.ng'
    });
    insertUser({
      publicId: 'EOC-LA', role: 'dispatcher', fullName: 'Lagos State EOC',
      phone: '+2348030000767', email: 'eoc@lagosstate.gov.ng'
    });
    insertUser({
      publicId: 'EOC-FC', role: 'dispatcher', fullName: 'FCT Emergency Operations Centre',
      phone: '+2348030000113', email: 'eoc@fct.gov.ng'
    });
    const citizenId = insertUser({
      publicId: 'CIT-8841', role: 'citizen', fullName: 'Adaeze Nwosu',
      phone: '+2348035550192', email: 'adaeze@example.com'
    });

    const policeId = insertAgency({
      code: 'POLICE', name: 'Nigeria Police Force', shortName: 'Police',
      jurisdiction: 'Nigeria', emergencyNumber: '112', color: '#3b82f6', icon: 'local_police'
    });
    const medicalId = insertAgency({
      code: 'MEDICAL', name: 'National Emergency Medical Service / Hospital Network', shortName: 'Hospital',
      jurisdiction: 'Nigeria', emergencyNumber: '112', color: '#ef4444', icon: 'medical_services'
    });
    const fireId = insertAgency({
      code: 'FIRE', name: 'Federal Fire Service', shortName: 'Fire Service',
      jurisdiction: 'Nigeria', emergencyNumber: '112', color: '#f97316', icon: 'local_fire_department'
    });
    const roadId = insertAgency({
      code: 'ROAD_SAFETY', name: 'Federal Road Safety Corps (FRSC)', shortName: 'Road Safety',
      jurisdiction: 'Nigeria', emergencyNumber: '122', color: '#eab308', icon: 'traffic'
    });
    const generalId = insertAgency({
      code: 'GENERAL', name: 'Community First Responders & NGOs', shortName: 'Others',
      jurisdiction: 'Nigeria', emergencyNumber: '112', color: '#a78bfa', icon: 'volunteer_activism'
    });

    const agencyId = { POLICE: policeId, MEDICAL: medicalId, FIRE: fireId, ROAD_SAFETY: roadId, GENERAL: generalId };

    const unitDefs = [
      ['POLICE-08', policeId, 'Toyota Hilux Patrol', 'LSD-08-AA', 'Ikeja GRA Division', 'available', 6.5830, 3.3520, 74, 0, 91],
      ['POLICE-12', policeId, 'Toyota Hilux Patrol', 'LSD-12-KJ', 'Lekki Phase 1 Division', 'en_route', 6.4478, 3.4723, 312, 36, 88],
      ['POLICE-04', policeId, 'Ford Ranger Rapid Response', 'LSD-04-SR', 'Surulere Division', 'on_scene', 6.5000, 3.3580, 0, 0, 76],
      ['POLICE-21', policeId, 'Toyota Hilux Patrol', 'LSD-21-OS', 'Oshodi Division', 'available', 6.5550, 3.3370, 110, 0, 64],
      ['AMB-04', medicalId, 'Mercedes Sprinter ICU', 'LAS-04-AM', 'Ikeja LASAMBUS Hub', 'en_route', 6.5900, 3.3450, 62, 38, 83],
      ['AMB-09', medicalId, 'Toyota Land Cruiser ALS', 'LAS-09-VI', 'Victoria Island Station', 'available', 6.4281, 3.4219, 20, 0, 95],
      ['AMB-02', medicalId, 'Mercedes Sprinter BLS', 'LAS-02-YB', 'Yaba General Hospital', 'available', 6.5095, 3.3711, 250, 0, 71],
      ['AMB-11', medicalId, 'Toyota HiAce BLS', 'LAS-11-AJ', 'Ajah / Sangotedo Station', 'available', 6.4667, 3.5667, 180, 0, 58],
      ['FIRE-03', fireId, 'Scania P320 Fire Engine', 'LSF-03-IK', 'Ikeja Fire Station', 'available', 6.5880, 3.3600, 40, 0, 87],
      ['FIRE-07', fireId, 'MAN TGM Rescue Tender', 'LSF-07-SU', 'Surulere Fire Station', 'on_scene', 6.4970, 3.3520, 0, 0, 79],
      ['FIRE-02', fireId, 'Scania P360 Water Tanker', 'LSF-02-AP', 'Apapa Fire Station', 'offline', 6.4480, 3.3590, 0, 0, 22],
      ['LASTMA-05', roadId, 'Toyota Hilux Traffic Van', 'LST-05-TM', 'Third Mainland Bridge Post', 'available', 6.4900, 3.4000, 340, 0, 90],
      ['LASTMA-11', roadId, 'Toyota Hilux Traffic Van', 'LST-11-OJ', 'Ojota Traffic Post', 'available', 6.5760, 3.3800, 90, 0, 85],
      ['LASTMA-08', roadId, 'Ford Transit Tow Unit', 'LST-08-VI', 'Victoria Island Traffic Post', 'available', 6.4281, 3.4219, 210, 0, 67],
      // FCT / Abuja state counterpart
      ['POLICE-FCT-01', policeId, 'Toyota Hilux Patrol', 'FCT-01-PF', 'Wuse Police Division', 'available', 9.0665, 7.4750, 180, 0, 92],
      ['AMB-FCT-01', medicalId, 'Mercedes Sprinter ALS', 'FCT-01-AM', 'Wuse District Hospital', 'available', 9.0700, 7.4800, 90, 0, 88],
      ['FIRE-FCT-01', fireId, 'Scania P320 Fire Engine', 'FCT-01-FS', 'Garki Fire Station', 'available', 9.0333, 7.4833, 45, 0, 84],
      ['FRSC-FCT-01', roadId, 'Toyota Hilux Traffic Van', 'FCT-01-RS', 'Maitama FRSC Post', 'available', 9.0833, 7.4950, 220, 0, 80],
      // Registered community first responders (protocol: register to use)
      ['CAR-LA-01', generalId, 'Toyota Corolla (private car)', 'KJA-418-XY', 'Lekki community responder', 'available', 6.4478, 3.4723, 120, 0, 100],
      ['CAR-FCT-01', generalId, 'Honda CR-V (private car)', 'ABJ-902-KD', 'Wuse community responder', 'available', 9.0600, 7.4700, 300, 0, 100],
      ['RESQ-LA-01', generalId, 'Volunteer ambulance', 'NGO-114-LA', 'Lagos NGO medical corps', 'available', 6.5200, 3.3900, 60, 0, 100]
    ];

    const AGENCY_KIND = {
      POLICE: 'police', MEDICAL: 'ambulance', FIRE: 'fire',
      ROAD_SAFETY: 'road_safety', GENERAL: 'car'
    };

    const responders = {};
    for (const [publicId, agency, vehicleType, plate, station, status, lat, lng, heading, speed, battery] of unitDefs) {
      const routed = stateForPoint(lat, lng);
      const kind = publicId.startsWith('RESQ-') ? 'other'
        : publicId.startsWith('CAR-') ? 'car'
        : publicId.startsWith('HOSP-') ? 'hospital'
        : AGENCY_KIND[agency === policeId ? 'POLICE' : agency === medicalId ? 'MEDICAL' : agency === fireId ? 'FIRE' : agency === roadId ? 'ROAD_SAFETY' : 'GENERAL'];
      const id = insertResponder({
        publicId, agencyId: agency, callSign: publicId, vehicleType, plate, station, status,
        lat, lng, heading, speed, battery, stateCode: routed?.code || 'LA', kind,
        community: publicId.startsWith('CAR-') || publicId.startsWith('RESQ-') ? 1 : 0
      });
      responders[publicId] = { id, lat, lng, status, stateCode: routed?.code || 'LA' };
      run(
        `INSERT INTO responder_locations (responder_id, lat, lng, heading, speed_kph, recorded_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        id, lat, lng, heading, speed, isoAgo(0)
      );
    }

    // Registration records for the community units already on the network,
    // plus one pending application for the state EOC to review.
    const registrationDefs = [
      {
        publicId: 'REG-1042', name: 'Kunle Adebayo', phone: '+2348025551101', kind: 'car',
        agency: 'GENERAL', state: 'LA', vehicle: 'Toyota Corolla (private car)',
        plate: 'KJA-418-XY', callsign: 'CAR-LA-01', status: 'approved', reviewer: 'Lagos State EOC'
      },
      {
        publicId: 'REG-1043', name: 'Hauwa Bello', phone: '+2348065551102', kind: 'car',
        agency: 'GENERAL', state: 'FC', vehicle: 'Honda CR-V (private car)',
        plate: 'ABJ-902-KD', callsign: 'CAR-FCT-01', status: 'approved', reviewer: 'FCT Emergency Operations Centre'
      },
      {
        publicId: 'REG-1044', name: 'Emeka Nwosu', phone: '+2348095551103', kind: 'other',
        agency: 'GENERAL', state: 'LA', vehicle: 'Volunteer ambulance',
        plate: 'NGO-114-LA', callsign: 'RESQ-LA-01', status: 'approved', reviewer: 'Lagos State EOC'
      },
      {
        publicId: 'REG-1051', name: 'Bola Martins', phone: '+2348135551104', kind: 'ambulance',
        agency: 'MEDICAL', state: 'LA', vehicle: 'Toyota HiAce (volunteer ambulance)',
        plate: 'NGO-221-LA', callsign: null, status: 'pending', reviewer: null
      }
    ];
    for (const reg of registrationDefs) {
      const unit = reg.callsign ? responders[reg.callsign] : null;
      const inserted = run(
        `INSERT INTO registrations
           (public_id, full_name, phone, responder_kind, agency_code, state_code, vehicle_type,
            plate_number, callsign_requested, status, verified_by, responder_id, created_at, reviewed_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        reg.publicId, reg.name, reg.phone, reg.kind, reg.agency, reg.state, reg.vehicle,
        reg.plate, reg.callsign, reg.status, reg.reviewer, unit?.id || null,
        isoAgo(reg.status === 'pending' ? 35 : 60 * 24 * 2),
        reg.status === 'pending' ? null : isoAgo(60 * 24 * 2)
      );
      if (unit) run('UPDATE responders SET registration_id = ? WHERE id = ?', Number(inserted.lastInsertRowid), unit.id);
    }

    // Tenant logins. NEMA owns the national account and issues state logins.
    // State EOCs then issue first-responder logins for their own units.
    const nemaAccount = createAccount({
      username: 'nema.admin', password: 'NEMA#2026', role: 'nema',
      displayName: 'NEMA National Emergency Operations Centre'
    });
    // Store temp_password so admin can display it
    try { run('UPDATE accounts SET temp_password = ? WHERE id = ?', 'NEMA#2026', nemaAccount.id); } catch {}
    // Seed all 37 State EOC counterpart accounts (36 states + FCT)
    const stateAccountMap = new Map();
    for (const state of NIGERIA_STATES) {
      const cleanName = (state.shortName || state.name).replace(/[^a-zA-Z0-9]/g, '');
      const username = state.code === 'FC' ? 'fct.eoc' : `${cleanName.toLowerCase()}.eoc`;
      const displayName = state.code === 'FC' ? 'FCT Emergency Operations Centre' : `${state.name} State Emergency Operations Centre`;
      const password = state.code === 'LA' ? 'Lagos#2026' : (state.code === 'FC' ? 'FCT#2026' : `${cleanName}#2026`);
      const acc = createAccount({
        username, password, role: 'state', displayName, stateCode: state.code,
        createdBy: nemaAccount.id
      });
      // Store temp_password for state accounts too
      try { run('UPDATE accounts SET temp_password = ? WHERE id = ?', password, acc.id); } catch {}
      stateAccountMap.set(state.code, acc);
    }
    const lagosAccount = stateAccountMap.get('LA');
    const fctAccount = stateAccountMap.get('FC');
    for (const [unitKey, username, password, label] of [
      ['AMB-04', 'amb.ikeja', 'RESP#2026', 'AMB-04 Ikeja ambulance crew'],
      ['POLICE-12', 'police.lekki', 'RESP#2026', 'POLICE-12 Lekki patrol'],
      ['AMB-FCT-01', 'amb.wuse', 'RESP#2026', 'AMB-FCT-01 Wuse ambulance crew'],
      ['CAR-LA-01', 'car.lekki', 'RESP#2026', 'CAR-LA-01 community responder']
    ]) {
      const unit = responders[unitKey];
      const acc2 = createAccount({
        username, password, role: 'responder', displayName: label,
        responderId: unit.id,
        createdBy: unit.stateCode === 'FC' ? fctAccount.id : lagosAccount.id
      });
      try { run('UPDATE accounts SET temp_password = ? WHERE id = ?', password, acc2.id); } catch {}
    }

    const incidents = {
      medicalIkeja: {
        code: 'INC-2904-LGS', reporterUserId: citizenId, reporterName: 'Adaeze Nwosu',
        reporterPhone: '+2348035550192', type: 'medical', priority: 1, status: 'en_route',
        lat: 6.6018, lng: 3.3515, accuracy: 9, address: 'Allen Avenue, Ikeja',
        landmark: 'Beside Ikeja Bus Terminal', description: 'Adult male collapsed at the bus stop and is not responding.',
        hazards: ['Crowd gathering', 'Heavy traffic'], peopleAffected: 1, source: 'app', liveTracking: true,
        dispatcherId, createdAt: isoAgo(9), acknowledgedAt: isoAgo(8), dispatchedAt: isoAgo(6)
      },
      policeLekki: {
        code: 'INC-2905-LGS', reporterName: 'Tunde Bakare', reporterPhone: '+2347055558821',
        type: 'police', priority: 1, status: 'en_route',
        lat: 6.4478, lng: 3.4723, accuracy: 18, address: 'Admiralty Way, Lekki Phase 1',
        landmark: 'Opposite Lekki Phase 1 Roundabout', description: 'Armed robbery in progress at a filling station. Two suspects reportedly armed.',
        hazards: ['Weapons reported', 'Suspects fleeing'], peopleAffected: 4, source: 'phone', liveTracking: false,
        dispatcherId, createdAt: isoAgo(14), acknowledgedAt: isoAgo(13), dispatchedAt: isoAgo(11)
      },
      roadBridge: {
        code: 'INC-2911-LGS', reporterName: 'LASTMA Camera 17', reporterPhone: null,
        type: 'road_safety', priority: 3, status: 'triage',
        lat: 6.4900, lng: 3.4000, accuracy: 25, address: 'Third Mainland Bridge, inward Lagos Island',
        landmark: 'Km 4 marker, near the toll gantry', description: 'Multi-vehicle collision blocking two lanes. No reported injuries yet.',
        hazards: ['Two lanes blocked', 'Debris on road'], peopleAffected: 3, source: 'partner', liveTracking: false,
        createdAt: isoAgo(3), acknowledgedAt: isoAgo(2)
      },
      fireSurulere: {
        code: 'INC-2908-LGS', reporterName: 'Ifeanyi Eze', reporterPhone: '+2348135557742',
        type: 'fire', priority: 1, status: 'on_scene',
        lat: 6.5000, lng: 3.3580, accuracy: 14, address: 'Bode Thomas Street, Surulere',
        landmark: 'Former textile warehouse, opposite Zenith Bank', description: 'Warehouse fire with heavy smoke. Staff report one person still inside.',
        hazards: ['Gas cylinders inside', 'Heavy smoke', 'Possible entrapment'], peopleAffected: 6, source: 'app', liveTracking: true,
        dispatcherId, createdAt: isoAgo(22), acknowledgedAt: isoAgo(21), dispatchedAt: isoAgo(19), arrivedAt: isoAgo(12)
      },
      medicalVI: {
        code: 'INC-2913-LGS', reporterName: 'Mariam Yusuf', reporterPhone: '+2348025554310',
        type: 'medical', priority: 2, status: 'new',
        lat: 6.4281, lng: 3.4219, accuracy: 22, address: 'Adeola Odeku Street, Victoria Island',
        landmark: 'Outside Eko Hotel north gate', description: 'Diabetic emergency, patient is conscious but disoriented.',
        hazards: [], peopleAffected: 1, source: 'app', liveTracking: true,
        createdAt: isoAgo(1)
      },
      medicalWuse: {
        code: 'INC-2921-FCT', reporterName: 'Grace Adamu', reporterPhone: '+2348065552211',
        type: 'medical', priority: 1, status: 'en_route',
        lat: 9.0665, lng: 7.4750, accuracy: 11, address: 'Aminu Kano Crescent, Wuse II, Abuja',
        landmark: 'Near Wuse Market main gate', description: 'Traders overcome by smoke from a market fire; two people are unconscious.',
        hazards: ['Smoke inhalation', 'Crowd gathering'], peopleAffected: 4, source: 'app', liveTracking: true,
        dispatcherId, createdAt: isoAgo(7), acknowledgedAt: isoAgo(6), dispatchedAt: isoAgo(4)
      },
      generalGarki: {
        code: 'INC-2922-FCT', reporterName: 'FCT Watch', reporterPhone: null,
        type: 'general', priority: 2, status: 'triage',
        lat: 9.0333, lng: 7.4833, accuracy: 30, address: 'Garki Model Market, Area 1, Abuja',
        landmark: 'Crowd surge at the east entrance', description: 'Crowd surge at a market entrance; several people are trapped against a barrier.',
        hazards: ['Crowd crush risk', 'Blocked exit'], peopleAffected: 12, source: 'partner', liveTracking: false,
        createdAt: isoAgo(4), acknowledgedAt: isoAgo(3)
      },
      communityLekki: {
        code: 'INC-2923-LGS', reporterName: 'Chinedu Okafor', reporterPhone: '+2348095551200',
        type: 'general', priority: 2, status: 'en_route',
        lat: 6.4410, lng: 3.4850, accuracy: 15, address: 'Jakande Estate, Lekki',
        landmark: 'Block 14, beside the community clinic', description: 'Elderly man collapsed in a stairwell; neighbours need help moving him safely.',
        hazards: ['Narrow stairwell'], peopleAffected: 1, source: 'app', liveTracking: true,
        dispatcherId, createdAt: isoAgo(5), acknowledgedAt: isoAgo(4), dispatchedAt: isoAgo(3)
      },
      resolvedFire: {
        code: 'INC-2899-LGS', reporterName: 'Apapa Port Control', reporterPhone: '+2348021119000',
        type: 'fire', priority: 2, status: 'resolved',
        lat: 6.4480, lng: 3.3590, accuracy: 30, address: 'Wharf Road, Apapa',
        landmark: 'Container terminal gate 4', description: 'Small container fire contained by port fire team. No casualties.',
        hazards: [], peopleAffected: 0, source: 'partner', liveTracking: false,
        createdAt: isoAgo(85), acknowledgedAt: isoAgo(84), dispatchedAt: isoAgo(82),
        arrivedAt: isoAgo(74), resolvedAt: isoAgo(40)
      }
    };

    const ids = {};
    for (const [key, incident] of Object.entries(incidents)) {
      ids[key] = insertIncident(incident);
      seededIncidentIds.push({
        id: ids[key], status: incident.status, createdAt: incident.createdAt
      });
    }

    // Seed assignments. Each route is a realistic synthetic road path; on a
    // live dispatch OSRM is attempted first.
    const amb04 = responders['AMB-04'];
    insertAssignment({
      incidentId: ids.medicalIkeja, responder: amb04, agencyId: medicalId, status: 'en_route',
      progress: 0.42, assignedAt: isoAgo(6), acceptedAt: isoAgo(6)
    });
    const police12 = responders['POLICE-12'];
    insertAssignment({
      incidentId: ids.policeLekki, responder: police12, agencyId: policeId, status: 'en_route',
      progress: 0.57, assignedAt: isoAgo(11), acceptedAt: isoAgo(10)
    });
    insertAssignment({
      incidentId: ids.medicalWuse, responder: responders['AMB-FCT-01'], agencyId: medicalId, status: 'en_route',
      progress: 0.36, assignedAt: isoAgo(4), acceptedAt: isoAgo(4)
    });
    insertAssignment({
      incidentId: ids.communityLekki, responder: responders['CAR-LA-01'], agencyId: generalId, status: 'en_route',
      progress: 0.28, assignedAt: isoAgo(3), acceptedAt: isoAgo(3)
    });
    insertAssignment({
      incidentId: ids.fireSurulere, responder: responders['FIRE-07'], agencyId: fireId, status: 'on_scene',
      progress: 1, assignedAt: isoAgo(19), acceptedAt: isoAgo(18), arrivedAt: isoAgo(12)
    });
    insertAssignment({
      incidentId: ids.fireSurulere, responder: responders['POLICE-04'], agencyId: policeId, status: 'on_scene',
      progress: 1, assignedAt: isoAgo(18), acceptedAt: isoAgo(18), arrivedAt: isoAgo(14)
    });
    insertAssignment({
      incidentId: ids.resolvedFire, responder: responders['FIRE-03'], agencyId: fireId, status: 'completed',
      progress: 1, assignedAt: isoAgo(82), acceptedAt: isoAgo(81), arrivedAt: isoAgo(74), completedAt: isoAgo(40)
    });

    // Timeline history for the active incidents.
    const event = (incidentId, type, actorType, message, minutes, payload = {}) =>
      addEvent(incidentId, { type, actorType, message, payload }, isoAgo(minutes));

    event(ids.medicalIkeja, 'created', 'citizen', 'SOS received from mobile app', 9, { source: 'app' });
    event(ids.medicalIkeja, 'acknowledged', 'dispatcher', 'Incident acknowledged by Dispatcher 042', 8);
    event(ids.medicalIkeja, 'dispatched', 'dispatcher', 'AMB-04 assigned — nearest ALS unit', 6, { unit: 'AMB-04' });
    event(ids.medicalIkeja, 'accepted', 'responder', 'AMB-04 accepted the dispatch', 6);
    event(ids.medicalIkeja, 'en_route', 'responder', 'AMB-04 is en route', 6);
    event(ids.policeLekki, 'created', 'citizen', 'Phone call transcribed to incident', 14, { source: 'phone' });
    event(ids.policeLekki, 'acknowledged', 'dispatcher', 'Priority 1 threat assessment completed', 13);
    event(ids.policeLekki, 'dispatched', 'dispatcher', 'POLICE-12 assigned — armed response', 11, { unit: 'POLICE-12' });
    event(ids.policeLekki, 'en_route', 'responder', 'POLICE-12 is en route', 10);
    event(ids.roadBridge, 'created', 'system', 'Partner camera detected a collision', 3, { source: 'partner' });
    event(ids.roadBridge, 'acknowledged', 'dispatcher', 'Awaiting LASTMA dispatch decision', 2);
    event(ids.fireSurulere, 'created', 'citizen', 'SOS received from mobile app', 22, { source: 'app' });
    event(ids.fireSurulere, 'acknowledged', 'dispatcher', 'Fire incident confirmed', 21);
    event(ids.fireSurulere, 'dispatched', 'dispatcher', 'FIRE-07 and POLICE-04 assigned', 19, { units: ['FIRE-07', 'POLICE-04'] });
    event(ids.fireSurulere, 'on_scene', 'responder', 'FIRE-07 arrived on scene', 12);
    event(ids.fireSurulere, 'on_scene', 'responder', 'POLICE-04 secured the perimeter', 14);
    event(ids.medicalVI, 'created', 'citizen', 'SOS received from mobile app', 1, { source: 'app' });
    event(ids.resolvedFire, 'resolved', 'dispatcher', 'Incident resolved — fire contained, no casualties', 40);

    // Two-way chat and pinned dispatcher notes.
    addMessage(ids.medicalIkeja, { senderType: 'citizen', senderName: 'Adaeze N.', body: 'He collapsed at the bus stop. Please hurry — he is not responding.' }, isoAgo(9));
    addMessage(ids.medicalIkeja, { senderType: 'dispatcher', senderName: 'Dispatcher 042', body: 'AMB-04 is en route, ETA 4 minutes. Keep him still and check for breathing.' }, isoAgo(7));
    addMessage(ids.medicalIkeja, { senderType: 'responder', senderName: 'AMB-04', body: 'Two minutes away. Please clear space around the patient.' }, isoAgo(2));
    addMessage(ids.policeLekki, { senderType: 'dispatcher', senderName: 'Dispatcher 042', body: 'POLICE-12 en route. Do not confront anyone — move to a safe place.' }, isoAgo(10));
    addMessage(ids.policeLekki, { senderType: 'citizen', senderName: 'Tunde B.', body: 'They are still inside the shop. One is wearing a black hoodie.' }, isoAgo(8));
    addMessage(ids.fireSurulere, { senderType: 'responder', senderName: 'FIRE-07', body: 'Fire knocked down on the ground floor. Searching for the missing worker now.' }, isoAgo(6));

    const note = (incidentId, body, minutes, pinned = 0, author = 'Dispatcher 042') =>
      run(
        `INSERT INTO incident_notes (incident_id, author_id, author_name, body, pinned, created_at)
         VALUES (?, ?, ?, ?, ?, ?)`,
        incidentId, 'DSP-042', author, body, pinned, isoAgo(minutes)
      );
    note(ids.medicalIkeja, 'Gate code 2468. Patient is behind the yellow kiosk beside the bus stop. Nearest hospital: LASUTH, 3.8 km.', 7, 1);
    note(ids.medicalIkeja, 'Caller is calm and providing updates. Live location is accurate to ±9 m.', 5, 0);
    note(ids.policeLekki, 'Suspects reportedly left in a black SUV toward Admiralty Way. Approach with caution.', 9, 1);
    note(ids.fireSurulere, 'Fire hydrant on Bode Thomas is operational. Gas cylinder stored at the rear of the building.', 15, 1);
    note(ids.roadBridge, 'Bridge camera shows two lanes blocked. Tow truck requested from LASTMA-11.', 2, 0);
    note(ids.medicalVI, 'Caller reports patient is diabetic and conscious. Keep on the line until unit arrives.', 1, 0);

    run(
      `INSERT INTO media_sessions (incident_id, kind, producer_type, producer_id, status, started_at, ended_at)
       VALUES (?, 'snapshot', 'citizen', 'CIT-8841', 'ended', ?, ?)`,
      ids.medicalIkeja, isoAgo(8), isoAgo(7)
    );

    // Breadcrumb trail for units already on scene.
    for (const callsign of ['FIRE-07', 'POLICE-04']) {
      const unit = responders[callsign];
      run(
        `INSERT INTO responder_locations (responder_id, incident_id, lat, lng, heading, speed_kph, recorded_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        unit.id, ids.fireSurulere, unit.lat, unit.lng, 0, 0, isoAgo(12)
      );
    }
  });

  // Open the AI support transcript for every seeded incident after the main
  // transaction so the AI service can write its own events and messages.
  for (const item of seededIncidentIds) {
    startAiSupport(item.id, { createdAt: item.createdAt, silent: true });
    if (item.status === 'on_scene') handoffOnScene(item.id, 'FIRE-07');
    if (item.status === 'resolved') closeAiSupport(item.id, 'Seeded incident resolved');
  }

  return true;
}

// Allow `node server/seed.js --force`
if (process.argv[1] && process.argv[1].endsWith('seed.js')) {
  const force = process.argv.includes('--force');
  const seeded = seedDatabase({ force });
  console.log(seeded ? '✅ Database seeded.' : 'ℹ️ Database already contains data. Use --force to reseed.');
}

export { CENTRE };
