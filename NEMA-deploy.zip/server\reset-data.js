/**
 * Remove demo / mock data from the live database.
 *
 * The seed in `server/seed.js` loads sample incidents, responders, users and
 * logins. This script purges that operational data while preserving records you
 * explicitly mark as real. The national agency reference rows and the stateless
 * Super Admin login (`admin`) are always kept.
 *
 * Usage:
 *   node server/reset-data.js --dry-run \
 *     --keep-incident=24 --keep-account=44 --keep-account=45 --keep-responder=22
 *
 *   node server/reset-data.js \
 *     --keep-incident=24 --keep-account=44 --keep-account=45 --keep-responder=22
 *
 * Repeated flags are allowed. Environment equivalents:
 *   KEEP_INCIDENT_IDS=24 KEEP_ACCOUNT_IDS=44,45 KEEP_RESPONDER_IDS=22
 *
 * Deletes (unless kept):
 *   - incidents and every child row (assignments, events, chat, notes, media,
 *     AI sessions, call sessions, recordings, GPS breadcrumbs)
 *   - responders / field units and their registration rows
 *   - citizen + dispatcher users
 *   - every login account except the kept ids
 *   - attached photo files and recording files on disk
 *
 * The script never creates a database row for the Super Admin; login for
 * `admin` is handled statelessly in services/auth.js.
 */
import fs from 'node:fs';
import path from 'node:path';
import { all, get, run, transaction, DB_PATH } from './db.js';

const DATA_DIR = path.dirname(DB_PATH);

function idsFromArgs(flag) {
  const values = [];
  const prefix = `--${flag}=`;
  for (const arg of process.argv) {
    if (arg.startsWith(prefix)) values.push(...arg.slice(prefix.length).split(','));
  }
  return values.map((value) => Number(value)).filter((value) => Number.isInteger(value) && value > 0);
}

function idsFromEnv(name) {
  return String(process.env[name] || '')
    .split(',')
    .map((value) => Number(value.trim()))
    .filter((value) => Number.isInteger(value) && value > 0);
}

const KEEP_INCIDENTS = [...new Set([
  ...idsFromArgs('keep-incident'),
  ...idsFromEnv('KEEP_INCIDENT_IDS')
])];
const KEEP_ACCOUNTS = [...new Set([
  ...idsFromArgs('keep-account'),
  ...idsFromEnv('KEEP_ACCOUNT_IDS')
])];
const KEEP_RESPONDERS = [...new Set([
  ...idsFromArgs('keep-responder'),
  ...idsFromEnv('KEEP_RESPONDER_IDS')
])];

function placeholders(ids) {
  return ids.map(() => '?').join(', ');
}

function listCount(table, where = '', params = []) {
  return get(`SELECT COUNT(*) AS count FROM ${table}${where ? ` WHERE ${where}` : ''}`, ...params).count;
}

function keptRows(table, ids) {
  if (!ids.length) return [];
  return all(`SELECT * FROM ${table} WHERE id IN (${placeholders(ids)})`, ...ids);
}

function deleteWhere(table, where, params = []) {
  if (!where) return run(`DELETE FROM ${table}`).changes;
  return run(`DELETE FROM ${table} WHERE ${where}`, ...params).changes;
}

function report({ dryRun }) {
  const keptIncidents = keptRows('incidents', KEEP_INCIDENTS);
  const keptAccounts = keptRows('accounts', KEEP_ACCOUNTS).map(({ password_hash, temp_password, ...rest }) => rest);
  const keptResponders = keptRows('responders', KEEP_RESPONDERS);

  const incidentFilter = KEEP_INCIDENTS.length
    ? `id NOT IN (${placeholders(KEEP_INCIDENTS)})`
    : '1=1';
  const accountFilter = KEEP_ACCOUNTS.length
    ? `id NOT IN (${placeholders(KEEP_ACCOUNTS)}) AND username <> 'admin' AND role <> 'superadmin'`
    : `username <> 'admin' AND role <> 'superadmin'`;
  const responderFilter = KEEP_RESPONDERS.length
    ? `id NOT IN (${placeholders(KEEP_RESPONDERS)})`
    : '1=1';
  const registrationFilter = KEEP_RESPONDERS.length
    ? `responder_id IS NULL OR responder_id NOT IN (${placeholders(KEEP_RESPONDERS)})`
    : '1=1';

  const removedIncidentIds = all(`SELECT id FROM incidents WHERE ${incidentFilter}`, ...KEEP_INCIDENTS).map((row) => row.id);
  const removedPhotoPaths = all(
    `SELECT photo_path FROM incidents WHERE ${incidentFilter} AND photo_path IS NOT NULL`,
    ...KEEP_INCIDENTS
  ).map((row) => row.photo_path);
  const removedRecordingPaths = removedIncidentIds.length
    ? all(
        `SELECT file_path FROM incident_recordings WHERE incident_id IN (${placeholders(removedIncidentIds)})`,
        ...removedIncidentIds
      ).map((row) => row.file_path)
    : [];

  const counts = {
    incidents: listCount('incidents', incidentFilter, KEEP_INCIDENTS),
    incident_assignments: removedIncidentIds.length
      ? listCount('incident_assignments', `incident_id IN (${placeholders(removedIncidentIds)})`, removedIncidentIds)
      : 0,
    incident_events: removedIncidentIds.length
      ? listCount('incident_events', `incident_id IN (${placeholders(removedIncidentIds)})`, removedIncidentIds)
      : 0,
    incident_messages: removedIncidentIds.length
      ? listCount('incident_messages', `incident_id IN (${placeholders(removedIncidentIds)})`, removedIncidentIds)
      : 0,
    incident_notes: removedIncidentIds.length
      ? listCount('incident_notes', `incident_id IN (${placeholders(removedIncidentIds)})`, removedIncidentIds)
      : 0,
    media_sessions: removedIncidentIds.length
      ? listCount('media_sessions', `incident_id IN (${placeholders(removedIncidentIds)})`, removedIncidentIds)
      : 0,
    ai_sessions: removedIncidentIds.length
      ? listCount('ai_sessions', `incident_id IN (${placeholders(removedIncidentIds)})`, removedIncidentIds)
      : 0,
    call_sessions: removedIncidentIds.length
      ? listCount('call_sessions', `incident_id IN (${placeholders(removedIncidentIds)})`, removedIncidentIds)
      : 0,
    incident_recordings: removedIncidentIds.length
      ? listCount('incident_recordings', `incident_id IN (${placeholders(removedIncidentIds)})`, removedIncidentIds)
      : 0,
    responders: listCount('responders', responderFilter, KEEP_RESPONDERS),
    registrations: listCount('registrations', registrationFilter, KEEP_RESPONDERS),
    users: listCount('users'),
    accounts: listCount('accounts', accountFilter, KEEP_ACCOUNTS),
    auth_sessions: listCount(
      'auth_sessions',
      KEEP_ACCOUNTS.length
        ? `account_id NOT IN (${placeholders(KEEP_ACCOUNTS)})`
        : '1=1',
      KEEP_ACCOUNTS
    )
  };

  const files = {
    photos: removedPhotoPaths,
    recordings: removedRecordingPaths
  };

  if (dryRun) {
    return {
      dryRun: true,
      keep: { incidents: keptIncidents, accounts: keptAccounts, responders: keptResponders },
      wouldDelete: counts,
      files
    };
  }

  const deleted = transaction(() => {
    // Remove GPS breadcrumbs first: deleting incidents nulls incident_id, so
    // filter by both responder and incident before the cascade runs.
    const locationClauses = [];
    const locationParams = [];
    if (KEEP_RESPONDERS.length) {
      locationClauses.push(`responder_id NOT IN (${placeholders(KEEP_RESPONDERS)})`);
      locationParams.push(...KEEP_RESPONDERS);
    }
    if (removedIncidentIds.length) {
      locationClauses.push(`incident_id IN (${placeholders(removedIncidentIds)})`);
      locationParams.push(...removedIncidentIds);
    }
    const locations = locationClauses.length
      ? deleteWhere('responder_locations', locationClauses.join(' OR '), locationParams)
      : 0;

    const registrations = deleteWhere('registrations', registrationFilter, KEEP_RESPONDERS);
    const users = deleteWhere('users');
    const responders = deleteWhere('responders', responderFilter, KEEP_RESPONDERS);
    const incidents = deleteWhere('incidents', incidentFilter, KEEP_INCIDENTS);
    const accounts = deleteWhere('accounts', accountFilter, KEEP_ACCOUNTS);

    // Kept responders whose only assignments were purged should return to the
    // available pool instead of staying stuck in en_route with no job.
    let respondersReset = 0;
    if (KEEP_RESPONDERS.length) {
      respondersReset = run(
        `UPDATE responders
            SET status = 'available', speed_kph = 0, updated_at = ?
          WHERE id IN (${placeholders(KEEP_RESPONDERS)})
            AND NOT EXISTS (
              SELECT 1 FROM incident_assignments a
               WHERE a.responder_id = responders.id
                 AND a.status NOT IN ('completed', 'declined', 'cancelled')
            )`,
        new Date().toISOString(),
        ...KEEP_RESPONDERS
      ).changes;
    }

    return {
      responder_locations: locations,
      registrations,
      users,
      responders,
      incidents,
      accounts,
      respondersReset
    };
  });

  // Delete attached files only after the database commit succeeds.
  const removedFiles = { photos: [], recordings: [] };
  const dataRoot = path.resolve(DATA_DIR);
  const insideDataDir = (filePath) => {
    const resolved = path.resolve(dataRoot, filePath);
    return resolved === dataRoot || resolved.startsWith(`${dataRoot}${path.sep}`);
  };
  for (const photoPath of removedPhotoPaths) {
    const resolved = path.resolve(dataRoot, photoPath);
    if (!insideDataDir(resolved)) continue;
    try { fs.rmSync(resolved, { force: true }); removedFiles.photos.push(photoPath); } catch { /* ignore */ }
  }
  for (const recordingPath of removedRecordingPaths) {
    const resolved = path.resolve(dataRoot, recordingPath);
    if (!insideDataDir(resolved)) continue;
    try { fs.rmSync(resolved, { force: true }); removedFiles.recordings.push(recordingPath); } catch { /* ignore */ }
  }

  // Prune recording folders that belong to deleted incidents, including orphan
  // files that no longer have a database row.
  const recordingsDir = path.join(dataRoot, 'recordings');
  if (fs.existsSync(recordingsDir)) {
    for (const entry of fs.readdirSync(recordingsDir, { withFileTypes: true })) {
      if (!entry.isDirectory()) continue;
      if (KEEP_INCIDENTS.includes(Number(entry.name))) continue;
      fs.rmSync(path.join(recordingsDir, entry.name), { recursive: true, force: true });
    }
  }

  // Prune photos for deleted incidents, including orphan files.
  const photosDir = path.join(dataRoot, 'incident-photos');
  if (fs.existsSync(photosDir)) {
    const keptPhotos = new Set(
      KEEP_INCIDENTS.length
        ? all(
            `SELECT photo_path FROM incidents WHERE id IN (${placeholders(KEEP_INCIDENTS)}) AND photo_path IS NOT NULL`,
            ...KEEP_INCIDENTS
          ).map((row) => path.resolve(dataRoot, row.photo_path))
        : []
    );
    for (const entry of fs.readdirSync(photosDir, { withFileTypes: true })) {
      if (!entry.isFile()) continue;
      const full = path.resolve(photosDir, entry.name);
      if (!keptPhotos.has(full)) {
        try { fs.rmSync(full, { force: true }); } catch { /* ignore */ }
      }
    }
  }

  return {
    dryRun: false,
    keep: { incidents: keptIncidents, accounts: keptAccounts, responders: keptResponders },
    deleted,
    removedFiles,
    remaining: {
      incidents: listCount('incidents'),
      accounts: listCount('accounts'),
      responders: listCount('responders'),
      registrations: listCount('registrations'),
      users: listCount('users'),
      agencies: listCount('agencies'),
      call_sessions: listCount('call_sessions'),
      incident_recordings: listCount('incident_recordings')
    }
  };
}

export function resetDemoData({ dryRun = false, keepIncidents = [], keepAccounts = [], keepResponders = [] } = {}) {
  // CLI callers use the parsed flags; API callers can pass explicit ids.
  if (keepIncidents.length || keepAccounts.length || keepResponders.length) {
    return reportWith({
      dryRun,
      keepIncidents: [...new Set([...KEEP_INCIDENTS, ...keepIncidents])],
      keepAccounts: [...new Set([...KEEP_ACCOUNTS, ...keepAccounts])],
      keepResponders: [...new Set([...KEEP_RESPONDERS, ...keepResponders])]
    });
  }
  return report({ dryRun });
}

function reportWith({ dryRun, keepIncidents, keepAccounts, keepResponders }) {
  KEEP_INCIDENTS.length = 0;
  KEEP_ACCOUNTS.length = 0;
  KEEP_RESPONDERS.length = 0;
  KEEP_INCIDENTS.push(...keepIncidents);
  KEEP_ACCOUNTS.push(...keepAccounts);
  KEEP_RESPONDERS.push(...keepResponders);
  return report({ dryRun });
}

const isCli = process.argv[1] && process.argv[1].endsWith('reset-data.js');
if (isCli) {
  const dryRun = process.argv.includes('--dry-run');
  const result = resetDemoData({ dryRun });
  console.log(JSON.stringify(result, null, 2));
  console.log(dryRun
    ? '\nDry run only — nothing was changed. Remove --dry-run to apply.'
    : '\nMock data removed. Kept records are listed under "keep".');
}
