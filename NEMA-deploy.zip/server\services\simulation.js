/**
 * Fleet movement simulator.
 * ---------------------------------------------------------------------------
 * In production the vehicle positions arrive from the responder tablet's GPS
 * (or the AVL/OBD feed from the vehicle). For this self-contained prototype we
 * smoothly animate en-route units along their assigned route so the map, ETA
 * and on-scene transition can be demonstrated without real vehicles.
 *
 * Disable with SIMULATE_FLEET=0.
 */
import { run, all, nowIso } from '../db.js';
import { pointAlongRoute, routeLengthKm, haversineKm, etaMinutes, toRad, toDeg } from '../geo.js';
import { getFleet, assignmentRoute, updateAssignmentStatus, getStats } from './incidents.js';
import * as rt from './realtime.js';

const TICK_MS = 2500;
const STEP_KM_PER_TICK = 0.055; // ~79 km/h simulated response speed
let timer = null;
let ticks = 0;

function moveEnRouteUnits() {
  const rows = all(
    `SELECT ia.*, r.call_sign, r.id AS unit_id, i.id AS incident_id
     FROM incident_assignments ia
     JOIN responders r ON r.id = ia.responder_id
     JOIN incidents i ON i.id = ia.incident_id
     WHERE ia.status IN ('accepted','en_route')
       AND i.status NOT IN ('resolved','cancelled')
       AND r.is_simulated = 1`
  );

  for (const row of rows) {
    try {
      const route = assignmentRoute(row);
      if (!route.coords.length || route.lengthKm <= 0) continue;
      const nextProgress = Math.min(1, Number(row.progress || 0) + STEP_KM_PER_TICK / route.lengthKm);
      const remainingKm = Math.max(0, route.lengthKm * (1 - nextProgress));

      // Geofence arrival: mark on-scene when within ~90 m of the incident.
      if (nextProgress >= 0.985 || remainingKm <= 0.09) {
        updateAssignmentStatus(row.id, 'on_scene', row.call_sign);
        continue;
      }

      const point = pointAlongRoute(route.coords, nextProgress);
      if (!point) continue;
      const at = nowIso();
      run(
        `UPDATE incident_assignments SET progress = ?, eta_minutes = ? WHERE id = ?`,
        nextProgress, etaMinutes(remainingKm), row.id
      );
      run(
        `UPDATE responders SET lat = ?, lng = ?, heading = ?, speed_kph = ?, status = 'en_route', updated_at = ? WHERE id = ?`,
        point.lat, point.lng, point.heading, 42, at, row.unit_id
      );
      run(
        `INSERT INTO responder_locations (responder_id, incident_id, lat, lng, heading, speed_kph, recorded_at)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        row.unit_id, row.incident_id, point.lat, point.lng, point.heading, 42, at
      );
    } catch (error) {
      console.warn('[simulation] movement failed:', error.message);
    }
  }
}

/**
 * Idle patrol drift. Keeps the command map feeling like a live AVL feed rather
 * than a static roster. Only units on duty and not assigned move.
 */
function driftAvailableUnits() {
  const units = all(
    `SELECT * FROM responders WHERE status = 'available' AND is_simulated = 1`
  );
  for (const unit of units) {
    if (Math.random() > 0.36) continue;
    const heading = (Number(unit.heading || 0) + (Math.random() * 42 - 21) + 360) % 360;
    const distanceKm = 0.035 + Math.random() * 0.06;
    const R = 6371.0088;
    const brng = (heading * Math.PI) / 180;
    const lat1 = (unit.lat * Math.PI) / 180;
    const lng1 = (unit.lng * Math.PI) / 180;
    const lat2 = Math.asin(
      Math.sin(lat1) * Math.cos(distanceKm / R) +
        Math.cos(lat1) * Math.sin(distanceKm / R) * Math.cos(brng)
    );
    const lng2 =
      lng1 +
      Math.atan2(
        Math.sin(brng) * Math.sin(distanceKm / R) * Math.cos(lat1),
        Math.cos(distanceKm / R) - Math.sin(lat1) * Math.sin(lat2)
      );
    run(
      `UPDATE responders SET lat = ?, lng = ?, heading = ?, speed_kph = 0, updated_at = ? WHERE id = ?`,
      toDeg(lat2), toDeg(lng2), heading, nowIso(), unit.id
    );
  }
}

function tick() {
  ticks += 1;
  try {
    moveEnRouteUnits();
    if (ticks % 2 === 0) driftAvailableUnits();
    rt.emitFleet(getFleet());
    if (ticks % 8 === 0) rt.emitStats(getStats());
  } catch (error) {
    console.error('[simulation] tick failed:', error);
  }
}

export function startSimulation() {
  if (process.env.SIMULATE_FLEET === '0' || timer) return;
  timer = setInterval(tick, TICK_MS);
  console.log(`🛰️  Fleet simulator started (${TICK_MS} ms tick)`);
}

export function stopSimulation() {
  if (timer) clearInterval(timer);
  timer = null;
}
